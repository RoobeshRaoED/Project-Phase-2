package com.hlms.UserServices.Enum;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum roleEnum {

    CUSTOMER,
    LEGAL,
    BANK_OFFICER,
    BIDDER,
    ADMIN;

    @JsonCreator
    public static roleEnum fromValue(String value) {

        return roleEnum.valueOf(
                value.toUpperCase());
    }
}