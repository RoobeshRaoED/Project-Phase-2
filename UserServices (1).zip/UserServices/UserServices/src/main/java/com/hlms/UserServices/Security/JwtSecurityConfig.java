package com.hlms.UserServices.Security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
//@EnableMethodSecurity
public class JwtSecurityConfig {

    @Autowired
    private JwtAuthenticationFilter jwtAuthenticationFilter;

    @Bean
    public PasswordEncoder passwordEncoder() {

        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(
            HttpSecurity http)
            throws Exception {
//    	http
//
//        .csrf(csrf -> csrf.disable())
//
//        .formLogin(form -> form.disable())
//
//        .httpBasic(httpBasic -> httpBasic.disable())
//
//        .headers(headers ->
//                headers.frameOptions(
//                        frame -> frame.disable()))
//
//        .authorizeHttpRequests(auth -> auth
//
//                .requestMatchers(
//                        "/swagger-ui/**",
//                        "/swagger-ui.html",
//                        "/v3/api-docs/**")
//                .permitAll()
//
//                .requestMatchers(
//                        "/h2-console/**")
//                .permitAll()
//
//                .requestMatchers(
//                        "/api/users/register",
//                        "/api/users/login",
//                        "/api/users/forgot-password",
//                        "/api/users/reset-password",
//                        "/api/otp/**")
//                .permitAll()
//
//                .anyRequest()
//                .authenticated())
//
//        .sessionManagement(session ->
//                session.sessionCreationPolicy(
//                        SessionCreationPolicy.STATELESS))
//
//        .addFilterBefore(
//                jwtAuthenticationFilter,
//                UsernamePasswordAuthenticationFilter.class);

        http

            .csrf(csrf -> csrf.disable())

            .formLogin(form -> form.disable())

            .httpBasic(httpBasic -> httpBasic.disable())

            .headers(headers ->
                    headers.frameOptions(
                            frame -> frame.disable()))

            .authorizeHttpRequests(auth -> auth

                    .requestMatchers(
                            "/swagger-ui/**",
                            "/swagger-ui.html",
                            "/v3/api-docs/**")
                    .permitAll()

                    .requestMatchers(
                            "/h2-console/**")
                    .permitAll()

                    .requestMatchers(
                            "/api/users/register",
                            "/api/users/login",
                            "/api/users/forgot-password",
                            "/api/users/reset-password",
                            "/api/otp/**")
                    .permitAll()

                    .anyRequest()
                    .authenticated())

            .sessionManagement(session ->
                    session.sessionCreationPolicy(
                            SessionCreationPolicy.STATELESS))

            .addFilterBefore(
                    jwtAuthenticationFilter,
                    UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}