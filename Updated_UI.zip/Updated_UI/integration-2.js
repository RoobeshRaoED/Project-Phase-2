
/* ======================================================================
   HLMS — CUSTOMER PORTAL (Pure HTML/CSS/JS, no backend)
   All persistence via localStorage. Built from Product/Sprint backlog.
   ====================================================================== */

/* ---------------------------- DB LAYER ---------------------------- */
const DB_KEY = 'hlms_db_v1';
function loadDB(){
  let raw = localStorage.getItem(DB_KEY);
  if(!raw){
    const fresh = { users:{}, session:null, applications:[], drafts:[], notifications:[], serviceRequests:[], nextTrack:1001, nextReq:5001 };
    localStorage.setItem(DB_KEY, JSON.stringify(fresh));
    return fresh;
  }
  return JSON.parse(raw);
}
function saveDB(){ localStorage.setItem(DB_KEY, JSON.stringify(DB)); }
let DB = loadDB();

/* ---------------------------- ADMIN / STAFF ROLES ---------------------------- */
const ROLE_LABELS = { admin:'Admin', employee:'Employee', legal:'Legal Team', bankoffice:'Bank Office', customer:'Customer', bidder:'Bidder' };
const DEFAULT_PERMISSIONS = {
  admin:      { view:true, add:true,  edit:true,  delete:true  },
  employee:   { view:true, add:true,  edit:true,  delete:false },
  legal:      { view:true, add:false, edit:true,  delete:false },
  loanofficer:{ view:true, add:true,  edit:true,  delete:false },
  bankoffice: { view:true, add:true,  edit:true,  delete:false },
  customer:   { view:true, add:false, edit:false, delete:false },
  bidder:     { view:true, add:true,  edit:false, delete:false }
};
function isAdmin(){ const u = currentUser(); return !!u && u.role==='admin'; }
/* Ensure at least one admin account exists, and older records have an `active` flag. */
(function ensureAdminSeed(){
  let changed = false;
  Object.values(DB.users).forEach(u=>{ if(u.active===undefined){ u.active = true; changed = true; } });
  if(!Object.values(DB.users).some(u=>u.role==='admin')){
    DB.users['admin@hlms.example.com'] = {
      email:'admin@hlms.example.com', name:'System Admin', mobile:'9999999999',
      idType:'PAN', idNumber:'ADMIN0000A', password:'Admin@123', role:'admin', active:true,
      createdAt:new Date().toISOString()
    };
    changed = true;
  }
  if(!Object.values(DB.users).some(u=>u.role==='legal')){
    DB.users['legal@hlms.example.com'] = {
      email:'legal@hlms.example.com', name:'Neha Kulkarni', mobile:'9888800000',
      idType:'PAN', idNumber:'LEGAL0000A', password:'Legal@123', role:'legal', active:true,
      createdAt:new Date().toISOString()
    };
    changed = true;
  }
  if(!Object.values(DB.users).some(u=>u.role==='bankoffice')){
    DB.users['bankoffice@hlms.example.com'] = {
      email:'bankoffice@hlms.example.com', name:'Rohit Iyer', mobile:'9888811111',
      idType:'PAN', idNumber:'BANKO0000A', password:'Bank@123', role:'bankoffice', active:true,
      createdAt:new Date().toISOString()
    };
    changed = true;
  }

  if(!DB.legalCases){ DB.legalCases = []; changed = true; }
  if(!DB.legalNotices){ DB.legalNotices = []; changed = true; }
  if(!DB.nextCase){ DB.nextCase = 1; changed = true; }
  if(!DB.nextNotice){ DB.nextNotice = 1; changed = true; }
  if(!DB.bids){ DB.bids = []; changed = true; }
  if(!DB.nextBid){ DB.nextBid = 1; changed = true; }
  if(!Object.values(DB.users).some(u=>u.role==='bidder')){
    DB.users['bidder@hlms.example.com'] = {
      email:'bidder@hlms.example.com', name:'Arjun Mehta', mobile:'9888822222',
      idType:'PAN', idNumber:'BIDDR0000A', password:'Bidder@123', role:'bidder', active:true,
      notifPrefs:{sms:true,email:true,inapp:true},
      createdAt:new Date().toISOString()
    };
    changed = true;
  }
  if(changed) saveDB();
})();
function isLegal(){ const u = currentUser(); return !!u && u.role==='legal'; }
function isBankOffice(){ const u = currentUser(); return !!u && u.role==='bankoffice'; }
function isBidder(){ const u = currentUser(); return !!u && u.role==='bidder'; }
function goMyProfile(){ go(isBankOffice() ? 'bosettings' : isBidder() ? 'biddersettings' : 'profile'); }

/* ---------------------------- LEGAL & VALUATION HELPERS ---------------------------- */
const LEGAL_STAGE_INDEX = 3; // 'Mortgage / Property Verification' in WORKFLOW_STAGES
const LEGAL_CHECKLIST = [
  {key:'titleDeed', label:'Title Deed / Ownership Document'},
  {key:'encumbrance', label:'Encumbrance Certificate (13 yrs)'},
  {key:'saleDeed', label:'Sale Deed / Agreement to Sell'},
  {key:'noc', label:'NOC from Society / Builder / Competent Authority'},
  {key:'valuation', label:'Property Valuation Report'},
  {key:'taxReceipt', label:'Latest Property Tax Receipt'}
];
const DOC_LABELS = {
  idProof:'Identity Proof (Aadhaar / PAN)', incomeProof:'Income Proof (Salary Slip / ITR)',
  addressProof:'Address Proof', bankStatement:'Bank Statement (Last 6 months)', propertyDocs:'Property Documents'
};
const PD_DOC_TYPES = [
  'Updated KYC / Identity Document', 'Property Insurance Renewal', 'NOC / Loan Closure Supporting Document',
  'Address Change Proof', 'Property Tax Receipt', 'Other Supporting Document'
];
function ensurePostDisbDocs(app){ if(!app.postDisbDocs) app.postDisbDocs=[]; return app.postDisbDocs; }
/* Bank Office verification status for the initial KYC / loan documents uploaded during application (app.documents) */
function ensureDocStatus(app){
  if(!app.docStatus) app.docStatus = {};
  Object.entries(app.documents||{}).forEach(([k,v])=>{
    if(v && !app.docStatus[k]){ app.docStatus[k] = { status:'Pending', remarks:'', verifiedBy:null, verifiedAt:null }; }
  });
  return app.docStatus;
}
function docBadgeClass(status){ return status==='Verified'?'badge-green':status==='Rejected'?'badge-red':'badge-orange'; }
function applicationsWithDocsForBO(){
  return (DB.applications||[]).filter(a=> a.documents && Object.values(a.documents).some(v=>v));
}
function pendingAppDocsCount(){
  let count = 0;
  applicationsWithDocsForBO().forEach(a=>{
    const ds = ensureDocStatus(a);
    Object.entries(a.documents||{}).forEach(([k,v])=>{ if(v && ds[k] && ds[k].status==='Pending') count++; });
  });
  return count;
}
function allPostDisbDocs(){
  let rows=[];
  (DB.applications||[]).forEach(a=>{ ensurePostDisbDocs(a).forEach(d=>rows.push(Object.assign({app:a}, d))); });
  return rows.sort((a,b)=> new Date(b.uploadedAt)-new Date(a.uploadedAt));
}
function pendingPostDisbDocsCount(){ return allPostDisbDocs().filter(d=>d.status==='Pending').length; }
function pdDocBadgeClass(status){ return status==='Verified'?'badge-green':status==='Rejected'?'badge-red':'badge-orange'; }
function ensureLegal(app){
  if(!app.legal){
    app.legal = { decision:null, decisionDate:null, officer:null, remarks:'' };
    LEGAL_CHECKLIST.forEach(c=>{ app.legal[c.key]='Pending'; });
  }
  if(!app.auction){
    app.auction = { stage:'None', noticeDate:null, noticeDueDate:null, demandAmount:0, possessionDate:null, auctionDate:null, reservePrice:0, notes:[] };
  }
  return app;
}
function daysBetween(a,b){ return Math.ceil((new Date(a)-new Date(b))/86400000); }
function decisionBadgeClass(d){
  if(d==='Approved') return 'badge-green';
  if(d==='Rejected') return 'badge-red';
  if(d==='Query Raised') return 'badge-orange';
  return 'badge-gray';
}
function getRejectionInfo(app){
  if(app.status!=='Rejected') return null;
  if(app.legal && app.legal.decision==='Rejected'){
    return { by:'Legal & Valuation Team', officer:app.legal.officer, date:app.legal.decisionDate, remarks:app.legal.remarks||'No additional remarks provided.' };
  }
  if(app.boDecision && app.boDecision.decision==='Rejected'){
    return { by:'Bank Office', officer:app.boDecision.officer, date:app.boDecision.date, remarks:app.boDecision.remarks||'No additional remarks provided.' };
  }
  return { by:'HLMS Bank', officer:'—', date:app.createdAt, remarks:'This application was not approved. Please contact support for details.' };
}
function auctionBadgeClass(stage){
  if(stage==='None') return 'badge-gray';
  if(stage==='Notice Issued') return 'badge-orange';
  if(stage==='Possession') return 'badge-red';
  if(stage==='Auction Scheduled') return 'badge-red';
  if(stage==='Resolved') return 'badge-green';
  return 'badge-gray';
}
function overdueLegalApplications(){
  const today = new Date();
  return DB.applications.filter(a=>a.repayment && a.repayment.schedule).map(a=>{
    ensureLegal(a);
    a.repayment.schedule.forEach(s=>{ if(s.status!=='Paid' && new Date(s.dueDate)<today) s.status='Overdue'; });
    const overdueCount = a.repayment.schedule.filter(s=>s.status==='Overdue').length;
    return Object.assign({overdueCount}, a);
  }).filter(a=>a.overdueCount>0);
}
function pendingLegalCount(){
  return DB.applications.filter(a=>a.stageIndex===LEGAL_STAGE_INDEX && a.status==='Under Review').length;
}
/* An application's mortgage/property case can only be opened for verification by the Loan Officer / Legal & Valuation Team
   once Bank Office has verified every uploaded document for that application. */
function bankOfficeVerified(app){
  const ds = ensureDocStatus(app);
  const uploaded = Object.entries(app.documents||{}).filter(([k,v])=>v);
  if(!uploaded.length) return false;
  return uploaded.every(([k])=> ds[k] && ds[k].status==='Verified');
}

/* ---------------------------- HELPERS ---------------------------- */
function $(sel,root){ return (root||document).querySelector(sel); }
function $all(sel,root){ return Array.from((root||document).querySelectorAll(sel)); }
function fmtINR(n){ n = Math.round(n||0); return '₹' + n.toLocaleString('en-IN'); }
function fmtDate(d){ const dt = new Date(d); return dt.toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}); }
function addDays(date,days){ const d = new Date(date); d.setDate(d.getDate()+days); return d.toISOString(); }
function uid(prefix){ return prefix+'_'+Math.random().toString(36).slice(2,9); }
function currentUser(){ return DB.session ? DB.users[DB.session] : null; }
function toast(title,msg,type){
  type = type||'info';
  const el = document.createElement('div');
  el.className = 'toast '+type;
  el.innerHTML = '<strong>'+title+'</strong>'+(msg||'');
  $('#toastWrap').appendChild(el);
  setTimeout(()=>{ el.style.opacity='0'; el.style.transition='.3s'; setTimeout(()=>el.remove(),300); }, 4200);
}
function escapeHtml(s){ return (s||'').toString().replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

/* Validation helpers */
const REGEX = {
  email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  mobile: /^[6-9]\d{9}$/,
  pan: /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/,
  aadhaar: /^\d{12}$/,
  password: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_\-+=]).{8,}$/
};
function fieldError(inputEl, msgEl, msg){
  inputEl.style.borderColor = 'var(--red)';
  if(msgEl){ msgEl.textContent = msg; msgEl.classList.remove('hidden'); }
  return false;
}
function fieldOk(inputEl, msgEl){
  inputEl.style.borderColor = 'var(--border)';
  if(msgEl){ msgEl.textContent=''; msgEl.classList.add('hidden'); }
  return true;
}

/* EMI calculation: standard reducing balance formula */
function calcEMI(principal, annualRate, years){
  const r = annualRate/12/100;
  const n = years*12;
  if(r===0) return principal/n;
  const emi = principal*r*Math.pow(1+r,n)/(Math.pow(1+r,n)-1);
  return emi;
}
function buildSchedule(principal, annualRate, years, startDate){
  const r = annualRate/12/100;
  const n = years*12;
  const emi = calcEMI(principal, annualRate, years);
  let balance = principal;
  const rows=[];
  for(let i=1;i<=n;i++){
    const interest = balance*r;
    let principalPaid = emi-interest;
    if(i===n){ principalPaid = balance; }
    balance = Math.max(0, balance-principalPaid);
    rows.push({
      no:i,
      dueDate: addDays(startDate, 30*i),
      emi: (i===n? principalPaid+interest : emi),
      principal: principalPaid,
      interest: interest,
      balance: balance,
      status:'Due'
    });
  }
  return rows;
}

/* Notifications */
function pushNotification(userEmail, title, body, channels){
  channels = channels || ['inapp'];
  DB.notifications.unshift({ id:uid('ntf'), userEmail, title, body, channels, read:false, ts:new Date().toISOString() });
  saveDB();
}
function notifyRoleUsers(role, title, body){
  Object.values(DB.users).filter(u=>u.role===role && u.active!==false).forEach(u=>{
    pushNotification(u.email, title, body, notifChannels(u.email));
  });
}
function unreadCount(){
  const u = currentUser(); if(!u) return 0;
  return DB.notifications.filter(n=>n.userEmail===u.email && !n.read).length;
}
function refreshNotifBadge(){
  const c = unreadCount();
  const el = $('#notifCount');
  if(el){ el.textContent = c; el.style.display = c>0 ? 'inline-block':'none'; }
}

/* ---------------------------- SIDEBAR (role-based) ---------------------------- */
function sidebarItemsFor(role){
  if(role==='admin'){
    return [
      {view:'admindash', ic:'▦', label:'Dashboard'},
      {view:'biddermgmt', ic:'🔨', label:'Bidder Management'},
      {view:'employeemgmt', ic:'🧑‍💼', label:'Employee Management'},
      {view:'profile', ic:'◍', label:'Profile'}
    ];
  }
  if(role==='legal'){
    const pending = pendingLegalCount();
    const pendingDocs = pendingPostDisbDocsCount();
    return [
      {view:'legaldash', ic:'▦', label:'Dashboard'},
      {view:'legalqueue', ic:'☑', label:'Legal Review Queue', badge: pending>0 ? String(pending) : null},
      {view:'legaldocuments', ic:'▯', label:'Document Center', badge: pendingDocs>0 ? String(pendingDocs) : null},
      {view:'legalauction', ic:'☆', label:'Auction & SARFAESI'},
      {view:'legalnotices', ic:'✉', label:'Legal Notices Log'},
      {view:'profile', ic:'◍', label:'Profile Settings'}
    ];
  }
  if(role==='bankoffice'){
    const pendingDocs = pendingAppDocsCount();
    return [
      {view:'bodash', ic:'▦', label:'Dashboard'},
      {view:'boapplications', ic:'▤', label:'Loan Applications'},
      {view:'boportfolio', ic:'👥', label:'Customer Portfolio'},
      {view:'bodisbursement', ic:'💳', label:'Disbursement Queue'},
      {view:'bonpa', ic:'⚠', label:'Overdue & NPA Tracking'},
      {view:'bodocs', ic:'▯', label:'Document Verification', badge: pendingDocs>0 ? String(pendingDocs) : null},
      {view:'boauction', ic:'☆', label:'Auction Management'},
      {view:'boreports', ic:'📊', label:'Reports & Analytics'},
      {view:'bosettings', ic:'⚙', label:'Settings'}
    ];
  }
  if(role==='bidder'){
    return [
      {view:'bidderdash', ic:'▦', label:'Dashboard'},
      {view:'bidderlistings', ic:'☆', label:'Auction Listings'},
      {view:'bidderbids', ic:'💰', label:'My Bids'},
      {view:'biddersettings', ic:'⚙', label:'Settings'}
    ];
  }
  return [
    {view:'dashboard', ic:'▦', label:'Dashboard'},
    {view:'eligibility', ic:'☑', label:'Check Eligibility'},
    {view:'guidance', ic:'◷', label:'Loan Guidance'},
    {view:'apply', ic:'▤', label:'Apply for Loan'},
    {view:'tracking', ic:'↗', label:'Loan Status Tracking'},
    {view:'repayment', ic:'Ⓡ', label:'Repayment'},
    {view:'postdisb', ic:'⌂', label:'Post Disbursement'},
    {view:'auction', ic:'☆', label:'Auction Management'},
    {view:'documents', ic:'▯', label:'Documents', badge:'NEW'},
    {view:'profile', ic:'◍', label:'Profile Settings'},
    {view:'support', ic:'?', label:'Support / Help'}
  ];
}
function renderSidebar(){
  const u = currentUser(); if(!u) return;
  const items = sidebarItemsFor(u.role);
  const itemsHtml = items.map(it=>`<button class="nav-item" data-view="${it.view}" onclick="go('${it.view}')"><span class="ic">${it.ic}</span>${it.label}${it.badge?`<span class="nav-badge">${it.badge}</span>`:''}</button>`).join('');
  $('#sidebar').innerHTML = itemsHtml + `<button class="nav-item" onclick="logout()" style="margin-top:14px;border-top:1px solid var(--border);padding-top:16px;color:var(--red);"><span class="ic" style="color:var(--red);">⏻</span>Log Out</button>`;
}

/* ---------------------------- ROUTER ---------------------------- */
const VIEWS_CUSTOMER = ['dashboard','guidance','eligibility','apply','tracking','repayment','postdisb','auction','documents','profile','support'];
const VIEWS_ADMIN = ['admindash','adminmgmt','employeemgmt','legalmgmt','bankofficemgmt','biddermgmt','profile'];
const VIEWS_LEGAL = ['legaldash','legalqueue','legalcasedetail','legaldocuments','legalauction','legalnotices','profile'];
const VIEWS_BANKOFFICE = ['bodash','boapplications','boappdetail','boportfolio','bodisbursement','bonpa','bodocs','boauction','boreports','bosettings'];
const VIEWS_BIDDER = ['bidderdash','bidderlistings','bidderlistingdetail','bidderbids','biddersettings'];
function currentViews(){ return isAdmin() ? VIEWS_ADMIN : isLegal() ? VIEWS_LEGAL : isBankOffice() ? VIEWS_BANKOFFICE : isBidder() ? VIEWS_BIDDER : VIEWS_CUSTOMER; }
function defaultView(){ return isAdmin() ? 'admindash' : isLegal() ? 'legaldash' : isBankOffice() ? 'bodash' : isBidder() ? 'bidderdash' : 'dashboard'; }
function go(view){
  if(!currentViews().includes(view)) view=defaultView();
  location.hash = view;
  if(isLegal() || isBankOffice()) renderSidebar();
  render(view);
  $all('.nav-item').forEach(b=>b.classList.toggle('active',
    b.dataset.view===view ||
    (view==='legalcasedetail' && b.dataset.view==='legalqueue') ||
    (['legalmgmt','bankofficemgmt'].includes(view) && b.dataset.view==='employeemgmt') ||
    (view==='adminmgmt' && b.dataset.view==='biddermgmt')
  ));
  document.getElementById('sidebar').classList.remove('open');
  window.scrollTo(0,0);
}
function toggleSidebar(){ $('#sidebar').classList.toggle('open'); }
window.addEventListener('hashchange', ()=>{
  if(!currentUser()) return;
  const v = location.hash.replace('#','') || defaultView();
  render(v);
  $all('.nav-item').forEach(b=>b.classList.toggle('active', b.dataset.view===v));
});

function render(view){
  refreshNotifBadge();
  const main = $('#main');
  switch(view){
    case 'dashboard': main.innerHTML = viewDashboard(); afterDashboard(); break;
    case 'guidance': main.innerHTML = viewGuidance(); afterGuidance(); break;
    case 'eligibility': main.innerHTML = viewEligibility(); afterEligibility(); break;
    case 'apply': main.innerHTML = viewApply(); afterApply(); break;
    case 'tracking': main.innerHTML = viewTracking(); afterTracking(); break;
    case 'repayment': main.innerHTML = viewRepayment(); afterRepayment(); break;
    case 'postdisb': main.innerHTML = viewPostDisb(); afterPostDisb(); break;
    case 'auction': main.innerHTML = viewAuction(); break;
    case 'documents': main.innerHTML = viewDocuments(); break;
    case 'profile': main.innerHTML = isAdmin() ? viewAdminProfile() : isLegal() ? viewLegalProfile() : viewProfile(); afterProfile(); break;
    case 'support': main.innerHTML = viewSupport(); afterSupport(); break;
    case 'admindash': main.innerHTML = viewAdminDashboard(); break;
    case 'biddermgmt': main.innerHTML = viewCustomerManagement('bidder'); break;
    case 'adminmgmt': main.innerHTML = viewCustomerManagement('admin'); break;
    case 'employeemgmt': main.innerHTML = viewEmployeeManagement('employee'); break;
    case 'legalmgmt': main.innerHTML = viewEmployeeManagement('legal'); break;
    case 'bankofficemgmt': main.innerHTML = viewEmployeeManagement('bankoffice'); break;
    case 'loanofficermgmt': main.innerHTML = viewStaffManagement('loanofficer'); break;
    case 'roles': main.innerHTML = viewRolePermissions(); break;
    case 'legaldash': main.innerHTML = viewLegalDashboard(); break;
    case 'legalqueue': main.innerHTML = viewLegalQueue(); break;
    case 'legalcasedetail': main.innerHTML = viewLegalCaseDetail(); break;
    case 'legaldocuments': main.innerHTML = viewLegalDocuments(); break;
    case 'legalauction': main.innerHTML = viewLegalAuction(); break;
    case 'bodash': main.innerHTML = viewBankOfficeDashboard(); break;
    case 'boapplications': main.innerHTML = viewBankOfficeApplications(); break;
    case 'boappdetail': main.innerHTML = viewBankOfficeAppDetail(); break;
    case 'boportfolio': main.innerHTML = viewBankOfficePortfolio(); break;
    case 'bodisbursement': main.innerHTML = viewBankOfficeDisbursement(); break;
    case 'bonpa': main.innerHTML = viewBankOfficeNPA(); break;
    case 'bodocs': main.innerHTML = viewBankOfficeDocuments(); break;
    case 'boauction': main.innerHTML = viewBankOfficeAuction(); break;
    case 'boreports': main.innerHTML = viewBankOfficeReports(); break;
    case 'bosettings': main.innerHTML = viewBankOfficeSettings(); break;
    case 'bidderdash': main.innerHTML = viewBidderDashboard(); break;
    case 'bidderlistings': main.innerHTML = viewBidderListings(); break;
    case 'bidderlistingdetail': main.innerHTML = viewBidderListingDetail(); break;
    case 'bidderbids': main.innerHTML = viewBidderMyBids(); break;
    case 'biddersettings': main.innerHTML = viewBidderSettings(); break;
    default: main.innerHTML = isAdmin() ? viewAdminDashboard() : isLegal() ? viewLegalDashboard() : isBankOffice() ? viewBankOfficeDashboard() : isBidder() ? viewBidderDashboard() : viewDashboard(); if(!isAdmin() && !isLegal() && !isBankOffice() && !isBidder()) afterDashboard();
  }
}

/* ================================================================
   AUTH: Registration (US-UM-02), Login+OTP (US-UM-03), Forgot (US-UM-04)
   ================================================================ */
let authMode = 'login';       // login | register | forgotEmail | forgotOtp | forgotReset | otp
let policyAccepted = false;   // tracks whether the register-page Privacy Policy has been accepted
let pendingOtp = null;
let pendingOtpFor = null;     // email awaiting otp for login/reset
let pendingLoginEmail = null;

function renderAuth(){
  const area = $('#authFormArea');
  if(authMode==='login') area.innerHTML = tplLogin();
  else if(authMode==='register') area.innerHTML = tplRegister();
  else if(authMode==='otp') area.innerHTML = tplOtp('Verify Login', 'Enter the OTP sent to your registered mobile/email to complete login.', 'submitLoginOtp()');
  else if(authMode==='forgotEmail') area.innerHTML = tplForgotEmail();
  else if(authMode==='forgotOtp') area.innerHTML = tplOtp('Verify OTP', 'Enter the OTP sent to reset your password.', 'submitForgotOtp()');
  else if(authMode==='forgotReset') area.innerHTML = tplForgotReset();
}
/* ================================================================
   GENERIC ENTER-KEY FIELD NAVIGATION (applies app-wide)
   Enter moves focus to the next input/select on the same
   page/form; on the last field it triggers that form's submit
   button instead. Works across auth screens, modals, and app pages.
   ================================================================ */
function getEnterNavScope(el){
  return el.closest('#authFormArea') || el.closest('.modal-box') || el.closest('.card') || el.closest('.main') || document;
}
function getEnterNavFields(scope){
  return Array.from(scope.querySelectorAll('input, select, textarea')).filter(f=>{
    if(f.disabled || f.type === 'hidden') return false;
    if(f.offsetParent === null) return false;
    return true;
  });
}
function getEnterNavSubmitBtn(scope){
  return scope.querySelector('.btn-primary:not([disabled])') || scope.querySelector('button.btn:not([disabled])');
}
function handleAppEnterKey(e){
  if(e.key !== 'Enter') return;
  const el = e.target;
  const tag = (el.tagName || '').toLowerCase();
  if(tag === 'button' || tag === 'a') return;
  if(tag === 'textarea') return;
  const scope = getEnterNavScope(el);
  const fields = getEnterNavFields(scope);
  const idx = fields.indexOf(el);
  e.preventDefault();
  if(idx > -1 && idx < fields.length - 1){
    const next = fields[idx + 1];
    next.focus();
    if(typeof next.select === 'function') try{ next.select(); }catch(_){}
    return;
  }
  // last field (or field not tracked): submit for auth screens by mode, otherwise click the scope's primary button
  if(scope.id === 'authFormArea'){
    if(authMode==='login') submitLogin();
    else if(authMode==='register') submitRegister();
    else if(authMode==='otp') submitLoginOtp();
    else if(authMode==='forgotEmail') submitForgotEmail();
    else if(authMode==='forgotOtp') submitForgotOtp();
    else if(authMode==='forgotReset') submitNewPassword();
    return;
  }
  const btn = getEnterNavSubmitBtn(scope);
  if(btn) btn.click();
}
document.addEventListener('keydown', handleAppEnterKey);
function switchAuth(mode){ authMode = mode; renderAuth(); }

function tplLogin(){
  return `
    <h2>Welcome back</h2>
    <div class="sub">Log in to manage your housing loan.</div>
    <div class="field">
      <label>Email or Mobile Number<span class="req">*</span></label>
      <input id="loginId" placeholder="you@example.com or 9876543210">
      <div class="error hidden" id="err_loginId"></div>
    </div>
    <div class="field">
      <label>Password<span class="req">*</span></label>
      <div class="password-wrap">
        <input id="loginPass" type="password" placeholder="Enter your password">
        <span class="password-toggle" onclick="togglePasswordVisibility('loginPass', this)">👁</span>
      </div>
      <div class="error hidden" id="err_loginPass"></div>
    </div>
    <button class="btn btn-primary btn-block" onclick="submitLogin()">Log In</button>
    <div class="auth-switch"><a href="#" onclick="switchAuth('forgotEmail');return false;">Forgot password?</a></div>
    <div class="auth-switch">Don't have an account? <a href="#" onclick="switchAuth('register');return false;">Register here</a></div>
    <div class="demo-note">Demo mode: OTP will be shown on-screen (no real SMS/email is sent since this app has no backend).</div>
    <div class="demo-note">Admin login: <strong>admin@hlms.example.com</strong> / <strong>Admin@123</strong></div>
    <div class="demo-note">Legal Team login: <strong>legal@hlms.example.com</strong> / <strong>Legal@123</strong></div>
    <div class="demo-note">Bank Office login: <strong>bankoffice@hlms.example.com</strong> / <strong>Bank@123</strong></div>
    <div class="demo-note">Bidder login: <strong>bidder@hlms.example.com</strong> / <strong>Bidder@123</strong></div>
  `;
}
function tplRegister(){
  policyAccepted = false;
  return `
    <h2>Create your account</h2>
    <div class="sub">Register as a home loan customer, or as a bidder to participate in bank e-auctions.</div>
    <div class="field">
      <label>Account Type<span class="req">*</span></label>
      <select id="regRole" onchange="toggleRegRoleHint()">
        <option value="customer">Home Loan Customer</option>
        <option value="bidder">Property Bidder</option>
      </select>
      
    </div>
    <div class="field"><label>Full Name<span class="req">*</span></label><input id="regName" placeholder="John Doe"><div class="error hidden" id="err_regName"></div></div>
    <div class="two-col">
      <div class="field"><label>Mobile Number<span class="req">*</span></label><input id="regMobile" maxlength="10" placeholder="9876543210"><div class="error hidden" id="err_regMobile"></div></div>
      <div class="field"><label>Email Address<span class="req">*</span></label><input id="regEmail" placeholder="you@example.com"><div class="error hidden" id="err_regEmail"></div></div>
    </div>
    <div class="two-col">
      <div class="field">
        <label>Password<span class="req">*</span></label>
        <div class="password-wrap">
          <input id="regPass" type="password" placeholder="Min 8 chars">
          <span class="password-toggle" onclick="togglePasswordVisibility('regPass', this)">👁</span>
        </div>
        <div class="error hidden" id="err_regPass"></div>
      </div>
      <div class="field">
        <label>Confirm Password<span class="req">*</span></label>
        <div class="password-wrap">
          <input id="regPass2" type="password" placeholder="Re-enter password">
          <span class="password-toggle" onclick="togglePasswordVisibility('regPass2', this)">👁</span>
        </div>
        <div class="error hidden" id="err_regPass2"></div>
      </div>
    </div>
   
    <div class="field policy-field">
      <label>Privacy Policy<span class="req">*</span></label>
      <button type="button" class="policy-link" onclick="openPolicyModal()">View Privacy Policy</button>
      <div class="policy-status" id="policyStatus">Not yet accepted</div>
    </div>
    <button class="btn btn-primary btn-block" id="createAccountBtn" disabled onclick="submitRegister()">Create Account</button>
    <div class="auth-switch">Already registered? <a href="#" onclick="switchAuth('login');return false;">Log in</a></div>
  `;
}
function tplPolicyContent(){
  return `
    <h4>1. Introduction</h4>
    <p>HLMS ("we", "our", "the Platform") provides an online Housing Loan Management System that allows customers to check loan eligibility, apply for loans, track application status, manage repayments, and access related banking services. This Privacy Policy explains how we collect, use, store, and protect your information when you use the Platform.</p>
    <h4>2. Information We Collect</h4>
    <ul>
      <li><strong>Personal Identification Information:</strong> name, date of birth, mobile number, email address, and government identity documents.</li>
      <li><strong>Financial Information:</strong> income details, bank statements, existing loan obligations, and credit score data used to assess loan eligibility.</li>
      <li><strong>Property Information:</strong> documents and details related to the property being financed or mortgaged.</li>
      <li><strong>Usage Data:</strong> pages visited, actions taken within the Platform, and device/browser information collected automatically to improve service quality.</li>
    </ul>
    <h4>3. How We Use Your Information</h4>
    <ul>
      <li>To assess loan eligibility and process loan applications.</li>
      <li>To communicate application status, repayment reminders, and account notifications.</li>
      <li>To comply with legal and regulatory obligations, including SARFAESI Act proceedings where applicable.</li>
      <li>To improve the security, performance, and usability of the Platform.</li>
    </ul>
    <h4>4. Data Sharing</h4>
    <p>We do not sell your personal information. Data may be shared internally with authorized Loan Officers, Legal &amp; Valuation teams, and Bank Office staff strictly for the purpose of processing your loan, and with credit bureaus or regulatory authorities where required by law.</p>
    <h4>5. Data Security</h4>
    <p>We apply reasonable administrative and technical safeguards to protect your information against unauthorized access, alteration, or disclosure. Access to sensitive financial and legal records is restricted by role-based permissions within the Platform.</p>
    <h4>6. Data Retention</h4>
    <p>We retain personal and loan-related records for as long as necessary to fulfil the purposes described in this policy and to meet statutory record-keeping requirements applicable to housing finance institutions.</p>
    <h4>7. Your Rights</h4>
    <p>You may request access to, correction of, or deletion of your personal information, subject to our legal and regulatory obligations, by contacting our support team via the Support/Help section of the Platform.</p>
    <h4>8. Changes to This Policy</h4>
    <p>We may update this Privacy Policy from time to time. Material changes will be communicated through the Platform. Continued use of HLMS after such updates constitutes acceptance of the revised policy.</p>
    <h4>9. Contact Us</h4>
    <p>For any privacy-related questions, please reach out via 📞 1800-123-4567 or ✉️ support@hlms.example.com.</p>
  `;
}
function openPolicyModal(){
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.id = 'policyModalOverlay';
  overlay.innerHTML = `
    <div class="modal-box" style="max-width:560px;">
      <h3>Privacy Policy</h3>
      <div class="policy-box">${tplPolicyContent()}</div>
      <label class="policy-check">
        <input type="checkbox" id="agreePolicyModal" ${policyAccepted ? 'checked' : ''}>
        <span>I have read and agree to the HLMS Privacy Policy above.</span>
      </label>
      <div style="text-align:right;margin-top:16px;display:flex;gap:10px;justify-content:flex-end;">
        <button class="btn btn-outline btn-sm" onclick="closePolicyModal()">Cancel</button>
        <button class="btn btn-primary btn-sm" onclick="confirmPolicyAccept()">Save</button>
      </div>
    </div>`;
  overlay.addEventListener('click', (e)=>{ if(e.target===overlay) closePolicyModal(); });
  document.body.appendChild(overlay);
}
function closePolicyModal(){
  $('#policyModalOverlay')?.remove();
}
function confirmPolicyAccept(){
  const cb = $('#agreePolicyModal');
  policyAccepted = !!(cb && cb.checked);
  updatePolicyStatusUI();
  toggleCreateAccountBtn();
  closePolicyModal();
}
function updatePolicyStatusUI(){
  const statusEl = $('#policyStatus');
  if(!statusEl) return;
  if(policyAccepted){
    statusEl.textContent = '✓ Policy accepted';
    statusEl.classList.add('accepted');
  } else {
    statusEl.textContent = 'Not yet accepted';
    statusEl.classList.remove('accepted');
  }
}
function toggleCreateAccountBtn(){
  const btn = $('#createAccountBtn');
  if(btn) btn.disabled = !policyAccepted;
}
function tplOtp(title, sub, onSubmitFn){
  return `
    <h2>${title}</h2>
    <div class="sub">${sub}</div>
    <div class="demo-note" id="otpDemoNote"></div>
    <div class="otp-boxes">
      ${[0,1,2,3,4,5].map(i=>`<input maxlength="1" inputmode="numeric" class="otpDigit" data-i="${i}" oninput="otpKeyMove(this)" onkeydown="otpBackspaceMove(event,this)">`).join('')}
    </div>
    <div class="error hidden" id="err_otp" style="text-align:center;"></div>
    <button class="btn btn-primary btn-block" onclick="${onSubmitFn}">Verify OTP</button>
    <div class="auth-switch"><a href="#" onclick="resendOtp();return false;">Resend OTP</a></div>
  `;
}
function tplForgotEmail(){
  return `
    <h2>Forgot Password</h2>
    <div class="sub">Enter your registered email or mobile number to receive an OTP.</div>
    <div class="field"><label>Email or Mobile<span class="req">*</span></label><input id="fpId" placeholder="you@example.com or 9876543210"><div class="error hidden" id="err_fpId"></div></div>
    <button class="btn btn-primary btn-block" onclick="submitForgotEmail()">Send OTP</button>
    <div class="auth-switch"><a href="#" onclick="switchAuth('login');return false;">Back to login</a></div>
  `;
}
function tplForgotReset(){
  return `
    <h2>Set New Password</h2>
    <div class="sub">Choose a new secure password for your account.</div>
    <div class="field"><label>New Password<span class="req">*</span></label><input id="npPass" type="password"><div class="error hidden" id="err_npPass"></div></div>
    <div class="field"><label>Confirm New Password<span class="req">*</span></label><input id="npPass2" type="password"><div class="error hidden" id="err_npPass2"></div></div>
    <button class="btn btn-primary btn-block" onclick="submitNewPassword()">Update Password</button>
  `;
}
function togglePasswordVisibility(inputId, iconEl){
  const el = $('#'+inputId);
  if(!el) return;
  if(el.type === 'password'){ el.type = 'text'; iconEl.textContent = '🙈'; }
  else { el.type = 'password'; iconEl.textContent = '👁'; }
}
function otpKeyMove(el){
  el.value = el.value.replace(/[^0-9]/g,'').slice(0,1);
  if(el.value && el.nextElementSibling && el.nextElementSibling.classList.contains('otpDigit')){
    el.nextElementSibling.focus();
    el.nextElementSibling.select();
  }
}
function otpBackspaceMove(e, el){
  if(e.key === 'Backspace' && !el.value && el.previousElementSibling && el.previousElementSibling.classList.contains('otpDigit')){
    el.previousElementSibling.focus();
    el.previousElementSibling.select();
  }
}
function readOtpInput(){ return $all('.otpDigit').map(i=>i.value).join(''); }
function genOtp(){ return String(Math.floor(100000+Math.random()*900000)); }

function submitLogin(){
  const idEl=$('#loginId'), passEl=$('#loginPass');
  let ok=true;
  const idVal = idEl.value.trim();
  if(!idVal) ok = fieldError(idEl, $('#err_loginId'), 'Enter your email or mobile number.') && ok;
  else fieldOk(idEl,$('#err_loginId'));
  if(!passEl.value) ok = fieldError(passEl, $('#err_loginPass'), 'Enter your password.') && ok;
  else fieldOk(passEl,$('#err_loginPass'));
  if(!ok) return;

  const user = Object.values(DB.users).find(u=>u.email===idVal || u.mobile===idVal);
  if(!user) return fieldError(idEl, $('#err_loginId'), 'No account found with these details.');
  if(user.active===false) return fieldError(idEl, $('#err_loginId'), 'This account has been deactivated. Contact your administrator.');
  if(user.password !== passEl.value) return fieldError(passEl, $('#err_loginPass'), 'Incorrect password.');

  pendingLoginEmail = user.email;
  pendingOtp = genOtp();
  authMode='otp'; renderAuth();
  setTimeout(()=>{ $('#otpDemoNote') && ($('#otpDemoNote').textContent = 'Your OTP is '+pendingOtp+' (demo display only).'); $('.otpDigit') && $('.otpDigit').focus(); },0);
}
function resendOtp(){
  pendingOtp = genOtp();
  toast('OTP Resent', 'A new OTP has been generated.', 'success');
  const note = $('#otpDemoNote'); if(note) note.textContent = 'Your OTP is '+pendingOtp+' (demo display only).';
}
function submitLoginOtp(){
  const val = readOtpInput();
  if(val.length!==6) return fieldError({style:{}}, $('#err_otp'), 'Enter all 6 digits.');
  if(val!==pendingOtp) return fieldError({style:{}}, $('#err_otp'), 'Incorrect OTP. Please try again.');
  DB.session = pendingLoginEmail; saveDB();
  pushNotification(pendingLoginEmail,'Login Successful','You logged in to your HLMS account.',['inapp']);
  enterApp();
}
function toggleRegRoleHint(){
  const role = $('#regRole').value;
  $('#regRoleHint').textContent = role==='bidder'
    ? 'Browse bank-listed auction properties and place bids on defaulted assets.'
    : 'Apply for and manage a housing loan.';
}
function submitRegister(){
  const name=$('#regName'), mobile=$('#regMobile'), email=$('#regEmail'), pass=$('#regPass'), pass2=$('#regPass2');
  const role = ($('#regRole') && $('#regRole').value) || 'customer';
  let ok=true;
  if(!name.value.trim() || name.value.trim().length<3) ok = fieldError(name,$('#err_regName'),'Enter your full name (min 3 characters).') && ok; else fieldOk(name,$('#err_regName'));
  if(!REGEX.mobile.test(mobile.value.trim())) ok = fieldError(mobile,$('#err_regMobile'),'Enter a valid 10-digit mobile number.') && ok; else fieldOk(mobile,$('#err_regMobile'));
  if(!REGEX.email.test(email.value.trim())) ok = fieldError(email,$('#err_regEmail'),'Enter a valid email address.') && ok; else fieldOk(email,$('#err_regEmail'));
  if(!REGEX.password.test(pass.value)) ok = fieldError(pass,$('#err_regPass'),'Password must have upper, lower, number & special char (8+ chars).') && ok; else fieldOk(pass,$('#err_regPass'));
  if(pass.value!==pass2.value || !pass2.value) ok = fieldError(pass2,$('#err_regPass2'),'Passwords do not match.') && ok; else fieldOk(pass2,$('#err_regPass2'));
  if(Object.values(DB.users).some(u=>u.email===email.value.trim())) ok = fieldError(email,$('#err_regEmail'),'An account already exists with this email.') && ok;
  if(!policyAccepted){
    toast('Accept Privacy Policy', 'Please read and agree to the Privacy Policy before creating your account.', 'error');
    ok = false;
  }
  if(!ok) return;

  const user = {
    email: email.value.trim(), name:name.value.trim(), mobile:mobile.value.trim(),
    password:pass.value, role:role,
    notifPrefs:{sms:true,email:true,inapp:true},
    createdAt:new Date().toISOString()
  };
  if(role==='customer'){
    user.employment = {type:'Salaried', employer:'', monthlyIncome:0, otherEMIs:0};
  }
  DB.users[user.email] = user; saveDB();
  toast('Account Created', role==='bidder' ? 'Your bidder account has been registered successfully. Please log in to browse auction listings.' : 'Your account has been registered successfully. Please log in.', 'success');
  switchAuth('login');
}
function submitForgotEmail(){
  const idEl=$('#fpId'); const idVal=idEl.value.trim();
  const user = Object.values(DB.users).find(u=>u.email===idVal || u.mobile===idVal);
  if(!user) return fieldError(idEl, $('#err_fpId'), 'No account found with these details.');
  pendingOtpFor = user.email; pendingOtp = genOtp();
  authMode='forgotOtp'; renderAuth();
  setTimeout(()=>{ $('#otpDemoNote').textContent = 'Your OTP is '+pendingOtp+' (demo display only).'; },0);
}
function submitForgotOtp(){
  const val = readOtpInput();
  if(val.length!==6) return fieldError({style:{}}, $('#err_otp'), 'Enter all 6 digits.');
  if(val!==pendingOtp) return fieldError({style:{}}, $('#err_otp'), 'Incorrect OTP.');
  authMode='forgotReset'; renderAuth();
}
function submitNewPassword(){
  const p1=$('#npPass'), p2=$('#npPass2');
  let ok=true;
  if(!REGEX.password.test(p1.value)) ok = fieldError(p1,$('#err_npPass'),'Password must have upper, lower, number & special char (8+ chars).') && ok; else fieldOk(p1,$('#err_npPass'));
  if(p1.value!==p2.value) ok = fieldError(p2,$('#err_npPass2'),'Passwords do not match.') && ok; else fieldOk(p2,$('#err_npPass2'));
  if(!ok) return;
  DB.users[pendingOtpFor].password = p1.value; saveDB();
  toast('Password Updated', 'You can now log in with your new password.', 'success');
  switchAuth('login');
}

/* ================================================================
   HOME / LANDING PAGE
   ================================================================ */
function openAuth(mode){
  authMode = mode || 'login';
  $('#homeScreen').classList.add('hidden');
  $('#authScreen').classList.remove('hidden');
  renderAuth();
  window.scrollTo(0,0);
}
function showHome(){
  $('#authScreen').classList.add('hidden');
  $('#homeScreen').classList.remove('hidden');
  window.scrollTo(0,0);
}

function enterApp(){
  $('#homeScreen').classList.add('hidden');
  $('#authScreen').classList.add('hidden');
  $('#app').classList.remove('hidden');
  const u = currentUser();
  $('#userNameTop').textContent = u.name.split(' ')[0];
  $('#userInitials').textContent = u.name.split(' ').map(s=>s[0]).join('').slice(0,2).toUpperCase();
  renderSidebar();
  const v = location.hash.replace('#','') || defaultView();
  go(v);
}
function logout(){
  DB.session = null; saveDB();
  $('#app').classList.add('hidden');
  $('#authScreen').classList.add('hidden');
  $('#homeScreen').classList.remove('hidden');
  authMode='login'; renderAuth();
  location.hash='';
}

/* ================================================================
   APPLICATION HELPERS (shared across views)
   ================================================================ */
function myApplications(){
  const u = currentUser(); if(!u) return [];
  return DB.applications.filter(a=>a.userEmail===u.email).sort((a,b)=> new Date(b.createdAt)-new Date(a.createdAt));
}
function myDrafts(){
  const u = currentUser(); if(!u) return [];
  return DB.drafts.filter(d=>d.userEmail===u.email);
}
const WORKFLOW_STAGES = ['Application Submitted','Document Verification','Eligibility & Credit Check','Mortgage / Property Verification','Final Approval','Disbursement'];
const STAGE_OFFSETS = [0,2,5,9,13,16]; // expected day offsets from submission
const OFFICERS = [
  {dept:'Customer Onboarding', officer:'A. Mehta'},
  {dept:'Document Verification Cell', officer:'S. Iyer'},
  {dept:'Credit Appraisal Dept', officer:'R. Sharma'},
  {dept:'Legal & Valuation Team', officer:'N. Kulkarni'},
  {dept:'Loan Approval Committee', officer:'P. Verma'},
  {dept:'Disbursement Desk', officer:'K. Das'}
];
function buildStages(app){
  return WORKFLOW_STAGES.map((name,i)=>({
    name,
    status: i<app.stageIndex?'completed': i===app.stageIndex?'current':'upcoming',
    expectedDate: addDays(app.createdAt, STAGE_OFFSETS[i]),
    officer: OFFICERS[i].officer, department: OFFICERS[i].dept
  }));
}
function advanceStage(appId){
  const app = DB.applications.find(a=>a.id===appId); if(!app) return;
  if(app.stageIndex < WORKFLOW_STAGES.length-1){
    app.stageIndex++;
    if(app.stageIndex === WORKFLOW_STAGES.length-1){
      app.status='Disbursed';
      app.disbursement = {
        date: new Date().toISOString(), amount: app.loanAmount, refNo:'DISB/'+new Date().getFullYear()+'/'+Math.floor(10000+Math.random()*89999),
        mode:'NEFT', bank:'HDFC Bank - 1234',
        insurance:{ property:{status:'Active', validTill: addDays(new Date(),365)}, life:{status:'Active', validTill: addDays(new Date(), 365*20)} }
      };
      app.repayment = { schedule: buildSchedule(app.loanAmount, app.interestRate, app.tenureYears, new Date()), outstandingBalance: app.loanAmount };
      pushNotification(app.userEmail,'Loan Disbursed! 🎉','Your loan amount of '+fmtINR(app.loanAmount)+' has been disbursed.',notifChannels(app.userEmail));
    } else {
      app.status='Under Review';
      pushNotification(app.userEmail,'Application Update', 'Your application '+app.trackingNo+' has moved to: '+WORKFLOW_STAGES[app.stageIndex],notifChannels(app.userEmail));
    }
    saveDB();
    toast('Status Updated', app.trackingNo+' moved to "'+WORKFLOW_STAGES[app.stageIndex]+'"','success');
    render(location.hash.replace('#','')||'tracking');
  } else {
    toast('Already Complete','This application has completed the full workflow.');
  }
}
function notifChannels(email){
  const u = DB.users[email]; if(!u) return ['inapp'];
  const ch=[]; if(u.notifPrefs.inapp) ch.push('inapp'); if(u.notifPrefs.sms) ch.push('sms'); if(u.notifPrefs.email) ch.push('email');
  return ch.length?ch:['inapp'];
}

/* Eligibility engine (US-EL-01..08) */
const UNSECURED_LIMIT = 3500000; // ₹35,00,000 max loan approvable without mortgage (business rule)
const STANDARD_RATE = 8.5;
function assessEligibility(income, otherEMIs, loanAmount, tenureYears){
  const emi = calcEMI(loanAmount, STANDARD_RATE, tenureYears);
  const totalObligation = emi + Number(otherEMIs||0);
  const dti = income>0 ? (totalObligation/income)*100 : 100;
  let status, reasons=[], suggestions=[];
  if(dti<=50){ status='Eligible'; }
  else if(dti<=60){ status='Conditionally Eligible'; }
  else { status='Not Eligible'; }

  if(dti>60) reasons.push('Your Debt-to-Income ratio ('+dti.toFixed(1)+'%) exceeds the acceptable limit of 60%.');
  else if(dti>50) reasons.push('Your Debt-to-Income ratio ('+dti.toFixed(1)+'%) is above the ideal limit of 50%.');
  if(reasons.length===0) reasons.push('You meet all eligibility criteria for this loan amount and tenure.');

  if(status!=='Eligible'){
    if(dti>50) suggestions.push('Reduce existing EMIs/liabilities or opt for a longer tenure to lower your EMI burden.');
    suggestions.push('Consider adding a co-applicant to increase combined household income.');
    suggestions.push('Try a lower loan amount using the simulator below.');
  }

  // Max loan without mortgage: solve for max principal such that DTI<=50% at same tenure, capped at UNSECURED_LIMIT
  const affordableEMI = Math.max(0, income*0.5 - Number(otherEMIs||0));
  const r = STANDARD_RATE/12/100, n=tenureYears*12;
  let maxByAffordability = affordableEMI>0 ? affordableEMI*(Math.pow(1+r,n)-1)/(r*Math.pow(1+r,n)) : 0;
  const maxUnsecured = Math.min(maxByAffordability, UNSECURED_LIMIT);

  const mortgageRequired = loanAmount > maxUnsecured;
  const ltv = 0.8;
  const requiredPropertyValue = mortgageRequired ? Math.ceil((loanAmount - maxUnsecured)/ltv) : 0;

  return { emi, dti, status, reasons, suggestions, maxUnsecured, mortgageRequired, requiredPropertyValue };
}
function lastEligibility(){
  const u = currentUser(); if(!u || !u.lastEligibility) return null;
  return u.lastEligibility;
}

/* Loan products (US-LG-01..06) */
const LOAN_PRODUCTS = [
  {id:'HP', name:'Home Purchase Loan', category:'Home Purchase', rate:8.5, maxTenure:30, maxLTV:'90%', desc:'Finance the purchase of a new or resale residential property.'},
  {id:'HC', name:'Home Construction Loan', category:'Construction', rate:8.75, maxTenure:25, maxLTV:'85%', desc:'Funds disbursed in stages to construct your house on owned land.'},
  {id:'HR', name:'Home Renovation Loan', category:'Renovation', rate:9.25, maxTenure:15, maxLTV:'80%', desc:'Renovate, repair or extend your existing home.'},
  {id:'PL', name:'Plot Loan', category:'Plot Loan', rate:9.0, maxTenure:20, maxLTV:'75%', desc:'Purchase a residential plot for future construction.'},
  {id:'BT', name:'Balance Transfer + Top-up', category:'Balance Transfer', rate:8.4, maxTenure:30, maxLTV:'90%', desc:'Transfer your existing home loan and get an additional top-up amount.'},
  {id:'NRI', name:'NRI Home Loan', category:'Home Purchase', rate:8.9, maxTenure:20, maxLTV:'80%', desc:'Home loan tailored for Non-Resident Indian customers.'}
];

/* ================================================================
   DASHBOARD
   ================================================================ */
function viewDashboard(){
  const u = currentUser();
  const apps = myApplications();
  const active = apps.find(a=>a.status!=='Disbursed' && a.status!=='Rejected') || apps[0];
  const disbursed = apps.filter(a=>a.status==='Disbursed');
  const elig = lastEligibility();

  return `
  <div class="page-head"><h1>Welcome back, ${escapeHtml(u.name.split(' ')[0])} 👋</h1><p>Here's a quick overview of your housing loan journey.</p></div>

  <div class="grid grid-3">
    <div class="card stat"><div class="lbl">Active Applications</div><div class="val teal">${apps.filter(a=>a.status!=='Disbursed'&&a.status!=='Rejected').length}</div></div>
    <div class="card stat"><div class="lbl">Disbursed Loans</div><div class="val teal">${disbursed.length}</div></div>
    <div class="card stat"><div class="lbl">Eligibility Status</div><div class="val">${elig? elig.status : 'Not Checked'}</div></div>
  </div>

  <div class="grid grid-2">
    <div class="card">
      <h3>📋 Current Application</h3>
      ${active ? `
        <div class="stat" style="margin-bottom:10px;"><div class="lbl">Tracking No.</div><div class="val">${active.trackingNo}</div></div>
        <div class="grid grid-2" style="margin-bottom:14px;">
          <div class="stat"><div class="lbl">Loan Type</div><div class="val">${active.loanType}</div></div>
          <div class="stat"><div class="lbl">Amount</div><div class="val">${fmtINR(active.loanAmount)}</div></div>
          <div class="stat"><div class="lbl">Status</div><div class="val"><span class="badge badge-navy">${active.status}</span></div></div>
          <div class="stat"><div class="lbl">Current Stage</div><div class="val">${WORKFLOW_STAGES[active.stageIndex]}</div></div>
        </div>
        <div class="progress-track"><div class="progress-fill" style="width:${(active.stageIndex/(WORKFLOW_STAGES.length-1)*100).toFixed(0)}%"></div></div>
        <div style="margin-top:14px;"><button class="btn btn-teal btn-sm" onclick="go('tracking')">View Full Tracking →</button></div>
      ` : `<div class="empty-state"><div class="ic">📄</div>No applications yet. <br><button class="btn btn-primary btn-sm" style="margin-top:10px;" onclick="go('apply')">Apply for a Loan</button></div>`}
    </div>

    <div class="card">
      <h3>✅ Quick Actions</h3>
      <div class="quick-links">
        <a href="#" onclick="go('eligibility');return false;">Check Loan Eligibility <span class="arrow">→</span></a>
        <a href="#" onclick="go('guidance');return false;">Explore Loan Products <span class="arrow">→</span></a>
        <a href="#" onclick="go('support');return false;">Get Support <span class="arrow">→</span></a>
      </div>
    </div>
  </div>
  `;
}
function afterDashboard(){}

function renderNotifList(limit){
  const u = currentUser();
  const list = DB.notifications.filter(n=>n.userEmail===u.email).slice(0, limit||20);
  if(!list.length) return '<div class="empty-state"><div class="ic">🔕</div>No notifications yet.</div>';
  return '<table><tbody>'+list.map(n=>`
    <tr>
      <td style="width:34px;">${n.read?'📖':'🔵'}</td>
      <td><strong>${escapeHtml(n.title)}</strong><br><span style="color:var(--text-gray);font-size:12px;">${escapeHtml(n.body)}</span></td>
      <td style="text-align:right;color:var(--text-gray);font-size:11.5px;">${n.channels.map(c=>`<span class="badge badge-gray" style="margin-left:4px;">${c}</span>`).join('')}<br>${fmtDate(n.ts)}</td>
    </tr>`).join('')+'</tbody></table>';
}
function openNotifPanel(){
  const u = currentUser();
  DB.notifications.filter(n=>n.userEmail===u.email).forEach(n=>n.read=true);
  saveDB(); refreshNotifBadge();
  showModal('🔔 Notifications', renderNotifList(30));
}

/* ================================================================
   LOAN GUIDANCE  (US-LG-01..06)
   ================================================================ */
let guidanceFilter = 'All';
let compareSelection = [];
function viewGuidance(){
  const cats = ['All', ...new Set(LOAN_PRODUCTS.map(p=>p.category))];
  const elig = lastEligibility();
  return `
  <div class="page-head"><h1>Loan Guidance</h1><p>Explore housing loan products, compare options, and get recommendations based on your profile.</p></div>

  <div class="card">
    <div class="tabs">${cats.map(c=>`<button class="tab ${guidanceFilter===c?'active':''}" onclick="setGuidanceFilter('${c}')">${c}</button>`).join('')}</div>
    <div class="grid grid-3" id="productGrid">${renderProductCards()}</div>
    <div style="margin-top:16px;display:flex;justify-content:space-between;align-items:center;">
      <span style="font-size:12.5px;color:var(--text-gray);">Select up to 3 products to compare.</span>
      <button class="btn btn-teal btn-sm" onclick="openCompare()">Compare Selected (<span id="cmpCount">0</span>)</button>
    </div>
  </div>

  <div class="grid grid-2">
    <div class="card">
      <h3>⭐ Personalized Recommendations</h3>
      ${elig ? renderRecommendations(elig) : `<div class="empty-state"><div class="ic">📊</div>Check your eligibility first to get personalized loan recommendations.<br><button class="btn btn-primary btn-sm" style="margin-top:10px;" onclick="go('eligibility')">Check Eligibility</button></div>`}
    </div>
    <div class="card">
      <h3>🧮 EMI &amp; Repayment Guidance</h3>
      <div class="field"><label>Loan Amount (₹)</label><input type="number" id="gAmount" value="2500000" oninput="updateGuidanceEmi()"></div>
      <div class="field"><label>Interest Rate (% p.a.)</label><input type="number" id="gRate" value="8.5" step="0.05" oninput="updateGuidanceEmi()"></div>
      <div class="field"><label>Tenure (Years): <b id="gYearsLbl">20</b></label><input type="range" min="1" max="30" value="20" id="gYears" oninput="updateGuidanceEmi()"></div>
      <div class="stat" style="margin-top:8px;"><div class="lbl">Estimated Monthly EMI</div><div class="val teal" id="gEmiOut" style="font-size:22px;">₹0</div></div>
      <p style="font-size:12px;color:var(--text-gray);margin-top:6px;">Longer tenure reduces EMI but increases total interest paid. Choose a repayment plan that keeps your EMI within 40-50% of monthly income.</p>
    </div>
  </div>
  `;
}
function renderProductCards(){
  const list = guidanceFilter==='All'? LOAN_PRODUCTS : LOAN_PRODUCTS.filter(p=>p.category===guidanceFilter);
  const elig = lastEligibility();
  return list.map(p=>{
    const recommended = elig && elig.status!=='Not Eligible' && p.rate<=9.0;
    return `<div class="product-card">
      <span class="tag">${p.category}</span>
      ${recommended?'<span class="rec">Recommended</span>':''}
      <h4>${p.name}</h4>
      <div class="rate">${p.rate}% p.a.</div>
      <p>${p.desc}</p>
      <p><b>Max Tenure:</b> ${p.maxTenure} yrs &nbsp; | &nbsp; <b>Max LTV:</b> ${p.maxLTV}</p>
      <label class="chk-row"><input type="checkbox" onchange="toggleCompare('${p.id}',this)" ${compareSelection.includes(p.id)?'checked':''}> Add to compare</label>
    </div>`;
  }).join('');
}
function setGuidanceFilter(c){ guidanceFilter=c; $('#productGrid').innerHTML = renderProductCards(); $all('.tab').forEach(t=>t.classList.toggle('active', t.textContent===c)); }
function toggleCompare(id, el){
  if(el.checked){
    if(compareSelection.length>=3){ el.checked=false; return toast('Limit Reached','You can compare up to 3 products only.'); }
    compareSelection.push(id);
  } else { compareSelection = compareSelection.filter(x=>x!==id); }
  $('#cmpCount').textContent = compareSelection.length;
}
function openCompare(){
  if(compareSelection.length<2) return toast('Select More','Please select at least 2 products to compare.');
  const items = LOAN_PRODUCTS.filter(p=>compareSelection.includes(p.id));
  const amt = 2500000, years=20;
  const html = `<table><thead><tr><th>Feature</th>${items.map(p=>`<th>${p.name}</th>`).join('')}</tr></thead><tbody>
    <tr><td>Interest Rate</td>${items.map(p=>`<td>${p.rate}% p.a.</td>`).join('')}</tr>
    <tr><td>Max Tenure</td>${items.map(p=>`<td>${p.maxTenure} yrs</td>`).join('')}</tr>
    <tr><td>Max LTV</td>${items.map(p=>`<td>${p.maxLTV}</td>`).join('')}</tr>
    <tr><td>EMI on ₹25,00,000 / 20yrs</td>${items.map(p=>`<td>${fmtINR(calcEMI(amt,p.rate,years))}</td>`).join('')}</tr>
  </tbody></table>`;
  showModal('🔍 Compare Loan Products', html);
}
function renderRecommendations(elig){
  const suitable = LOAN_PRODUCTS.filter(p=> elig.status==='Eligible' ? true : p.rate<=9.0).slice(0,3);
  return suitable.map(p=>`<div class="product-card" style="margin-bottom:10px;">
      <span class="rec">Matches your profile</span>
      <h4>${p.name}</h4><div class="rate">${p.rate}% p.a.</div>
      <p>Based on your eligibility status "<b>${elig.status}</b>" and max eligible amount ${fmtINR(elig.maxUnsecured)}.</p>
    </div>`).join('');
}
function updateGuidanceEmi(){
  const amt = Number($('#gAmount').value||0), rate=Number($('#gRate').value||0), yrs=Number($('#gYears').value||1);
  $('#gYearsLbl').textContent = yrs;
  $('#gEmiOut').textContent = fmtINR(calcEMI(amt,rate,yrs));
}
function afterGuidance(){ updateGuidanceEmi(); $('#cmpCount').textContent = compareSelection.length; }

/* ================================================================
   CHECK ELIGIBILITY  (US-EL-01..08 + US-MRC display)
   ================================================================ */
function viewEligibility(){
  const u = currentUser();
  const emp = u.employment||{};
  return `
  <div class="page-head"><h1>Check Loan Eligibility</h1><p>Get an instant eligibility assessment based on your income and obligations.</p></div>
  <div class="grid grid-2">
    <div class="card">
      <h3>📝 Your Financial Details</h3>
      <div class="two-col">
        <div class="field"><label>Monthly Income (₹)</label><input type="number" id="elIncome" value="${emp.monthlyIncome||60000}"></div>
        <div class="field"><label>Other Monthly EMIs (₹)</label><input type="number" id="elOtherEmi" value="${emp.otherEMIs||0}"></div>
      </div>
      <div class="two-col">
        <div class="field"><label>PAN Number</label><input id="elPan" maxlength="10" placeholder="e.g. ABCDE1234F" value="${escapeHtml(emp.pan||'')}" style="text-transform:uppercase;"><div class="error hidden" id="err_elPan"></div></div>
        <div class="field"><label>Employment Type</label>
          <select id="elEmpType"><option ${emp.type==='Salaried'?'selected':''}>Salaried</option><option ${emp.type==='Self-Employed'?'selected':''}>Self-Employed</option></select>
        </div>
      </div>
      <div class="field"><label>Desired Loan Amount (₹): <b id="elAmountLbl">${(emp.desiredAmount||2500000).toLocaleString('en-IN')}</b></label>
        <input type="range" min="100000" max="10000000" step="50000" id="elAmount" value="${emp.desiredAmount||2500000}" oninput="liveEligibility()"></div>
      <div class="field"><label>Tenure (Years): <b id="elYearsLbl">20</b></label>
        <input type="range" min="1" max="30" id="elYears" value="20" oninput="liveEligibility()"></div>
      <div class="error hidden" id="err_elForm"></div>
      <button class="btn btn-primary btn-block" style="margin-top:8px;" onclick="runEligibility()">Check Eligibility</button>
      <p style="font-size:11.5px;color:var(--text-gray);margin-top:10px;">Tip: Adjust the sliders above to simulate different loan amounts and tenures — results update instantly once you run the first check.</p>
    </div>
    <div class="card" id="eligResultCard">${renderEligResult(lastEligibility())}</div>
  </div>
  `;
}
function afterEligibility(){}
function liveEligibility(){
  $('#elAmountLbl').textContent = Number($('#elAmount').value).toLocaleString('en-IN');
  $('#elYearsLbl').textContent = $('#elYears').value;
  if(lastEligibility()) runEligibility(true);
}
function runEligibility(silent){
  const income = Number($('#elIncome').value||0);
  const otherEmi = Number($('#elOtherEmi').value||0);
  const pan = $('#elPan').value.trim().toUpperCase();
  const amount = Number($('#elAmount').value||0);
  const years = Number($('#elYears').value||1);
  const empType = $('#elEmpType').value;

  if(income<=0) return fieldError({style:{}}, $('#err_elForm'), 'Monthly income must be greater than 0.');
  if(pan && !REGEX.pan.test(pan)) return fieldError($('#elPan'), $('#err_elPan'), 'Enter a valid PAN (e.g. ABCDE1234F).');
  fieldOk($('#elPan'), $('#err_elPan'));
  fieldOk({style:{}}, $('#err_elForm'));

  const result = assessEligibility(income, otherEmi, amount, years);
  result.income=income; result.otherEmi=otherEmi; result.amount=amount; result.years=years; result.pan=pan;

  const u = currentUser();
  u.employment = {...u.employment, monthlyIncome:income, otherEMIs:otherEmi, pan, type:empType, desiredAmount:amount};
  u.lastEligibility = result;
  saveDB();
  $('#eligResultCard').innerHTML = renderEligResult(result);
  if(!silent) toast('Eligibility Checked', 'Status: '+result.status, result.status==='Not Eligible'?'error':'success');
}
function renderEligResult(r){
  if(!r) return '<div class="empty-state"><div class="ic">📊</div>Fill in your details and click "Check Eligibility" to see your result.</div>';
  const badgeClass = r.status==='Eligible'?'badge-green': r.status==='Conditionally Eligible'?'badge-orange':'badge-red';
  return `
    <h3>📊 Eligibility Result</h3>
    <div style="text-align:center;margin-bottom:16px;">
      <span class="badge ${badgeClass}" style="font-size:15px;padding:8px 20px;">${r.status}</span>
    </div>
    <div class="grid grid-2" style="margin-bottom:14px;">
      <div class="stat"><div class="lbl">Estimated EMI</div><div class="val">${fmtINR(r.emi)}</div></div>
      <div class="stat"><div class="lbl">Debt-to-Income Ratio</div><div class="val">${r.dti.toFixed(1)}%</div></div>
      <div class="stat"><div class="lbl">Max Loan (No Mortgage)</div><div class="val teal">${fmtINR(r.maxUnsecured)}</div></div>
      <div class="stat"><div class="lbl">PAN Number</div><div class="val">${r.pan?escapeHtml(r.pan):'—'}</div></div>
    </div>
    <div class="card" style="background:#fbfcfd;box-shadow:none;padding:14px;margin-bottom:12px;">
      <b style="font-size:13px;color:var(--navy);">Why this result?</b>
      <ul style="margin:8px 0 0;padding-left:18px;font-size:12.5px;color:var(--text-mid);">${r.reasons.map(x=>`<li>${x}</li>`).join('')}</ul>
    </div>
    ${r.suggestions.length? `<div class="card" style="background:var(--teal-light);box-shadow:none;padding:14px;margin-bottom:12px;">
      <b style="font-size:13px;color:var(--navy);">💡 Suggestions to improve eligibility</b>
      <ul style="margin:8px 0 0;padding-left:18px;font-size:12.5px;color:var(--text-mid);">${r.suggestions.map(x=>`<li>${x}</li>`).join('')}</ul>
    </div>`:''}
    ${r.mortgageRequired? `<div class="card" style="background:var(--orange-bg);box-shadow:none;padding:14px;">
      <b style="font-size:13px;color:var(--orange);">🏠 Mortgage Required</b>
      <p style="font-size:12.5px;color:var(--text-mid);margin:6px 0 0;">Your requested amount (${fmtINR(r.amount)}) exceeds the unsecured limit of ${fmtINR(r.maxUnsecured)}. A property mortgage is required as collateral.
      Estimated minimum property value needed (at 80% LTV): <b>${fmtINR(r.requiredPropertyValue)}</b>.</p>
    </div>` : `<div class="card" style="background:var(--green-bg);box-shadow:none;padding:14px;"><b style="font-size:13px;color:var(--green);">✓ No mortgage required for this amount.</b></div>`}
    <button class="btn btn-teal btn-block" style="margin-top:14px;" onclick="go('apply')">Proceed to Apply →</button>
  `;
}

/* ================================================================
   APPLY FOR LOAN  (US-LA-01..06)
   ================================================================ */
let applyStep = 1;
let applyDraftId = null;
let applyData = {};
function freshApplyData(){
  const u = currentUser();
  const emp = u.employment||{};
  return {
    loanType:'Home Purchase Loan', loanAmount: emp.desiredAmount||2500000, tenureYears:20, purpose:'Purchase of Residential Property',
    personal:{ name:u.name, mobile:u.mobile, email:u.email, pan: emp.pan||'', address:{doorNo:'',street:'',city:'',state:'',pincode:''} },
    employment:{ type:emp.type||'Salaried', employer:'', monthlyIncome:emp.monthlyIncome||60000, otherEMIs:emp.otherEMIs||0 },
    property:{ address:'', type:'Residential', value:0, addressFile:null },
    documents:{ idProof:false, incomeProof:false, addressProof:false, propertyDocs:false, bankStatement:false }
  };
}
function viewApply(){
  const drafts = myDrafts();
  if(!applyData.loanType) applyData = freshApplyData();
  return `
  <div class="page-head"><h1>Apply for Housing Loan</h1><p>Complete the steps below to submit your application online — no paperwork or branch visit required.</p></div>

  ${drafts.length? `<div class="card" style="background:var(--orange-bg);box-shadow:none;">
    <h3 style="color:var(--orange);">📝 Saved Drafts (${drafts.length})</h3>
    ${drafts.map(d=>`<div class="doc-row"><div><div class="name">${d.loanType} — ${fmtINR(d.loanAmount)}</div><div class="meta">Saved ${fmtDate(d.savedAt)}</div></div>
      <div><button class="btn btn-outline btn-sm" onclick="resumeDraft('${d.id}')">Resume</button> <button class="btn btn-outline btn-sm" onclick="deleteDraft('${d.id}')">Delete</button></div></div>`).join('')}
  </div>`:''}

  <div class="card">
    <div class="stepper">
      ${['Loan Details','Employment','Property','Documents','Review'].map((s,i)=>{
        const n=i+1;
        return `<div class="step ${applyStep>n?'done':applyStep===n?'current':''}"><div class="dot">${applyStep>n?'✓':n}</div><div class="lbl">${s}</div></div>`;
      }).join('')}
    </div>
    <div id="applyStepBody">${renderApplyStep()}</div>
  </div>
  `;
}
function afterApply(){}
function renderApplyStep(){
  if(applyStep===1) return stepLoanDetails();
  if(applyStep===2) return stepEmployment();
  if(applyStep===3) return stepProperty();
  if(applyStep===4) return stepDocuments();
  if(applyStep===5) return stepReview();
}
function stepLoanDetails(){
  const d = applyData;
  const addr = d.personal.address && typeof d.personal.address==='object' ? d.personal.address : {doorNo:'',street:'',city:'',state:'',pincode:''};
  return `  
  <div class="two-col">
    <div class="field"><label>Loan Type<span class="req">*</span></label><select id="apLoanType">${LOAN_PRODUCTS.map(p=>`<option ${d.loanType===p.name?'selected':''}>${p.name}</option>`).join('')}</select></div>
    <div class="field"><label>Purpose<span class="req">*</span></label><input id="apPurpose" value="${escapeHtml(d.purpose)}"></div>
  </div>
  <div class="field"><label>Loan Amount (₹)<span class="req">*</span></label><input type="number" id="apAmount" min="200000" max="200000000"  value="${d.loanAmount}"><div class="error hidden" id="err_apAmount"></div></div>
  <div class="field"><label>Tenure (Years): <b id="apTenureLbl">${d.tenureYears}</b><span class="req">*</span></label><input type="range" min="1" max="30" id="apTenure" value="${d.tenureYears}" oninput="$('#apTenureLbl').textContent=this.value"></div>
  <div class="field"><label>Full Name<span class="req">*</span></label><input id="apName" value="${escapeHtml(d.personal.name)}"><div class="error hidden" id="err_apName"></div></div>
  <div class="two-col">
    <div class="field"><label>Mobile<span class="req">*</span></label><input id="apMobile" value="${escapeHtml(d.personal.mobile)}"><div class="error hidden" id="err_apMobile"></div></div>
    <div class="field"><label>Email<span class="req">*</span></label><input id="apEmail" value="${escapeHtml(d.personal.email)}"><div class="error hidden" id="err_apEmail"></div></div>
  </div>
  <div class="field"><label>PAN Number<span class="req">*</span></label><input id="apPan" maxlength="10" style="text-transform:uppercase;" placeholder="e.g. ABCDE1234F" value="${escapeHtml(d.personal.pan||'')}"><div class="error hidden" id="err_apPan"></div></div>
  <div class="field"><label>Current Address<span class="req">*</span></label></div>
  <div class="two-col">
    <div class="field"><label>Door / Flat No.<span class="req">*</span></label><input id="apAddrDoor" value="${escapeHtml(addr.doorNo)}"><div class="error hidden" id="err_apAddrDoor"></div></div>
    <div class="field"><label>Street / Locality<span class="req">*</span></label><input id="apAddrStreet" value="${escapeHtml(addr.street)}"><div class="error hidden" id="err_apAddrStreet"></div></div>
  </div>
  <div class="two-col">
    <div class="field"><label>City<span class="req">*</span></label><input id="apAddrCity" value="${escapeHtml(addr.city)}"><div class="error hidden" id="err_apAddrCity"></div></div>
    <div class="field"><label>State<span class="req">*</span></label><input id="apAddrState" value="${escapeHtml(addr.state)}"><div class="error hidden" id="err_apAddrState"></div></div>
  </div>
  <div class="field"><label>Pincode<span class="req">*</span></label><input id="apAddrPincode" maxlength="6" value="${escapeHtml(addr.pincode)}"><div class="error hidden" id="err_apAddrPincode"></div></div>
  <div style="display:flex;justify-content:space-between;margin-top:16px;">
    <button class="btn btn-outline" onclick="saveDraftNow()">Save as Draft</button>
    <button class="btn btn-primary" onclick="nextStep(1)">Next →</button>
  </div>`;
}
function stepEmployment(){
  const e = applyData.employment;
  return `
  <div class="two-col">
    <div class="field"><label>Employment Type<span class="req">*</span></label><select id="apEmpType"><option ${e.type==='Salaried'?'selected':''}>Salaried</option><option ${e.type==='Self-Employed'?'selected':''}>Self-Employed</option></select></div>
    <div class="field"><label>Employer / Business Name<span class="req">*</span></label><input id="apEmployer" value="${escapeHtml(e.employer)}"><div class="error hidden" id="err_apEmployer"></div></div>
  </div>
  <div class="two-col">
    <div class="field"><label required>Monthly Income (₹)<span class="req">*</span></label><input type="number" id="apIncome" value="${e.monthlyIncome}"><div class="error hidden" id="err_apIncome"></div></div>
    <div class="field"><label>Other Monthly EMIs (₹)<span class="req">*</span></label><input type="number" id="apOtherEmi" value="${e.otherEMIs}"></div>
  </div>
  <div style="display:flex;justify-content:space-between;margin-top:16px;">
    <button class="btn btn-outline" onclick="prevStep()">← Back</button>
    <div><button class="btn btn-outline" onclick="saveDraftNow()">Save Draft</button> <button class="btn btn-primary" onclick="nextStep(2)">Next →</button></div>
  </div>`;
}
function stepProperty(){
  const p = applyData.property;
  const elig = assessEligibility(applyData.employment.monthlyIncome, applyData.employment.otherEMIs, applyData.loanAmount, applyData.tenureYears);
  return `
  <div class="field"><label>Property Address<span class="req">*</span></label><textarea id="apPropAddress" rows="2">${escapeHtml(p.address)}</textarea><div class="error hidden" id="err_apPropAddress"></div></div>
  <div class="field">
    <label>Upload Property Address Proof<span class="req">*</span></label>
    <div class="upload-box" onclick="document.getElementById('apPropAddressFile').click()">
      <input type="file" id="apPropAddressFile" accept=".pdf,.jpg,.jpeg,.png" onchange="handlePropAddressFile(this)">
      📎 ${p.addressFile ? 'Replace file — '+(p.addressFile.name||'uploaded') : 'Click to upload a document showing the property address'}
    </div>
    <div class="error hidden" id="err_apPropAddressFile"></div>
  </div>
  <div class="two-col">
    <div class="field"><label>Property Type<span class="req">*</span></label><select id="apPropType"><option ${p.type==='Residential'?'selected':''}>Residential</option><option ${p.type==='Plot'?'selected':''}>Plot</option><option ${p.type==='Under Construction'?'selected':''}>Under Construction</option></select></div>
    <div class="field"><label>Estimated Property Value (₹)<span class="req">*</span></label><input type="number" id="apPropValue" value="${p.value||0}"><div class="error hidden" id="err_apPropValue"></div></div>
  </div>
  ${elig.mortgageRequired? `<div class="card" style="background:var(--orange-bg);box-shadow:none;padding:14px;">
    <b style="color:var(--orange);font-size:13px;">🏠 Mortgage Required</b>
    <p style="font-size:12.5px;color:var(--text-mid);margin:6px 0 0;">Your loan amount exceeds the unsecured limit of ${fmtINR(elig.maxUnsecured)}. Minimum property value required: <b>${fmtINR(elig.requiredPropertyValue)}</b> (at 80% LTV).</p>
    <p id="collateralMsg" style="font-size:12.5px;margin:8px 0 0;font-weight:700;"></p>
  </div>`:'<div class="card" style="background:var(--green-bg);box-shadow:none;padding:14px;"><b style="color:var(--green);font-size:13px;">✓ No mortgage required for this loan amount.</b></div>'}
  <div style="display:flex;justify-content:space-between;margin-top:16px;">
    <button class="btn btn-outline" onclick="prevStep()">← Back</button>
    <div><button class="btn btn-outline" onclick="saveDraftNow()">Save Draft</button> <button class="btn btn-primary" onclick="nextStep(3)">Next →</button></div>
  </div>`;
}
function stepDocuments(){
  const docs = applyData.documents;
  const elig = assessEligibility(applyData.employment.monthlyIncome, applyData.employment.otherEMIs, applyData.loanAmount, applyData.tenureYears);
  let items = [
    {key:'idProof', label:'Identity Proof (Aadhaar / PAN)'},
    {key:'incomeProof', label:'Income Proof (Salary Slip / ITR)'},
    {key:'addressProof', label:'Address Proof'},
    {key:'bankStatement', label:'Bank Statement (Last 6 months)'},
    {key:'propertyDocs', label:'Property Documents'}
  ];
  // Skip mortgage/property documents when the requested amount is within the unsecured eligibility limit
  if(elig.mortgageRequired){
  items.push({key:'mortgageDocs', label:'Mortgage Documents (Title Deed / Ownership Proof)'});
} else {
  delete docs.mortgageDocs;
}
  return `
  <p style="font-size:13px;color:var(--text-mid);margin-top:0;">All documents below are mandatory. Accepted formats: PDF, JPG, PNG. Max size 5MB per file.</p>
  ${!elig.mortgageRequired? `<div class="card" style="background:var(--green-bg);box-shadow:none;padding:12px;margin-bottom:12px;"><b style="font-size:12.5px;color:var(--green);">✓ Your requested amount is within your unsecured eligibility — property/mortgage documents are not required.</b></div>` : ''}
  ${items.map(it=>`
    <div class="field">
      <label>${it.label} ${docs[it.key]?'<span class="badge badge-green" style="margin-left:6px;">Uploaded</span>':'<span class="badge badge-red" style="margin-left:6px;">Required</span>'}</label>
      <div class="upload-box" onclick="document.getElementById('file_${it.key}').click()">
        <input type="file" id="file_${it.key}" accept=".pdf,.jpg,.jpeg,.png" onchange="handleDocUpload('${it.key}', this)">
        📎 ${docs[it.key] ? 'Replace file — '+ (docs[it.key].name||'uploaded') : 'Click to upload file'}
      </div>
    </div>
  `).join('')}
  <div class="error hidden" id="err_apDocs"></div>
  <div style="display:flex;justify-content:space-between;margin-top:16px;">
    <button class="btn btn-outline" onclick="prevStep()">← Back</button>
    <div><button class="btn btn-outline" onclick="saveDraftNow()">Save Draft</button> <button class="btn btn-primary" onclick="nextStep(4)">Next →</button></div>
  </div>`;
}
function stepReview(){
  const d = applyData;
  return `
  <h3 style="margin-top:0;">Review Your Application</h3>
  <div class="grid grid-2">
    <div class="stat"><div class="lbl">Loan Type</div><div class="val">${d.loanType}</div></div>
    <div class="stat"><div class="lbl">Loan Amount</div><div class="val">${fmtINR(d.loanAmount)}</div></div>
    <div class="stat"><div class="lbl">Tenure</div><div class="val">${d.tenureYears} Years</div></div>
    <div class="stat"><div class="lbl">Purpose</div><div class="val">${escapeHtml(d.purpose)}</div></div>
    <div class="stat"><div class="lbl">Applicant</div><div class="val">${escapeHtml(d.personal.name)}</div></div>
    <div class="stat"><div class="lbl">PAN Number</div><div class="val">${escapeHtml(d.personal.pan||'—')}</div></div>
    <div class="stat"><div class="lbl">Contact</div><div class="val">${escapeHtml(d.personal.mobile)} / ${escapeHtml(d.personal.email)}</div></div>
    <div class="stat"><div class="lbl">Employment</div><div class="val">${d.employment.type} — ${escapeHtml(d.employment.employer)}</div></div>
    <div class="stat"><div class="lbl">Monthly Income</div><div class="val">${fmtINR(d.employment.monthlyIncome)}</div></div>
    <div class="stat"><div class="lbl">Property</div><div class="val">${d.property.type} — ${fmtINR(d.property.value)}</div></div>
  </div>
  <div style="margin:14px 0;"><b style="font-size:13px;color:var(--navy);">Documents:</b>
    <div style="margin-top:6px;">${Object.entries(d.documents).map(([k,v])=>`<span class="badge ${v?'badge-green':'badge-red'}" style="margin-right:6px;margin-bottom:6px;display:inline-block;">${k}: ${v?'Uploaded':'Missing'}</span>`).join('')}</div>
  </div>
  <label class="chk-row" style="margin-bottom:14px;"><input type="checkbox" id="apConfirm"> I confirm the above details are accurate and complete.</label>
  <div class="error hidden" id="err_apConfirm"></div>
  <div style="display:flex;justify-content:space-between;">
    <button class="btn btn-outline" onclick="prevStep()">← Back to Edit</button>
    <button class="btn btn-primary" onclick="submitApplication()">Submit Application</button>
  </div>`;
}
function collectStepData(step){
  const d = applyData;
  if(step===1){
    d.loanType = $('#apLoanType').value; d.purpose = $('#apPurpose').value; d.loanAmount = Number($('#apAmount').value||0);
    d.tenureYears = Number($('#apTenure').value||1);
    d.personal.name = $('#apName').value.trim(); d.personal.mobile = $('#apMobile').value.trim(); d.personal.email = $('#apEmail').value.trim();
    d.personal.pan = $('#apPan').value.trim().toUpperCase();
    d.personal.address = {
      doorNo: $('#apAddrDoor').value.trim(), street: $('#apAddrStreet').value.trim(),
      city: $('#apAddrCity').value.trim(), state: $('#apAddrState').value.trim(), pincode: $('#apAddrPincode').value.trim()
    };
  } else if(step===2){
    d.employment.type = $('#apEmpType').value; d.employment.employer = $('#apEmployer').value.trim();
    d.employment.monthlyIncome = Number($('#apIncome').value||0); d.employment.otherEMIs = Number($('#apOtherEmi').value||0);
  } else if(step===3){
    d.property.address = $('#apPropAddress').value.trim(); d.property.type = $('#apPropType').value; d.property.value = Number($('#apPropValue').value||0);
  }
}
function validateStep(step){
  let ok=true;
  if(step===1){
    // if(applyData.loanAmount<=0) ok = fieldError($('#apAmount'),$('#err_apAmount'),'Enter a valid loan amount.') && ok; else fieldOk($('#apAmount'),$('#err_apAmount'));
    if(applyData.loanAmount<200000||applyData.loanAmount>200000000) ok = fieldError($('#apAmount'),$('#err_apAmount'),'Loan amount must be between ₹2,00,000 and ₹20,00,00,000.') && ok; else fieldOk($('#apAmount'),$('#err_apAmount'));
    if(!applyData.personal.name) ok = fieldError($('#apName'),$('#err_apName'),'Name is required.') && ok; else fieldOk($('#apName'),$('#err_apName'));
    if(!REGEX.mobile.test(applyData.personal.mobile)) ok = fieldError($('#apMobile'),$('#err_apMobile'),'Enter a valid 10-digit mobile number.') && ok; else fieldOk($('#apMobile'),$('#err_apMobile'));
    if(!REGEX.email.test(applyData.personal.email)) ok = fieldError($('#apEmail'),$('#err_apEmail'),'Enter a valid email address.') && ok; else fieldOk($('#apEmail'),$('#err_apEmail'));
    if(!REGEX.pan.test(applyData.personal.pan||'')) ok = fieldError($('#apPan'),$('#err_apPan'),'Enter a valid PAN (e.g. ABCDE1234F).') && ok; else fieldOk($('#apPan'),$('#err_apPan'));
    const addr = applyData.personal.address||{};
    if(!addr.doorNo) ok = fieldError($('#apAddrDoor'),$('#err_apAddrDoor'),'Door / Flat No. is required.') && ok; else fieldOk($('#apAddrDoor'),$('#err_apAddrDoor'));
    if(!addr.street) ok = fieldError($('#apAddrStreet'),$('#err_apAddrStreet'),'Street / Locality is required.') && ok; else fieldOk($('#apAddrStreet'),$('#err_apAddrStreet'));
    if(!addr.city) ok = fieldError($('#apAddrCity'),$('#err_apAddrCity'),'City is required.') && ok; else fieldOk($('#apAddrCity'),$('#err_apAddrCity'));
    if(!addr.state) ok = fieldError($('#apAddrState'),$('#err_apAddrState'),'State is required.') && ok; else fieldOk($('#apAddrState'),$('#err_apAddrState'));
    if(!/^\d{6}$/.test(addr.pincode||'')) ok = fieldError($('#apAddrPincode'),$('#err_apAddrPincode'),'Enter a valid 6-digit pincode.') && ok; else fieldOk($('#apAddrPincode'),$('#err_apAddrPincode'));
  }
  if(step===2){
    if(!applyData.employment.employer) ok = fieldError($('#apEmployer'),$('#err_apEmployer'),'This field is required.') && ok; else fieldOk($('#apEmployer'),$('#err_apEmployer'));
    if(applyData.employment.monthlyIncome<=0) ok = fieldError($('#apIncome'),$('#err_apIncome'),'Enter a valid monthly income.') && ok; else fieldOk($('#apIncome'),$('#err_apIncome'));
  }
  if(step===3){
    if(!applyData.property.address) ok = fieldError($('#apPropAddress'),$('#err_apPropAddress'),'Property address is required.') && ok; else fieldOk($('#apPropAddress'),$('#err_apPropAddress'));
    if(applyData.property.value<=0) ok = fieldError($('#apPropValue'),$('#err_apPropValue'),'Enter a valid property value.') && ok; else fieldOk($('#apPropValue'),$('#err_apPropValue'));
    if(!applyData.property.addressFile) ok = fieldError({style:{}},$('#err_apPropAddressFile'),'Please upload a property address proof document.') && ok; else fieldOk({style:{}},$('#err_apPropAddressFile'));
  }
  if(step===4){
    const elig = assessEligibility(applyData.employment.monthlyIncome, applyData.employment.otherEMIs, applyData.loanAmount, applyData.tenureYears);
    const missing = Object.entries(applyData.documents)
      .filter(([k,v])=> !(k==='propertyDocs' && !elig.mortgageRequired))
      .filter(([k,v])=>!v).map(([k])=>k);
    if(missing.length){ ok = fieldError({style:{}}, $('#err_apDocs'), 'Please upload all mandatory documents: '+missing.join(', ')) && ok; }
    else fieldOk({style:{}}, $('#err_apDocs'));
  }
  return ok;
}
function nextStep(fromStep){
  collectStepData(fromStep);
  if(!validateStep(fromStep)) return;
  applyStep++;
  render('apply');
}
function prevStep(){ applyStep = Math.max(1, applyStep-1); render('apply'); }
function handleDocUpload(key, input){
  const file = input.files[0]; if(!file) return;
  const okTypes = ['application/pdf','image/jpeg','image/jpg','image/png'];
  if(!okTypes.includes(file.type)) { toast('Invalid File','Only PDF, JPG, PNG files are allowed.','error'); input.value=''; return; }
  if(file.size > 5*1024*1024){ toast('File Too Large','Maximum file size is 5MB.','error'); input.value=''; return; }
  applyData.documents[key] = {name:file.name, size:file.size, uploadedAt:new Date().toISOString()};
  toast('File Uploaded', file.name, 'success');
  render('apply');
}
function handlePropAddressFile(input){
  const file = input.files[0]; if(!file) return;
  const okTypes = ['application/pdf','image/jpeg','image/jpg','image/png'];
  if(!okTypes.includes(file.type)) { toast('Invalid File','Only PDF, JPG, PNG files are allowed.','error'); input.value=''; return; }
  if(file.size > 5*1024*1024){ toast('File Too Large','Maximum file size is 5MB.','error'); input.value=''; return; }
  applyData.property.addressFile = {name:file.name, size:file.size, uploadedAt:new Date().toISOString()};
  toast('File Uploaded', file.name, 'success');
  render('apply');
}
function saveDraftNow(){
  collectStepData(applyStep);
  const u = currentUser();
  const draft = {...applyData, id: applyDraftId||uid('draft'), userEmail:u.email, savedAt:new Date().toISOString(), step:applyStep};
  applyDraftId = draft.id;
  const idx = DB.drafts.findIndex(d=>d.id===draft.id);
  if(idx>=0) DB.drafts[idx]=draft; else DB.drafts.push(draft);
  saveDB();
  toast('Draft Saved','You can resume this application anytime.','success');
  render('apply');
}
function resumeDraft(id){
  const d = DB.drafts.find(x=>x.id===id); if(!d) return;
  applyData = JSON.parse(JSON.stringify(d));
  applyDraftId = d.id; applyStep = d.step||1;
  render('apply');
}
function deleteDraft(id){ DB.drafts = DB.drafts.filter(d=>d.id!==id); saveDB(); render('apply'); }
function submitApplication(){
  collectStepData(5);
  if(!$('#apConfirm').checked) return fieldError({style:{}}, $('#err_apConfirm'), 'Please confirm before submitting.');
  fieldOk({style:{}}, $('#err_apConfirm'));
  const u = currentUser();
  const trackNo = 'APP-'+new Date().getFullYear()+'-'+String(DB.nextTrack++).padStart(5,'0');
  const app = {
    id: uid('app'), trackingNo: trackNo, userEmail: u.email, createdAt: new Date().toISOString(),
    loanType: applyData.loanType, loanAmount: applyData.loanAmount, tenureYears: applyData.tenureYears, purpose: applyData.purpose,
    interestRate: (LOAN_PRODUCTS.find(p=>p.name===applyData.loanType)||{rate:STANDARD_RATE}).rate,
    personal: applyData.personal, employment: applyData.employment, property: applyData.property, documents: applyData.documents,
    status:'Submitted', stageIndex:0
  };
  DB.applications.push(app);
  if(applyDraftId){ DB.drafts = DB.drafts.filter(d=>d.id!==applyDraftId); }
  saveDB();
  pushNotification(u.email, 'Application Submitted', 'Your application '+trackNo+' has been submitted successfully.', notifChannels(u.email));
  toast('Application Submitted!', 'Tracking No: '+trackNo, 'success');
  applyData = {}; applyStep = 1; applyDraftId = null;
  go('tracking');
}

/* ================================================================
   LOAN STATUS TRACKING (US-LT-01..06)
   ================================================================ */
let trackingSelectedId = null;
function viewTracking(){
  const apps = myApplications();
  if(!apps.length) return `<div class="page-head"><h1>Loan Status Tracking</h1><p>Track your application in real time.</p></div>
    <div class="card"><div class="empty-state"><div class="ic">📭</div>No applications submitted yet.<br><button class="btn btn-primary btn-sm" style="margin-top:10px;" onclick="go('apply')">Apply Now</button></div></div>`;
  if(!trackingSelectedId || !apps.find(a=>a.id===trackingSelectedId)) trackingSelectedId = apps[0].id;
  const app = apps.find(a=>a.id===trackingSelectedId);
  const stages = buildStages(app);
  const pendingTasks = [];
  Object.entries(app.documents||{}).forEach(([k,v])=>{ if(!v) pendingTasks.push('Upload missing document: '+k); });
  if(app.status==='Under Review' && app.stageIndex===3 && app.property.value < (assessEligibility(app.employment.monthlyIncome, app.employment.otherEMIs, app.loanAmount, app.tenureYears).requiredPropertyValue)){
    pendingTasks.push('Provide additional collateral — property value insufficient for requested loan amount.');
  }
  if(!pendingTasks.length) pendingTasks.push('No pending actions. We will notify you when the next stage begins.');

  return `
  <div class="page-head"><h1>Loan Status Tracking</h1><p>Monitor your application progress in real time.</p></div>
  ${apps.length>1? `<div class="field" style="max-width:360px;"><label>Select Application</label>
    <select onchange="trackingSelectedId=this.value; render('tracking')">${apps.map(a=>`<option value="${a.id}" ${a.id===app.id?'selected':''}>${a.trackingNo} — ${a.loanType}</option>`).join('')}</select></div>`:''}

  ${app.status==='Rejected'? renderRejectionBanner(app) : ''}

  <div class="grid grid-2">
    <div class="card">
      <h3>📍 Application Summary</h3>
      <div class="grid grid-2">
        <div class="stat"><div class="lbl">Tracking No.</div><div class="val">${app.trackingNo}</div></div>
        <div class="stat"><div class="lbl">Status</div><div class="val"><span class="badge badge-navy">${app.status}</span></div></div>
        <div class="stat"><div class="lbl">Loan Type</div><div class="val">${app.loanType}</div></div>
        <div class="stat"><div class="lbl">Amount</div><div class="val">${fmtINR(app.loanAmount)}</div></div>
        <div class="stat"><div class="lbl">Current Stage</div><div class="val">${WORKFLOW_STAGES[app.stageIndex]}</div></div>
        <div class="stat"><div class="lbl">Handled By</div><div class="val">${stages[app.stageIndex].officer}</div></div>
      </div>
      <div style="margin-top:16px;">
        <button class="btn btn-teal btn-sm" onclick="advanceStage('${app.id}')">🔄 Simulate: Advance to Next Stage</button>
        <p style="font-size:11px;color:var(--text-gray);margin-top:6px;">Demo control — since this app has no backend, use this to simulate the bank processing your application.</p>
      </div>
    </div>
    <div class="card">
      <h3>⏳ Pending Tasks / Required Actions</h3>
      <ul style="padding-left:18px;font-size:13px;color:var(--text-mid);line-height:1.8;">${pendingTasks.map(t=>`<li>${t}</li>`).join('')}</ul>
    </div>
  </div>

  <div class="card">
    <h3>🗂️ Workflow Timeline</h3>
    <div class="timeline">
      ${stages.map((s,i)=>`
        <div class="tl-item ${s.status==='completed'?'done':s.status==='current'?'current':''}">
          <div class="tl-dot">${s.status==='completed'?'✓':i+1}</div>
          <div class="tl-body">
            <h5>${s.name}</h5>
            <p>${s.status==='completed'?'Completed':s.status==='current'?'In Progress':'Upcoming'} · Expected: ${fmtDate(s.expectedDate)} </p>
          </div>
        </div>`).join('')}
    </div>
  </div>
  `;
}
function afterTracking(){}
function renderRejectionBanner(app){
  const info = getRejectionInfo(app);
  if(!info) return '';
  return `
  <div class="card" style="background:var(--red-bg);box-shadow:none;">
    <h3 style="color:var(--red);">✕ Application Rejected</h3>
    <table><tbody>
      <tr><td>Rejected By</td><td style="text-align:right;">${escapeHtml(info.by)}</td></tr>
      <tr><td>Officer</td><td style="text-align:right;">${escapeHtml(info.officer||'—')}</td></tr>
      <tr><td>Date</td><td style="text-align:right;">${fmtDate(info.date)}</td></tr>
    </tbody></table>
    <div class="field" style="margin-top:10px;"><label>Reason / Remarks</label>
      <div style="font-size:13px;color:var(--text-mid);background:#fff;border:1px solid var(--border);border-radius:8px;padding:10px 12px;">${escapeHtml(info.remarks)}</div>
    </div>
  </div>`;
}

/* ================================================================
   REPAYMENT (US-LRM-01..04)
   ================================================================ */
function viewRepayment(){
  const disbursed = myApplications().filter(a=>a.status==='Disbursed');
  if(!disbursed.length) return `<div class="page-head"><h1>Repayment</h1><p>Track EMI payments, schedule and outstanding balance.</p></div>
    <div class="card"><div class="empty-state"><div class="ic">💳</div>No disbursed loans yet. Repayment details will appear here once your loan is disbursed.</div></div>`;
  if(!window._repaySelected || !disbursed.find(a=>a.id===window._repaySelected)) window._repaySelected = disbursed[0].id;
  const app = disbursed.find(a=>a.id===window._repaySelected);
  const sched = app.repayment.schedule;
  const paidCount = sched.filter(s=>s.status==='Paid').length;
  const nextDue = sched.find(s=>s.status!=='Paid');
  const today = new Date();
  sched.forEach(s=>{ if(s.status!=='Paid' && new Date(s.dueDate)<today) s.status='Overdue'; });

  return `
  <div class="page-head"><h1>Repayment</h1><p>Track your EMI payments, schedule, and outstanding balance.</p></div>
  ${disbursed.length>1? `<div class="field" style="max-width:360px;"><label>Select Loan</label>
    <select onchange="window._repaySelected=this.value; render('repayment')">${disbursed.map(a=>`<option value="${a.id}" ${a.id===app.id?'selected':''}>${a.trackingNo}</option>`).join('')}</select></div>`:''}

  <div class="grid grid-4">
    <div class="card stat"><div class="lbl">EMI Amount</div><div class="val teal">${fmtINR(calcEMI(app.loanAmount, app.interestRate, app.tenureYears))}</div></div>
    <div class="card stat"><div class="lbl">Outstanding Balance</div><div class="val">${fmtINR(app.repayment.outstandingBalance)}</div></div>
    <div class="card stat"><div class="lbl">Installments Paid</div><div class="val">${paidCount} / ${sched.length}</div></div>
    <div class="card stat"><div class="lbl">Next Due Date</div><div class="val" style="${nextDue && nextDue.status==='Overdue'?'color:var(--red)':''}">${nextDue? fmtDate(nextDue.dueDate) + (nextDue.status==='Overdue'?' (Overdue)':'') : 'Fully Paid'}</div></div>
  </div>

  <div class="card">
    <div style="display:flex;justify-content:space-between;align-items:center;">
      <h3 style="margin:0;">📅 Repayment Schedule</h3>
      ${nextDue? `<button class="btn btn-primary btn-sm" onclick="payEmi('${app.id}', ${nextDue.no})">Pay Next EMI (${fmtINR(nextDue.emi)})</button>`:'<span class="badge badge-green">Loan Fully Repaid</span>'}
    </div>
    <div style="max-height:420px;overflow-y:auto;margin-top:12px;">
    <table><thead><tr><th>#</th><th>Due Date</th><th>EMI</th><th>Principal</th><th>Interest</th><th>Balance</th><th>Status</th></tr></thead>
    <tbody>${sched.map(s=>`<tr>
      <td>${s.no}</td><td>${fmtDate(s.dueDate)}</td><td>${fmtINR(s.emi)}</td><td>${fmtINR(s.principal)}</td><td>${fmtINR(s.interest)}</td><td>${fmtINR(s.balance)}</td>
      <td><span class="badge ${s.status==='Paid'?'badge-green':s.status==='Overdue'?'badge-red':'badge-gray'}">${s.status}</span></td>
    </tr>`).join('')}</tbody></table>
    </div>
  </div>
  `;
}
function afterRepayment(){}
function payEmi(appId, installmentNo){
  const app = DB.applications.find(a=>a.id===appId); if(!app) return;
  const inst = app.repayment.schedule.find(s=>s.no===installmentNo); if(!inst || inst.status==='Paid') return;
  inst.status='Paid'; inst.paidDate = new Date().toISOString();
  app.repayment.outstandingBalance = Math.max(0, inst.balance);
  saveDB();
  pushNotification(app.userEmail, 'EMI Payment Successful', 'Installment #'+installmentNo+' of '+fmtINR(inst.emi)+' recorded.', notifChannels(app.userEmail));
  toast('Payment Recorded', 'Installment #'+installmentNo+' marked as paid.', 'success');
  render('repayment');
}

/* ================================================================
   POST DISBURSEMENT (US-PD-01..04) — themed like the reference screenshot
   ================================================================ */
function viewPostDisb(){
  const disbursed = myApplications().filter(a=>a.status==='Disbursed');
  if(!disbursed.length) return `<div class="page-head"><h1>Post Disbursement</h1><p>Manage your loan after disbursement and track property &amp; account details.</p></div>
    <div class="card"><div class="empty-state"><div class="ic">🏠</div>No disbursed loans yet. This section unlocks after your loan is disbursed.</div></div>`;
  if(!window._pdSelected || !disbursed.find(a=>a.id===window._pdSelected)) window._pdSelected = disbursed[0].id;
  const app = disbursed.find(a=>a.id===window._pdSelected);
  const disb = app.disbursement;
  const myReqs = DB.serviceRequests.filter(r=>r.appId===app.id);

  return `
  <div class="page-head"><h1>Post Disbursement</h1><p>Manage your loan after disbursement and track property &amp; account details.</p></div>
  ${disbursed.length>1? `<div class="field" style="max-width:360px;"><label>Select Loan Account</label>
    <select onchange="window._pdSelected=this.value; render('postdisb')">${disbursed.map(a=>`<option value="${a.id}" ${a.id===app.id?'selected':''}>${a.trackingNo} - ${a.loanType}</option>`).join('')}</select></div>`:''}

  <div class="grid" style="grid-template-columns:2.2fr 1fr;">
    <div class="card">
      <div class="grid grid-3">
        <div class="stat"><div class="lbl">Loan Account No.</div><div class="val">${app.trackingNo}</div></div>
        <div class="stat"><div class="lbl">Loan Tenure</div><div class="val">${app.tenureYears} Years</div></div>
        <div class="stat"><div class="lbl">Loan Type</div><div class="val">${app.loanType}</div></div>
        <div class="stat"><div class="lbl">Interest Rate (p.a.)</div><div class="val">${app.interestRate}%</div></div>
        <div class="stat"><div class="lbl">Loan Amount</div><div class="val">${fmtINR(app.loanAmount)}</div></div>
        <div class="stat"><div class="lbl">EMI Amount</div><div class="val">${fmtINR(calcEMI(app.loanAmount, app.interestRate, app.tenureYears))}</div></div>
        <div class="stat"><div class="lbl">Disbursed Amount</div><div class="val">${fmtINR(disb.amount)}</div></div>
        <div class="stat"><div class="lbl">Next EMI Due</div><div class="val">${fmtDate(app.repayment.schedule.find(s=>s.status!=='Paid')?.dueDate || disb.date)}</div></div>
      </div>
    </div>
    <div class="card">
      <h3>Quick Links</h3>
      <div class="quick-links">
        <a href="#" onclick="go('repayment');return false;">View Repayment Schedule <span class="arrow">→</span></a>
        <a href="#" onclick="go('repayment');return false;">View Amortization Schedule <span class="arrow">→</span></a>
        <a href="#" onclick="downloadDisbursementLetter('${app.id}')">Download Disbursement Letter <span class="arrow">→</span></a>
      </div>
    </div>
  </div>

  <div class="grid grid-3">
    <div class="card">
      <h3>💲 Disbursement Details</h3>
      <table><tbody>
        <tr><td>Disbursement Date</td><td style="text-align:right;">${fmtDate(disb.date)}</td></tr>
        <tr><td>Reference No.</td><td style="text-align:right;">${disb.refNo}</td></tr>
        <tr><td>Disbursed To</td><td style="text-align:right;">${escapeHtml(app.personal.name)}</td></tr>
        <tr><td>Disbursement Mode</td><td style="text-align:right;">${disb.mode}</td></tr>
        <tr><td>Bank</td><td style="text-align:right;">${disb.bank}</td></tr>
        <tr><td>Purpose</td><td style="text-align:right;">${escapeHtml(app.purpose)}</td></tr>
      </tbody></table>
      <div style="margin-top:10px;"><a href="#" onclick="downloadDisbursementLetter('${app.id}')">📄 View Disbursement Letter</a></div>
    </div>
    <div class="card">
      <h3>⌂ Property Details</h3>
      <table><tbody>
        <tr><td>Address</td><td style="text-align:right;">${escapeHtml(app.property.address)}</td></tr>
        <tr><td>Property Type</td><td style="text-align:right;">${app.property.type}</td></tr>
        <tr><td>Property Value</td><td style="text-align:right;">${fmtINR(app.property.value)}</td></tr>
        <tr><td>Loan To Value (LTV)</td><td style="text-align:right;">${Math.round(app.loanAmount/app.property.value*100)}%</td></tr>
        <tr><td>Legal Verification</td><td style="text-align:right;"><span class="badge badge-green">Completed</span></td></tr>
      </tbody></table>
      <div style="margin-top:10px;"><a href="#" onclick="downloadDoc('Property Documents - '+'${app.trackingNo}')">📄 View Property Documents</a></div>
    </div>
    <div class="card">
      <h3>○ Insurance Details</h3>
      <table><tbody>
        <tr><td>Property Insurance</td><td style="text-align:right;"><span class="badge badge-green">${disb.insurance.property.status}</span></td></tr>
        <tr><td colspan="2" style="font-size:11px;color:var(--text-gray);">Valid till ${fmtDate(disb.insurance.property.validTill)}</td></tr>
        <tr><td>Life Insurance</td><td style="text-align:right;"><span class="badge badge-green">${disb.insurance.life.status}</span></td></tr>
        <tr><td colspan="2" style="font-size:11px;color:var(--text-gray);">Valid till ${fmtDate(disb.insurance.life.validTill)}</td></tr>
      </tbody></table>
    </div>
  </div>

  <div class="grid grid-2">
    <div class="card">
      <h3>🛎️ Raise a Service Request</h3>
      <div class="field"><label>Request Type</label>
        <select id="pdReqType">
          <option>NOC / Loan Closure Letter</option><option>Interest Certificate</option>
          <option>Property Document Retrieval</option><option>Engineer Inspection Request</option>
          <option>EMI Date Change Request</option><option>Other</option>
        </select>
      </div>
      <div class="field"><label>Description</label><textarea id="pdReqDesc" rows="3" placeholder="Describe your request..."></textarea><div class="error hidden" id="err_pdReqDesc"></div></div>
      <button class="btn btn-primary" onclick="submitServiceRequest('${app.id}')">Submit Request</button>
    </div>
    <div class="card">
      <h3>📨 My Service Requests</h3>
      ${myReqs.length? `<table><thead><tr><th>Ref</th><th>Type</th><th>Status</th></tr></thead><tbody>
        ${myReqs.map(r=>`<tr><td>${r.ref}</td><td>${escapeHtml(r.type)}</td><td><span class="badge ${r.status==='Completed'?'badge-green':r.status==='In Progress'?'badge-orange':'badge-gray'}">${r.status}</span></td></tr>`).join('')}
      </tbody></table>
      ${myReqs.some(r=>r.status!=='Completed')? `<button class="btn btn-outline btn-sm" style="margin-top:10px;" onclick="advanceServiceRequest('${myReqs.find(r=>r.status!=='Completed').id}')">🔄 Simulate: Advance Request Status</button>`:''}
      `:'<div class="empty-state"><div class="ic">📭</div>No service requests yet.</div>'}
    </div>
  </div>

  <div class="grid grid-2">
    <div class="card">
      <h3>📤 Upload Document for Legal Verification</h3>
      <p style="font-size:12.5px;color:var(--text-mid);margin-top:0;">Upload any post-disbursement document (e.g. renewed insurance, updated KYC, address change proof). The Legal &amp; Valuation Team will review and verify it.</p>
      <div class="field"><label>Document Type</label>
        <select id="pdDocType">${PD_DOC_TYPES.map(t=>`<option>${t}</option>`).join('')}</select>
      </div>
      <div class="field"><label>Note (optional)</label><textarea id="pdDocNote" rows="2" placeholder="Add a short note for the legal team..."></textarea></div>
      <div class="upload-box" onclick="document.getElementById('pdDocFile').click()">
        <input type="file" id="pdDocFile" accept=".pdf,.jpg,.jpeg,.png" onchange="handlePostDisbDocUpload('${app.id}', this)">
        📎 Click to upload file (PDF, JPG, PNG · Max 5MB)
      </div>
    </div>
    <div class="card">
      <h3>📑 My Uploaded Documents</h3>
      ${!ensurePostDisbDocs(app).length? `<div class="empty-state"><div class="ic">📭</div>No documents uploaded yet for this loan account.</div>` :
        `<table><thead><tr><th>Document</th><th>Type</th><th>Status</th><th></th></tr></thead><tbody>
        ${ensurePostDisbDocs(app).map(d=>`<tr>
          <td>${escapeHtml(d.name)}<div style="font-size:11px;color:var(--text-gray);">${fmtDate(d.uploadedAt)}</div></td>
          <td>${escapeHtml(d.type)}</td>
          <td><span class="badge ${pdDocBadgeClass(d.status)}">${d.status}</span>${d.status==='Rejected'&&d.remarks? `<div style="font-size:11px;color:var(--red);margin-top:3px;">${escapeHtml(d.remarks)}</div>`:''}</td>
          <td style="text-align:right;"><button class="btn btn-outline btn-sm" onclick="downloadTextFile('Placeholder content for '+'${escapeHtml(d.name)}','${escapeHtml(d.name)}.txt')">View</button></td>
        </tr>`).join('')}
        </tbody></table>`}
    </div>
  </div>
  `;
}
function afterPostDisb(){}
function handlePostDisbDocUpload(appId, input){
  const file = input.files[0]; if(!file) return;
  const okTypes = ['application/pdf','image/jpeg','image/jpg','image/png'];
  if(!okTypes.includes(file.type)) { toast('Invalid File','Only PDF, JPG, PNG files are allowed.','error'); input.value=''; return; }
  if(file.size > 5*1024*1024){ toast('File Too Large','Maximum file size is 5MB.','error'); input.value=''; return; }
  const app = DB.applications.find(a=>a.id===appId); if(!app) return;
  const type = $('#pdDocType').value;
  const note = $('#pdDocNote').value.trim();
  const doc = { id:uid('pdd'), type, name:file.name, size:file.size, note, status:'Pending', uploadedAt:new Date().toISOString(), verifiedBy:null, verifiedAt:null, remarks:'' };
  ensurePostDisbDocs(app).unshift(doc);
  saveDB();
  notifyRoleUsers('legal', 'New Document for Verification', app.personal.name+' ('+app.trackingNo+') uploaded "'+type+'" and needs legal verification.');
  toast('Document Uploaded', type+' — pending legal verification.', 'success');
  render('postdisb');
}
function submitServiceRequest(appId){
  const desc = $('#pdReqDesc').value.trim();
  if(!desc) return fieldError($('#pdReqDesc'), $('#err_pdReqDesc'), 'Please describe your request.');
  fieldOk($('#pdReqDesc'), $('#err_pdReqDesc'));
  const app = DB.applications.find(a=>a.id===appId);
  const req = { id:uid('req'), ref:'SR-'+(DB.nextReq++), appId, userEmail:app.userEmail, type:$('#pdReqType').value, desc, status:'Requested', createdAt:new Date().toISOString() };
  DB.serviceRequests.push(req); saveDB();
  pushNotification(app.userEmail,'Service Request Submitted', req.ref+' — '+req.type, notifChannels(app.userEmail));
  toast('Request Submitted', req.ref, 'success');
  render('postdisb');
}
function advanceServiceRequest(id){
  const req = DB.serviceRequests.find(r=>r.id===id); if(!req) return;
  const flow = ['Requested','In Review','In Progress','Completed'];
  const idx = flow.indexOf(req.status);
  req.status = flow[Math.min(idx+1, flow.length-1)];
  saveDB();
  pushNotification(req.userEmail, 'Service Request Update', req.ref+' is now: '+req.status, notifChannels(req.userEmail));
  toast('Status Updated', req.ref+' → '+req.status, 'success');
  render('postdisb');
}
function downloadDisbursementLetter(appId){
  const app = DB.applications.find(a=>a.id===appId);
  const content = `HOUSING LOAN MANAGEMENT SYSTEM\nDISBURSEMENT LETTER\n\nDate: ${fmtDate(app.disbursement.date)}\nReference No: ${app.disbursement.refNo}\n\nDear ${app.personal.name},\n\nWe are pleased to confirm disbursement of your ${app.loanType} as follows:\n\nLoan Account No: ${app.trackingNo}\nLoan Amount: ${fmtINR(app.loanAmount)}\nDisbursed Amount: ${fmtINR(app.disbursement.amount)}\nInterest Rate: ${app.interestRate}% p.a.\nTenure: ${app.tenureYears} years\nEMI: ${fmtINR(calcEMI(app.loanAmount, app.interestRate, app.tenureYears))}\nDisbursement Mode: ${app.disbursement.mode}\nBank: ${app.disbursement.bank}\n\nThis is a system-generated letter for your records.\n\nHLMS Customer Portal`;
  downloadTextFile(content, app.trackingNo+'_Disbursement_Letter.txt');
}
function downloadDoc(name){
  downloadTextFile('This is a system-generated placeholder document: '+name+'\nGenerated on '+fmtDate(new Date()), name.replace(/\s+/g,'_')+'.txt');
}
function downloadTextFile(content, filename){
  const blob = new Blob([content], {type:'text/plain'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href=url; a.download=filename; a.click();
  URL.revokeObjectURL(url);
  toast('Download Started', filename, 'success');
}

/* ================================================================
   AUCTION MANAGEMENT (customer read-only view, US-AM-03 perspective)
   ================================================================ */
function viewAuction(){
  const apps = myApplications();
  const overdueLoans = apps.filter(a=>a.repayment && a.repayment.schedule && a.repayment.schedule.some(s=>s.status==='Overdue'));
  return `
  <div class="page-head"><h1>Auction Management</h1><p>Read-only view of asset auction status linked to seriously overdue accounts.</p></div>
  <div class="card">
    ${overdueLoans.length===0? `<div class="empty-state"><div class="ic">✅</div>Your account is in good standing. No auction proceedings have been initiated against your mortgaged property.</div>` :
      overdueLoans.map(a=>`
        <div class="doc-row" style="align-items:flex-start;">
          <div>
            <div class="name">${a.trackingNo} — ${a.loanType}</div>
            <div class="meta">Overdue installments detected. Your account is under review by the recovery team. No auction has been scheduled yet.</div>
          </div>
          <span class="badge badge-orange">Under Watch</span>
        </div>`).join('')}
  </div>
  <div class="card" style="background:var(--teal-light);box-shadow:none;">
    <p style="margin:0;font-size:13px;color:var(--text-mid);">If your loan account is flagged for default and remains unresolved, the bank may initiate asset auction proceedings as per your loan agreement and applicable banking guidelines. Please use the <a href="#" onclick="go('repayment');return false;">Repayment</a> section to clear overdue installments and avoid escalation.</p>
  </div>
  `;
}

/* ================================================================
   DOCUMENTS
   ================================================================ */
function viewDocuments(){
  const apps = myApplications();
  let rows = [];
  apps.forEach(a=>{
    const ds = ensureDocStatus(a);
    Object.entries(a.documents||{}).forEach(([k,v])=>{
      if(v) rows.push({app:a.trackingNo, name:k, file:v.name||('system-'+k), date:v.uploadedAt||a.createdAt, status:(ds[k]&&ds[k].status)||'Pending', remarks:(ds[k]&&ds[k].remarks)||''});
    });
    if(a.status==='Disbursed'){
      rows.push({app:a.trackingNo, name:'Disbursement Letter', file:'system-generated', date:a.disbursement.date, gen:()=>downloadDisbursementLetter(a.id)});
      rows.push({app:a.trackingNo, name:'Sanction Letter', file:'system-generated', date:a.disbursement.date, gen:()=>downloadDoc(a.trackingNo+' Sanction Letter')});
    }
  });
  const pdRows = [];
  apps.forEach(a=>{ ensurePostDisbDocs(a).forEach(d=>pdRows.push(Object.assign({app:a.trackingNo}, d))); });
  return `
  <div class="page-head"><h1>Documents</h1><p>All documents uploaded and generated across your loan applications.</p></div>
  <div class="card">
    ${rows.length? `<table><thead><tr><th>Application</th><th>Document</th><th>File</th><th>Date</th><th>Bank Office Status</th><th></th></tr></thead><tbody>
      ${rows.map(r=>`<tr><td>${r.app}</td><td>${r.name}</td><td>${escapeHtml(r.file)}</td><td>${fmtDate(r.date)}</td>
        <td>${r.status? `<span class="badge ${docBadgeClass(r.status)}">${r.status}</span>${r.status==='Rejected'&&r.remarks? `<div style="font-size:11px;color:var(--red);margin-top:3px;">${escapeHtml(r.remarks)}</div>`:''}` : '<span style="color:var(--text-gray);font-size:12px;">—</span>'}</td>
        <td><button class="btn btn-outline btn-sm" onclick="${r.gen? 'documentsDownload(\''+r.app+'\',\''+r.name+'\')':'documentsDownload(\''+r.app+'\',\''+r.name+'\')'}">Download</button></td></tr>`).join('')}
    </tbody></table>` : `<div class="empty-state"><div class="ic">🗂️</div>No documents yet. Upload documents while applying for a loan.</div>`}
  </div>
  <div class="card">
    <h3>⚖ Legal Verification Status (Post-Disbursement Uploads)</h3>
    ${pdRows.length? `<table><thead><tr><th>Application</th><th>Document</th><th>Type</th><th>Uploaded</th><th>Status</th></tr></thead><tbody>
      ${pdRows.map(r=>`<tr><td>${r.app}</td><td>${escapeHtml(r.name)}</td><td>${escapeHtml(r.type)}</td><td>${fmtDate(r.uploadedAt)}</td>
        <td><span class="badge ${pdDocBadgeClass(r.status)}">${r.status}</span>${r.status==='Rejected'&&r.remarks? `<div style="font-size:11px;color:var(--red);margin-top:3px;">${escapeHtml(r.remarks)}</div>`:''}</td></tr>`).join('')}
    </tbody></table>` : `<div class="empty-state"><div class="ic">📭</div>No post-disbursement documents uploaded yet. Use <a href="#" onclick="go('postdisb');return false;">Post Disbursement</a> to upload one for legal verification.</div>`}
  </div>
  `;
}
function documentsDownload(appTrack, name){ downloadDoc(appTrack+' - '+name); }

/* ================================================================
   PROFILE SETTINGS (US-UM-05)
   ================================================================ */
function viewProfile(){
  const u = currentUser();
  const emp = u.employment||{};
  return `
  <div class="page-head"><h1>Profile Settings</h1><p>Manage your personal, employment and financial information.</p></div>
  <div class="grid grid-2">
    <div class="card">
      <h3>👤 Personal Information</h3>
      <div class="field"><label>Full Name</label><input id="pfName" value="${escapeHtml(u.name)}"><div class="error hidden" id="err_pfName"></div></div>
      <div class="two-col">
        <div class="field"><label>Mobile</label><input id="pfMobile" value="${escapeHtml(u.mobile)}"><div class="error hidden" id="err_pfMobile"></div></div>
        <div class="field"><label>Email</label><input value="${escapeHtml(u.email)}" disabled></div>
      </div>
      <button class="btn btn-primary" onclick="savePersonal()">Save Changes</button>
    </div>
    <div class="card">
      <h3>💼 Employment &amp; Financial Information</h3>
      <div class="two-col">
        <div class="field"><label>Employment Type</label><select id="pfEmpType"><option ${emp.type==='Salaried'?'selected':''}>Salaried</option><option ${emp.type==='Self-Employed'?'selected':''}>Self-Employed</option></select></div>
        <div class="field"><label>Employer / Business</label><input id="pfEmployer" value="${escapeHtml(emp.employer||'')}"></div>
      </div>
      <div class="two-col">
        <div class="field"><label>Monthly Income (₹)</label><input type="number" id="pfIncome" value="${emp.monthlyIncome||0}"></div>
        <div class="field"><label>Other Monthly EMIs (₹)</label><input type="number" id="pfOtherEmi" value="${emp.otherEMIs||0}"></div>
      </div>
      <button class="btn btn-primary" onclick="saveEmployment()">Save Changes</button>
    </div>
  </div>
  <div class="grid grid-2">
    <div class="card">
      <h3>🔔 Notification Preferences</h3>
      <label class="chk-row" style="margin-bottom:10px;"><input type="checkbox" id="npSms" ${u.notifPrefs.sms?'checked':''}> SMS Notifications</label><br>
      <label class="chk-row" style="margin-bottom:10px;"><input type="checkbox" id="npEmail" ${u.notifPrefs.email?'checked':''}> Email Notifications</label><br>
      <label class="chk-row" style="margin-bottom:14px;"><input type="checkbox" id="npInapp" ${u.notifPrefs.inapp?'checked':''}> In-App Notifications</label>
      <button class="btn btn-primary btn-sm" onclick="saveNotifPrefs()">Save Preferences</button>
    </div>
    <div class="card">
      <h3>🔒 Change Password</h3>
      <div class="field"><label>Current Password</label><input type="password" id="cpCurrent"><div class="error hidden" id="err_cpCurrent"></div></div>
      <div class="field"><label>New Password</label><input type="password" id="cpNew"><div class="error hidden" id="err_cpNew"></div></div>
      <div class="field"><label>Confirm New Password</label><input type="password" id="cpNew2"><div class="error hidden" id="err_cpNew2"></div></div>
      <button class="btn btn-primary btn-sm" onclick="changePasswordProfile()">Update Password</button>
    </div>
  </div>
  `;
}
function afterProfile(){}
function savePersonal(){
  const u = currentUser();
  const nameEl=$('#pfName'), mobileEl=$('#pfMobile');
  let ok=true;
  if(!nameEl.value.trim()) ok = fieldError(nameEl,$('#err_pfName'),'Name is required.') && ok; else fieldOk(nameEl,$('#err_pfName'));
  if(!REGEX.mobile.test(mobileEl.value.trim())) ok = fieldError(mobileEl,$('#err_pfMobile'),'Enter a valid 10-digit mobile number.') && ok; else fieldOk(mobileEl,$('#err_pfMobile'));
  if(!ok) return;
  u.name = nameEl.value.trim(); u.mobile = mobileEl.value.trim();
  saveDB(); $('#userNameTop').textContent = u.name.split(' ')[0];
  $('#userInitials').textContent = u.name.split(' ').map(s=>s[0]).join('').slice(0,2).toUpperCase();
  toast('Profile Updated','Your personal information has been saved.','success');
}
function saveEmployment(){
  const u = currentUser();
  u.employment = { type:$('#pfEmpType').value, employer:$('#pfEmployer').value.trim(), monthlyIncome:Number($('#pfIncome').value||0), otherEMIs:Number($('#pfOtherEmi').value||0), desiredAmount:(u.employment||{}).desiredAmount };
  saveDB();
  toast('Profile Updated','Your employment and financial details have been saved.','success');
}
function saveNotifPrefs(){
  const u = currentUser();
  u.notifPrefs = { sms:$('#npSms').checked, email:$('#npEmail').checked, inapp:$('#npInapp').checked };
  saveDB();
  toast('Preferences Saved','Your notification channel preferences have been updated.','success');
}
function changePasswordProfile(){
  const u = currentUser();
  const cur=$('#cpCurrent'), n1=$('#cpNew'), n2=$('#cpNew2');
  let ok=true;
  if(cur.value!==u.password) ok = fieldError(cur,$('#err_cpCurrent'),'Current password is incorrect.') && ok; else fieldOk(cur,$('#err_cpCurrent'));
  if(!REGEX.password.test(n1.value)) ok = fieldError(n1,$('#err_cpNew'),'Password must have upper, lower, number & special char (8+ chars).') && ok; else fieldOk(n1,$('#err_cpNew'));
  if(n1.value!==n2.value) ok = fieldError(n2,$('#err_cpNew2'),'Passwords do not match.') && ok; else fieldOk(n2,$('#err_cpNew2'));
  if(!ok) return;
  u.password = n1.value; saveDB();
  toast('Password Changed','Your password has been updated successfully.','success');
  cur.value=n1.value=n2.value='';
}

/* ================================================================
   ADMIN PANEL
   Dashboard, User Management (customers + Add Admin), Employee /
   Legal Team / Loan Officer Management, Role & Permission, Profile.
   ================================================================ */
function usersByRole(role){
  return Object.values(DB.users).filter(u=>u.role===role).sort((a,b)=>a.name.localeCompare(b.name));
}
function viewAdminDashboard(){
  const u = currentUser();
const counts = {
    customer: usersByRole('customer').length,
    admin: usersByRole('admin').length,
    employee: usersByRole('employee').length,
    legal: usersByRole('legal').length,
    bankoffice: usersByRole('bankoffice').length,
    bidder: usersByRole('bidder').length
  };
  const apps = DB.applications||[];
  const activeApps = apps.filter(a=>a.status!=='Disbursed' && a.status!=='Rejected').length;
  return `
  <div class="page-head"><h1>Welcome, ${escapeHtml(u.name.split(' ')[0])} 👋</h1><p>Here's what's happening across HLMS today.</p></div>
  <div class="grid grid-4">
    <div class="card stat"><div class="lbl">Employees</div><div class="val">${counts.employee}</div></div>
    <div class="card stat"><div class="lbl">Legal Team</div><div class="val">${counts.legal}</div></div>
    <div class="card stat"><div class="lbl">Bank Office</div><div class="val">${counts.bankoffice}</div></div>
    <div class="card stat"><div class="lbl">Bidders</div><div class="val">${counts.bidder}</div></div>
  </div>
  <div class="grid grid-4">
    <div class="card stat"><div class="lbl">Total Staff</div><div class="val teal">${counts.admin+counts.employee+counts.legal+counts.bankoffice}</div></div>
  </div>
  <div class="grid grid-2">
    <div class="card">
      <h3>✅ Quick Actions</h3>
      <div class="quick-links">
        <a href="#" onclick="go('employeemgmt');return false;">Manage Employees <span class="arrow">→</span></a>
        <a href="#" onclick="go('legalmgmt');return false;">Manage Legal Team <span class="arrow">→</span></a>
        <a href="#" onclick="go('bankofficemgmt');return false;">Manage Bank Office <span class="arrow">→</span></a>
        <a href="#" onclick="go('biddermgmt');return false;">Manage Bidders <span class="arrow">→</span></a>
        <a href="#" onclick="go('adminmgmt');return false;">Manage Admins <span class="arrow">→</span></a>
      </div>
    </div>
    <div class="card">
      <h3>🕓 Recently Added Users</h3>
      ${renderRecentUsers()}
    </div>
  </div>
  `;
}
function renderRecentUsers(){
  const list = Object.values(DB.users).sort((a,b)=> new Date(b.createdAt||0)-new Date(a.createdAt||0)).slice(0,6);
  if(!list.length) return '<div class="empty-state"><div class="ic">👥</div>No users yet.</div>';
  return '<table><tbody>'+list.map(u=>`
    <tr>
      <td><strong>${escapeHtml(u.name)}</strong><br><span style="color:var(--text-gray);font-size:12px;">${escapeHtml(u.email)}</span></td>
      <td style="text-align:right;"><span class="badge badge-navy">${ROLE_LABELS[u.role]||u.role}</span></td>
    </tr>`).join('')+'</tbody></table>';
}

/* ---- Generic staff table + add/activate/delete ---- */
function renderUserTable(list){
  if(!list.length) return '<div class="empty-state"><div class="ic">👤</div>No records yet.</div>';
  return `<table><thead><tr><th>Name</th><th>Email</th><th>Mobile</th><th>Status</th><th></th></tr></thead><tbody>
  ${list.map(u=>`<tr>
    <td>${escapeHtml(u.name)}</td>
    <td>${escapeHtml(u.email)}</td>
    <td>${escapeHtml(u.mobile||'-')}</td>
    <td><span class="badge ${u.active!==false?'badge-green':'badge-red'}">${u.active!==false?'Active':'Inactive'}</span></td>
    <td style="text-align:right;white-space:nowrap;">
      <button class="btn btn-outline btn-sm" onclick="toggleUserActive('${u.email}')">${u.active!==false?'Deactivate':'Activate'}</button>
      <button class="btn btn-danger btn-sm" onclick="deleteStaffUser('${u.email}')">Delete</button>
    </td>
  </tr>`).join('')}
  </tbody></table>`;
}
/* ---- Customer Management: Customers | Bidders | Admins, as tabs on one page ---- */
function viewCustomerManagement(activeTab){
  activeTab = activeTab || 'bidder';
  const tabs = [
    {key:'bidder', label:'Bidders', view:'biddermgmt'},
    {key:'admin', label:'Admins', view:'adminmgmt'}
  ];
  const label = ROLE_LABELS[activeTab];
  const list = usersByRole(activeTab);
  return `
  <div class="page-head"><h1>Bidder Management</h1><p>Manage bidder and administrator accounts from one place.</p></div>
  <div class="tabs">${tabs.map(t=>`<button class="tab ${activeTab===t.key?'active':''}" onclick="go('${t.view}')">${t.label}</button>`).join('')}</div>
  <div class="card">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
      <h3 style="margin:0;">${activeTab==='bidder'?'🔨':'🛡️'} ${label}s (${list.length})</h3>
      <button class="btn btn-primary btn-sm" onclick="openAddStaffModal('${activeTab}')">+ Add ${label}</button>
    </div>
    ${renderUserTable(list)}
  </div>
  `;
}
/* ---- Employee Management: Employees | Legal Team | Bank Office, as tabs on one page ---- */
function viewEmployeeManagement(activeTab){
  activeTab = activeTab || 'employee';
  const tabs = [
    {key:'employee', label:'Employees', view:'employeemgmt'},
    {key:'legal', label:'Legal Team', view:'legalmgmt'},
    {key:'bankoffice', label:'Bank Office', view:'bankofficemgmt'}
  ];
  const label = ROLE_LABELS[activeTab];
  const list = usersByRole(activeTab);
  return `
  <div class="page-head"><h1>Employee Management</h1><p>Manage staff accounts and their access to HLMS across departments.</p></div>
  <div class="tabs">${tabs.map(t=>`<button class="tab ${activeTab===t.key?'active':''}" onclick="go('${t.view}')">${t.label}</button>`).join('')}</div>
  <div class="card">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
      <h3 style="margin:0;">${label}s (${list.length})</h3>
      <button class="btn btn-primary btn-sm" onclick="openAddStaffModal('${activeTab}')">+ Add ${label}</button>
    </div>
    ${renderUserTable(list)}
  </div>
  `;
}
function viewStaffManagement(role){
  const label = ROLE_LABELS[role];
  const list = usersByRole(role);
  return `
  <div class="page-head"><h1>${label} Management</h1><p>Manage ${label.toLowerCase()} accounts and their access to HLMS.</p></div>
  <div class="card">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
      <h3 style="margin:0;">${label}s (${list.length})</h3>
      <button class="btn btn-primary btn-sm" onclick="openAddStaffModal('${role}')">+ Add ${label}</button>
    </div>
    ${renderUserTable(list)}
  </div>
  `;
}
function openAddStaffModal(role){
  const label = ROLE_LABELS[role];
  showModal(`Add ${label}`, `
    <div class="field"><label>Full Name</label><input id="stName"><div class="error hidden" id="err_stName"></div></div>
    <div class="field"><label>Email</label><input id="stEmail"><div class="error hidden" id="err_stEmail"></div></div>
    <div class="field"><label>Mobile</label><input id="stMobile"><div class="error hidden" id="err_stMobile"></div></div>
    <div class="field"><label>Password</label><input type="password" id="stPass"><div class="error hidden" id="err_stPass"></div></div>
    <div class="field"><label>Confirm Password</label><input type="password" id="stPass2"><div class="error hidden" id="err_stPass2"></div></div>
    <button class="btn btn-primary btn-block" onclick="submitAddStaff('${role}')">Create ${label} Account</button>
  `);
}
function submitAddStaff(role){
  const name=$('#stName'), email=$('#stEmail'), mobile=$('#stMobile'), pass=$('#stPass'), pass2=$('#stPass2');
  let ok=true;
  if(!name.value.trim() || name.value.trim().length<3) ok = fieldError(name,$('#err_stName'),'Enter full name (min 3 characters).') && ok; else fieldOk(name,$('#err_stName'));
  if(!REGEX.email.test(email.value.trim())) ok = fieldError(email,$('#err_stEmail'),'Enter a valid email address.') && ok; else fieldOk(email,$('#err_stEmail'));
  if(!REGEX.mobile.test(mobile.value.trim())) ok = fieldError(mobile,$('#err_stMobile'),'Enter a valid 10-digit mobile number.') && ok; else fieldOk(mobile,$('#err_stMobile'));
  if(!REGEX.password.test(pass.value)) ok = fieldError(pass,$('#err_stPass'),'Password must have upper, lower, number & special char (8+ chars).') && ok; else fieldOk(pass,$('#err_stPass'));
  if(pass.value!==pass2.value || !pass2.value) ok = fieldError(pass2,$('#err_stPass2'),'Passwords do not match.') && ok; else fieldOk(pass2,$('#err_stPass2'));
  if(Object.values(DB.users).some(u=>u.email===email.value.trim())) ok = fieldError(email,$('#err_stEmail'),'An account already exists with this email.') && ok;
  if(!ok) return;

  const user = {
    email: email.value.trim(), name:name.value.trim(), mobile:mobile.value.trim(),
    idType:'PAN', idNumber:'', password:pass.value, role:role, active:true,
    createdAt:new Date().toISOString()
  };
  DB.users[user.email] = user; saveDB();
  document.querySelector('.modal-overlay')?.remove();
  toast(`${ROLE_LABELS[role]} Added`, `${escapeHtml(user.name)} can now log in with the credentials provided.`, 'success');
  render(location.hash.replace('#','') || defaultView());
}
function toggleUserActive(email){
  const u = DB.users[email]; if(!u) return;
  if(u.email===currentUser().email) return toast('Action Blocked','You cannot deactivate your own account.','error');
  if(u.role==='admin' && u.active!==false && usersByRole('admin').filter(a=>a.active!==false).length<=1){
    return toast('Action Blocked','At least one active admin account must remain.','error');
  }
  u.active = u.active===false ? true : false; saveDB();
  toast('Status Updated', `${escapeHtml(u.name)} is now ${u.active?'active':'inactive'}.`, 'success');
  render(location.hash.replace('#','') || defaultView());
}
function deleteStaffUser(email){
  const u = DB.users[email]; if(!u) return;
  if(u.email===currentUser().email) return toast('Action Blocked','You cannot delete your own account.','error');
  if(u.role==='admin' && usersByRole('admin').length<=1) return toast('Action Blocked','At least one admin account must remain.','error');
  if(!confirm(`Delete ${u.name} (${u.email})? This cannot be undone.`)) return;
  delete DB.users[email]; saveDB();
  toast('User Deleted', `${escapeHtml(u.name)}'s account has been removed.`, 'success');
  render(location.hash.replace('#','') || defaultView());
}

function saveRolePermissions(){
  const roles = ['employee','legal','loanofficer','bankoffice','customer'];
  const cols = ['view','add','edit','delete'];
  const perms = DB.rolePermissions || JSON.parse(JSON.stringify(DEFAULT_PERMISSIONS));
  roles.forEach(r=>{
    perms[r] = perms[r] || {};
    cols.forEach(c=>{ const el = $('#perm_'+r+'_'+c); if(el) perms[r][c] = el.checked; });
  });
  DB.rolePermissions = perms; saveDB();
  toast('Permissions Saved','Role permissions have been updated.','success');
}

/* ---- Admin Profile (lighter than customer profile: no employment info) ---- */
function viewAdminProfile(){
  const u = currentUser();
  return `
  <div class="page-head"><h1>Profile</h1><p>Manage your account details and password.</p></div>
  <div class="grid grid-2">
    <div class="card">
      <h3>👤 Personal Information</h3>
      <div class="field"><label>Full Name</label><input id="pfName" value="${escapeHtml(u.name)}"><div class="error hidden" id="err_pfName"></div></div>
      <div class="two-col">
        <div class="field"><label>Mobile</label><input id="pfMobile" value="${escapeHtml(u.mobile)}"><div class="error hidden" id="err_pfMobile"></div></div>
        <div class="field"><label>Email</label><input value="${escapeHtml(u.email)}" disabled></div>
      </div>
      <div class="field"><label>Role</label><input value="${ROLE_LABELS[u.role]||u.role}" disabled></div>
      <button class="btn btn-primary" onclick="savePersonal()">Save Changes</button>
    </div>
    <div class="card">
      <h3>🔒 Change Password</h3>
      <div class="field"><label>Current Password</label><input type="password" id="cpCurrent"><div class="error hidden" id="err_cpCurrent"></div></div>
      <div class="field"><label>New Password</label><input type="password" id="cpNew"><div class="error hidden" id="err_cpNew"></div></div>
      <div class="field"><label>Confirm New Password</label><input type="password" id="cpNew2"><div class="error hidden" id="err_cpNew2"></div></div>
      <button class="btn btn-primary btn-sm" onclick="changePasswordProfile()">Update Password</button>
    </div>
  </div>
  `;
}

/* ================================================================
   LEGAL & VALUATION TEAM PORTAL (role: legal)
   Dashboard, Legal Review Queue, Case Detail, Document Center,
   Auction & SARFAESI Management, Legal Notices Log, Profile.
   ================================================================ */
let legalCurrentCaseId = null;
function openLegalCase(appId){
  const app = DB.applications.find(a=>a.id===appId);
  if(app && app.stageIndex===LEGAL_STAGE_INDEX && app.status==='Under Review' && !bankOfficeVerified(ensureLegal(app))){
    toast('Locked','This case cannot be opened yet — Bank Office must verify all submitted documents before mortgage verification can begin.','error');
    return;
  }
  legalCurrentCaseId = appId; go('legalcasedetail');
}

function viewLegalDashboard(){
  const u = currentUser();
  const queue = DB.applications.filter(a=>a.stageIndex===LEGAL_STAGE_INDEX && a.status==='Under Review');
  const verifiedThisMonth = DB.applications.filter(a=>{ ensureLegal(a); return a.legal.decision==='Approved' && a.legal.decisionDate && new Date(a.legal.decisionDate).getMonth()===new Date().getMonth(); }).length;
  const auctionActive = DB.applications.filter(a=>{ ensureLegal(a); return a.auction.stage!=='None' && a.auction.stage!=='Resolved'; }).length;
  const noticesActive = DB.legalNotices.filter(n=>n.status==='Active').length;
  saveDB();
  return `
  <div class="page-head"><h1>Welcome, ${escapeHtml(u.name.split(' ')[0])}</h1><p>Here's what needs your attention across legal review and recovery today.</p></div>
  <div class="grid grid-4">
    <div class="card stat"><div class="lbl">Pending Legal Review</div><div class="val orange">${queue.length}</div><div class="sub">Property / mortgage clearance</div></div>
    <div class="card stat"><div class="lbl">Verified This Month</div><div class="val teal">${verifiedThisMonth}</div><div class="sub">Applications cleared</div></div>
    <div class="card stat"><div class="lbl">Active Auction / SARFAESI</div><div class="val red">${auctionActive}</div><div class="sub">Recovery proceedings in motion</div></div>
    <div class="card stat"><div class="lbl">Active Legal Notices</div><div class="val">${noticesActive}</div><div class="sub">Awaiting borrower response</div></div>
  </div>
  <div class="card">
    <h3>☑ Legal Review Queue</h3>
    ${queue.length===0? `<div class="empty-state"><div class="ic">✅</div>No applications pending legal review.</div>` :
      `<table><thead><tr><th>Tracking No.</th><th>Applicant</th><th>Property</th><th></th></tr></thead><tbody>
      ${queue.slice(0,5).map(a=>`<tr class="clickable-row" onclick="openLegalCase('${a.id}')">
        <td>${a.trackingNo}</td><td>${escapeHtml(a.personal.name)}</td><td>${escapeHtml(a.property.type)}</td>
        <td style="text-align:right;"><span class="badge badge-orange">Review Now</span></td>
      </tr>`).join('')}
      </tbody></table>
      ${queue.length>5? `<button class="btn btn-outline btn-sm" style="margin-top:12px;" onclick="go('legalqueue')">View all ${queue.length} cases</button>`:''}`}
  </div>
  <div class="card">
    <h3>☆ Auction &amp; SARFAESI Snapshot</h3>
    ${renderLegalAuctionSnapshotTable()}
    <button class="btn btn-outline btn-sm" style="margin-top:12px;" onclick="go('legalauction')">Manage Auction &amp; SARFAESI</button>
  </div>
  `;
}
function renderLegalAuctionSnapshotTable(){
  const items = overdueLegalApplications();
  if(items.length===0) return `<div class="empty-state"><div class="ic">✅</div>No accounts currently under recovery watch.</div>`;
  return `<table><thead><tr><th>Tracking No.</th><th>Borrower</th><th>Overdue Installments</th><th>Stage</th></tr></thead><tbody>
    ${items.map(a=>`<tr><td>${a.trackingNo}</td><td>${escapeHtml(a.personal.name)}</td><td>${a.overdueCount}</td><td><span class="badge ${auctionBadgeClass(a.auction.stage)}">${a.auction.stage}</span></td></tr>`).join('')}
  </tbody></table>`;
}

/* ---- Legal Review Queue ---- */
function viewLegalQueue(){
  const all = DB.applications.filter(a=>a.stageIndex>=LEGAL_STAGE_INDEX).map(ensureLegal);
  const pendingAll = all.filter(a=>a.stageIndex===LEGAL_STAGE_INDEX && a.status==='Under Review');
  const locked = pendingAll.filter(a=>!bankOfficeVerified(a));
  const pending = pendingAll.filter(a=>bankOfficeVerified(a));
  const resolved = all.filter(a=>!(a.stageIndex===LEGAL_STAGE_INDEX && a.status==='Under Review'));
  return `
  <div class="page-head"><h1>Legal Review Queue</h1><p>Applications awaiting property title &amp; mortgage document clearance.</p></div>
  <div class="card">
    <h3>🕓 Ready for Mortgage Verification (${pending.length})</h3>
    ${pending.length===0? `<div class="empty-state"><div class="ic">✅</div>Nothing pending. New applications will appear here once Document Verification and Credit Check are complete.</div>` :
      `<table><thead><tr><th>Tracking No.</th><th>Applicant</th><th>Loan Type</th><th>Loan Amount</th><th>Property Type</th><th></th></tr></thead><tbody>
      ${pending.map(a=>`<tr class="clickable-row" onclick="openLegalCase('${a.id}')">
        <td>${a.trackingNo}</td><td>${escapeHtml(a.personal.name)}</td><td>${escapeHtml(a.loanType)}</td>
        <td>${fmtINR(a.loanAmount)}</td><td>${escapeHtml(a.property.type)}</td>
        <td style="text-align:right;"><button class="btn btn-primary btn-sm" onclick="event.stopPropagation();openLegalCase('${a.id}')">Review</button></td>
      </tr>`).join('')}</tbody></table>`}
  </div>
  <div class="card">
    <h3>🔒 Awaiting Bank Office Verification (${locked.length})</h3>
    ${locked.length===0? `<div class="empty-state"><div class="ic">✅</div>No cases waiting on Bank Office.</div>` :
      `<p style="font-size:12.5px;color:var(--text-gray);margin-top:0;">These applications cannot be opened for mortgage verification yet — Bank Office must verify all submitted documents first.</p>
      <table><thead><tr><th>Tracking No.</th><th>Applicant</th><th>Loan Type</th><th>Loan Amount</th><th>Property Type</th><th></th></tr></thead><tbody>
      ${locked.map(a=>`<tr>
        <td>${a.trackingNo}</td><td>${escapeHtml(a.personal.name)}</td><td>${escapeHtml(a.loanType)}</td>
        <td>${fmtINR(a.loanAmount)}</td><td>${escapeHtml(a.property.type)}</td>
        <td style="text-align:right;"><span class="badge badge-orange">Pending Bank Office</span></td>
      </tr>`).join('')}</tbody></table>`}
  </div>
  <div class="card">
    <h3>📋 Recently Actioned</h3>
    ${resolved.length===0? `<div class="empty-state"><div class="ic">📭</div>No history yet.</div>` :
      `<table><thead><tr><th>Tracking No.</th><th>Applicant</th><th>Decision</th><th>Officer</th><th>Date</th></tr></thead><tbody>
      ${resolved.slice(0,10).map(a=>`<tr class="clickable-row" onclick="openLegalCase('${a.id}')">
        <td>${a.trackingNo}</td><td>${escapeHtml(a.personal.name)}</td>
        <td><span class="badge ${decisionBadgeClass(a.legal.decision)}">${a.legal.decision||'Not yet reviewed'}</span></td>
        <td>${escapeHtml(a.legal.officer||'—')}</td><td>${fmtDate(a.legal.decisionDate)}</td>
      </tr>`).join('')}</tbody></table>`}
  </div>
  `;
}

/* ---- Case Detail (Property & Document Legal Verification) ---- */
function viewLegalCaseDetail(){
  const app = DB.applications.find(a=>a.id===legalCurrentCaseId);
  if(!app) return `<div class="empty-state"><div class="ic">⚠️</div>Case not found.</div><button class="btn btn-outline btn-sm" onclick="go('legalqueue')">Back to Queue</button>`;
  ensureLegal(app);
  const allVerified = LEGAL_CHECKLIST.every(c=>app.legal[c.key]==='Verified');
  const anyDiscrepancy = LEGAL_CHECKLIST.some(c=>app.legal[c.key]==='Discrepancy');
  const docs = Object.entries(app.documents||{}).filter(([k,v])=>v);
  return `
  <div class="back-link" onclick="go('legalqueue')">← Back to Legal Review Queue</div>
  <div class="page-head">
    <div><h1>${app.trackingNo}</h1><p>${escapeHtml(app.loanType)} · ${escapeHtml(app.personal.name)}</p></div>
    <span class="badge ${decisionBadgeClass(app.legal.decision)}">${app.legal.decision || 'Awaiting Review'}</span>
  </div>

  <div class="grid grid-2">
    <div class="card">
      <h3>👤 Applicant &amp; Loan Details</h3>
      <table><tbody>
        <tr><td>Applicant Name</td><td style="text-align:right;">${escapeHtml(app.personal.name)}</td></tr>
        <tr><td>Mobile</td><td style="text-align:right;">${escapeHtml(app.personal.mobile||'—')}</td></tr>
        <tr><td>Loan Type</td><td style="text-align:right;">${escapeHtml(app.loanType)}</td></tr>
        <tr><td>Loan Amount</td><td style="text-align:right;">${fmtINR(app.loanAmount)}</td></tr>
        <tr><td>Tenure</td><td style="text-align:right;">${app.tenureYears} years</td></tr>
        <tr><td>Employment</td><td style="text-align:right;">${escapeHtml((app.employment&&app.employment.type)||'—')}</td></tr>
      </tbody></table>
    </div>
    <div class="card">
      <h3>⌂ Property Details</h3>
      <table><tbody>
        <tr><td>Address</td><td style="text-align:right;">${escapeHtml(app.property.address)}</td></tr>
        <tr><td>Property Type</td><td style="text-align:right;">${escapeHtml(app.property.type)}</td></tr>
        <tr><td>Declared Value</td><td style="text-align:right;">${fmtINR(app.property.value)}</td></tr>
        <tr><td>Loan-to-Value (LTV)</td><td style="text-align:right;">${app.property.value ? Math.round(app.loanAmount/app.property.value*100) : '—'}%</td></tr>
      </tbody></table>
    </div>
  </div>

  <div class="card">
    <h3>📄 Submitted Documents</h3>
    ${docs.length===0? `<div class="empty-state"><div class="ic">📭</div>No documents uploaded yet.</div>` :
      docs.map(([k,v])=>`<div class="doc-row">
        <div><div class="name">${escapeHtml((v&&v.name) || DOC_LABELS[k] || k)}</div><div class="meta">Uploaded ${fmtDate((v&&v.uploadedAt)||app.createdAt)}</div></div>
        <div class="actions"><button class="btn btn-outline btn-sm" onclick="downloadTextFile('Placeholder content for '+'${escapeHtml((v&&v.name)||DOC_LABELS[k]||k)}','${escapeHtml((v&&v.name)||k)}.txt')">View</button></div>
      </div>`).join('')}
  </div>

  <div class="card">
    <h3>⚖️ Legal &amp; Title Verification Checklist</h3>
    ${LEGAL_CHECKLIST.map(c=>`
      <div class="checklist-row">
        <div class="cl-name">${c.label}</div>
        <select class="cl-${app.legal[c.key]}" onchange="setLegalChecklistStatus('${app.id}','${c.key}',this.value)">
          <option value="Pending" ${app.legal[c.key]==='Pending'?'selected':''}>Pending</option>
          <option value="Verified" ${app.legal[c.key]==='Verified'?'selected':''}>Verified</option>
          <option value="Discrepancy" ${app.legal[c.key]==='Discrepancy'?'selected':''}>Discrepancy Found</option>
        </select>
      </div>`).join('')}
    <div class="field" style="margin-top:14px;">
      <label>Legal Remarks / Notes</label>
      <textarea id="legalRemarks" rows="3" placeholder="Add any observations, discrepancies or conditions for approval...">${escapeHtml(app.legal.remarks||'')}</textarea>
    </div>
    <button class="btn btn-outline btn-sm" onclick="saveLegalRemarks('${app.id}')">Save Remarks</button>
  </div>

  <div class="card" style="${allVerified?'background:var(--green-bg);':anyDiscrepancy?'background:var(--red-bg);':''}box-shadow:none;">
    ${allVerified? `<b style="color:var(--green);font-size:13.5px;">✓ All checklist items verified. This case is ready to be forwarded for final approval.</b>` :
      anyDiscrepancy? `<b style="color:var(--red);font-size:13.5px;">⚠ Discrepancy found in one or more documents. Consider raising a query or rejecting.</b>` :
      `<b style="color:var(--text-mid);font-size:13.5px;">Complete the checklist above before making a decision.</b>`}
  </div>

  <div class="card">
    <h3>✅ Decision</h3>
    <div style="display:flex;gap:12px;flex-wrap:wrap;">
      <button class="btn btn-primary" ${app.legal.decision?'disabled':''} onclick="decideLegalCase('${app.id}','Approved')">Approve &amp; Forward to Final Approval</button>
      <button class="btn btn-outline" ${app.legal.decision?'disabled':''} onclick="decideLegalCase('${app.id}','Query Raised')">Raise Query to Applicant</button>
      <button class="btn btn-danger" ${app.legal.decision?'disabled':''} onclick="decideLegalCase('${app.id}','Rejected')">Reject Application</button>
    </div>
    ${app.legal.decision? `<p style="font-size:12.5px;color:var(--text-gray);margin:12px 0 0;">Decision recorded by ${escapeHtml(app.legal.officer||'')} on ${fmtDate(app.legal.decisionDate)}.</p>`:''}
  </div>
  `;
}
function setLegalChecklistStatus(appId, key, value){
  const app = DB.applications.find(a=>a.id===appId); ensureLegal(app);
  app.legal[key]=value; saveDB();
  render('legalcasedetail');
}
function saveLegalRemarks(appId){
  const app = DB.applications.find(a=>a.id===appId); ensureLegal(app);
  app.legal.remarks = $('#legalRemarks').value.trim(); saveDB();
  toast('Remarks Saved','Legal remarks have been updated.','success');
}
function decideLegalCase(appId, decision){
  const app = DB.applications.find(a=>a.id===appId); ensureLegal(app);
  const s = currentUser();
  if(decision==='Approved'){
    const notVerified = LEGAL_CHECKLIST.filter(c=>app.legal[c.key]!=='Verified');
    if(notVerified.length>0){ toast('Cannot Approve','Please mark all checklist items as Verified first.'); return; }
    app.legal.decision='Approved'; app.legal.decisionDate=new Date().toISOString(); app.legal.officer=s.name;
    app.stageIndex = LEGAL_STAGE_INDEX+1; app.status='Under Review';
    pushNotification(app.userEmail,'Legal Verification Completed','Your application '+app.trackingNo+' has cleared legal & property verification and moved to Final Approval.', notifChannels(app.userEmail));
    toast('Case Approved', app.trackingNo+' forwarded to Final Approval.', 'success');
  } else if(decision==='Query Raised'){
    app.legal.decision='Query Raised'; app.legal.decisionDate=new Date().toISOString(); app.legal.officer=s.name;
    app.status='Under Review';
    pushNotification(app.userEmail,'Additional Information Required','The Legal team has raised a query on your application '+app.trackingNo+'. Please check remarks: '+(app.legal.remarks||'See portal for details.'), notifChannels(app.userEmail));
    notifyRoleUsers('bankoffice','Legal Query Raised','A discrepancy was found by the Legal Team on application '+app.trackingNo+' ('+escapeHtml(app.personal.name)+'). Remarks: '+(app.legal.remarks||'See case detail.'));
    toast('Query Raised', 'Applicant has been notified.', 'success');
  } else if(decision==='Rejected'){
    app.legal.decision='Rejected'; app.legal.decisionDate=new Date().toISOString(); app.legal.officer=s.name;
    app.status='Rejected';
    pushNotification(app.userEmail,'Application Rejected','Your application '+app.trackingNo+' could not be approved due to legal/title verification issues. Remarks: '+(app.legal.remarks||'Contact support for details.'), notifChannels(app.userEmail));
    notifyRoleUsers('bankoffice','Application Rejected by Legal Team','Application '+app.trackingNo+' ('+escapeHtml(app.personal.name)+') was rejected by the Legal Team due to a title/document discrepancy. Remarks: '+(app.legal.remarks||'See case detail.'));
    toast('Case Rejected', app.trackingNo+' has been rejected.', 'success');
  }
  saveDB();
  render('legalcasedetail');
}

/* ---- Document Center ---- */
function viewLegalDocuments(){
  const apps = DB.applications;
  let rows = [];
  apps.forEach(a=>{
    Object.entries(a.documents||{}).forEach(([k,v])=>{ if(v) rows.push({trackingNo:a.trackingNo, applicant:a.personal.name, name:(v.name||DOC_LABELS[k]||k), date:v.uploadedAt||a.createdAt}); });
  });
  rows.sort((a,b)=>new Date(b.date)-new Date(a.date));
  const pdDocs = allPostDisbDocs();
  const pending = pdDocs.filter(d=>d.status==='Pending');
  return `
  <div class="page-head"><div><h1>Document Center</h1><p>All customer-submitted documents across applications, in one place.</p></div></div>
  <div class="card">
    <h3>📤 Post-Disbursement Document Verification ${pending.length? `<span class="badge badge-orange" style="margin-left:6px;">${pending.length} pending</span>`:''}</h3>
    <p style="font-size:12.5px;color:var(--text-mid);margin-top:0;">Documents uploaded by customers after loan disbursement, awaiting your verification.</p>
    ${pdDocs.length===0? `<div class="empty-state"><div class="ic">📭</div>No post-disbursement documents uploaded yet.</div>` :
      `<table><thead><tr><th>Tracking No.</th><th>Applicant</th><th>Document</th><th>Type</th><th>Uploaded</th><th>Status</th><th></th></tr></thead><tbody>
      ${pdDocs.map(d=>`<tr>
        <td>${d.app.trackingNo}</td><td>${escapeHtml(d.app.personal.name)}</td>
        <td>${escapeHtml(d.name)}${d.note? `<div style="font-size:11px;color:var(--text-gray);">Note: ${escapeHtml(d.note)}</div>`:''}</td>
        <td>${escapeHtml(d.type)}</td><td>${fmtDate(d.uploadedAt)}</td>
        <td><span class="badge ${pdDocBadgeClass(d.status)}">${d.status}</span>${d.status==='Rejected'&&d.remarks? `<div style="font-size:11px;color:var(--red);margin-top:3px;">${escapeHtml(d.remarks)}</div>`:''}</td>
        <td style="text-align:right;white-space:nowrap;">
          <button class="btn btn-outline btn-sm" onclick="downloadTextFile('Placeholder content for '+'${escapeHtml(d.name)}','${escapeHtml(d.name)}.txt')">View</button>
          ${d.status==='Pending'? ` <button class="btn btn-primary btn-sm" onclick="verifyPostDisbDoc('${d.app.id}','${d.id}')">Verify</button> <button class="btn btn-danger btn-sm" onclick="openRejectPostDisbDocModal('${d.app.id}','${d.id}')">Reject</button>`:''}
        </td>
      </tr>`).join('')}</tbody></table>`}
  </div>
  <div class="card">
    <h3>🗂️ Application Documents</h3>
    ${rows.length===0? `<div class="empty-state"><div class="ic">📭</div>No documents available.</div>` :
      `<table><thead><tr><th>Tracking No.</th><th>Applicant</th><th>Document</th><th>Uploaded</th><th></th></tr></thead><tbody>
      ${rows.map(r=>`<tr>
        <td>${r.trackingNo}</td><td>${escapeHtml(r.applicant)}</td><td>${escapeHtml(r.name)}</td><td>${fmtDate(r.date)}</td>
        <td style="text-align:right;"><button class="btn btn-outline btn-sm" onclick="downloadTextFile('Placeholder content for '+'${escapeHtml(r.name)}','${escapeHtml(r.name)}.txt')">View</button></td>
      </tr>`).join('')}</tbody></table>`}
  </div>
  `;
}
function verifyPostDisbDoc(appId, docId){
  const app = DB.applications.find(a=>a.id===appId); if(!app) return;
  const doc = ensurePostDisbDocs(app).find(d=>d.id===docId); if(!doc) return;
  const s = currentUser();
  doc.status='Verified'; doc.verifiedBy=s.name; doc.verifiedAt=new Date().toISOString(); doc.remarks='';
  saveDB();
  pushNotification(app.userEmail, 'Document Verified', 'Your document "'+doc.type+'" ('+doc.name+') has been verified by the Legal & Valuation Team.', notifChannels(app.userEmail));
  toast('Document Verified', doc.name, 'success');
  render('legaldocuments');
}
function openRejectPostDisbDocModal(appId, docId){
  showModal('Reject Document', `
    <p style="font-size:12.5px;color:var(--text-mid);">The customer will be notified and asked to re-upload a correct document.</p>
    <div class="field"><label>Reason for Rejection</label><textarea id="pdDocRejectRemarks" rows="4" placeholder="e.g. Document unclear, expired, does not match records..."></textarea><div class="error hidden" id="err_pdDocRejectRemarks"></div></div>
    <button class="btn btn-danger btn-block" onclick="rejectPostDisbDoc('${appId}','${docId}')">Confirm Rejection</button>
  `);
}
function rejectPostDisbDoc(appId, docId){
  const app = DB.applications.find(a=>a.id===appId); if(!app) return;
  const doc = ensurePostDisbDocs(app).find(d=>d.id===docId); if(!doc) return;
  const remarksEl = $('#pdDocRejectRemarks');
  const remarks = remarksEl.value.trim();
  if(!remarks){ fieldError(remarksEl, $('#err_pdDocRejectRemarks'), 'Please provide a reason for rejection.'); return; }
  const s = currentUser();
  doc.status='Rejected'; doc.verifiedBy=s.name; doc.verifiedAt=new Date().toISOString(); doc.remarks=remarks;
  saveDB();
  pushNotification(app.userEmail, 'Document Rejected', 'Your document "'+doc.type+'" ('+doc.name+') was rejected by the Legal & Valuation Team. Reason: '+remarks+'. Please re-upload from Post Disbursement.', notifChannels(app.userEmail));
  $('.modal-overlay')?.remove();
  toast('Document Rejected', doc.name, 'success');
  render('legaldocuments');
}

/* ---- Auction & SARFAESI Management ---- */
function viewLegalAuction(){
  const list = overdueLegalApplications();
  saveDB();
  return `
  <div class="page-head"><div><h1>Auction &amp; SARFAESI Management</h1><p>Manage recovery proceedings for seriously overdue, secured loan accounts.</p></div></div>
  <div class="card" style="background:var(--purple-bg);box-shadow:none;">
    <p style="margin:0;font-size:13px;color:var(--text-mid);">Under the SARFAESI Act, a Demand Notice under Section 13(2) gives the borrower 60 days to repay before further recovery action (symbolic possession, e-auction) may proceed.</p>
  </div>
  ${list.length===0? `<div class="card"><div class="empty-state"><div class="ic">✅</div>No accounts currently overdue enough to require recovery action.</div></div>` :
    list.map(a=>renderLegalAuctionCard(a)).join('')}
  `;
}
function renderLegalAuctionCard(app){
  const st = app.auction;
  let noticeInfo = '';
  if(st.stage!=='None' && st.noticeDueDate){
    const remaining = daysBetween(st.noticeDueDate, new Date());
    noticeInfo = `<span class="countdown-pill ${remaining<0?'overdue':''}">${remaining<0? (Math.abs(remaining)+' days past notice period') : (remaining+' days remaining in notice period')}</span>`;
  }
  return `
  <div class="card">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;">
      <div>
        <h3 style="margin-bottom:6px;">${app.trackingNo} — ${escapeHtml(app.personal.name)}</h3>
        <div style="font-size:12.5px;color:var(--text-mid);">${escapeHtml(app.property.address)}</div>
      </div>
      <span class="badge ${auctionBadgeClass(st.stage)}">${st.stage}</span>
    </div>
    <table style="margin-top:14px;"><tbody>
      <tr><td>Overdue Installments</td><td style="text-align:right;">${app.overdueCount}</td></tr>
      <tr><td>Outstanding Balance</td><td style="text-align:right;">${fmtINR(app.repayment.outstandingBalance)}</td></tr>
      <tr><td>Property Value</td><td style="text-align:right;">${fmtINR(app.property.value)}</td></tr>
      ${st.noticeDate? `<tr><td>Demand Notice Issued</td><td style="text-align:right;">${fmtDate(st.noticeDate)} ${noticeInfo}</td></tr>`:''}
      ${st.auctionDate? `<tr><td>e-Auction Scheduled</td><td style="text-align:right;">${fmtDate(st.auctionDate)} · Reserve ${fmtINR(st.reservePrice)}</td></tr>`:''}
      ${st.stage==='Auction Scheduled'? (()=>{ const bids=bidsForApp(app.id); const hb=bids.length?bids[0]:null; return `<tr><td>Bidder Activity</td><td style="text-align:right;">${bids.length} bid(s)${hb? ' · Highest '+fmtINR(hb.amount) : ''}</td></tr>`; })() : ''}
    </tbody></table>
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:14px;">
      ${st.stage==='None'? `<button class="btn btn-danger btn-sm" onclick="issueDemandNotice('${app.id}')">Issue Demand Notice (Sec 13(2))</button>`:''}
      ${st.stage==='Notice Issued'? `<button class="btn btn-danger btn-sm" onclick="takeLegalPossession('${app.id}')">Record Symbolic Possession</button>`:''}
      ${st.stage==='Possession'? `<button class="btn btn-danger btn-sm" onclick="openLegalAuctionScheduleModal('${app.id}')">Post for e-Auction</button>`:''}
      ${st.stage!=='None' && st.stage!=='Resolved'? `<button class="btn btn-outline btn-sm" onclick="resolveLegalAuction('${app.id}')">Mark Resolved / Withdraw</button>`:''}
    </div>
  </div>`;
}
function issueDemandNotice(appId){
  const app = DB.applications.find(a=>a.id===appId); ensureLegal(app);
  const s = currentUser();
  app.auction.stage='Notice Issued';
  app.auction.noticeDate=new Date().toISOString();
  app.auction.noticeDueDate=addDays(new Date(),60);
  app.auction.demandAmount = app.repayment.outstandingBalance;
  saveDB();
  const notice = {
    id:uid('ntc'), noticeNo:'SARFAESI/13(2)/'+new Date().getFullYear()+'/'+String(DB.nextNotice++).padStart(5,'0'),
    appId:app.id, trackingNo:app.trackingNo, borrower:app.personal.name, type:'Demand Notice — Section 13(2), SARFAESI Act',
    issueDate:new Date().toISOString(), dueDate:app.auction.noticeDueDate, status:'Active', officer:s.name,
    content:`HOUSING LOAN MANAGEMENT SYSTEM\nLEGAL & VALUATION TEAM\n\nDEMAND NOTICE UNDER SECTION 13(2) OF THE SARFAESI ACT, 2002\n\nDate: ${fmtDate(new Date())}\nLoan Account No.: ${app.trackingNo}\n\nTo,\n${app.personal.name}\n${app.property.address}\n\nDear Sir/Madam,\n\nYour loan account has become classified as a Non-Performing Asset due to non-payment of dues. You are hereby called upon to repay the outstanding amount of ${fmtINR(app.repayment.outstandingBalance)} within 60 days of this notice, failing which the Bank may exercise its rights under Section 13(4) of the SARFAESI Act, 2002, including taking possession of the secured asset described below and its sale by e-auction, without further reference to you.\n\nSecured Asset: ${app.property.address}\n\nThis is a system-generated legal notice for demonstration purposes.\n\nFor HLMS Bank\nLegal & Valuation Team\n${s.name}`
  };
  DB.legalNotices.unshift(notice); saveDB();
  pushNotification(app.userEmail, 'Legal Notice Issued', 'A Demand Notice under Section 13(2) of the SARFAESI Act has been issued on your loan account '+app.trackingNo+'. Please clear outstanding dues within 60 days.', notifChannels(app.userEmail));
  notifyRoleUsers('bankoffice', 'Demand Notice Issued', 'Legal & Valuation Team issued a Section 13(2) demand notice on loan account '+app.trackingNo+' ('+app.personal.name+').');
  toast('Demand Notice Issued', notice.noticeNo, 'success');
  render(location.hash.replace('#','') || 'legalauction');
}
function takeLegalPossession(appId){
  const app = DB.applications.find(a=>a.id===appId); ensureLegal(app);
  app.auction.stage='Possession'; app.auction.possessionDate=new Date().toISOString();
  app.auction.notes.push({date:new Date().toISOString(), text:'Symbolic possession of secured asset recorded under Section 13(4).'});
  saveDB();
  const s = currentUser();
  pushNotification(app.userEmail,'Possession Notice','Symbolic possession of the secured property under loan account '+app.trackingNo+' has been recorded.', notifChannels(app.userEmail));
  notifyRoleUsers(s.role==='bankoffice'?'legal':'bankoffice', 'Symbolic Possession Recorded', 'Symbolic possession of the secured property under loan account '+app.trackingNo+' ('+app.personal.name+') has been recorded by '+s.name+'. It is now eligible to be listed for e-auction.');
  toast('Possession Recorded', app.trackingNo, 'success');
  render(location.hash.replace('#','') || 'legalauction');
}
function openLegalAuctionScheduleModal(appId){
  const app = DB.applications.find(a=>a.id===appId);
  showModal('Post Property for e-Auction', `
    <p style="font-size:12.5px;color:var(--text-mid);margin-top:-6px;">This will publish <strong>${escapeHtml(app.property.address)}</strong> to the Bidder Portal so registered bidders can view and bid on it.</p>
    <div class="field"><label>Auction Date</label><input type="date" id="mAuctionDate" min="${new Date().toISOString().slice(0,10)}"></div>
    <div class="field"><label>Reserve Price (₹)</label><input type="number" id="mReservePrice" placeholder="e.g. 4200000" value="${app.property.value?Math.round(app.property.value*0.8):''}"></div>
    <button class="btn btn-primary btn-block" style="margin-top:10px;" onclick="scheduleLegalAuction('${appId}')">Post Auction to Bidder Portal</button>
  `);
}
function scheduleLegalAuction(appId){
  const app = DB.applications.find(a=>a.id===appId); ensureLegal(app);
  const dateVal = $('#mAuctionDate').value, price = Number($('#mReservePrice').value)||0;
  if(!dateVal || price<=0){ toast('Missing Details','Please provide an auction date and reserve price.'); return; }
  app.auction.stage='Auction Scheduled';
  app.auction.auctionDate = new Date(dateVal).toISOString();
  app.auction.reservePrice = price;
  saveDB();
  const s = currentUser();
  const notice = { id:uid('ntc'), noticeNo:'AUCTION/'+new Date().getFullYear()+'/'+String(DB.nextNotice++).padStart(5,'0'),
    appId:app.id, trackingNo:app.trackingNo, borrower:app.personal.name, type:'e-Auction Sale Notice',
    issueDate:new Date().toISOString(), dueDate:app.auction.auctionDate, status:'Active', officer:s.name,
    content:`HOUSING LOAN MANAGEMENT SYSTEM\nSALE NOTICE FOR e-AUCTION OF SECURED ASSET\n\nLoan Account No.: ${app.trackingNo}\nBorrower: ${app.personal.name}\nProperty: ${app.property.address}\nAuction Date: ${fmtDate(app.auction.auctionDate)}\nReserve Price: ${fmtINR(price)}\n\nThis is a system-generated legal notice for demonstration purposes.` };
  DB.legalNotices.unshift(notice); saveDB();
  pushNotification(app.userEmail,'e-Auction Scheduled','An e-auction sale of the secured property under loan account '+app.trackingNo+' has been scheduled for '+fmtDate(app.auction.auctionDate)+'.', notifChannels(app.userEmail));
  notifyRoleUsers(s.role==='bankoffice'?'legal':'bankoffice', 'Property Posted for e-Auction', s.name+' posted '+app.property.address+' (loan '+app.trackingNo+') for e-auction on '+fmtDate(app.auction.auctionDate)+', reserve '+fmtINR(price)+'.');
  notifyRoleUsers('bidder', 'New Property Listed for e-Auction', 'A new property has been listed for e-auction: '+app.property.address+'. Reserve price '+fmtINR(price)+'. Auction date '+fmtDate(app.auction.auctionDate)+'.');
  $('.modal-overlay')?.remove();
  toast('Auction Posted', 'Now visible to bidders — '+fmtDate(app.auction.auctionDate), 'success');
  render(location.hash.replace('#','') || 'legalauction');
}
function resolveLegalAuction(appId){
  const app = DB.applications.find(a=>a.id===appId); ensureLegal(app);
  app.auction.stage='Resolved';
  app.auction.notes.push({date:new Date().toISOString(), text:'Recovery proceedings resolved / withdrawn.'});
  saveDB();
  pushNotification(app.userEmail,'Recovery Proceedings Resolved','Recovery proceedings on your loan account '+app.trackingNo+' have been resolved.', notifChannels(app.userEmail));
  toast('Marked Resolved', app.trackingNo, 'success');
  render(location.hash.replace('#','') || 'legalauction');
}

/* ---- Legal Notices Log ---- */
function viewLegalNotices(){
  const notices = DB.legalNotices.slice().sort((a,b)=>new Date(b.issueDate)-new Date(a.issueDate));
  return `
  <div class="page-head">
    <div><h1>Legal Notices Log</h1><p>All demand and auction notices issued, plus manual legal correspondence.</p></div>
    <button class="btn btn-primary" onclick="openDraftNoticeModal()">+ Draft Custom Notice</button>
  </div>
  <div class="card">
    ${notices.length===0? `<div class="empty-state"><div class="ic">✉️</div>No notices issued yet.</div>` :
      `<table><thead><tr><th>Notice No.</th><th>Type</th><th>Loan A/C</th><th>Borrower</th><th>Issued</th><th>Status</th><th></th></tr></thead><tbody>
      ${notices.map(n=>`<tr>
        <td>${n.noticeNo}</td><td>${escapeHtml(n.type)}</td><td>${n.trackingNo||'—'}</td><td>${escapeHtml(n.borrower||'—')}</td>
        <td>${fmtDate(n.issueDate)}</td><td><span class="badge ${n.status==='Active'?'badge-orange':'badge-gray'}">${n.status}</span></td>
        <td style="text-align:right;"><button class="btn btn-outline btn-sm" onclick="downloadTextFile(\`${(n.content||'').replace(/`/g,"'")}\`,'${n.noticeNo.replace(/\//g,'_')}.txt')">Download</button></td>
      </tr>`).join('')}</tbody></table>`}
  </div>
  `;
}
function openDraftNoticeModal(){
  const apps = DB.applications;
  showModal('Draft Custom Legal Notice', `
    <div class="field"><label>Application</label>
      <select id="mNoticeApp"><option value="">— Not linked to an application —</option>${apps.map(a=>`<option value="${a.id}">${a.trackingNo} — ${escapeHtml(a.personal.name)}</option>`).join('')}</select>
    </div>
    <div class="field"><label>Notice Type</label><input id="mNoticeType" placeholder="e.g. Legal Opinion Letter, Cease &amp; Desist"></div>
    <div class="field"><label>Notice Content</label><textarea id="mNoticeContent" rows="6" placeholder="Type the full notice text..."></textarea></div>
    <button class="btn btn-primary btn-block" style="margin-top:10px;" onclick="draftLegalNotice()">Save &amp; Log Notice</button>
  `);
}
function draftLegalNotice(){
  const appId = $('#mNoticeApp').value, type = $('#mNoticeType').value.trim(), content = $('#mNoticeContent').value.trim();
  if(!type||!content){ toast('Missing Details','Please provide a notice type and content.'); return; }
  const app = appId ? DB.applications.find(a=>a.id===appId) : null;
  const n = { id:uid('ntc'), noticeNo:'LEGAL/'+new Date().getFullYear()+'/'+String(DB.nextNotice++).padStart(5,'0'),
    appId: appId||null, trackingNo: app?app.trackingNo:null, borrower: app?app.personal.name:null,
    type, issueDate:new Date().toISOString(), dueDate:null, status:'Active', officer:currentUser().name, content };
  DB.legalNotices.unshift(n); saveDB();
  if(app) pushNotification(app.userEmail, type, 'A new legal communication has been issued regarding your loan account '+app.trackingNo+'.', notifChannels(app.userEmail));
  $('.modal-overlay')?.remove();
  toast('Notice Logged', n.noticeNo, 'success');
  render('legalnotices');
}

/* ---- Legal Team Profile ---- */
function viewLegalProfile(){
  const s = currentUser();
  return `
  <div class="page-head"><h1>Profile Settings</h1><p>Your Legal &amp; Valuation Team account details.</p></div>
  <div class="grid grid-2">
    <div class="card">
      <h3>👤 Account Details</h3>
      <div class="field"><label>Full Name</label><input id="pfName" value="${escapeHtml(s.name)}"><div class="error hidden" id="err_pfName"></div></div>
      <div class="two-col">
        <div class="field"><label>Mobile</label><input id="pfMobile" value="${escapeHtml(s.mobile||'')}"><div class="error hidden" id="err_pfMobile"></div></div>
        <div class="field"><label>Email</label><input value="${escapeHtml(s.email)}" disabled></div>
      </div>
      <div class="field"><label>Role</label><input value="${ROLE_LABELS[s.role]||s.role}" disabled></div>
      <button class="btn btn-primary" onclick="savePersonal()">Save Changes</button>
    </div>
    <div class="card">
      <h3>📊 Your Activity Summary</h3>
      <table><tbody>
        <tr><td>Cases Reviewed</td><td style="text-align:right;">${DB.applications.filter(a=>a.legal&&a.legal.officer===s.name).length}</td></tr>
        <tr><td>Notices Issued</td><td style="text-align:right;">${DB.legalNotices.filter(n=>n.officer===s.name).length}</td></tr>
      </tbody></table>
    </div>
  </div>
  <div class="card">
    <h3>🔒 Change Password</h3>
    <div class="field"><label>Current Password</label><input type="password" id="cpCurrent"><div class="error hidden" id="err_cpCurrent"></div></div>
    <div class="field"><label>New Password</label><input type="password" id="cpNew"><div class="error hidden" id="err_cpNew"></div></div>
    <div class="field"><label>Confirm New Password</label><input type="password" id="cpNew2"><div class="error hidden" id="err_cpNew2"></div></div>
    <button class="btn btn-primary btn-sm" onclick="changePasswordProfile()">Update Password</button>
  </div>
  `;
}

/* ================================================================
   BANK OFFICE PORTAL (role: bankoffice)
   Dashboard, Loan Applications, Customer Portfolio, Disbursement Queue,
   Overdue & NPA Tracking, Document Verification, Auction Management,
   Reports & Analytics, Settings.
   ================================================================ */
let boCurrentAppId = null;
function openBankOfficeApp(appId){ boCurrentAppId = appId; go('boappdetail'); }
function boIsNPA(overdueCount){ return overdueCount>=3; }

function viewBankOfficeDashboard(){
  const u = currentUser();
  const apps = DB.applications||[];
  const pendingReview = apps.filter(a=>a.status==='Under Review' || a.status==='Submitted').length;
  const readyToDisburse = apps.filter(a=>a.stageIndex===WORKFLOW_STAGES.length-1 && a.status!=='Disbursed').length;
  const disbursedThisMonth = apps.filter(a=>a.status==='Disbursed' && a.disbursement && new Date(a.disbursement.date).getMonth()===new Date().getMonth()).length;
  const overdue = overdueLegalApplications();
  const npaCount = overdue.filter(a=>boIsNPA(a.overdueCount)).length;
  const recent = apps.slice().sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)).slice(0,5);
  return `
  <div class="page-head"><h1>Welcome, ${escapeHtml(u.name.split(' ')[0])} 👋</h1><p>Branch-level overview of loan applications, disbursements and recovery.</p></div>
  <div class="grid grid-4">
    <div class="card stat"><div class="lbl">Total Applications</div><div class="val">${apps.length}</div></div>
    <div class="card stat"><div class="lbl">Pending Review</div><div class="val orange">${pendingReview}</div></div>
    <div class="card stat"><div class="lbl">Ready to Disburse</div><div class="val teal">${readyToDisburse}</div></div>
    <div class="card stat"><div class="lbl">Disbursed This Month</div><div class="val teal">${disbursedThisMonth}</div></div>
  </div>
  <div class="grid grid-2">
    <div class="card stat"><div class="lbl">Overdue Accounts</div><div class="val orange">${overdue.length}</div><div class="sub">Accounts with missed installments</div></div>
    <div class="card stat"><div class="lbl">NPA Accounts</div><div class="val red">${npaCount}</div><div class="sub">3+ overdue installments</div></div>
  </div>
  <div class="card">
    <h3>📋 Recent Applications</h3>
    ${recent.length===0? `<div class="empty-state"><div class="ic">📭</div>No applications yet.</div>` :
      `<table><thead><tr><th>Tracking No.</th><th>Applicant</th><th>Loan Type</th><th>Amount</th><th>Status</th><th></th></tr></thead><tbody>
      ${recent.map(a=>`<tr class="clickable-row" onclick="openBankOfficeApp('${a.id}')">
        <td>${a.trackingNo}</td><td>${escapeHtml(a.personal.name)}</td><td>${escapeHtml(a.loanType)}</td>
        <td>${fmtINR(a.loanAmount)}</td><td><span class="badge ${boStatusBadge(a.status)}">${a.status}</span></td>
        <td style="text-align:right;"><span class="arrow">→</span></td>
      </tr>`).join('')}</tbody></table>`}
    <button class="btn btn-outline btn-sm" style="margin-top:12px;" onclick="go('boapplications')">View All Applications</button>
  </div>
  <div class="grid grid-2">
    <div class="card">
      <h3>✅ Quick Actions</h3>
      <div class="quick-links">
        <a href="#" onclick="go('bodisbursement');return false;">Process Disbursement Queue <span class="arrow">→</span></a>
        <a href="#" onclick="go('bonpa');return false;">Review Overdue &amp; NPA Accounts <span class="arrow">→</span></a>
        <a href="#" onclick="go('bodocs');return false;">Document Verification <span class="arrow">→</span></a>
        <a href="#" onclick="go('boreports');return false;">View Reports &amp; Analytics <span class="arrow">→</span></a>
      </div>
    </div>
    <div class="card">
      <h3>👥 Portfolio Snapshot</h3>
      ${renderBankOfficePortfolioSnapshot()}
    </div>
  </div>
  `;
}
function boStatusBadge(status){
  if(status==='Disbursed') return 'badge-green';
  if(status==='Rejected') return 'badge-red';
  if(status==='Under Review') return 'badge-orange';
  return 'badge-gray';
}
function renderBankOfficePortfolioSnapshot(){
  const customers = usersByRole('customer');
  const apps = DB.applications||[];
  const totalDisbursed = apps.filter(a=>a.status==='Disbursed').reduce((s,a)=>s+(a.disbursement?a.disbursement.amount:0),0);
  return `<table><tbody>
    <tr><td>Total Customers</td><td style="text-align:right;">${customers.length}</td></tr>
    <tr><td>Active Loan Accounts</td><td style="text-align:right;">${apps.filter(a=>a.status==='Disbursed').length}</td></tr>
    <tr><td>Total Disbursed Amount</td><td style="text-align:right;">${fmtINR(totalDisbursed)}</td></tr>
  </tbody></table>`;
}

/* ---- Loan Applications ---- */
function viewBankOfficeApplications(){
  const apps = (DB.applications||[]).slice().sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
  return `
  <div class="page-head"><h1>Loan Applications</h1><p>All loan applications submitted across the branch.</p></div>
  <div class="card">
    ${apps.length===0? `<div class="empty-state"><div class="ic">📭</div>No applications yet.</div>` :
      `<table><thead><tr><th>Tracking No.</th><th>Applicant</th><th>Loan Type</th><th>Amount</th><th>Stage</th><th>Status</th><th></th></tr></thead><tbody>
      ${apps.map(a=>`<tr class="clickable-row" onclick="openBankOfficeApp('${a.id}')">
        <td>${a.trackingNo}</td><td>${escapeHtml(a.personal.name)}</td><td>${escapeHtml(a.loanType)}</td>
        <td>${fmtINR(a.loanAmount)}</td><td>${escapeHtml(WORKFLOW_STAGES[a.stageIndex])}</td>
        <td><span class="badge ${boStatusBadge(a.status)}">${a.status}</span></td>
        <td style="text-align:right;"><button class="btn btn-outline btn-sm" onclick="event.stopPropagation();openBankOfficeApp('${a.id}')">View</button></td>
      </tr>`).join('')}</tbody></table>`}
  </div>
  `;
}

/* ---- Application Detail (view + advance non-legal stages) ---- */
function viewBankOfficeAppDetail(){
  const app = DB.applications.find(a=>a.id===boCurrentAppId);
  if(!app) return `<div class="empty-state"><div class="ic">⚠️</div>Application not found.</div><button class="btn btn-outline btn-sm" onclick="go('boapplications')">Back to Applications</button>`;
  ensureLegal(app);
  const stages = buildStages(app);
  const canAdvance = app.status!=='Disbursed' && app.status!=='Rejected' && app.stageIndex!==LEGAL_STAGE_INDEX;
  const canReject = app.status!=='Disbursed' && app.status!=='Rejected';
  return `
  <div class="back-link" onclick="go('boapplications')">← Back to Loan Applications</div>
  <div class="page-head">
    <div><h1>${app.trackingNo}</h1><p>${escapeHtml(app.loanType)} · ${escapeHtml(app.personal.name)}</p></div>
    <span class="badge ${boStatusBadge(app.status)}">${app.status}</span>
  </div>
  ${app.status==='Rejected'? renderRejectionBanner(app) : ''}
  ${app.status!=='Rejected' && app.legal && app.legal.decision==='Query Raised'? `
  <div class="card" style="background:var(--orange-bg);box-shadow:none;">
    <h3 style="color:var(--orange);">⚠ Discrepancy Flagged by Legal Team</h3>
    <p style="margin:0;font-size:13px;color:var(--text-mid);">${escapeHtml(app.legal.remarks||'The Legal Team has raised a query on this application.')}</p>
  </div>` : ''}
  <div class="grid grid-2">
    <div class="card">
      <h3>👤 Applicant &amp; Loan Details</h3>
      <table><tbody>
        <tr><td>Applicant Name</td><td style="text-align:right;">${escapeHtml(app.personal.name)}</td></tr>
        <tr><td>PAN Number</td><td style="text-align:right;">${escapeHtml(app.personal.pan||'—')}</td></tr>
        <tr><td>Mobile</td><td style="text-align:right;">${escapeHtml(app.personal.mobile||'—')}</td></tr>
        <tr><td>Loan Type</td><td style="text-align:right;">${escapeHtml(app.loanType)}</td></tr>
        <tr><td>Loan Amount</td><td style="text-align:right;">${fmtINR(app.loanAmount)}</td></tr>
        <tr><td>Interest Rate</td><td style="text-align:right;">${app.interestRate}% p.a.</td></tr>
        <tr><td>Tenure</td><td style="text-align:right;">${app.tenureYears} years</td></tr>
        <tr><td>EMI</td><td style="text-align:right;">${fmtINR(calcEMI(app.loanAmount, app.interestRate, app.tenureYears))}</td></tr>
      </tbody></table>
    </div>
    <div class="card">
      <h3>⌂ Property Details</h3>
      <table><tbody>
        <tr><td>Address</td><td style="text-align:right;">${escapeHtml(app.property.address)}</td></tr>
        <tr><td>Property Type</td><td style="text-align:right;">${escapeHtml(app.property.type)}</td></tr>
        <tr><td>Declared Value</td><td style="text-align:right;">${fmtINR(app.property.value)}</td></tr>
      </tbody></table>
    </div>
  </div>
  <div class="card">
    <h3>↗ Workflow Progress</h3>
    <table><thead><tr><th>Stage</th><th>Status</th><th>Officer / Dept.</th></tr></thead><tbody>
    ${stages.map(s=>`<tr><td>${s.name}</td><td><span class="badge ${s.status==='completed'?'badge-green':s.status==='current'?'badge-orange':'badge-gray'}">${s.status}</span></td><td style="text-align:right;">${s.officer} · ${s.department}</td></tr>`).join('')}
    </tbody></table>
    ${canAdvance? `<button class="btn btn-primary btn-sm" style="margin-top:14px;" onclick="advanceStage('${app.id}')">Move to Next Stage</button>` :
      app.stageIndex===LEGAL_STAGE_INDEX && app.status!=='Rejected'? `<p style="font-size:12.5px;color:var(--text-gray);margin-top:12px;">This application is awaiting Legal &amp; Property Verification and can only be advanced by the Legal Team.</p>` : ''}
  </div>
  ${canReject? `
  <div class="card">
    <h3>⚖ Bank Office Decision</h3>
    <p style="font-size:12.5px;color:var(--text-mid);margin:0 0 14px;">As Bank Office, you may reject this application directly — for example, following a discrepancy flagged by the Legal Team, or on your own review. The applicant will be notified immediately with your reason.</p>
    <button class="btn btn-danger btn-sm" onclick="openBankOfficeRejectModal('${app.id}')">Reject Application</button>
  </div>` : ''}
  `;
}
const BO_REJECTION_REASONS = [
  'Title discrepancy flagged by Legal Team',
  'Insufficient income / high debt-to-income ratio',
  'Incomplete or invalid documentation',
  'Property value below required threshold',
  'Poor credit history',
  'Applicant did not respond to a query in time',
  'Other (specify below)'
];
function openBankOfficeRejectModal(appId){
  showModal('Reject Application', `
    <p style="font-size:12.5px;color:var(--text-mid);">This will mark the application as Rejected and notify the applicant with the reason below.</p>
    <div class="field"><label>Rejection Reason<span class="req">*</span></label>
      <select id="boRejectReason" onchange="onBoRejectReasonChange(this)">
        <option value="" selected disabled>Select a reason...</option>
        ${BO_REJECTION_REASONS.map(r=>`<option value="${escapeHtml(r)}">${escapeHtml(r)}</option>`).join('')}
      </select>
      <div class="error hidden" id="err_boRejectReason"></div>
    </div>
    <div class="field"><label>Additional Remarks${''}<span class="req">*</span></label><textarea id="boRejectRemarks" rows="4" placeholder="Add specifics the applicant should know..."></textarea><div class="error hidden" id="err_boRejectRemarks"></div></div>
    <button class="btn btn-danger btn-block" onclick="rejectApplicationByBankOffice('${appId}')">Confirm Rejection</button>
  `);
}
function onBoRejectReasonChange(sel){
  const remarksEl = $('#boRejectRemarks');
  if(sel.value && sel.value!=='Other (specify below)' && !remarksEl.value.trim()){
    remarksEl.value = sel.value + ' — ';
    remarksEl.focus();
    remarksEl.setSelectionRange(remarksEl.value.length, remarksEl.value.length);
  }
  fieldOk(sel, $('#err_boRejectReason'));
}
function rejectApplicationByBankOffice(appId){
  const app = DB.applications.find(a=>a.id===appId); if(!app) return;
  const reasonEl = $('#boRejectReason');
  const remarksEl = $('#boRejectRemarks');
  const reason = reasonEl.value;
  const remarks = remarksEl.value.trim();
  let ok = true;
  if(!reason){ ok = fieldError(reasonEl, $('#err_boRejectReason'), 'Please select a rejection reason.') && ok; } else fieldOk(reasonEl, $('#err_boRejectReason'));
  if(!remarks){ ok = fieldError(remarksEl, $('#err_boRejectRemarks'), 'Please provide details for the applicant.') && ok; } else fieldOk(remarksEl, $('#err_boRejectRemarks'));
  if(!ok) return;
  const s = currentUser();
  app.status = 'Rejected';
  app.boDecision = { decision:'Rejected', officer:s.name, date:new Date().toISOString(), reason, remarks };
  saveDB();
  pushNotification(app.userEmail, 'Application Rejected', 'Your application '+app.trackingNo+' has been rejected by the Bank Office. Reason: '+remarks, notifChannels(app.userEmail));
  $('.modal-overlay')?.remove();
  toast('Application Rejected', app.trackingNo+' — applicant has been notified.', 'success');
  render('boappdetail');
}

/* ---- Customer Portfolio ---- */
function viewBankOfficePortfolio(){
  const customers = usersByRole('customer');
  const apps = DB.applications||[];
  return `
  <div class="page-head"><h1>Customer Portfolio</h1><p>Overview of all registered customers and their loan accounts.</p></div>
  <div class="card">
    ${customers.length===0? `<div class="empty-state"><div class="ic">👥</div>No customers registered yet.</div>` :
      `<table><thead><tr><th>Customer</th><th>Email</th><th>Applications</th><th>Active Loans</th><th>Total Disbursed</th></tr></thead><tbody>
      ${customers.map(c=>{
        const cApps = apps.filter(a=>a.userEmail===c.email);
        const active = cApps.filter(a=>a.status==='Disbursed').length;
        const total = cApps.filter(a=>a.status==='Disbursed').reduce((s,a)=>s+(a.disbursement?a.disbursement.amount:0),0);
        return `<tr>
          <td>${escapeHtml(c.name)}</td><td>${escapeHtml(c.email)}</td>
          <td>${cApps.length}</td><td>${active}</td><td>${fmtINR(total)}</td>
        </tr>`;
      }).join('')}</tbody></table>`}
  </div>
  `;
}

/* ---- Disbursement Queue ---- */
function viewBankOfficeDisbursement(){
  const apps = DB.applications||[];
  const ready = apps.filter(a=>a.stageIndex===WORKFLOW_STAGES.length-1 && a.status!=='Disbursed');
  const disbursed = apps.filter(a=>a.status==='Disbursed').sort((a,b)=>new Date(b.disbursement.date)-new Date(a.disbursement.date));
  return `
  <div class="page-head"><h1>Disbursement Queue</h1><p>Applications that have cleared final approval and are ready for fund disbursement.</p></div>
  <div class="card">
    <h3>💳 Ready to Disburse (${ready.length})</h3>
    ${ready.length===0? `<div class="empty-state"><div class="ic">✅</div>No applications currently awaiting disbursement.</div>` :
      `<table><thead><tr><th>Tracking No.</th><th>Applicant</th><th>Loan Amount</th><th></th></tr></thead><tbody>
      ${ready.map(a=>`<tr>
        <td>${a.trackingNo}</td><td>${escapeHtml(a.personal.name)}</td><td>${fmtINR(a.loanAmount)}</td>
        <td style="text-align:right;"><button class="btn btn-primary btn-sm" onclick="advanceStage('${a.id}')">Disburse Funds</button></td>
      </tr>`).join('')}</tbody></table>`}
  </div>
  <div class="card">
    <h3>📜 Recently Disbursed</h3>
    ${disbursed.length===0? `<div class="empty-state"><div class="ic">📭</div>No disbursements recorded yet.</div>` :
      `<table><thead><tr><th>Tracking No.</th><th>Applicant</th><th>Amount</th><th>Ref No.</th><th>Date</th></tr></thead><tbody>
      ${disbursed.slice(0,10).map(a=>`<tr>
        <td>${a.trackingNo}</td><td>${escapeHtml(a.personal.name)}</td><td>${fmtINR(a.disbursement.amount)}</td>
        <td>${a.disbursement.refNo}</td><td>${fmtDate(a.disbursement.date)}</td>
      </tr>`).join('')}</tbody></table>`}
  </div>
  `;
}

/* ---- Overdue & NPA Tracking ---- */
function viewBankOfficeNPA(){
  const list = overdueLegalApplications();
  return `
  <div class="page-head"><h1>Overdue &amp; NPA Tracking</h1><p>Monitor loan accounts with missed EMI payments and classify Non-Performing Assets.</p></div>
  <div class="grid grid-2">
    <div class="card stat"><div class="lbl">Overdue Accounts</div><div class="val orange">${list.length}</div></div>
    <div class="card stat"><div class="lbl">NPA Accounts (3+ overdue EMIs)</div><div class="val red">${list.filter(a=>boIsNPA(a.overdueCount)).length}</div></div>
  </div>
  <div class="card" style="background:var(--purple-bg);box-shadow:none;">
    <p style="margin:0;font-size:13px;color:var(--text-mid);">As Bank Office, you may classify an account as a Non-Performing Asset once it has 3 or more overdue EMI installments (typically 90+ days past due). Classifying an account as NPA issues a demand notice and starts the recovery / auction process, which is then carried through by the Legal &amp; Valuation Team.</p>
  </div>
  <div class="card">
    ${list.length===0? `<div class="empty-state"><div class="ic">✅</div>No overdue accounts at this time.</div>` :
      `<table><thead><tr><th>Tracking No.</th><th>Borrower</th><th>Overdue Installments</th><th>Outstanding Balance</th><th>Classification</th><th>Recovery Stage</th><th></th></tr></thead><tbody>
      ${list.map(a=>`<tr>
        <td class="clickable-row" onclick="openBankOfficeApp('${a.id}')">${a.trackingNo}</td><td>${escapeHtml(a.personal.name)}</td><td>${a.overdueCount}</td>
        <td>${fmtINR(a.repayment.outstandingBalance)}</td>
        <td><span class="badge ${boIsNPA(a.overdueCount)?'badge-red':'badge-orange'}">${boIsNPA(a.overdueCount)?'NPA':'Overdue'}</span></td>
        <td><span class="badge ${auctionBadgeClass(a.auction.stage)}">${a.auction.stage}</span></td>
        <td style="text-align:right;">${boIsNPA(a.overdueCount) && a.auction.stage==='None'? `<button class="btn btn-danger btn-sm" onclick="markAppAsNPA('${a.id}')">Mark as NPA &amp; Start Auction</button>` : (a.auction.stage!=='None'? `<span style="font-size:11.5px;color:var(--text-gray);">Recovery in progress</span>` : '')}</td>
      </tr>`).join('')}</tbody></table>`}
  </div>
  `;
}
function markAppAsNPA(appId){
  const app = DB.applications.find(a=>a.id===appId); if(!app) return;
  ensureLegal(app);
  if(app.auction.stage!=='None'){ toast('Already In Recovery','This account is already under recovery proceedings.'); return; }
  const overdueCount = (app.repayment && app.repayment.schedule) ? app.repayment.schedule.filter(s=>s.status==='Overdue').length : 0;
  if(!boIsNPA(overdueCount)){ toast('Not Eligible','This account has fewer than 3 overdue installments and cannot be classified as NPA yet.'); return; }
  if(!confirm(`Classify ${app.trackingNo} (${app.personal.name}) as NPA and start the auction/recovery process? A demand notice will be issued and the Legal Team will be notified.`)) return;
  const s = currentUser();
  app.npa = { marked:true, markedBy:s.name, date:new Date().toISOString(), overdueCount };
  app.auction.stage = 'Notice Issued';
  app.auction.noticeDate = new Date().toISOString();
  app.auction.noticeDueDate = addDays(new Date(), 60);
  app.auction.demandAmount = app.repayment.outstandingBalance;
  saveDB();
  const notice = {
    id:uid('ntc'), noticeNo:'NPA/'+new Date().getFullYear()+'/'+String(DB.nextNotice++).padStart(5,'0'),
    appId:app.id, trackingNo:app.trackingNo, borrower:app.personal.name, type:'NPA Classification & Demand Notice — Section 13(2), SARFAESI Act',
    issueDate:new Date().toISOString(), dueDate:app.auction.noticeDueDate, status:'Active', officer:s.name,
    content:`HOUSING LOAN MANAGEMENT SYSTEM\nBANK OFFICE\n\nNPA CLASSIFICATION & DEMAND NOTICE UNDER SECTION 13(2) OF THE SARFAESI ACT, 2002\n\nDate: ${fmtDate(new Date())}\nLoan Account No.: ${app.trackingNo}\n\nTo,\n${app.personal.name}\n${app.property.address}\n\nDear Sir/Madam,\n\nYour loan account has been classified as a Non-Performing Asset (NPA) due to non-payment of ${overdueCount} or more EMI installments. You are hereby called upon to repay the outstanding amount of ${fmtINR(app.repayment.outstandingBalance)} within 60 days of this notice, failing which the Bank may exercise its rights under Section 13(4) of the SARFAESI Act, 2002, including taking possession of the secured asset and its sale by e-auction, without further reference to you.\n\nSecured Asset: ${app.property.address}\n\nThis is a system-generated legal notice for demonstration purposes.\n\nFor HLMS Bank\nBank Office\n${s.name}`
  };
  DB.legalNotices.unshift(notice); saveDB();
  pushNotification(app.userEmail, 'Account Classified as NPA', 'Your loan account '+app.trackingNo+' has been classified as a Non-Performing Asset due to '+overdueCount+' overdue installments. A demand notice has been issued — please clear outstanding dues within 60 days.', notifChannels(app.userEmail));
  notifyRoleUsers('legal', 'Account Classified as NPA by Bank Office', 'Bank Office has classified loan account '+app.trackingNo+' ('+escapeHtml(app.personal.name)+') as NPA and issued a demand notice. Please continue recovery proceedings under Auction & SARFAESI.');
  toast('Marked as NPA', app.trackingNo+' — demand notice issued and Legal Team notified.', 'success');
  render('bonpa');
}

/* ---- Document Verification (grouped per customer, with Verify / Reject) ---- */
function viewBankOfficeDocuments(){
  const apps = applicationsWithDocsForBO().slice().sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
  const totalPending = pendingAppDocsCount();
  return `
  <div class="page-head"><h1>Document Verification</h1><p>Review each customer's submitted KYC and loan documents, and verify or reject them individually.</p></div>
  <div class="grid grid-4">
    <div class="card stat"><div class="lbl">Customers with Documents</div><div class="val">${apps.length}</div></div>
    <div class="card stat"><div class="lbl">Documents Pending Review</div><div class="val orange">${totalPending}</div></div>
  </div>
  ${apps.length===0? `<div class="card"><div class="empty-state"><div class="ic">📭</div>No documents have been submitted yet.</div></div>` :
    apps.map(a=>renderBankOfficeCustomerDocCard(a)).join('')}
  `;
}
function renderBankOfficeCustomerDocCard(app){
  const ds = ensureDocStatus(app);
  const docs = Object.entries(app.documents||{}).filter(([k,v])=>v);
  const pendingCount = docs.filter(([k])=>ds[k] && ds[k].status==='Pending').length;
  return `
  <div class="card">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;margin-bottom:8px;">
      <div>
        <h3 style="margin:0;">👤 ${escapeHtml(app.personal.name)} <span style="font-weight:500;color:var(--text-gray);font-size:12.5px;">· ${app.trackingNo}</span></h3>
        <p style="margin:2px 0 0;font-size:12.5px;color:var(--text-gray);">${escapeHtml(app.loanType)} · ${fmtINR(app.loanAmount)}</p>
      </div>
      ${pendingCount>0? `<span class="badge badge-orange">${pendingCount} pending</span>` : `<span class="badge badge-green">All reviewed</span>`}
    </div>
    <table><thead><tr><th>Document</th><th>Uploaded</th><th>Status</th><th></th></tr></thead><tbody>
    ${docs.map(([k,v])=>{
      const st = ds[k] || {status:'Pending'};
      return `<tr>
        <td>${escapeHtml(v.name || DOC_LABELS[k] || k)}<div style="font-size:11px;color:var(--text-gray);">${DOC_LABELS[k]||k}</div></td>
        <td>${fmtDate(v.uploadedAt||app.createdAt)}</td>
        <td><span class="badge ${docBadgeClass(st.status)}">${st.status}</span>${st.status==='Rejected'&&st.remarks? `<div style="font-size:11px;color:var(--red);margin-top:3px;">${escapeHtml(st.remarks)}</div>`:''}</td>
        <td style="text-align:right;white-space:nowrap;">
          <button class="btn btn-outline btn-sm" onclick="downloadTextFile('Placeholder content for '+'${escapeHtml(v.name||DOC_LABELS[k]||k)}','${escapeHtml(v.name||k)}.txt')">View</button>
          ${st.status==='Pending'? ` <button class="btn btn-primary btn-sm" onclick="verifyAppDocument('${app.id}','${k}')">Verify</button> <button class="btn btn-danger btn-sm" onclick="openRejectAppDocumentModal('${app.id}','${k}')">Reject</button>` : ''}
        </td>
      </tr>`;
    }).join('')}
    </tbody></table>
  </div>
  `;
}
function verifyAppDocument(appId, key){
  const app = DB.applications.find(a=>a.id===appId); if(!app) return;
  const ds = ensureDocStatus(app);
  const s = currentUser();
  ds[key] = { status:'Verified', remarks:'', verifiedBy:s.name, verifiedAt:new Date().toISOString() };
  saveDB();
  const label = (app.documents[key]&&app.documents[key].name) || DOC_LABELS[key] || key;
  pushNotification(app.userEmail, 'Document Verified', 'Your document "'+label+'" for application '+app.trackingNo+' has been verified by the Bank Office.', notifChannels(app.userEmail));
  toast('Document Verified', label, 'success');
  render('bodocs');
}
function openRejectAppDocumentModal(appId, key){
  showModal('Reject Document', `
    <p style="font-size:12.5px;color:var(--text-mid);">The customer will be notified and asked to re-upload a correct document.</p>
    <div class="field"><label>Reason for Rejection</label><textarea id="appDocRejectRemarks" rows="4" placeholder="e.g. Document unclear, expired, does not match records..."></textarea><div class="error hidden" id="err_appDocRejectRemarks"></div></div>
    <button class="btn btn-danger btn-block" onclick="rejectAppDocument('${appId}','${key}')">Confirm Rejection</button>
  `);
}
function rejectAppDocument(appId, key){
  const app = DB.applications.find(a=>a.id===appId); if(!app) return;
  const remarksEl = $('#appDocRejectRemarks');
  const remarks = remarksEl.value.trim();
  if(!remarks){ fieldError(remarksEl, $('#err_appDocRejectRemarks'), 'Please provide a reason for rejection.'); return; }
  const ds = ensureDocStatus(app);
  const s = currentUser();
  ds[key] = { status:'Rejected', remarks, verifiedBy:s.name, verifiedAt:new Date().toISOString() };
  saveDB();
  const label = (app.documents[key]&&app.documents[key].name) || DOC_LABELS[key] || key;
  pushNotification(app.userEmail, 'Document Rejected', 'Your document "'+label+'" for application '+app.trackingNo+' was rejected by the Bank Office. Reason: '+remarks+'. Please re-upload a correct document.', notifChannels(app.userEmail));
  $('.modal-overlay')?.remove();
  toast('Document Rejected', label, 'success');
  render('bodocs');
}

/* ---- Auction Management (Bank Office can post loan-defaulter properties for e-auction) ---- */
function viewBankOfficeAuction(){
  const all = overdueLegalApplications().map(a=>{ ensureLegal(a); return a; });
  const inRecovery = all.filter(a=>a.auction.stage!=='None');
  const eligibleForRecovery = all.filter(a=>a.auction.stage==='None' && boIsNPA(a.overdueCount));
  const live = inRecovery.filter(a=>a.auction.stage==='Auction Scheduled');
  const totalBids = live.reduce((s,a)=>s+bidsForApp(a.id).length,0);
  return `
  <div class="page-head"><h1>Auction Management</h1><p>Post loan-defaulter properties for e-auction and track live bidding — synced live with the Legal &amp; Valuation Team and the Bidder Portal.</p></div>
  <div class="grid grid-4">
    <div class="card stat"><div class="lbl">Defaulters Eligible to List</div><div class="val orange">${eligibleForRecovery.length}</div></div>
    <div class="card stat"><div class="lbl">In Recovery Pipeline</div><div class="val">${inRecovery.length}</div></div>
    <div class="card stat"><div class="lbl">Live on Bidder Portal</div><div class="val teal">${live.length}</div></div>
    <div class="card stat"><div class="lbl">Total Bids Received</div><div class="val green">${totalBids}</div></div>
  </div>
  <div class="card" style="background:var(--purple-bg);box-shadow:none;">
    <p style="margin:0;font-size:13px;color:var(--text-mid);">Move a defaulting account through recovery — record symbolic possession, then post it for e-auction. Once posted, it instantly appears in the Bidder Portal for registered bidders to bid on, and stays in sync with the Legal &amp; Valuation Team's SARFAESI dashboard.</p>
  </div>
  ${inRecovery.length===0? `<div class="card"><div class="empty-state"><div class="ic">✅</div>No accounts currently under recovery proceedings.<br>Classify overdue accounts as NPA from <a href="#" onclick="go('bonpa');return false;">Overdue &amp; NPA Tracking</a> to begin.</div></div>` :
    inRecovery.map(a=>renderBankOfficeAuctionCard(a)).join('')}
  `;
}
function renderBankOfficeAuctionCard(app){
  const st = app.auction;
  const bids = bidsForApp(app.id);
  const hb = bids.length ? bids[0] : null;
  let noticeInfo = '';
  if(st.stage!=='None' && st.noticeDueDate){
    const remaining = daysBetween(st.noticeDueDate, new Date());
    noticeInfo = `<span class="countdown-pill ${remaining<0?'overdue':''}">${remaining<0? (Math.abs(remaining)+' days past notice period') : (remaining+' days remaining in notice period')}</span>`;
  }
  return `
  <div class="card">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;">
      <div>
        <h3 style="margin-bottom:6px;">${app.trackingNo} — ${escapeHtml(app.personal.name)}</h3>
        <div style="font-size:12.5px;color:var(--text-mid);">${escapeHtml(app.property.address)}</div>
      </div>
      <span class="badge ${auctionBadgeClass(st.stage)}">${st.stage}</span>
    </div>
    <table style="margin-top:14px;"><tbody>
      <tr><td>Overdue Installments</td><td style="text-align:right;">${app.overdueCount}</td></tr>
      <tr><td>Outstanding Balance</td><td style="text-align:right;">${fmtINR(app.repayment.outstandingBalance)}</td></tr>
      <tr><td>Property Value</td><td style="text-align:right;">${fmtINR(app.property.value)}</td></tr>
      ${st.noticeDate? `<tr><td>Demand Notice Issued</td><td style="text-align:right;">${fmtDate(st.noticeDate)} ${noticeInfo}</td></tr>`:''}
      ${st.auctionDate? `<tr><td>Posted for e-Auction</td><td style="text-align:right;">${fmtDate(st.auctionDate)} · Reserve ${fmtINR(st.reservePrice)}</td></tr>`:''}
      ${st.stage==='Auction Scheduled'? `<tr><td>Bidder Activity</td><td style="text-align:right;">${bids.length} bid(s)${hb? ' · Highest '+fmtINR(hb.amount)+(hb.bidderName? ' by '+bidderMaskedName(hb.bidderName):'') : ' · No bids yet'}</td></tr>`:''}
    </tbody></table>
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:14px;">
      ${st.stage==='Notice Issued'? `<button class="btn btn-danger btn-sm" onclick="takeLegalPossession('${app.id}')">Record Symbolic Possession</button>`:''}
      ${st.stage==='Possession'? `<button class="btn btn-primary btn-sm" onclick="openLegalAuctionScheduleModal('${app.id}')">📢 Post Auction for Bidders</button>`:''}
      ${st.stage==='Auction Scheduled'? `<span class="demo-note" style="display:inline-block;">✅ Live on Bidder Portal</span>`:''}
      ${st.stage!=='None' && st.stage!=='Resolved'? `<button class="btn btn-outline btn-sm" onclick="resolveLegalAuction('${app.id}')">Mark Resolved / Withdraw</button>`:''}
    </div>
  </div>`;
}
function bidderMaskedName(name){
  const parts=(name||'Bidder').trim().split(' ');
  return parts[0][0] + '*** ' + (parts.length>1 ? parts[parts.length-1][0]+'.' : '');
}

/* ---- Reports & Analytics ---- */
function viewBankOfficeReports(){
  const apps = DB.applications||[];
  const totalDisbursed = apps.filter(a=>a.status==='Disbursed').reduce((s,a)=>s+(a.disbursement?a.disbursement.amount:0),0);
  const avgLoan = apps.length? Math.round(apps.reduce((s,a)=>s+a.loanAmount,0)/apps.length) : 0;
  const byType = {};
  apps.forEach(a=>{ byType[a.loanType] = (byType[a.loanType]||0)+1; });
  const byStatus = {};
  apps.forEach(a=>{ byStatus[a.status] = (byStatus[a.status]||0)+1; });
  return `
  <div class="page-head"><h1>Reports &amp; Analytics</h1><p>Branch-level lending performance summary.</p></div>
  <div class="grid grid-4">
    <div class="card stat"><div class="lbl">Total Applications</div><div class="val">${apps.length}</div></div>
    <div class="card stat"><div class="lbl">Total Disbursed</div><div class="val teal">${fmtINR(totalDisbursed)}</div></div>
    <div class="card stat"><div class="lbl">Average Loan Amount</div><div class="val">${fmtINR(avgLoan)}</div></div>
    <div class="card stat"><div class="lbl">Overdue Accounts</div><div class="val orange">${overdueLegalApplications().length}</div></div>
  </div>
  <div class="grid grid-2">
    <div class="card">
      <h3>📊 Applications by Loan Type</h3>
      ${Object.keys(byType).length===0? `<div class="empty-state"><div class="ic">📭</div>No data yet.</div>` :
        `<table><tbody>${Object.entries(byType).map(([k,v])=>`<tr><td>${escapeHtml(k)}</td><td style="text-align:right;">${v}</td></tr>`).join('')}</tbody></table>`}
    </div>
    <div class="card">
      <h3>📊 Applications by Status</h3>
      ${Object.keys(byStatus).length===0? `<div class="empty-state"><div class="ic">📭</div>No data yet.</div>` :
        `<table><tbody>${Object.entries(byStatus).map(([k,v])=>`<tr><td>${escapeHtml(k)}</td><td style="text-align:right;">${v}</td></tr>`).join('')}</tbody></table>`}
    </div>
  </div>
  `;
}

/* ---- Settings ---- */
function viewBankOfficeSettings(){
  const s = currentUser();
  return `
  <div class="page-head"><h1>Settings</h1><p>Your Bank Office account details and preferences.</p></div>
  <div class="grid grid-2">
    <div class="card">
      <h3>👤 Account Details</h3>
      <div class="field"><label>Full Name</label><input id="pfName" value="${escapeHtml(s.name)}"><div class="error hidden" id="err_pfName"></div></div>
      <div class="two-col">
        <div class="field"><label>Mobile</label><input id="pfMobile" value="${escapeHtml(s.mobile||'')}"><div class="error hidden" id="err_pfMobile"></div></div>
        <div class="field"><label>Email</label><input value="${escapeHtml(s.email)}" disabled></div>
      </div>
      <div class="field"><label>Role</label><input value="${ROLE_LABELS[s.role]||s.role}" disabled></div>
      <button class="btn btn-primary" onclick="savePersonal()">Save Changes</button>
    </div>
    <div class="card">
      <h3>🔒 Change Password</h3>
      <div class="field"><label>Current Password</label><input type="password" id="cpCurrent"><div class="error hidden" id="err_cpCurrent"></div></div>
      <div class="field"><label>New Password</label><input type="password" id="cpNew"><div class="error hidden" id="err_cpNew"></div></div>
      <div class="field"><label>Confirm New Password</label><input type="password" id="cpNew2"><div class="error hidden" id="err_cpNew2"></div></div>
      <button class="btn btn-primary btn-sm" onclick="changePasswordProfile()">Update Password</button>
    </div>
  </div>
  `;
}

/* ================================================================
   BIDDER PORTAL
   Browse bank-listed auction properties (defaulted assets under
   SARFAESI e-auction) and place bids.
   ================================================================ */
function auctionListings(){
  return (DB.applications||[]).filter(a=>{ ensureLegal(a); return a.auction.stage==='Auction Scheduled'; })
    .sort((x,y)=> new Date(x.auction.auctionDate) - new Date(y.auction.auctionDate));
}
function isAuctionOpen(app){ return app.auction.auctionDate && new Date(app.auction.auctionDate) > new Date(); }
function bidsForApp(appId){
  return (DB.bids||[]).filter(b=>b.appId===appId)
    .sort((a,b)=> b.amount-a.amount || new Date(a.createdAt)-new Date(b.createdAt));
}
function highestBid(appId){ const list = bidsForApp(appId); return list.length ? list[0] : null; }
function myBids(){
  const u = currentUser(); if(!u) return [];
  return (DB.bids||[]).filter(b=>b.bidderId===u.email).sort((a,b)=> new Date(b.createdAt)-new Date(a.createdAt));
}
function minNextBid(app){
  const hb = highestBid(app.id);
  if(!hb) return app.auction.reservePrice;
  const step = Math.max(5000, Math.round(app.auction.reservePrice*0.01/1000)*1000);
  return hb.amount + step;
}
function bidderDisplayName(bid){
  const u = currentUser();
  if(u && bid.bidderId===u.email) return 'You';
  const parts = (bid.bidderName||'Bidder').trim().split(' ');
  return parts[0][0] + '*** ' + (parts.length>1 ? parts[parts.length-1][0]+'.' : '');
}

let bidderCurrentAppId = null;
function openBidderListing(appId){ bidderCurrentAppId = appId; go('bidderlistingdetail'); }

function viewBidderDashboard(){
  const u = currentUser();
  const listings = auctionListings();
  const open = listings.filter(isAuctionOpen);
  const mine = myBids();
  const winning = open.filter(a=>{ const hb = highestBid(a.id); return hb && hb.bidderId===u.email; }).length;
  const upcoming = open.slice(0,5);
  return `
  <div class="page-head"><h1>Welcome, ${escapeHtml(u.name.split(' ')[0])}</h1><p>Browse bank-listed auction properties and track your bids.</p></div>
  <div class="grid grid-3">
    <div class="card stat"><div class="lbl">My Total Bids</div><div class="val teal">${mine.length}</div></div>
    <div class="card stat"><div class="lbl">Currently Highest On</div><div class="val green">${winning}</div></div>
    <div class="card stat"><div class="lbl">Listed All-Time</div><div class="val">${listings.length}</div></div>
  </div>
  <div class="card">
    <h3>⏰ Closing Soon</h3>
    ${upcoming.length===0? `<div class="empty-state"><div class="ic">📭</div>No auctions currently open for bidding. Check back soon.</div>` :
      `<table><thead><tr><th>Property</th><th>Type</th><th>Reserve Price</th><th>Auction Date</th><th>Current Highest</th><th></th></tr></thead><tbody>
      ${upcoming.map(a=>{ const hb=highestBid(a.id); return `<tr class="clickable-row" onclick="openBidderListing('${a.id}')">
        <td>${escapeHtml(a.property.address)}</td><td>${escapeHtml(a.property.type)}</td>
        <td>${fmtINR(a.auction.reservePrice)}</td><td>${fmtDate(a.auction.auctionDate)}</td>
        <td>${hb? fmtINR(hb.amount) : '—'}</td>
        <td style="text-align:right;"><button class="btn btn-teal btn-sm" onclick="event.stopPropagation();openBidderListing('${a.id}')">View &amp; Bid</button></td>
      </tr>`; }).join('')}
      </tbody></table>`}
  </div>
  <div class="card" style="background:var(--teal-light);box-shadow:none;">
    <p style="margin:0;font-size:13px;color:var(--text-mid);">Properties appear here once listed by the bank's Legal &amp; Valuation Team for e-auction following SARFAESI recovery proceedings. Review each listing carefully before placing a bid — all bids are binding as per the auction terms &amp; conditions.</p>
  </div>
  `;
}

let bidderListingsTab = 'open';
function setBidderListingsTab(t){ bidderListingsTab=t; render('bidderlistings'); }
function viewBidderListings(){
  const all = auctionListings();
  const open = all.filter(isAuctionOpen);
  const closed = all.filter(a=>!isAuctionOpen(a));
  const list = bidderListingsTab==='open' ? open : closed;
  return `
  <div class="page-head"><h1>Auction Listings</h1><p>Properties listed by the bank for e-auction after SARFAESI recovery proceedings.</p></div>
  <div class="tabs">
    <button class="tab ${bidderListingsTab==='open'?'active':''}" onclick="setBidderListingsTab('open')">Open for Bidding (${open.length})</button>
    <button class="tab ${bidderListingsTab==='closed'?'active':''}" onclick="setBidderListingsTab('closed')">Closed (${closed.length})</button>
  </div>
  <div class="grid grid-3">
    ${list.length===0? `<div class="empty-state" style="grid-column:1/-1;"><div class="ic">📭</div>No listings in this category right now.</div>` :
      list.map(a=>{ const hb=highestBid(a.id); return `
      <div class="product-card">
        <span class="tag">${escapeHtml(a.property.type)}</span>
        <h4>${escapeHtml(a.property.address)}</h4>
        <div class="rate">${fmtINR(a.auction.reservePrice)}</div>
        <p>Reserve Price · Auction ${fmtDate(a.auction.auctionDate)}</p>
        <p>Current Highest: ${hb? fmtINR(hb.amount) : 'No bids yet'} · ${bidsForApp(a.id).length} bid(s)</p>
        <button class="btn btn-teal btn-sm btn-block" onclick="openBidderListing('${a.id}')">${isAuctionOpen(a)?'View &amp; Bid':'View Details'}</button>
      </div>`; }).join('')}
  </div>
  `;
}

function viewBidderListingDetail(){
  const app = (DB.applications||[]).find(a=>a.id===bidderCurrentAppId);
  if(!app || app.auction.stage!=='Auction Scheduled'){
    return `<div class="empty-state"><div class="ic">🔍</div>Listing not found or no longer available.<div style="margin-top:14px;"><button class="btn btn-outline btn-sm" onclick="go('bidderlistings')">Back to Listings</button></div></div>`;
  }
  const open = isAuctionOpen(app);
  const bids = bidsForApp(app.id);
  const hb = bids.length ? bids[0] : null;
  const u = currentUser();
  const iAmHighest = hb && hb.bidderId===u.email;
  const minAmt = minNextBid(app);
  const daysLeft = Math.ceil((new Date(app.auction.auctionDate) - new Date())/86400000);
  return `
  <div class="back-link" onclick="go('bidderlistings')">← Back to Listings</div>
  <div class="page-head"><h1>${escapeHtml(app.property.type)} Property — ${app.trackingNo}</h1><p>Bank-listed asset under e-auction (SARFAESI proceedings).</p></div>
  <div class="grid grid-2">
    <div class="card">
      <h3>🏠 Property Details</h3>
      <table><tbody>
        <tr><td>Address</td><td style="text-align:right;">${escapeHtml(app.property.address)}</td></tr>
        <tr><td>Property Type</td><td style="text-align:right;">${escapeHtml(app.property.type)}</td></tr>
        <tr><td>Declared Value</td><td style="text-align:right;">${fmtINR(app.property.value)}</td></tr>
        <tr><td>Reserve Price</td><td style="text-align:right;"><strong>${fmtINR(app.auction.reservePrice)}</strong></td></tr>
        <tr><td>Auction Date</td><td style="text-align:right;">${fmtDate(app.auction.auctionDate)}</td></tr>
        <tr><td>Status</td><td style="text-align:right;">${open? `<span class="countdown-pill">${daysLeft<=0?'Closing today':daysLeft+' day(s) left'}</span>` : `<span class="badge badge-gray">Bidding Closed</span>`}</td></tr>
      </tbody></table>
      <p style="font-size:11.5px;color:var(--text-gray);margin-top:12px;">Borrower identity is withheld from the public listing per bank policy. Loan account reference: ${app.trackingNo}.</p>
    </div>
    <div class="card">
      <h3>💰 Place Your Bid</h3>
      ${!open? `<div class="empty-state"><div class="ic">🔒</div>Bidding is closed for this property.</div>` : `
      <div class="field"><label>Current Highest Bid</label><input value="${hb? fmtINR(hb.amount) : 'No bids yet — reserve price applies'}" disabled></div>
      ${iAmHighest? `<div class="demo-note" style="background:var(--green-bg);border-color:var(--green);color:var(--green);">You currently hold the highest bid on this property.</div>` : ''}
      <div class="field"><label>Your Bid Amount (min ${fmtINR(minAmt)})</label><input id="bidAmount" type="number" min="${minAmt}" step="1000" placeholder="${minAmt}"><div class="error hidden" id="err_bidAmount"></div></div>
      <button class="btn btn-primary btn-block" onclick="placeBid()">Place Bid</button>
      <p style="font-size:11.5px;color:var(--text-gray);margin-top:10px;">By placing a bid you agree this is a binding offer as per the bank's e-auction terms &amp; conditions.</p>
      `}
    </div>
  </div>
  <div class="card">
    <h3>📜 Bid History</h3>
    ${bids.length===0? `<div class="empty-state"><div class="ic">📭</div>No bids placed yet. Be the first to bid.</div>` :
      `<table><thead><tr><th>Bidder</th><th>Amount</th><th>Time</th></tr></thead><tbody>
      ${bids.map(b=>`<tr class="${b.bidderId===u.email?'bid-row-mine':''}"><td>${bidderDisplayName(b)}</td><td>${fmtINR(b.amount)}</td><td>${fmtDate(b.createdAt)}</td></tr>`).join('')}
      </tbody></table>`}
  </div>
  `;
}
function placeBid(){
  const app = (DB.applications||[]).find(a=>a.id===bidderCurrentAppId);
  if(!app) return;
  if(!isAuctionOpen(app)){ toast('Auction Closed','This auction is no longer accepting bids.'); return; }
  const inp = $('#bidAmount');
  const amt = Number(inp.value||0);
  const minAmt = minNextBid(app);
  if(!amt || amt < minAmt){ fieldError(inp, $('#err_bidAmount'), `Bid must be at least ${fmtINR(minAmt)}.`); return; }
  fieldOk(inp, $('#err_bidAmount'));
  const u = currentUser();
  const bid = { id:'BID'+String(DB.nextBid++).padStart(5,'0'), appId:app.id, bidderId:u.email, bidderName:u.name, amount:amt, createdAt:new Date().toISOString() };
  DB.bids.push(bid); saveDB();
  toast('Bid Placed', `Your bid of ${fmtINR(amt)} has been recorded.`, 'success');
  render('bidderlistingdetail');
}

function viewBidderMyBids(){
  const mine = myBids();
  const u = currentUser();
  return `
  <div class="page-head"><h1>My Bids</h1><p>All bids you've placed across auction listings.</p></div>
  <div class="card">
    ${mine.length===0? `<div class="empty-state"><div class="ic">📭</div>You haven't placed any bids yet. Browse <a href="#" onclick="go('bidderlistings');return false;">Auction Listings</a> to get started.</div>` :
      `<table><thead><tr><th>Property</th><th>My Bid</th><th>Current Highest</th><th>Status</th><th>Placed On</th><th></th></tr></thead><tbody>
      ${mine.map(b=>{
        const app = (DB.applications||[]).find(a=>a.id===b.appId); if(!app) return '';
        const hb = highestBid(app.id);
        const winning = hb && hb.bidderId===u.email;
        return `<tr class="clickable-row" onclick="openBidderListing('${app.id}')">
          <td>${escapeHtml(app.property.address)}</td>
          <td>${fmtINR(b.amount)}</td>
          <td>${hb? fmtINR(hb.amount) : '—'}</td>
          <td><span class="badge ${winning?'badge-green':'badge-orange'}">${winning?'Highest Bidder':'Outbid'}</span></td>
          <td>${fmtDate(b.createdAt)}</td>
          <td style="text-align:right;"><button class="btn btn-outline btn-sm" onclick="event.stopPropagation();openBidderListing('${app.id}')">View</button></td>
        </tr>`;
      }).join('')}
      </tbody></table>`}
  </div>
  `;
}

function viewBidderSettings(){
  const s = currentUser();
  return `
  <div class="page-head"><h1>Settings</h1><p>Your Bidder account details and preferences.</p></div>
  <div class="grid grid-2">
    <div class="card">
      <h3>👤 Account Details</h3>
      <div class="field"><label>Full Name</label><input id="pfName" value="${escapeHtml(s.name)}"><div class="error hidden" id="err_pfName"></div></div>
      <div class="two-col">
        <div class="field"><label>Mobile</label><input id="pfMobile" value="${escapeHtml(s.mobile||'')}"><div class="error hidden" id="err_pfMobile"></div></div>
        <div class="field"><label>Email</label><input value="${escapeHtml(s.email)}" disabled></div>
      </div>
      <div class="field"><label>Role</label><input value="${ROLE_LABELS[s.role]||s.role}" disabled></div>
      <button class="btn btn-primary" onclick="savePersonal()">Save Changes</button>
    </div>
    <div class="card">
      <h3>🔒 Change Password</h3>
      <div class="field"><label>Current Password</label><input type="password" id="cpCurrent"><div class="error hidden" id="err_cpCurrent"></div></div>
      <div class="field"><label>New Password</label><input type="password" id="cpNew"><div class="error hidden" id="err_cpNew"></div></div>
      <div class="field"><label>Confirm New Password</label><input type="password" id="cpNew2"><div class="error hidden" id="err_cpNew2"></div></div>
      <button class="btn btn-primary btn-sm" onclick="changePasswordProfile()">Update Password</button>
    </div>
  </div>
  `;
}

/* ================================================================
   SUPPORT / HELP
   ================================================================ */
const FAQS = [
  {q:'How is my loan eligibility calculated?', a:'Eligibility is based on your monthly income and existing EMIs (Debt-to-Income ratio), evaluated against the loan amount and tenure you select.'},
  {q:'What documents do I need to apply?', a:'You will need Identity Proof, Income Proof, Address Proof, Bank Statements (last 6 months), and Property Documents.'},
  {q:'When is a mortgage required?', a:'A mortgage is required when your requested loan amount exceeds the unsecured eligibility limit calculated from your income and obligations.'},
  {q:'Can I save my application and complete it later?', a:'Yes, use the "Save as Draft" button at any step of the application form. You can resume it from the Apply for Loan page.'},
  {q:'How will I be notified about my application status?', a:'You will receive updates via SMS, Email and in-app notifications based on your preferences set in Profile Settings.'}
];
function viewSupport(){
  return `
  <div class="page-head"><h1>Support / Help</h1><p>Find answers to common questions or reach out to our support team.</p></div>
  <div class="grid grid-2">
    <div class="card">
      <h3>❓ Frequently Asked Questions</h3>
      ${FAQS.map((f,i)=>`<div class="accordion-item">
        <div class="accordion-head" onclick="toggleAccordion(${i})">${f.q}<span>+</span></div>
        <div class="accordion-body" id="acc_${i}">${f.a}</div>
      </div>`).join('')}
    </div>
    <div class="card">
      <h3>✉️ Contact Support</h3>
      <div class="field"><label>Subject</label><input id="supSubject" placeholder="Briefly describe your issue"><div class="error hidden" id="err_supSubject"></div></div>
      <div class="field"><label>Message</label><textarea id="supMessage" rows="5" placeholder="Describe your issue in detail..."></textarea><div class="error hidden" id="err_supMessage"></div></div>
      <button class="btn btn-primary" onclick="submitSupport()">Send Message</button>
      <p style="font-size:12px;color:var(--text-gray);margin-top:14px;">Or reach us directly: 📞 1800-123-4567 &nbsp;|&nbsp; ✉️ support@hlms.example.com</p>
    </div>
  </div>
  `;
}
function afterSupport(){}
function toggleAccordion(i){
  const el = $('#acc_'+i);
  el.classList.toggle('open');
}
function submitSupport(){
  const subj=$('#supSubject'), msg=$('#supMessage');
  let ok=true;
  if(!subj.value.trim()) ok = fieldError(subj,$('#err_supSubject'),'Subject is required.') && ok; else fieldOk(subj,$('#err_supSubject'));
  if(!msg.value.trim() || msg.value.trim().length<10) ok = fieldError(msg,$('#err_supMessage'),'Please provide more detail (min 10 characters).') && ok; else fieldOk(msg,$('#err_supMessage'));
  if(!ok) return;
  toast('Message Sent','Our support team will get back to you within 24 hours.','success');
  subj.value=''; msg.value='';
}

/* ================================================================
   GLOBAL SEARCH (simple client-side)
   ================================================================ */
const SEARCH_INDEX = [
  {label:'Dashboard', view:'dashboard'}, {label:'Loan Guidance', view:'guidance'},
  {label:'Check Eligibility', view:'eligibility'}, {label:'Apply for Loan', view:'apply'},
  {label:'Loan Status Tracking', view:'tracking'}, {label:'Repayment', view:'repayment'},
  {label:'Post Disbursement', view:'postdisb'}, {label:'Auction Management', view:'auction'},
  {label:'Documents', view:'documents'}, {label:'Profile Settings', view:'profile'}, {label:'Support / Help', view:'support'},
  {label:'Employee Management', view:'employeemgmt'},
 {label:'Legal Team Management', view:'legalmgmt'},
{label:'Bank Office Management', view:'bankofficemgmt'},
{label:'Bidder Management', view:'biddermgmt'},
{label:'Admin Management', view:'adminmgmt'},
  {label:'Legal Dashboard', view:'legaldash'}, {label:'Legal Review Queue', view:'legalqueue'},
  {label:'Legal Document Center', view:'legaldocuments'}, {label:'Auction & SARFAESI', view:'legalauction'},
  {label:'Legal Notices Log', view:'legalnotices'},
  {label:'Bank Office Dashboard', view:'bodash'}, {label:'Loan Applications', view:'boapplications'},
  {label:'Customer Portfolio', view:'boportfolio'}, {label:'Disbursement Queue', view:'bodisbursement'},
  {label:'Overdue & NPA Tracking', view:'bonpa'}, {label:'Document Verification', view:'bodocs'},
  {label:'Auction Management', view:'boauction'}, {label:'Reports & Analytics', view:'boreports'},
  {label:'Bank Office Settings', view:'bosettings'}
];
function getSearchDropdown(){ return document.getElementById('searchDropdown'); }
function closeSearchDropdown(){
  const dd = getSearchDropdown();
  if(dd){ dd.classList.add('hidden'); dd.innerHTML=''; }
}
function navFromSearch(view){
  closeSearchDropdown();
  const input = $('#globalSearch');
  if(input) input.value='';
  go(view);
}
function handleGlobalSearch(val){
  const dd = getSearchDropdown();
  if(!dd) return;
  const q = (val||'').trim().toLowerCase();
  if(!q){ closeSearchDropdown(); return; }
  const matches = SEARCH_INDEX.filter(s=>s.label.toLowerCase().includes(q)).slice(0,8);
  if(!matches.length){
    dd.innerHTML = `<div class="search-dropdown-empty">No results for "${escapeHtml(val)}". Try: eligibility, apply, repayment, documents...</div>`;
  } else {
    dd.innerHTML = matches.map((m,i)=>`<div class="search-dropdown-item${i===0?' active':''}" data-view="${m.view}" onclick="navFromSearch('${m.view}')">🔎 ${escapeHtml(m.label)}</div>`).join('');
  }
  dd.classList.remove('hidden');
}
document.addEventListener('keydown', (e)=>{
  if(document.activeElement && document.activeElement.id==='globalSearch'){
    const dd = getSearchDropdown();
    if(!dd || dd.classList.contains('hidden')) return;
    const items = Array.from(dd.querySelectorAll('.search-dropdown-item'));
    if(!items.length) return;
    let idx = items.findIndex(it=>it.classList.contains('active'));
    if(e.key==='ArrowDown'){
      e.preventDefault();
      idx = (idx+1) % items.length;
      items.forEach(it=>it.classList.remove('active')); items[idx].classList.add('active');
      items[idx].scrollIntoView({block:'nearest'});
    } else if(e.key==='ArrowUp'){
      e.preventDefault();
      idx = idx<=0 ? items.length-1 : idx-1;
      items.forEach(it=>it.classList.remove('active')); items[idx].classList.add('active');
      items[idx].scrollIntoView({block:'nearest'});
    } else if(e.key==='Enter'){
      const target = items[idx>=0?idx:0];
      if(target) navFromSearch(target.getAttribute('data-view'));
    } else if(e.key==='Escape'){
      closeSearchDropdown();
    }
  }
});
document.addEventListener('click', (e)=>{
  const wrap = document.querySelector('.topbar-search');
  if(wrap && !wrap.contains(e.target)) closeSearchDropdown();
});

/* ================================================================
   MODAL
   ================================================================ */
function showModal(title, bodyHtml){
  const overlay = document.createElement('div');
  overlay.className='modal-overlay';
  overlay.innerHTML = `<div class="modal-box"><h3>${title}</h3>${bodyHtml}<div style="text-align:right;margin-top:16px;"><button class="btn btn-outline btn-sm" onclick="this.closest('.modal-overlay').remove()">Close</button></div></div>`;
  overlay.addEventListener('click', (e)=>{ if(e.target===overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

/* ================================================================
   INIT
   ================================================================ */
(function init(){
  const yearEl = document.getElementById('homeYear');
  if(yearEl) yearEl.textContent = new Date().getFullYear();
  renderAuth();
  if(DB.session && DB.users[DB.session]){
    enterApp();
  }
})();

