# HLMS Notifications — every scenario, and how to test each one

---

# 1. Where notifications now come from

The key change since last time: **stage hand-offs are now wired at the single point every
transition passes through**, `LoanApplicationService.updateStage()`. Whoever triggers a
move — the bank office UI, legal-service calling back over Feign, a future scheduled job —
the notification fires. A new caller cannot forget to raise it.

Everything below happens automatically. Nothing is seeded by hand.

---

# 2. The complete scenario matrix

## Along the loan lifecycle

| # | When this happens | Customer | Bank Officer | Legal | Bidder | Admin |
|---|---|---|---|---|---|---|
| 1 | Customer submits an application | "Application submitted" | "New application to review" | — | — | — |
| 2 | Moves to **Document Verification** (stage 2) | "Application \<status\>" | "Documents ready for verification" | — | — | — |
| 3 | Moves to **Legal Verification** (stage 3) | "Application \<status\>" | — | **"New case for legal verification"** | — | — |
| 4 | Legal records a decision | "Legal verification \<verdict\>" | "Legal verification \<verdict\>" | "Legal decision recorded" | — | — |
| 5 | Moves to **Bank Office Decision** (stage 4) | "Application \<status\>" | **"Legal verification complete — decision needed"** | — | — | — |
| 6 | Officer **approves** | **"Loan approved"** | "Decision recorded" | — | — | — |
| 6b | Officer **rejects** | **"Loan application rejected"** + reason | "Decision recorded" | — | — | — |
| 6c | Officer approves **with conditions** | "Loan conditionally approved" + reason | "Decision recorded" | — | — | — |
| 7 | Moves to **Disbursement** (stage 5) | "Application \<status\>" | "Approved — ready to disburse" | — | — | — |
| 8 | Loan is **disbursed** | **"Loan disbursed"** + reference | — | — | — | — |

Scenarios 3, 5, 6 and 8 are the four you asked for specifically.

## Repayment and default

| # | When this happens | Customer | Bank Officer | Legal | Bidder | Admin |
|---|---|---|---|---|---|---|
| 9 | EMI recorded as **PAID** | "EMI payment received" | — | — | — | — |
| 10 | EMI becomes **OVERDUE** | "EMI overdue" | "EMI overdue" | — | — | — |
| 11 | Legal notice **ISSUED** | "\<type\> notice issued" | "\<type\> notice issued" | — | — | — |
| 12 | Auction reaches **Auction Scheduled** | — | "Auction scheduled" | — | **"New auction listed"** | — |
| 13 | A bid is placed | — | "New auction bid" | — | "Bid placed" (to the bidder) | — |
| 14 | Someone bids higher | — | — | — | **"You have been outbid"** | — |

## Service and account

| # | When this happens | Customer | Bank Officer | Legal | Bidder | Admin |
|---|---|---|---|---|---|---|
| 15 | Customer raises a **service request** | "Service request raised" | **"New service request: \<type\>"** | — | — | — |
| 16 | Officer updates a request's status | "Service request \<status\>" | — | — | — | — |
| 17 | Anyone registers | "Welcome to HLMS" | — | — | — | **"New \<role\> registered"** |

## What each role actually receives

- **CUSTOMER** — submission receipt, every status move, legal outcome, **approve/reject
  decision**, disbursement, EMI paid, EMI overdue, legal notice, service request updates
- **BANK_OFFICER** — new applications, documents to verify, **legal work complete**,
  ready to disburse, legal decisions, notices issued, EMI overdue, bids, **service
  requests**, decision confirmations
- **LEGAL** — **new case ready for verification**, own decision confirmations
- **BIDDER** — new auction listed, bid placed, outbid
- **ADMIN** — new registrations

**A deliberate design note on admin:** the admin role touches only `/api/users` and has no
loan involvement at all, so flooding admins with loan traffic would be noise. They get
account events. If you want admins copied on more, say which and I'll add it.

---

# 3. Two rules that stop notification spam

**Team notifications fire only on entry to a stage.** `announceStageChange()` compares the
new `stageIndex` to the previous one and returns early if they match. Re-saving an
application at the same stage does not re-notify the whole team.

**Customer notifications fire only when the status text changes.** A stage-only tweak that
leaves the status alone is silent.

The same pattern is used for EMI status, auction stage, and revised decisions.

---

# 4. Testing it — one walkthrough per role

## Setup

Create five accounts, one per role, at `/register`:

| Email | Role | Password |
|---|---|---|
| `customer@hlms.com` | CUSTOMER | `Test@123` |
| `officer@hlms.com` | BANK_OFFICER | `Test@123` |
| `legal@hlms.com` | LEGAL | `Test@123` |
| `bidder1@hlms.com` | BIDDER | `Test@123` |
| `bidder2@hlms.com` | BIDDER | `Test@123` |
| `admin@hlms.com` | ADMIN | `Test@123` |

**Use several browsers** (or one normal + several incognito windows) so you can stay
signed in as more than one role and watch notifications land in real time. One profile per
role is the single biggest thing that makes this easy to test.

Remember the poll is **30 seconds** — or click the bell to force a refresh.

---

## Test A — ADMIN (fastest smoke test)

1. Sign in as `admin@hlms.com`, stay on the dashboard
2. In another browser, register any new user
3. **Within 30s:** toast bottom-right, badge on the bell, dropdown shows
   "New \<role\> registered"

If this works, the whole chain is live: service → notification-service → database →
frontend poll → toast.

---

## Test B — CUSTOMER + BANK_OFFICER (scenarios 1, 2)

1. Browser 1: sign in as `customer@hlms.com` → Apply for Loan → fill and **submit**
2. Customer bell → "Application submitted"
3. Browser 2: sign in as `officer@hlms.com` → **"New application to review"**

---

## Test C — the hand-off to LEGAL (scenario 3) ⭐

This is your second requested scenario.

1. Browser 2 (officer): open the application, advance it to **Legal Verification**
2. Browser 3: sign in as `legal@hlms.com`
3. **Legal receives "New case for legal verification"** naming the application and applicant
4. Customer also sees the status move

---

## Test D — legal finishes, officer is told (scenario 5) ⭐

Your third requested scenario.

1. Browser 3 (legal): record the verification decision on that application
2. **Officer receives "Legal verification complete — decision needed"**
3. Customer receives the legal outcome
4. Legal receives their own "Legal decision recorded" confirmation

---

## Test E — approve / reject reaches the customer (scenario 6) ⭐

Your first requested scenario, and the message customers care most about.

1. Browser 2 (officer): record the bank office decision with status **APPROVED**
2. **Customer receives "Loan approved"** — "Good news… Disbursement will follow shortly."

Then test the other branch on a second application with **REJECTED**:

3. **Customer receives "Loan application rejected"** with the reason attached

`CONDITIONALLY_APPROVED` gives a third variant. `PENDING` deliberately sends nothing —
it's a placeholder, not an outcome.

---

## Test F — disbursement (scenario 8) ⭐

Your fourth requested scenario.

1. Browser 2 (officer): disburse the approved loan
2. **Customer receives "Loan disbursed"** with the reference number

---

## Test G — service request reaches the bank (scenario 15) ⭐

Your fifth requested scenario.

1. Browser 1 (customer): Support → raise a request, e.g. type `Statement`
2. Customer gets a receipt with the reference number
3. **Officer receives "New service request: Statement"** naming the customer, the
   application, and the description

Then have the officer change its status — the customer is told.

---

## Test H — BIDDER (scenarios 12, 13, 14)

1. Browser 2 (officer) or legal: set an auction case's stage to **"Auction Scheduled"**
2. Browser 4: sign in as `bidder1@hlms.com` → **"New auction listed"** with date and
   reserve price
3. bidder1 places a bid → "Bid placed"
4. Browser 5: `bidder2@hlms.com` places a **higher** bid on the same auction
5. **bidder1 receives "You have been outbid"** ← the one bidders actually act on
6. Officer receives "New auction bid" for both

---

## Test I — repayment and default (scenarios 9, 10, 11)

1. Mark an EMI installment **PAID** → customer: "EMI payment received"
2. Let one fall **OVERDUE** → customer *and* officer both told
3. Legal issues a notice with status **ISSUED** → borrower warned, officer informed
   (a **DRAFT** notice sends nothing — it's the officer's working copy, and telling a
   borrower about a draft would be both alarming and wrong)

---

# 5. Quick checklist

| Scenario | Trigger | Watch |
|---|---|---|
| Registration | register anyone | admin bell |
| Submit | customer submits | customer + officer |
| → Legal | officer advances to stage 3 | **legal bell** |
| Legal done | legal records decision | **officer bell** |
| Approve | officer sets APPROVED | **customer bell** |
| Reject | officer sets REJECTED | **customer bell** + reason |
| Disburse | officer disburses | **customer bell** |
| Service request | customer raises one | **officer bell** |
| Auction scheduled | stage → Auction Scheduled | **bidder bell** |
| Outbid | second bidder bids higher | **first bidder's bell** |
| EMI overdue | installment goes OVERDUE | customer + officer |

---

# 6. If something doesn't arrive

| Symptom | Likely cause |
|---|---|
| Nothing for anyone | Not all services running — notifications originate in loan/legal/repayment/user, not notification-service |
| One role gets nothing | No account exists with that role — role fan-out finds nobody |
| Team notification missing, individual ones fine | Role fan-out needs the caller's JWT; check the service log for "Could not resolve role" |
| Toast never shows | The first poll after sign-in is deliberately silent; trigger a *new* event with the tab open |
| Badge lags | 30-second poll — click the bell to force refresh |
| Deactivated staff still notified | They shouldn't be; `active: false` users are skipped |

Every publisher logs a warning and continues on failure — a notification outage never
rolls back a loan submission or fails a bid. **So check the service logs**, not just the
UI, if something is missing.

---

# 7. Still outstanding

**The security gap I flagged.** `GET /api/notifications?userEmail=…` still doesn't check
the email against the caller's token — any signed-in user can read anyone's notifications
by editing the URL. This matters more now that notifications carry decisions and reasons.
It's a small fix and I'd recommend doing it before any demo.

**I could not compile the backend here** — no JDK in this environment. I syntax-checked
every edited file and verified every getter I call exists against its entity. Run
`mvn clean install -DskipTests` first; if anything fails, send me the error.
