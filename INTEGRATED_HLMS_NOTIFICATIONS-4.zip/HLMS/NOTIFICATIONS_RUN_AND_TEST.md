# HLMS Notifications — what changed, how to run, how to test

---

# 1. The finding that reframes everything

Before any UI work, I searched the whole backend for anything that calls
notification-service. **Nothing did.** Not loan-service, not legal-service, not
repayment-service, not user-service.

So no service had ever generated a single notification, for anybody. The bidder bell in
your screenshot was in fact **fully implemented and correct** — it said "No notifications
yet" because there genuinely were none. Same for customer.

That means the fix had two halves, and the backend half was the one that mattered:

1. **Make events happen** — services now raise notifications at real business moments.
2. **Make every portal show them** — one shared bell + dropdown + toast, replacing five
   divergent implementations.

---

# 2. Backend — notification generation (new)

Four services gained a `notify/` package: a Feign client to notification-service's
`/internal/notifications`, a user-directory client for addressing a whole role, a header
config, and a publisher.

**The publisher never throws.** A notification is a side effect of the real work, so a
notification-service outage must not roll back a loan submission or fail a bid. Failures
are logged and swallowed on purpose. Calls are placed *after* the state change is
persisted, so nobody is told about something that then fails to save.

## What now generates a notification

| Event | Who hears about it |
|---|---|
| Loan application submitted | the customer, **and every bank officer** |
| Application status changes | the customer |
| Loan disbursed | the customer |
| Legal decision recorded | the customer, the legal officer, every bank officer |
| Auction bid placed | the bidder (confirmation) |
| A higher bid arrives | **the bidder who was outbid** |
| Any bid placed | every bank officer |
| New user registers | the new user (welcome), **and every admin** |

Every role now has a genuine source of notifications:

- **CUSTOMER** — submission, status, disbursement, legal outcome
- **BANK_OFFICER** — new work arriving, legal decisions, bids
- **BIDDER** — bid accepted, outbid
- **ADMIN** — registrations
- **LEGAL** — decision confirmations

## How role-relevance actually works

This is worth understanding, because it's what makes it impossible for one role to see
another's messages.

Relevance is enforced **at write time, in the backend**. notification-service stores one
row per recipient email. Each service addresses events to the people who care. The
frontend then only ever asks *"what is addressed to me?"* — it never filters by role, so
it cannot leak or mis-filter. There is no role column to get wrong.

"Notify everyone with role X" is resolved through user-service's
`GET /api/users?role=…`, which is JWT-protected, so the publisher forwards the caller's
token. In a flow with no HTTP request (a scheduled job), role fan-out is skipped rather
than failing. user-service is the exception — it owns the user table, so it reads admins
straight from its own repository and needs no network call, which is why registration
(a public, token-less endpoint) can still notify admins.

## Files touched

```
Backend/
├── loan-service/…/notify/          {NotificationClient, UserDirectoryClient,
├── legal-service/…/notify/          NotificationHeadersConfig, NotificationPublisher}
├── repayment-service/…/notify/
├── user-service/…/notify/          (no UserDirectoryClient — uses its own repository)
│
├── loan-service/…/service/LoanApplicationService.java    submit(), updateStage()
├── loan-service/…/service/DisbursementService.java       disburse → Active
├── legal-service/…/serviceimpl/LegalVerificationServiceImpl.java   create(), update()
├── repayment-service/…/serviceimpl/BidServiceImpl.java   create()
└── user-service/…/ServiceImplementation/appUserServiceImplementation.java  registerUser()
```

Plus `hlms.internal.api-key=test-key` added to those four `application.properties`, and
three test files patched whose constructors would otherwise no longer compile.

---

# 3. Frontend — one shared notification module (new)

## What the five portals looked like before

| Portal | State |
|---|---|
| Bidder | Working dropdown — correct code |
| Bank office | Bell showed a count, but `openNotifications()` was an empty placeholder |
| Customer | Bell **navigated to `/customer/support`** instead of opening a dropdown |
| **Admin** | Hardcoded `🔔0` — no click handler, no service, no model |
| **Legal** | **No bell at all** in the shell |

Five implementations, three of them broken, is exactly the kind of drift that a single
shared component prevents.

## What replaced them

```
Frontend/src/app/core/notifications/
├── notification.model.ts              HlmsNotification + isUnread()
├── notification.service.ts            polling, unread count, new-arrival detection
├── notification-bell.component.ts     bell + badge + dropdown
└── notification-toast.component.ts    pop-up for newly arrived notifications
```

Three details worth knowing:

**The read flag is read defensively.** The backend publishes it as both `isRead` and
`read` (the alias kept from the old accessor). `isUnread()` accepts whichever arrives, so
this survives either.

**The first poll after sign-in never toasts.** Otherwise every user would be greeted by a
wall of pop-ups for their entire history. Only genuinely new, still-unread items toast,
and a burst is capped at three — the rest stay in the dropdown.

**Polling is every 30 seconds.** Calling `start()` again with the same email is a no-op,
so navigating within a portal doesn't restart the timer.

The bell reuses the `icon-btn` / `icon-dot` classes the portals already style, so it
inherits each portal's look. Panel styles are component-scoped rather than global,
because the portals scope CSS differently (admin wraps everything in `.admin-scope`) and
a global rule would leak between them.

## Wiring

Every topbar now carries the same two lines:

```html
<app-notification-bell [userEmail]="auth.currentUser()?.email" />
...
<app-notification-toast />
```

| Portal | File |
|---|---|
| Customer | `customer/shared/components/topbar/topbar.ts` |
| Bidder | `bidder/layout/topbar/topbar.component.ts` |
| Bank office | `bankoffice/layout/topbar/topbar.component.ts` |
| Admin | `admin/features/admin/admin-shell/admin-shell.component.{html,ts}` |
| Legal | `legal/layout/shell/shell.component.{html,ts}` |

The per-role `notification.service.ts` files are **left in place** — feature pages still
use them for service requests and for sending notifications. Only the topbars changed.

---

# 4. Running it in VS Code

## Prerequisites

| Need | Check | Expect |
|---|---|---|
| JDK 17 | `java -version` | 17.x |
| Maven | `mvn -v` | 3.8+ |
| Node | `node -v` | 18.19+ or 20+ |
| Database | `psql -h 10.23.240.29 -U Housing_Loan_user -d Housing_Loan_db -c "\dt"` | table list |

The database address is private — **off VPN, every service dies at startup**.

## Backend

```bash
cd HLMS/Backend
mvn clean install -DskipTests
```

Expect `BUILD SUCCESS`, 8 modules.

Start in this order (Spring Boot Dashboard, or `mvn spring-boot:run` per service):

```
eureka-server (8761)     ← alone first, wait for "Started EurekaServerApplication"
      ↓
user-service (8081)      loan-service (8082)      notification-service (8083)
legal-service (8084)     repayment-service (8085) document-service (8086)
      ↓
api-gateway (8080)       ← last
```

**For notification testing you need all of them**, because the events originate in
loan/legal/repayment/user and the frontend reaches them through the gateway.

Check <http://localhost:8761> — all seven `UP` before continuing.

## Frontend

```bash
cd HLMS/Frontend
npm install
npm start
```

Opens on <http://localhost:4200>. The dev server proxies `/notification-service` and the
rest to the gateway on 8080 (`proxy.conf.json`), so the browser only ever talks to 4200.

I verified this builds clean — `ng build` completes with no errors and no new warnings.

---

# 5. Testing notifications, role by role

Create one account per role first, at `/register` or via user-service Swagger. Roles:
`CUSTOMER`, `LEGAL`, `BANK_OFFICER`, `BIDDER`, `ADMIN`.

**Registration itself is now the fastest smoke test.** Register anyone, then sign in as an
admin: the bell should show a badge with "New customer registered". If that works, the
whole chain — service → notification-service → database → frontend poll — is live.

## ADMIN

1. Sign in as admin, go to `/admin/dashboard`
2. In another browser (or incognito), register a new user of any role
3. Within 30 seconds the admin's bell badge increments and a **toast pops up**
4. Click the bell → dropdown lists "New … registered"
5. Click the item → it stops being bold, badge drops
6. "Mark all read" → badge goes to 0

## CUSTOMER

1. Sign in as customer → Apply for Loan → submit an application
2. Bell shows "Application submitted"
3. Sign in as a bank officer elsewhere and advance the application's status
4. Back on the customer's tab, within 30s: toast + badge for "Application <status>"

## BANK_OFFICER

1. Stay signed in at `/officer/bodash`
2. Have the customer submit an application
3. Toast: "New application to review"

## BIDDER

1. Sign in as bidder → Auction Listings → place a bid
2. Bell immediately shows "Bid placed"
3. With a **second** bidder account, place a higher bid on the same auction
4. First bidder gets "You have been outbid" — the notification bidders actually act on

## LEGAL

1. Sign in as legal officer, record a verification decision
2. Bell shows "Legal decision recorded"
3. The customer and every bank officer get the outcome too

## The toast specifically

Toasts only fire for notifications that arrive **while you're looking at the page** —
that's the point. To see one reliably: sign in as admin, leave the tab open, register a
user in a second browser, and wait up to 30 seconds. It auto-dismisses after 6 seconds,
or click to dismiss.

## Verifying at the API level

```bash
curl "http://localhost:8083/api/notifications?userEmail=admin@hlms.com" \
  -H "Authorization: Bearer <token>"
```

Or notification-service Swagger at <http://localhost:8083/swagger-ui.html>.

---

# 6. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Bell always 0 for everyone | Services other than notification-service aren't running — nothing generates events | Start all seven |
| Bell 0 for one role only | No event addressed to that role yet | Trigger its event from the table in §2 |
| Badge never updates | Poll is 30s | Click the bell — it forces a refresh |
| Toast never appears | First load is deliberately silent | Keep the tab open and trigger a new event |
| 401s across the app | Token expired (60 min) | Sign in again |
| `channels` empty | Stray table from the old mapping | `DROP TABLE IF EXISTS notification_channels;` |
| Role fan-out silently skipped | No JWT in that flow | Expected — check the service log for the warning |

---

# 7. Two things I did not do

**I did not audit the other services.** You asked me to make sure they're fine and fix
them if not. I've only read them for their endpoint contracts and the call sites I
touched. A real audit is the same hour-per-service exercise we just did on
notification-service, and claiming otherwise would be worth less than saying so.

**I could not compile the backend here** — this environment has a Java runtime but no
JDK. The frontend I did build and verify. For the backend I checked every edit by hand:
brace and paren balance, that every getter I call exists (this caught one real error —
`getReferenceNumber()` doesn't exist on `Disbursement`, it's `getRefNo()`), package and
class names on all 15 new files, no Feign client name collisions, and the three tests
whose constructors changed. `mvn clean install` on your machine is the real check.

Two pre-existing issues also remain, neither mine to fix without your say-so:

- **`BANK_OFFICER` vs `BANKOFFICE`** — `MortgageController:41` and
  `StatusTrackingController:50` check a role string that doesn't exist in `roleEnum`. No
  token can satisfy them.
- **notification-service still has zero tests.** Everything verified so far is manual.
