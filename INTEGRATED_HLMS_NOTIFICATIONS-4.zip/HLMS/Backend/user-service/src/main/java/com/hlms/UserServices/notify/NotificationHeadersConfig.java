package com.hlms.UserServices.notify;

import feign.RequestInterceptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * Outgoing headers for the notification Feign clients.
 *
 * Two different auth schemes are in play, so both headers are attached and each callee
 * uses the one it cares about:
 *   - notification-service's /internal/** wants X-Internal-Api-Key
 *   - user-service's /api/users wants the caller's JWT
 */
@Configuration
public class NotificationHeadersConfig {

    private final String internalApiKey;

    public NotificationHeadersConfig(
            @Value("${hlms.internal.api-key:test-key}") String internalApiKey) {
        this.internalApiKey = internalApiKey;
    }

    @Bean
    public RequestInterceptor notificationOutgoingHeaders() {
        return template -> {
            if (!template.headers().containsKey("X-Internal-Api-Key")) {
                template.header("X-Internal-Api-Key", internalApiKey);
            }
            if (template.headers().containsKey(HttpHeaders.AUTHORIZATION)) {
                return;
            }
            ServletRequestAttributes attrs =
                    (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if (attrs == null) {
                return;
            }
            String auth = attrs.getRequest().getHeader(HttpHeaders.AUTHORIZATION);
            if (auth != null && !auth.isBlank()) {
                template.header(HttpHeaders.AUTHORIZATION, auth);
            }
        };
    }
}
