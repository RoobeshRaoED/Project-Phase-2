package com.hlms.UserServices.ServiceImplementation;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hlms.UserServices.Dto.LoginRequestDTO;
import com.hlms.UserServices.Dto.LoginResponseDTO;
import com.hlms.UserServices.Dto.RegisterRequestDTO;
import com.hlms.UserServices.Entity.appUserEntity;
import com.hlms.UserServices.Exception.DuplicateRecordException;
import com.hlms.UserServices.Exception.InvalidCredentialsException;
import com.hlms.UserServices.Exception.ResourceNotFoundException;
import com.hlms.UserServices.Repository.appUserRepository;
import com.hlms.UserServices.Service.appUserService;
import com.hlms.UserServices.notify.NotificationPublisher;
import com.hlms.UserServices.security.JwtService;

@Service
public class appUserServiceImplementation implements appUserService {

    @Autowired
    private appUserRepository repository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private NotificationPublisher notifications;

    @Override
    @Transactional
    public appUserEntity registerUser(RegisterRequestDTO request) {

        if (repository.existsByEmail(request.getEmail())) {
            throw new DuplicateRecordException("User already exists");
        }

        appUserEntity user = new appUserEntity();

        user.setEmail(request.getEmail());
        user.setName(request.getName());
        user.setMobile(request.getMobile());
        user.setRole(request.getRole());
        user.setIdType(request.getIdType());
        user.setIdNumber(request.getIdNumber());

        user.setPasswordHash(
                passwordEncoder.encode(request.getPassword()));

        user.setCreatedAt(LocalDateTime.now());

        appUserEntity saved = repository.save(user);

        /*
         * Registration is a public endpoint with no JWT, so the role fan-out helper
         * (which needs a token to read the directory over HTTP) cannot be used here.
         * This service owns the user table, so admins are read straight from the
         * repository instead - no network call, no auth to forward.
         */
        String roleName = saved.getRole() == null ? "USER" : saved.getRole().name();
        String roleLabel = readableRole(roleName);

        /*
         * One endpoint, two very different journeys - and the wording has to match which
         * one actually happened:
         *   - a visitor signing themselves up at /register  -> no authenticated caller
         *   - an admin adding staff from the console        -> an authenticated caller
         * Saying "X has registered" when an admin created the account is simply untrue,
         * so the caller is inspected rather than assumed.
         */
        String createdBy = authenticatedCallerEmail();
        boolean selfSignup = createdBy == null;

        // --- 1. the new account holder ---------------------------------------------
        notifications.toUser(
                saved.getEmail(),
                "Welcome to HLMS",
                selfSignup
                        ? "Your " + roleLabel + " account is ready. You can sign in with "
                                + saved.getEmail() + "."
                        : "A " + roleLabel + " account has been created for you. Sign in with "
                                + saved.getEmail() + " using the password you were given.");

        // --- 2. the admin team ------------------------------------------------------
        /*
         * Admins are told about accounts they did NOT create - a public sign-up, or a
         * colleague adding staff. Telling an admin about their own click is noise: they
         * were looking at the screen when it happened.
         */
        for (appUserEntity admin : getUsersByRole("ADMIN")) {

            // The new user is already in this list when they are themselves an ADMIN,
            // because the row was saved a few lines above. Without this they would be
            // told about the creation of their own account, on top of the welcome
            // message they just received.
            if (admin.getEmail().equalsIgnoreCase(saved.getEmail())) {
                continue;
            }

            // The admin who performed the action does not need telling about it.
            if (!selfSignup && createdBy.equalsIgnoreCase(admin.getEmail())) {
                continue;
            }

            String title;
            String body;
            if (selfSignup) {
                title = "New " + roleLabel + " sign-up";
                body = saved.getName() + " signed up as a " + roleLabel + " ("
                        + saved.getEmail() + ").";
            } else {
                title = roleLabel.substring(0, 1).toUpperCase() + roleLabel.substring(1)
                        + " account added";
                body = createdBy + " created a " + roleLabel + " account for "
                        + saved.getName() + " (" + saved.getEmail() + ").";
            }
            notifications.toUser(admin.getEmail(), title, body);
        }

        return saved;
    }

    @Override
    @Transactional(readOnly = true)
    public LoginResponseDTO login(LoginRequestDTO request) {

        appUserEntity user = repository
                .findByEmailAndDeletedAtIsNull(request.getEmail())
                .orElseThrow(() ->
                        new ResourceNotFoundException("User not found"));

        if (!passwordEncoder.matches(
                request.getPassword(),
                user.getPasswordHash())) {

            throw new InvalidCredentialsException(
                    "Invalid password");
        }

        if (!Boolean.TRUE.equals(user.getActive())) {
            throw new InvalidCredentialsException("Account is inactive");
        }

        String token = jwtService.generateToken(
                user.getEmail(),
                user.getRole().name());

        return new LoginResponseDTO(token);
    }

    @Override
    @Transactional(readOnly = true)
    public appUserEntity getUserByEmail(String email) {

        return repository
                .findByEmailAndDeletedAtIsNull(email)
                .orElseThrow(() ->
                        new ResourceNotFoundException("User not found"));
    }

    @Override
    @Transactional
    public appUserEntity updateUser(
            String email,
            appUserEntity updatedUser) {

        appUserEntity existing = getUserByEmail(email);

        existing.setName(updatedUser.getName());
        existing.setMobile(updatedUser.getMobile());
        existing.setPrefEmail(updatedUser.getPrefEmail());
        existing.setPrefSms(updatedUser.getPrefSms());
        existing.setPrefInapp(updatedUser.getPrefInapp());

        return repository.save(existing);
    }

    @Override
    @Transactional
    public void deleteUser(String email) {

        appUserEntity user = getUserByEmail(email);

        user.setDeletedAt(LocalDateTime.now());

        repository.save(user);
    }

    @Override
    public String forgotPassword(String email) {

        getUserByEmail(email);

        String otp = String.valueOf(
                (int) ((Math.random() * 900000) + 100000));

        return otp;
    }

    @Override
    @Transactional
    public String resetPassword(
            String email,
            String otpCode,
            String newPassword) {

        appUserEntity user = getUserByEmail(email);

        user.setPasswordHash(
                passwordEncoder.encode(newPassword));

        repository.save(user);

        return "Password Reset Successful";
    }

    @Override
    @Transactional(readOnly = true)
    public List<appUserEntity> getUsersByRole(String role) {

        return repository.findAll()
                .stream()
                .filter(user -> user.getDeletedAt() == null)
                .filter(user -> user.getRole() != null)
                .filter(user -> user.getRole().name().equalsIgnoreCase(role))
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<appUserEntity> getAllUsers() {

        return repository.findAll()
                .stream()
                .filter(user -> user.getDeletedAt() == null)
                .collect(Collectors.toList());
    }

    /**
     * The signed-in caller's email, or null when the request was anonymous.
     *
     * /api/users/register is permitAll, so a public sign-up arrives with either no
     * Authentication at all or Spring's "anonymousUser" placeholder. An admin adding
     * staff from the console arrives with a real JWT.
     */
    private String authenticatedCallerEmail() {
        org.springframework.security.core.Authentication auth =
                org.springframework.security.core.context.SecurityContextHolder
                        .getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated()) {
            return null;
        }
        String name = auth.getName();
        if (name == null || name.isBlank() || "anonymousUser".equals(name)) {
            return null;
        }
        return name;
    }

    /**
     * Turns a roleEnum name into something that reads like English in a message.
     * "BANK_OFFICER" as-is produces "New BANK_OFFICER registered", which looks like a
     * database dump rather than a notification.
     */
    private String readableRole(String roleName) {
        if (roleName == null) {
            return "user";
        }
        return switch (roleName) {
            case "BANK_OFFICER" -> "bank officer";
            case "LEGAL" -> "legal team";
            case "ADMIN" -> "admin";
            case "CUSTOMER" -> "customer";
            case "BIDDER" -> "bidder";
            default -> roleName.toLowerCase().replace('_', ' ');
        };
    }
}
