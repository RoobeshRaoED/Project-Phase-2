package com.hlms.UserServices.notify;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * Raises notifications for business events in this service.
 *
 * Every method here is best-effort and NEVER throws: a notification is a side effect of
 * the real work, so a notification-service outage must not roll back a loan submission or
 * fail a bid. Failures are logged and swallowed deliberately.
 *
 * Call these AFTER the state change has been persisted, so a user is never told about
 * something that then fails to save.
 */
@Component
public class NotificationPublisher {

    private static final Logger log = LoggerFactory.getLogger(NotificationPublisher.class);

    private final NotificationClient notificationClient;

    public NotificationPublisher(NotificationClient notificationClient) {
        this.notificationClient = notificationClient;
    }

    /** Notifies one person by email. No-op when the email is missing. */
    public void toUser(String userEmail, String title, String body) {
        if (userEmail == null || userEmail.isBlank() || title == null || title.isBlank()) {
            return;
        }
        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("userEmail", userEmail);
            payload.put("title", title);
            payload.put("body", body);
            notificationClient.send(payload);
        } catch (Exception ex) {
            log.warn("Notification to {} failed ({}) - continuing", userEmail, ex.toString());
        }
    }

}
