package com.tcs.hlms.serviceImplementation;
import com.tcs.hlms.exceptions.ResourceNotFoundException;
import com.tcs.hlms.entity.PostDisbursementDocumentEntity;
import com.tcs.hlms.repository.PostDisbursementDocumentRepository;
import com.tcs.hlms.notify.NotificationPublisher;
import com.tcs.hlms.service.PostDisbursementDocumentService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PostDisbursementDocumentServiceImpl
        implements PostDisbursementDocumentService {

    private final PostDisbursementDocumentRepository repository;
    private final NotificationPublisher notifications;

    public PostDisbursementDocumentServiceImpl(
            PostDisbursementDocumentRepository repository,
            NotificationPublisher notifications) {
        this.repository = repository;
        this.notifications = notifications;
    }

    @Override
    public PostDisbursementDocumentEntity saveDocument(
            PostDisbursementDocumentEntity document) {

        boolean isNewUpload = document.getPdDocId() == null
                || repository.findById(document.getPdDocId()).isEmpty();

        PostDisbursementDocumentEntity saved = repository.save(document);

        /*
         * A customer uploading a document is work arriving for the bank, but nothing
         * told anyone - the file simply appeared in the list and waited to be noticed.
         * Only the first save announces it; verifying the same row later goes through
         * here too, and that outcome is announced by the screen that performs it.
         */
        if (isNewUpload) {
            notifications.toRole(
                    "BANK_OFFICER",
                    "New document uploaded",
                    "A " + (saved.getDocType() == null ? "document" : saved.getDocType())
                            + " (" + saved.getFileName() + ") was uploaded for application "
                            + saved.getAppId() + " and is awaiting verification.");
        }

        return saved;
    }

    @Override
    public PostDisbursementDocumentEntity getDocumentById(
            String documentId) {

        return repository.findById(documentId)
        		.orElseThrow(() ->
        	    new ResourceNotFoundException(
        	        "Post Disbursement Document not found : "
        	                + documentId));
    }

    @Override
    public List<PostDisbursementDocumentEntity> getDocumentsByAppId(
            String appId) {

        return repository.findByAppId(appId);
    }

    @Override
    public List<PostDisbursementDocumentEntity> getAllDocuments() {

        return repository.findAll();
    }

    @Override
    public void deleteDocument(String documentId) {

        repository.deleteById(documentId);
    }
}