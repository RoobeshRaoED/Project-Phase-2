package com.tcs.hlms.notify;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

/**
 * Sends a notification through notification-service's service-to-service endpoint,
 * which is guarded by X-Internal-Api-Key rather than JWT.
 */
@FeignClient(
        name = "notification-service",
        contextId = "documentNotificationClient",
        configuration = NotificationHeadersConfig.class)
public interface NotificationClient {

    @PostMapping("/internal/notifications")
    Map<String, Object> send(@RequestBody Map<String, Object> body);
}
