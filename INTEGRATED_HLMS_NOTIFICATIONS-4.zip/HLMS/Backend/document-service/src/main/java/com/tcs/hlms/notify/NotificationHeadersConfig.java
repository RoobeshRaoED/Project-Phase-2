package com.tcs.hlms.notify;

import feign.RequestInterceptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * Attaches both auth schemes: the internal key for notification-service's /internal/**,
 * and the caller's JWT for user-service's role directory.
 */
@Configuration
public class NotificationHeadersConfig {

    private final String internalApiKey;

    public NotificationHeadersConfig(
            @Value("${hlms.internal.api-key:test-key}") String internalApiKey) {
        this.internalApiKey = internalApiKey;
    }

    @Bean
    public RequestInterceptor documentNotificationHeaders() {
        return template -> {
            if (!template.headers().containsKey("X-Internal-Api-Key")) {
                template.header("X-Internal-Api-Key", internalApiKey);
            }
            if (template.headers().containsKey(HttpHeaders.AUTHORIZATION)) {
                return;
            }
            ServletRequestAttributes attrs =
                    (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if (attrs == null) {
                return;
            }
            String auth = attrs.getRequest().getHeader(HttpHeaders.AUTHORIZATION);
            if (auth != null && !auth.isBlank()) {
                template.header(HttpHeaders.AUTHORIZATION, auth);
            }
        };
    }
}
