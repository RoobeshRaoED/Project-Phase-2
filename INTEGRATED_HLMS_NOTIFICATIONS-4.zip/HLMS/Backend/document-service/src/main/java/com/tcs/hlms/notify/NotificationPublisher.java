package com.tcs.hlms.notify;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Raises notifications for document events. Best-effort throughout: a document upload
 * must never fail because a notification could not be delivered.
 */
@Component
public class NotificationPublisher {

    private static final Logger log = LoggerFactory.getLogger(NotificationPublisher.class);

    private final NotificationClient notificationClient;
    private final UserDirectoryClient userDirectoryClient;

    public NotificationPublisher(NotificationClient notificationClient,
                                 UserDirectoryClient userDirectoryClient) {
        this.notificationClient = notificationClient;
        this.userDirectoryClient = userDirectoryClient;
    }

    public void toUser(String userEmail, String title, String body) {
        if (userEmail == null || userEmail.isBlank() || title == null || title.isBlank()) {
            return;
        }
        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("userEmail", userEmail);
            payload.put("title", title);
            payload.put("body", body);
            notificationClient.send(payload);
        } catch (Exception ex) {
            log.warn("Notification to {} failed ({}) - continuing", userEmail, ex.toString());
        }
    }

    /** Needs the caller's JWT to read the directory; a no-op outside an HTTP request. */
    public void toRole(String role, String title, String body) {
        if (role == null || role.isBlank()) {
            return;
        }
        List<Map<String, Object>> users;
        try {
            users = userDirectoryClient.byRole(role);
        } catch (Exception ex) {
            log.warn("Could not resolve role {} for notification ({}) - skipping", role, ex.toString());
            return;
        }
        if (users == null) {
            return;
        }
        for (Map<String, Object> user : users) {
            Object email = user.get("email");
            Object active = user.get("active");
            if (email != null && !Boolean.FALSE.equals(active)) {
                toUser(String.valueOf(email), title, body);
            }
        }
    }
}
