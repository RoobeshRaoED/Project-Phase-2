package com.tcs.hlms.notify;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Map;

/** Resolves "everyone with role X" so a notification can be addressed to a whole team. */
@FeignClient(
        name = "user-service",
        contextId = "documentUserDirectoryClient",
        configuration = NotificationHeadersConfig.class)
public interface UserDirectoryClient {

    @GetMapping("/api/users")
    List<Map<String, Object>> byRole(@RequestParam("role") String role);
}
