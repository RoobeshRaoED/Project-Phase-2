package com.hlms2.repayment.serviceimpl;

import com.hlms2.repayment.dto.EmiInstallmentDTO;
import com.hlms2.repayment.entity.EmiInstallment;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.exception.ValidationException;
import com.hlms2.repayment.repository.EmiInstallmentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EmiInstallmentServiceImplTest {

    @Mock
    private EmiInstallmentRepository repository;

    private EmiInstallmentServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new EmiInstallmentServiceImpl(repository, null,
                new com.hlms2.repayment.notify.NotificationPublisher(null, null));
    }

    private EmiInstallmentDTO validDto() {
        EmiInstallmentDTO dto = new EmiInstallmentDTO();
        dto.setAppId("APP-1");
        dto.setInstallmentNo(1);
        dto.setDueDate(LocalDate.now().plusDays(30));
        dto.setEmiAmount(BigDecimal.valueOf(1000));
        dto.setPrincipalComponent(BigDecimal.valueOf(700));
        dto.setInterestComponent(BigDecimal.valueOf(300));
        dto.setClosingBalance(BigDecimal.valueOf(9000));
        return dto;
    }

    // ---------- create() ----------

    @Test
    void create_positive_pendingWhenDueInFuture() {
        EmiInstallmentDTO dto = validDto();
        when(repository.save(any(EmiInstallment.class))).thenAnswer(inv -> inv.getArgument(0));

        EmiInstallmentDTO result = service.create(dto);

        assertThat(result.getInstallmentId()).startsWith("EMI-");
        assertThat(result.getStatus()).isEqualTo("PENDING");
    }

    @Test
    void create_positive_overdueWhenDueDatePassedAndUnpaid() {
        EmiInstallmentDTO dto = validDto();
        dto.setDueDate(LocalDate.now().minusDays(5));
        when(repository.save(any(EmiInstallment.class))).thenAnswer(inv -> inv.getArgument(0));

        EmiInstallmentDTO result = service.create(dto);

        assertThat(result.getStatus()).isEqualTo("OVERDUE");
    }

    @Test
    void create_positive_paidWhenPaidDateSet() {
        EmiInstallmentDTO dto = validDto();
        dto.setDueDate(LocalDate.now().minusDays(5));
        dto.setStatus("PAID");
        dto.setPaidDate(LocalDate.now());
        when(repository.save(any(EmiInstallment.class))).thenAnswer(inv -> inv.getArgument(0));

        EmiInstallmentDTO result = service.create(dto);

        assertThat(result.getStatus()).isEqualTo("PAID");
    }

    @Test
    void create_negative_missingAppId_throws() {
        EmiInstallmentDTO dto = validDto();
        dto.setAppId(null);

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
        verifyNoInteractions(repository);
    }

    @Test
    void create_negative_nonPositiveInstallmentNo_throws() {
        EmiInstallmentDTO dto = validDto();
        dto.setInstallmentNo(0);

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_missingDueDate_throws() {
        EmiInstallmentDTO dto = validDto();
        dto.setDueDate(null);

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_nonPositiveEmiAmount_throws() {
        EmiInstallmentDTO dto = validDto();
        dto.setEmiAmount(BigDecimal.ZERO);

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_negativePrincipalComponent_throws() {
        EmiInstallmentDTO dto = validDto();
        dto.setPrincipalComponent(BigDecimal.valueOf(-1));

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_negativeInterestComponent_throws() {
        EmiInstallmentDTO dto = validDto();
        dto.setInterestComponent(BigDecimal.valueOf(-1));

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_negativeClosingBalance_throws() {
        EmiInstallmentDTO dto = validDto();
        dto.setClosingBalance(BigDecimal.valueOf(-1));

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_componentsDoNotSumToEmiAmount_throws() {
        EmiInstallmentDTO dto = validDto();
        dto.setPrincipalComponent(BigDecimal.valueOf(100));
        dto.setInterestComponent(BigDecimal.valueOf(100));
        // emiAmount is 1000, sum is 200 -> way off tolerance of 1

        assertThatThrownBy(() -> service.create(dto))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("must equal emiAmount");
    }

    @Test
    void create_edge_componentsWithinRoundingToleranceAccepted() {
        EmiInstallmentDTO dto = validDto();
        dto.setEmiAmount(BigDecimal.valueOf(1000));
        dto.setPrincipalComponent(BigDecimal.valueOf(700));
        dto.setInterestComponent(BigDecimal.valueOf(300.5)); // sum 1000.5, diff 0.5 <= tolerance(1)
        when(repository.save(any(EmiInstallment.class))).thenAnswer(inv -> inv.getArgument(0));

        assertThat(service.create(dto)).isNotNull();
    }

    @Test
    void create_negative_invalidStatus_throws() {
        EmiInstallmentDTO dto = validDto();
        dto.setStatus("CANCELLED");

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_paidStatusWithoutPaidDate_throws() {
        EmiInstallmentDTO dto = validDto();
        dto.setStatus("PAID");
        dto.setPaidDate(null);

        assertThatThrownBy(() -> service.create(dto))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("paidDate is required");
    }

    // ---------- update() ----------

    @Test
    void update_positive_updatesExisting() {
        EmiInstallmentDTO dto = validDto();
        dto.setInstallmentId("EMI-1");
        EmiInstallment existing = EmiInstallment.builder().installmentId("EMI-1").appId("APP-1").build();
        when(repository.findByInstallmentIdAndDeletedAtIsNull("EMI-1")).thenReturn(Optional.of(existing));
        when(repository.save(any(EmiInstallment.class))).thenAnswer(inv -> inv.getArgument(0));

        assertThat(service.update(dto)).isNotNull();
    }

    @Test
    void update_negative_missingInstallmentId_throws() {
        assertThatThrownBy(() -> service.update(validDto())).isInstanceOf(ValidationException.class);
    }

    @Test
    void update_negative_notFound_throws() {
        EmiInstallmentDTO dto = validDto();
        dto.setInstallmentId("EMI-404");
        when(repository.findByInstallmentIdAndDeletedAtIsNull("EMI-404")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.update(dto)).isInstanceOf(ResourceNotFoundException.class);
    }

    // ---------- softDelete() / restore() ----------

    @Test
    void softDelete_positive_returnsTrue() {
        EmiInstallment existing = EmiInstallment.builder().installmentId("EMI-1").appId("APP-1").build();
        when(repository.findByInstallmentIdAndDeletedAtIsNull("EMI-1")).thenReturn(Optional.of(existing));

        assertThat(service.softDelete("EMI-1")).isTrue();
    }

    @Test
    void softDelete_negative_notFound_returnsFalse() {
        when(repository.findByInstallmentIdAndDeletedAtIsNull("EMI-404")).thenReturn(Optional.empty());

        assertThat(service.softDelete("EMI-404")).isFalse();
    }

    // ---------- findById / findAll / getPaymentHistory ----------

    @Test
    void findById_negative_missingId_throws() {
        assertThatThrownBy(() -> service.findById(null)).isInstanceOf(ValidationException.class);
    }

    @Test
    void findAll_edge_empty() {
        when(repository.findByDeletedAtIsNull()).thenReturn(List.of());

        assertThat(service.findAll()).isEmpty();
    }

    @Test
    void getPaymentHistory_positive_sortsByInstallmentNo() {
        EmiInstallment i2 = EmiInstallment.builder().installmentId("EMI-2").appId("APP-1").installmentNo(2).status("PENDING").build();
        EmiInstallment i1 = EmiInstallment.builder().installmentId("EMI-1").appId("APP-1").installmentNo(1).status("PENDING").build();
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(List.of(i2, i1));

        List<EmiInstallmentDTO> result = service.getPaymentHistory("APP-1");

        assertThat(result).extracting(EmiInstallmentDTO::getInstallmentNo).containsExactly(1, 2);
    }

    @Test
    void getPaymentHistory_negative_missingAppId_throws() {
        assertThatThrownBy(() -> service.getPaymentHistory(null)).isInstanceOf(ValidationException.class);
    }

    // ---------- detectOverdueLoans() ----------

    @Test
    void detectOverdueLoans_positive_returnsDistinctAppIds() {
        EmiInstallment overdue1 = EmiInstallment.builder().installmentId("EMI-1").appId("APP-1").status("OVERDUE").build();
        EmiInstallment overdue2 = EmiInstallment.builder().installmentId("EMI-2").appId("APP-1").status("OVERDUE").build();
        EmiInstallment overdue3 = EmiInstallment.builder().installmentId("EMI-3").appId("APP-2").status("OVERDUE").build();
        EmiInstallment pending = EmiInstallment.builder().installmentId("EMI-4").appId("APP-3").status("PENDING").build();
        when(repository.findByDeletedAtIsNull()).thenReturn(List.of(overdue1, overdue2, overdue3, pending));

        Set<String> result = service.detectOverdueLoans();

        assertThat(result).containsExactlyInAnyOrder("APP-1", "APP-2");
    }

    @Test
    void detectOverdueLoans_edge_noOverdueInstallments_returnsEmptySet() {
        EmiInstallment pending = EmiInstallment.builder().installmentId("EMI-1").appId("APP-1").status("PENDING").build();
        when(repository.findByDeletedAtIsNull()).thenReturn(List.of(pending));

        assertThat(service.detectOverdueLoans()).isEmpty();
    }

    // ---------- determineEscalationLevel() ----------

    @Test
    void determineEscalationLevel_edge_zeroOverdue_returnsNone() {
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(List.of());

        assertThat(service.determineEscalationLevel("APP-1")).isEqualTo("NONE");
    }

    @Test
    void determineEscalationLevel_positive_oneOrTwoOverdue_returnsReminder() {
        List<EmiInstallment> installments = List.of(
                EmiInstallment.builder().installmentId("EMI-1").appId("APP-1").installmentNo(1).status("OVERDUE").build(),
                EmiInstallment.builder().installmentId("EMI-2").appId("APP-1").installmentNo(2).status("OVERDUE").build());
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(installments);

        assertThat(service.determineEscalationLevel("APP-1")).isEqualTo("REMINDER");
    }

    @Test
    void determineEscalationLevel_positive_threeOrFourOverdue_returnsNotice() {
        List<EmiInstallment> installments = List.of(
                EmiInstallment.builder().installmentId("EMI-1").appId("APP-1").installmentNo(1).status("OVERDUE").build(),
                EmiInstallment.builder().installmentId("EMI-2").appId("APP-1").installmentNo(2).status("OVERDUE").build(),
                EmiInstallment.builder().installmentId("EMI-3").appId("APP-1").installmentNo(3).status("OVERDUE").build());
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(installments);

        assertThat(service.determineEscalationLevel("APP-1")).isEqualTo("NOTICE");
    }

    @Test
    void determineEscalationLevel_edge_fiveOrMoreOverdue_returnsLegalEscalation() {
        List<EmiInstallment> installments = List.of(
                EmiInstallment.builder().installmentId("EMI-1").appId("APP-1").installmentNo(1).status("OVERDUE").build(),
                EmiInstallment.builder().installmentId("EMI-2").appId("APP-1").installmentNo(2).status("OVERDUE").build(),
                EmiInstallment.builder().installmentId("EMI-3").appId("APP-1").installmentNo(3).status("OVERDUE").build(),
                EmiInstallment.builder().installmentId("EMI-4").appId("APP-1").installmentNo(4).status("OVERDUE").build(),
                EmiInstallment.builder().installmentId("EMI-5").appId("APP-1").installmentNo(5).status("OVERDUE").build());
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(installments);

        assertThat(service.determineEscalationLevel("APP-1")).isEqualTo("LEGAL_ESCALATION");
    }

    @Test
    void determineEscalationLevel_negative_missingAppId_throws() {
        assertThatThrownBy(() -> service.determineEscalationLevel(null)).isInstanceOf(ValidationException.class);
    }

    // ---------- getDefaultStatus() ----------

    @Test
    void getDefaultStatus_edge_noOverdue_returnsInGoodStanding() {
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(List.of());

        assertThat(service.getDefaultStatus("APP-1")).isEqualTo("IN_GOOD_STANDING");
    }

    @Test
    void getDefaultStatus_positive_overdueReturnsDefaultedWithAmountAndLevel() {
        EmiInstallment overdue = EmiInstallment.builder().installmentId("EMI-1").appId("APP-1")
                .installmentNo(1).status("OVERDUE").emiAmount(BigDecimal.valueOf(1500)).build();
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(List.of(overdue));

        String result = service.getDefaultStatus("APP-1");

        assertThat(result).contains("DEFAULTED").contains("1 overdue").contains("1500").contains("REMINDER");
    }

    @Test
    void getDefaultStatus_negative_missingAppId_throws() {
        assertThatThrownBy(() -> service.getDefaultStatus(null)).isInstanceOf(ValidationException.class);
    }
}
