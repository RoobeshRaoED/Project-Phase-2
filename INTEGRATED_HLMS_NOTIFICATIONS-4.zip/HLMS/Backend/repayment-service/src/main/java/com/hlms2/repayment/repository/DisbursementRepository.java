package com.hlms2.repayment.repository;

import com.hlms2.repayment.entity.Disbursement;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface DisbursementRepository extends JpaRepository<Disbursement, Long> {
    Optional<Disbursement> findByAppIdAndDeletedAtIsNull(String appId);

    /**
     * Any row for this application, soft-deleted included. The unique constraint on
     * disbursement.app_id applies regardless of deleted_at, so the duplicate check has
     * to see soft-deleted rows too.
     */
    Optional<Disbursement> findByAppId(String appId);
    Optional<Disbursement> findByDisbursementIdAndDeletedAtIsNull(Long disbursementId);
    List<Disbursement> findByDeletedAtIsNull();
}
