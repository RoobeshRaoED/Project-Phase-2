package com.hlms2.repayment.notify;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

/**
 * Sends a notification through notification-service's service-to-service endpoint.
 *
 * This endpoint skips JWT and is guarded by X-Internal-Api-Key instead, which
 * {@link NotificationHeadersConfig} attaches. It exists so that system flows with no
 * logged-in user (status transitions, scheduled jobs) can still raise a notification.
 */
@FeignClient(
        name = "notification-service",
        contextId = "notificationClient",
        configuration = NotificationHeadersConfig.class)
public interface NotificationClient {

    @PostMapping("/internal/notifications")
    Map<String, Object> send(@RequestBody Map<String, Object> body);
}
