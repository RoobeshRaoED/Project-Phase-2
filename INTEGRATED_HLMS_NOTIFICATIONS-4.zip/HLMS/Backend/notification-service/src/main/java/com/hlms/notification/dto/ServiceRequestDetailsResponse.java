package com.hlms.notification.dto;

import com.hlms.notification.entity.ServiceRequest;

/** A service request together with the cross-service context for its application. */
public record ServiceRequestDetailsResponse(
        ServiceRequest serviceRequest,
        ApplicationContextResponse applicationContext) { }
