package com.hlms.notification.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** One row of document-service's ApplicationDocumentEntity (file bytes omitted). */
@JsonIgnoreProperties(ignoreUnknown = true)
public record DocumentResponse(
        String documentId,
        String appId,
        String docType,
        String verificationStatus,
        String verifiedBy) { }
