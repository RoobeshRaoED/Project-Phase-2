package com.hlms.notification.client;

import feign.RequestInterceptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * Outgoing header policy for every Feign call this service makes.
 *
 * FIX: previously this only attached X-Internal-Api-Key, and the clients pointed at
 * /internal/** endpoints that no other HLMS service actually exposes - so every
 * enrichment call came back 401/404 and the details were silently dropped.
 *
 * The clients now call the real /api/** endpoints, which are secured with the same JWT
 * this service already validated on the inbound request. So the caller's
 * "Authorization: Bearer ..." header is forwarded downstream. The internal API key is
 * still attached, which keeps notification-service's own /internal/notifications
 * endpoint usable by other services, and costs nothing on calls that ignore it.
 */
@Configuration
public class FeignClientConfig {

    private final String internalApiKey;

    public FeignClientConfig(@Value("${hlms.internal.api-key}") String internalApiKey) {
        this.internalApiKey = internalApiKey;
    }

    @Bean
    public RequestInterceptor outgoingHeadersInterceptor() {
        return template -> {
            if (!template.headers().containsKey("X-Internal-Api-Key")) {
                template.header("X-Internal-Api-Key", internalApiKey);
            }

            if (template.headers().containsKey(HttpHeaders.AUTHORIZATION)) {
                return;
            }

            ServletRequestAttributes attributes =
                    (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if (attributes == null) {
                // No inbound HTTP request (scheduled job / startup) - nothing to forward.
                return;
            }

            String authorization = attributes.getRequest().getHeader(HttpHeaders.AUTHORIZATION);
            if (authorization != null && !authorization.isBlank()) {
                template.header(HttpHeaders.AUTHORIZATION, authorization);
            }
        };
    }
}
