package com.hlms.notification.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Subset of repayment-service's EmiInstallmentDTO. */
@JsonIgnoreProperties(ignoreUnknown = true)
public record EmiInstallmentResponse(
        String installmentId,
        String appId,
        Integer installmentNo,
        LocalDate dueDate,
        BigDecimal emiAmount,
        String status,
        LocalDate paidDate) { }
