package com.hlms.notification.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Looks up basic loan application facts (owner, product, amount, status) from loan-service.
 *
 * FIX: this used to call GET /internal/applications/{appId}, which loan-service does not
 * expose - every call 404'd. It now calls the endpoint that really exists:
 * LoanApplicationController -> GET /api/loan-applications/{appId}.
 */
@FeignClient(name = "loan-service", configuration = FeignClientConfig.class)
public interface LoanApplicationClient {

    @GetMapping("/api/loan-applications/{appId}")
    ApplicationSummaryResponse getApplication(@PathVariable("appId") String appId);
}
