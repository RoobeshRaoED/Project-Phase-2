package com.hlms.notification.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** Subset of legal-service's LegalVerificationDTO. */
@JsonIgnoreProperties(ignoreUnknown = true)
public record LegalVerificationResponse(
        Long verificationId,
        String appId,
        String decision,
        String officerEmail,
        String remarks,
        Boolean infoRequested) { }
