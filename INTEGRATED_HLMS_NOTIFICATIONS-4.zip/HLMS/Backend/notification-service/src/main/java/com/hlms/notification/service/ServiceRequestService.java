package com.hlms.notification.service;

import com.hlms.notification.client.ApplicationSummaryResponse;
import com.hlms.notification.client.UserClient;
import com.hlms.notification.client.UserSummaryResponse;
import com.hlms.notification.dto.ApplicationContextResponse;
import com.hlms.notification.dto.ServiceRequestDetailsResponse;
import com.hlms.notification.entity.ServiceRequest;
import com.hlms.notification.exception.BadRequestException;
import com.hlms.notification.exception.ResourceNotFoundException;
import com.hlms.notification.repository.ServiceRequestRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

/** Backs feature "9. Post-Disbursement Service Management". */
@Service
public class ServiceRequestService {

    private static final Logger log = LoggerFactory.getLogger(ServiceRequestService.class);

    private final ServiceRequestRepository repository;
    private final ApplicationContextService applicationContextService;
    private final NotificationService notificationService;
    private final UserClient userClient;

    public ServiceRequestService(ServiceRequestRepository repository,
                                 ApplicationContextService applicationContextService,
                                 NotificationService notificationService,
                                 UserClient userClient) {
        this.repository = repository;
        this.applicationContextService = applicationContextService;
        this.notificationService = notificationService;
        this.userClient = userClient;
    }

    @Transactional
    public ServiceRequest create(String appId, String userEmail, String requestType, String description) {
        if (appId == null || appId.isBlank()) {
            throw new BadRequestException("appId is required");
        }
        if (requestType == null || requestType.isBlank()) {
            throw new BadRequestException("requestType is required");
        }

        // Confirm the application exists before opening a request against it. Only a
        // definite 404 from loan-service blocks the request; an outage does not.
        if (applicationContextService.applicationDefinitelyMissing(appId)) {
            throw new BadRequestException("No such loan application: " + appId);
        }

        // FIX: userEmail arrived null from clients that only sent appId, then failed at
        // the DB. Fall back to the application's owner when loan-service can tell us.
        String effectiveEmail = userEmail;
        if (effectiveEmail == null || effectiveEmail.isBlank()) {
            ApplicationSummaryResponse application = applicationContextService.getApplication(appId);
            effectiveEmail = application == null ? null : application.userEmail();
        }
        if (effectiveEmail == null || effectiveEmail.isBlank()) {
            throw new BadRequestException("userEmail is required (and could not be resolved from " + appId + ")");
        }

        ServiceRequest sr = ServiceRequest.builder()
                .requestId("SR-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase())
                .refNo("SR-REF-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase())
                .appId(appId)
                .userEmail(effectiveEmail)
                .requestType(requestType)
                .description(description)
                .status("Requested")
                .build();

        ServiceRequest saved = repository.save(sr);

        // The customer gets a receipt...
        notifyQuietly(saved, "Service request raised",
                "Your " + requestType + " request has been raised. Reference: " + saved.getRefNo());

        // ...and the bank gets the actual work item. Without this the request would sit
        // in the database with nobody told to act on it.
        notifyRole("BANK_OFFICER",
                "New service request: " + requestType,
                "A " + requestType + " request (" + saved.getRefNo() + ") was raised by "
                        + saved.getUserEmail()
                        + (saved.getAppId() == null ? "" : " for application " + saved.getAppId())
                        + ". " + (description == null || description.isBlank() ? "" : description));

        return saved;
    }

    public List<ServiceRequest> listForUser(String userEmail) {
        return repository.findByUserEmailAndDeletedAtIsNull(userEmail);
    }

    /**
     * Every open request across all customers - what the bank office works from.
     * Officers are notified when a request is raised, so they need somewhere to act
     * on it; without this endpoint the notification led nowhere.
     */
    public List<ServiceRequest> listAll() {
        return repository.findByDeletedAtIsNullOrderByCreatedAtDesc();
    }

    public List<ServiceRequest> listForApp(String appId) {
        return repository.findByAppIdAndDeletedAtIsNull(appId);
    }

    public ServiceRequest get(String requestId) {
        return repository.findById(requestId)
                .filter(r -> r.getDeletedAt() == null)
                .orElseThrow(() -> new ResourceNotFoundException("Service request not found: " + requestId));
    }

    /**
     * The request plus everything the other services know about its application.
     * This is what the four previously-unused Feign clients were built for.
     */
    public ServiceRequestDetailsResponse getWithDetails(String requestId) {
        ServiceRequest sr = get(requestId);
        ApplicationContextResponse context =
                sr.getAppId() == null ? null : applicationContextService.getFullContext(sr.getAppId());
        return new ServiceRequestDetailsResponse(sr, context);
    }

    @Transactional
    public ServiceRequest updateStatus(String requestId, String status) {
        return updateStatus(requestId, status, null);
    }

    /**
     * Moves a request along and tells the customer what it means for them.
     *
     * The officer's note is passed through verbatim when present - "rejected" on its own
     * tells a customer nothing, and the reason is the whole point of the message.
     */
    @Transactional
    public ServiceRequest updateStatus(String requestId, String status, String note) {
        if (status == null || status.isBlank()) {
            throw new BadRequestException("status is required");
        }
        ServiceRequest sr = get(requestId);

        String previous = sr.getStatus();
        sr.setStatus(status);
        ServiceRequest saved = repository.save(sr);

        // Re-saving at the same status is not news.
        if (status.equalsIgnoreCase(previous)) {
            return saved;
        }

        String type = saved.getRequestType() == null ? "request" : saved.getRequestType();
        String suffix = (note == null || note.isBlank()) ? "" : " Note from the bank: " + note;

        String title;
        String body;
        switch (status.toUpperCase().replace('_', ' ')) {
            case "IN PROGRESS" -> {
                title = "Service request in progress";
                body = "Your " + type + " request (" + saved.getRefNo()
                        + ") has been picked up by the bank and is being worked on." + suffix;
            }
            case "COMPLETED", "RESOLVED", "CLOSED" -> {
                title = "Service request completed";
                body = "Your " + type + " request (" + saved.getRefNo()
                        + ") has been completed." + suffix;
            }
            case "REJECTED", "DECLINED" -> {
                title = "Service request declined";
                body = "Your " + type + " request (" + saved.getRefNo()
                        + ") could not be actioned." + (suffix.isEmpty()
                                ? " Please contact the branch for details." : suffix);
            }
            default -> {
                title = "Service request updated";
                body = "Your " + type + " request (" + saved.getRefNo()
                        + ") is now: " + status + "." + suffix;
            }
        }

        notifyQuietly(saved, title, body);
        return saved;
    }

    private void notifyQuietly(ServiceRequest sr, String title, String body) {
        try {
            notificationService.send(sr.getUserEmail(), title, body, null);
        } catch (Exception ex) {
            log.warn("Could not raise notification for service request {}: {}", sr.getRequestId(), ex.toString());
        }
    }

    /**
     * Addresses a notification to everyone holding a role. Needs the caller's JWT to
     * read the user directory, which is present here because a service request always
     * originates from a signed-in customer.
     */
    private void notifyRole(String role, String title, String body) {
        List<UserSummaryResponse> recipients;
        try {
            recipients = userClient.getUsersByRole(role);
        } catch (Exception ex) {
            log.warn("Could not resolve role {} for service-request notification: {}", role, ex.toString());
            return;
        }
        if (recipients == null) {
            return;
        }
        for (UserSummaryResponse user : recipients) {
            if (user.email() == null || Boolean.FALSE.equals(user.active())) {
                continue;
            }
            try {
                notificationService.send(user.email(), title, body, null);
            } catch (Exception ex) {
                log.warn("Could not notify {}: {}", user.email(), ex.toString());
            }
        }
    }
}
