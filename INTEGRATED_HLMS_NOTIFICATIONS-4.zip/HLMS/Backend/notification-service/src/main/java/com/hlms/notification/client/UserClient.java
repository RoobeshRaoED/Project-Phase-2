package com.hlms.notification.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * Looks up basic user identity (name, mobile, role, channel preferences) from user-service.
 *
 * FIX: was GET /internal/users/{email} (nonexistent). user-service really exposes
 * appUserController -> GET /api/users/{email}.
 */
@FeignClient(name = "user-service", configuration = FeignClientConfig.class)
public interface UserClient {

    @GetMapping("/api/users/{email}")
    UserSummaryResponse getUser(@PathVariable("email") String email);

    /**
     * Everyone holding a role, so a notification can be addressed to a whole team
     * (all bank officers) rather than one person. Used when a customer raises a
     * service request and the bank needs to see it.
     */
    @GetMapping("/api/users")
    List<UserSummaryResponse> getUsersByRole(@RequestParam("role") String role);
}
