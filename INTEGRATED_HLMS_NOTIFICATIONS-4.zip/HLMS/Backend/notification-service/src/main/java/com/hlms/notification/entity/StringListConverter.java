package com.hlms.notification.entity;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Maps a List&lt;String&gt; to a single comma-separated column and back.
 *
 * Notification.channels used to be an @ElementCollection, which made Hibernate look for
 * a side table ("notification_channels") instead of the notification.channels column that
 * actually exists in the shared schema. Any row written by another service - or by SQL -
 * therefore came back with an empty channel list.
 */
@Converter
public class StringListConverter implements AttributeConverter<List<String>, String> {

    private static final String DELIMITER = ",";

    @Override
    public String convertToDatabaseColumn(List<String> attribute) {
        if (attribute == null || attribute.isEmpty()) {
            return null;
        }
        return String.join(DELIMITER, attribute);
    }

    @Override
    public List<String> convertToEntityAttribute(String dbData) {
        if (dbData == null || dbData.isBlank()) {
            return new ArrayList<>();
        }
        // Tolerates values written as "inapp,sms", "{inapp,sms}" (Postgres array literal)
        // and "[\"inapp\"]"-ish leftovers, so old rows still read cleanly.
        String cleaned = dbData.trim()
                .replaceAll("^[\\{\\[\"']+", "")
                .replaceAll("[\\}\\]\"']+$", "");
        return Arrays.stream(cleaned.split(DELIMITER))
                .map(s -> s.replace("\"", "").trim())
                .filter(s -> !s.isEmpty())
                .collect(java.util.stream.Collectors.toCollection(ArrayList::new));
    }
}
