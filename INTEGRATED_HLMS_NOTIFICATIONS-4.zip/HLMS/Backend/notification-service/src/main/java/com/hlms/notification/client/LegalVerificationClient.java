package com.hlms.notification.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Fetches the legal verification decision for an application from legal-service.
 *
 * FIX: was GET /internal/legal-verifications/application/{appId}/status (nonexistent).
 * The real endpoint is LegalVerificationController ->
 * GET /api/legal/verifications/by-application/{appId}.
 */
@FeignClient(name = "legal-service", configuration = FeignClientConfig.class)
public interface LegalVerificationClient {

    @GetMapping("/api/legal/verifications/by-application/{appId}")
    LegalVerificationResponse getByApplication(@PathVariable("appId") String appId);
}
