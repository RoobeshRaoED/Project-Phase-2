package com.hlms.notification.controller;

import com.hlms.notification.dto.ServiceRequestDetailsResponse;
import com.hlms.notification.entity.ServiceRequest;
import com.hlms.notification.service.ServiceRequestService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/** Feature 9: Post-Disbursement Service Management (US-PD-01..04) */
@RestController
@RequestMapping("/api/service-requests")
public class ServiceRequestController {

    private final ServiceRequestService service;

    public ServiceRequestController(ServiceRequestService service) {
        this.service = service;
    }

    @PostMapping
    public ServiceRequest create(@RequestBody Map<String, String> body) {
        return service.create(body.get("appId"), body.get("userEmail"),
                body.get("requestType"), body.get("description"));
    }

    @GetMapping
    public List<ServiceRequest> listForUser(@RequestParam String userEmail) {
        return service.listForUser(userEmail);
    }

    /** Bank office queue - every live request, newest first. */
    @GetMapping("/all")
    public List<ServiceRequest> listAll() {
        return service.listAll();
    }

    @GetMapping("/by-app/{appId}")
    public List<ServiceRequest> listForApp(@PathVariable String appId) {
        return service.listForApp(appId);
    }

    @GetMapping("/{requestId}")
    public ServiceRequest get(@PathVariable String requestId) {
        return service.get(requestId);
    }

    /**
     * NEW: the request plus the loan application, customer, document, legal and
     * repayment details pulled from the other services.
     */
    @GetMapping("/{requestId}/details")
    public ServiceRequestDetailsResponse getDetails(@PathVariable String requestId) {
        return service.getWithDetails(requestId);
    }

    /**
     * Bank office action on a request. An optional "note" is passed through to the
     * customer's notification - a decline with no reason is not much use to them.
     */
    @PatchMapping("/{requestId}/status")
    public ServiceRequest updateStatus(@PathVariable String requestId, @RequestBody Map<String, String> body) {
        return service.updateStatus(requestId, body.get("status"), body.get("note"));
    }
}
