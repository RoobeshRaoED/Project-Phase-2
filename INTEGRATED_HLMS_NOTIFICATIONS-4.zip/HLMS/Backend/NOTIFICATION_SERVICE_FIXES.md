# notification-service — what was broken and what changed

Drop these files over `hlms-microservices/notification-service/`, keeping the same paths.
Everything else in the service (SecurityConfig, JwtService, entities `AppUser` /
`ServiceRequest`, repositories, `NotificationController`, `InternalNotificationController`,
`LoggingNotificationGateway`, `ApiError`, the exception classes) is unchanged.

---

## 1. The module could not build inside the reactor — `pom.xml`

`notification-service/pom.xml` declared `groupId=com.hlms2`, `artifactId=legal-service` —
byte-for-byte the same coordinates as the `legal-service` module. Maven rejects a reactor
containing two projects with identical coordinates, so `mvn clean install` from
`hlms-microservices/` failed, and when built individually its jar overwrote legal-service's
in `~/.m2`.

Now `com.hlms:notification-service:1.0.0`. Also removed the duplicated `springdoc`
dependency (2.6.0 *and* 2.3.0 were declared) and added `spring-boot-starter-actuator`,
which `SecurityConfig` and the Eureka health check both assume is present.

## 2. Hibernate was talking H2 to a Postgres database — `application.properties`

```
spring.datasource.url=jdbc:postgresql://...      <- Postgres
spring.jpa.database-platform=...H2Dialect        <- H2
```

Every other service uses `PostgreSQLDialect`. With the H2 dialect, Hibernate generated
H2-flavoured SQL and DDL against Postgres — the main reason reads and schema updates
misbehaved. Fixed, along with removing the leftover H2-console properties, adding Feign
timeouts, `open-in-view=false`, and ISO-8601 date serialisation.

## 3. `channels` was mapped to a table that isn't in the schema — `Notification.java`

`channels` was an `@ElementCollection`, so Hibernate looked for a side table
`notification_channels` instead of the `notification.channels` column. Any row written by
another service or by SQL came back with an empty channel list. Now stored in-row via
`StringListConverter` (new file), which also tolerates values written as
`inapp,sms`, `{inapp,sms}` or quoted variants.

**Run once after deploying**, if the stray table was created:
```sql
DROP TABLE IF EXISTS notification_channels;
```
If your `notification.channels` column is a Postgres array (`text[]`) rather than
`text`/`varchar`, convert it instead of using the converter as-is:
```sql
ALTER TABLE notification ALTER COLUMN channels TYPE text USING array_to_string(channels, ',');
```

## 4. `isRead` was published to JSON as `read` — `Notification.java`

The accessor was `isRead()`, so Jackson named the property `read` and any client reading
`notification.isRead` got `undefined`. The accessor is now `getIsRead()`, and `read` is
kept as an alias so anything already using the old key keeps working.

## 5. **Every cross-service lookup was pointed at endpoints that don't exist**

This is why details never came through. All five Feign clients called `/internal/**`
paths, and **no HLMS service exposes any `/internal/**` endpoint** except
notification-service itself. Every call returned 401/404 and was swallowed.

Repointed to the endpoints that actually exist:

| Client | Was (404) | Now |
|---|---|---|
| `LoanApplicationClient` | `/internal/applications/{appId}` | `GET /api/loan-applications/{appId}` |
| `UserClient` | `/internal/users/{email}` | `GET /api/users/{email}` |
| `DocumentStatusClient` | `/internal/documents/application/{appId}/status` | `GET /api/application-documents/app/{appId}` |
| `LegalVerificationClient` | `/internal/legal-verifications/application/{appId}/status` | `GET /api/legal/verifications/by-application/{appId}` |
| `RepaymentSummaryClient` | `/internal/repayment/application/{appId}/summary` | `GET /api/emi/{appId}/schedule` |

Those endpoints are JWT-protected (`anyRequest().authenticated()` in each service), and
the old interceptor only sent `X-Internal-Api-Key`. `FeignClientConfig` now **forwards the
caller's `Authorization: Bearer …` header** downstream, and still attaches the internal
key. New lenient response records — `DocumentResponse`, `LegalVerificationResponse`,
`EmiInstallmentResponse` — match the real payloads; `DocumentStatusResponse`,
`LegalStatusResponse` and `RepaymentSummaryResponse` are kept and now hold the *derived*
counts.

## 6. Four of the five clients were never called by anything

`UserClient`, `DocumentStatusClient`, `LegalVerificationClient` and
`RepaymentSummaryClient` were declared and wired by Spring but injected nowhere — no code
path fetched any of it. New `ApplicationContextService` uses them, degrading per-service:
an unreachable service yields `null` for that section and its name in `unavailable`,
rather than failing the whole response.

Two new read endpoints:

- `GET /api/service-requests/{requestId}/details` — the request plus full application context
- `GET /api/application-context/{appId}` — the aggregated view on its own

## 7. Smaller correctness fixes

- `ServiceRequestService.create` blocked on *any* Feign failure being read as "no such
  application". Only a definite 404 blocks now; it also resolves a missing `userEmail`
  from the application, and raises a notification on create and on status change.
- `NotificationService.send` validated nothing — a null `userEmail`/`title` reached the DB
  as a raw 500. Now a 400.
- `markRead` used bare `orElseThrow()` → 500 on an unknown id. Now a 404.
- Failed channel dispatches were swallowed with an empty catch block. Now logged.
- **US-NM-04 was not implemented**: `app_user.pref_sms / pref_email / pref_inapp` were
  ignored. When a caller doesn't specify channels, the recipient's preferences now decide
  (falling back to in-app). An explicit channel list still wins, for system-critical mail.
- `GlobalExceptionHandler` turned `AccessDeniedException` into a 500 and never logged the
  cause of generic 500s. Both fixed, plus a `FeignException` handler returning 502.

---

## Verify

```bash
cd hlms-microservices && mvn clean install          # previously failed on duplicate coordinates
# start eureka-server, then user-service, loan-service, document-service,
# legal-service, repayment-service, then notification-service

TOKEN=$(curl -s -X POST http://localhost:8081/api/users/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"<user>","password":"<pass>"}' | jq -r .token)

curl -s http://localhost:8083/api/application-context/<APP_ID> -H "Authorization: Bearer $TOKEN" | jq
curl -s -X POST http://localhost:8083/api/notifications -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"userEmail":"<user>","title":"Test","body":"Hello"}' | jq
```

The first call is the one to watch: `unavailable` should come back `[]`. Whatever is listed
there is the service that still isn't answering — check it's registered in Eureka and that
the JWT secret in its `application.properties` matches user-service's.
