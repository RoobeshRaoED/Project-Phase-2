package com.hlms2.legal.serviceimpl;

import com.hlms2.legal.dto.LegalNoticeDTO;
import com.hlms2.legal.entity.LegalNotice;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.exception.ValidationException;
import com.hlms2.legal.exception.Validators;
import com.hlms2.legal.repository.AppUserRepository;
import com.hlms2.legal.repository.LegalNoticeRepository;
import com.hlms2.legal.client.LoanServiceClient;
import com.hlms2.legal.notify.NotificationPublisher;
import com.hlms2.legal.service.LegalNoticeService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Ported from hlms2.serviceimpl.LegalNoticeServiceImpl (plain JDBC
 * version), then updated for hlms_schema_updated_v2.sql: delete is now a
 * soft delete (sets deleted_at), with a matching restore(). PK unchanged
 * (notice_id remains the natural key).
 *
 * Business rules unchanged: auto-generates noticeId/noticeNo, dueDate
 * must be on/after issueDate, status restricted to
 * DRAFT/SENT/DELIVERED/FAILED, officer + content required.
 */
@Service
@Transactional
public class LegalNoticeServiceImpl implements LegalNoticeService {

    private static final List<String> VALID_TYPES = List.of("DEFAULT_NOTICE", "DEMAND_NOTICE", "AUCTION_NOTICE", "LEGAL_NOTICE");
    private static final List<String> VALID_STATUSES = List.of("DRAFT", "SENT", "DELIVERED", "FAILED", "ACTIVE");

    private static final Logger log = LoggerFactory.getLogger(LegalNoticeServiceImpl.class);

    private final LegalNoticeRepository repository;
    private final AppUserRepository appUserRepository;
    @org.springframework.beans.factory.annotation.Autowired
    private NotificationPublisher notifications;

    @org.springframework.beans.factory.annotation.Autowired
    private LoanServiceClient loanServiceClient;

    public LegalNoticeServiceImpl(LegalNoticeRepository repository, AppUserRepository appUserRepository) {
        this.repository = repository;
        this.appUserRepository = appUserRepository;
    }

    @Override
    public LegalNoticeDTO create(LegalNoticeDTO dto) {
        validate(dto);
        LegalNotice entity = toEntity(dto);
        if (entity.getNoticeId() == null || entity.getNoticeId().isBlank()) {
            entity.setNoticeId("NOT-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        // Unique, trackable notice number generated automatically.
        entity.setNoticeNo("NOTICE-" + entity.getIssueDate() + "-" + entity.getNoticeId().substring(entity.getNoticeId().length() - 4));
        entity.setStatus(entity.getStatus() == null ? "DRAFT" : entity.getStatus());
        LegalNotice saved = repository.save(entity);
        announceNotice(saved);
        return toDto(saved);
    }

    /**
     * Warns the borrower that a legal notice has been issued against their loan, and
     * keeps the bank informed.
     *
     * Only ISSUED notices are announced - a DRAFT is the officer's working copy and
     * telling a borrower about it would be both alarming and wrong.
     */
    private void announceNotice(LegalNotice notice) {
        if (notice.getStatus() == null || !"ISSUED".equalsIgnoreCase(notice.getStatus())) {
            return;
        }

        String applicantEmail = null;
        try {
            Map<String, Object> app = loanServiceClient.getLoanApplication(notice.getAppId());
            if (app != null && app.get("userEmail") != null) {
                applicantEmail = String.valueOf(app.get("userEmail"));
            }
        } catch (Exception ex) {
            log.warn("Could not resolve borrower for notice {}: {}", notice.getNoticeId(), ex.toString());
        }

        String type = notice.getNoticeType() == null ? "Legal" : notice.getNoticeType();

        notifications.toUser(
                applicantEmail,
                type + " notice issued",
                "A " + type + " notice (" + notice.getNoticeNo() + ") has been issued on your loan"
                        + (notice.getDueDate() == null ? "" : ", with a response due by " + notice.getDueDate())
                        + ". Please contact the branch immediately.");

        notifications.toRole(
                "BANK_OFFICER",
                type + " notice issued",
                "Notice " + notice.getNoticeNo() + " has been issued on application "
                        + notice.getAppId() + ".");
    }

    @Override
    public LegalNoticeDTO update(LegalNoticeDTO dto) {
        Validators.required(dto.getNoticeId(), "noticeId");
        LegalNotice existing = repository.findByNoticeIdAndDeletedAtIsNull(dto.getNoticeId())
                .orElseThrow(() -> new ResourceNotFoundException("Notice " + dto.getNoticeId() + " does not exist."));
        validate(dto);
        LegalNotice entity = toEntity(dto);
        entity.setNoticeNo(dto.getNoticeNo() != null ? dto.getNoticeNo() : existing.getNoticeNo());
        return toDto(repository.save(entity));
    }

    @Override
    public boolean softDelete(String noticeId) {
        return repository.findByNoticeIdAndDeletedAtIsNull(noticeId)
                .map(entity -> {
                    entity.setDeletedAt(OffsetDateTime.now());
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    public boolean restore(String noticeId) {
        return repository.findById(noticeId)
                .filter(entity -> entity.getDeletedAt() != null)
                .map(entity -> {
                    entity.setDeletedAt(null);
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    @Transactional(readOnly = true)
    public LegalNoticeDTO findById(String noticeId) {
        Validators.required(noticeId, "noticeId");
        return repository.findByNoticeIdAndDeletedAtIsNull(noticeId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<LegalNoticeDTO> findAll() {
        return repository.findByDeletedAtIsNull().stream().map(this::toDto).toList();
    }

    private void validate(LegalNoticeDTO dto) {
        Validators.required(dto.getAppId(), "appId");
        Validators.oneOf(dto.getNoticeType(), "noticeType", VALID_TYPES.toArray(new String[0]));
        Validators.required(dto.getIssueDate(), "issueDate");
        Validators.afterOrEqual(dto.getDueDate(), dto.getIssueDate(), "dueDate", "issueDate");
        if (dto.getStatus() != null) {
            Validators.oneOf(dto.getStatus(), "status", VALID_STATUSES.toArray(new String[0]));
        }
        Validators.required(dto.getOfficerEmail(), "officerEmail");
        if (appUserRepository.findByEmailAndActiveTrueAndDeletedAtIsNull(dto.getOfficerEmail()).isEmpty()) {
            throw new ValidationException("officerEmail " + dto.getOfficerEmail() + " is not a known active app_user.");
        }
        Validators.required(dto.getContent(), "content");
    }

    private LegalNotice toEntity(LegalNoticeDTO dto) {
        return LegalNotice.builder()
                .noticeId(dto.getNoticeId())
                .noticeNo(dto.getNoticeNo())
                .appId(dto.getAppId())
                .noticeType(dto.getNoticeType())
                .issueDate(dto.getIssueDate())
                .dueDate(dto.getDueDate())
                .status(dto.getStatus())
                .officerEmail(dto.getOfficerEmail())
                .content(dto.getContent())
                .build();
    }

    private LegalNoticeDTO toDto(LegalNotice entity) {
        return LegalNoticeDTO.builder()
                .noticeId(entity.getNoticeId())
                .noticeNo(entity.getNoticeNo())
                .appId(entity.getAppId())
                .noticeType(entity.getNoticeType())
                .issueDate(entity.getIssueDate())
                .dueDate(entity.getDueDate())
                .status(entity.getStatus())
                .officerEmail(entity.getOfficerEmail())
                .content(entity.getContent())
                .build();
    }
}
