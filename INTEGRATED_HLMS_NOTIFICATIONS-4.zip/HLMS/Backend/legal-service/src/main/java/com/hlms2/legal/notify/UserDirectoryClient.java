package com.hlms2.legal.notify;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Map;

/**
 * Resolves "everyone with role X" to a list of user records, so a notification can be
 * addressed to a whole role (all bank officers, all admins) rather than one person.
 *
 * user-service secures this endpoint with JWT, so {@link NotificationHeadersConfig}
 * forwards the caller's Authorization header. Outside an HTTP request there is no token
 * to forward, and {@link NotificationPublisher} skips role fan-out rather than failing.
 */
@FeignClient(
        name = "user-service",
        contextId = "notificationUserDirectoryClient",
        configuration = NotificationHeadersConfig.class)
public interface UserDirectoryClient {

    @GetMapping("/api/users")
    List<Map<String, Object>> byRole(@RequestParam("role") String role);
}
