package com.hlms2.legal.serviceimpl;

import com.hlms2.legal.dto.BankOfficeDecisionDTO;
import com.hlms2.legal.entity.BankOfficeDecision;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.exception.ValidationException;
import com.hlms2.legal.exception.Validators;
import com.hlms2.legal.repository.AppUserRepository;
import com.hlms2.legal.repository.BankOfficeDecisionRepository;
import com.hlms2.legal.client.LoanServiceClient;
import com.hlms2.legal.notify.NotificationPublisher;
import com.hlms2.legal.service.BankOfficeDecisionService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Ported from hlms2.serviceimpl.BankOfficeDecisionServiceImpl (plain JDBC
 * version), then updated for hlms_schema_updated_v2.sql:
 *
 * - decision_id is now the surrogate PK; app_id is a unique lookup column.
 * - the "decision" column was renamed to "status" in the schema - the DTO
 *   and entity field are renamed to match.
 * - delete is now a soft delete (sets deleted_at), with a matching restore().
 *
 * Business rule unchanged (US-EL-05): reason is required unless status is
 * APPROVED.
 */
@Service
@Transactional
public class BankOfficeDecisionServiceImpl implements BankOfficeDecisionService {

    private static final List<String> VALID_STATUSES = List.of("APPROVED", "CONDITIONALLY_APPROVED", "REJECTED", "PENDING");

    private static final Logger log = LoggerFactory.getLogger(BankOfficeDecisionServiceImpl.class);

    private final BankOfficeDecisionRepository repository;
    private final AppUserRepository appUserRepository;
    private final NotificationPublisher notifications;
    private final LoanServiceClient loanServiceClient;

    public BankOfficeDecisionServiceImpl(BankOfficeDecisionRepository repository,
                                         AppUserRepository appUserRepository,
                                         NotificationPublisher notifications,
                                         LoanServiceClient loanServiceClient) {
        this.repository = repository;
        this.appUserRepository = appUserRepository;
        this.notifications = notifications;
        this.loanServiceClient = loanServiceClient;
    }

    /**
     * Tells the customer the outcome of the bank's final decision - the single message
     * they have been waiting for through the whole process.
     *
     * The applicant's email lives in loan-service, so it is fetched over Feign. Best
     * effort throughout: recording a decision must never fail because a notification
     * could not be delivered.
     */
    private void announceDecision(BankOfficeDecision decision) {
        String status = decision.getStatus() == null ? "PENDING" : decision.getStatus().toUpperCase();

        // PENDING is a placeholder, not an outcome - saying nothing is correct here.
        if ("PENDING".equals(status)) {
            return;
        }

        String applicantEmail = null;
        String trackingNo = decision.getAppId();
        try {
            Map<String, Object> app = loanServiceClient.getLoanApplication(decision.getAppId());
            if (app != null) {
                Object email = app.get("userEmail");
                Object tracking = app.get("trackingNo");
                if (email != null) applicantEmail = String.valueOf(email);
                if (tracking != null) trackingNo = String.valueOf(tracking);
            }
        } catch (Exception ex) {
            log.warn("Could not resolve applicant for decision on {}: {}", decision.getAppId(), ex.toString());
        }

        String title;
        String body;
        switch (status) {
            case "APPROVED" -> {
                title = "Loan approved";
                body = "Good news - your loan application " + trackingNo
                        + " has been APPROVED. Disbursement will follow shortly.";
            }
            case "CONDITIONALLY_APPROVED" -> {
                title = "Loan conditionally approved";
                body = "Your loan application " + trackingNo + " has been approved subject to "
                        + "conditions. " + reasonSuffix(decision);
            }
            case "REJECTED" -> {
                title = "Loan application rejected";
                body = "We are sorry - your loan application " + trackingNo
                        + " has been rejected. " + reasonSuffix(decision);
            }
            default -> {
                title = "Loan decision recorded";
                body = "A decision of \"" + status.toLowerCase().replace('_', ' ')
                        + "\" has been recorded on your application " + trackingNo + ".";
            }
        }

        notifications.toUser(applicantEmail, title, body);

        notifications.toUser(
                decision.getOfficerEmail(),
                "Your decision was saved",
                "You recorded \"" + status.toLowerCase().replace('_', ' ')
                        + "\" on application " + trackingNo + ".");
    }

    private String reasonSuffix(BankOfficeDecision decision) {
        String reason = decision.getReason();
        if (reason == null || reason.isBlank()) {
            return "Please contact the branch for details.";
        }
        return "Reason: " + reason;
    }

    @Override
    public BankOfficeDecisionDTO create(BankOfficeDecisionDTO dto) {
        Validators.required(dto.getAppId(), "appId");
        if (repository.findByAppIdAndDeletedAtIsNull(dto.getAppId()).isPresent()) {
            throw new ValidationException("A bank office decision already exists for application " + dto.getAppId() + ".");
        }
        validate(dto);
        BankOfficeDecision entity = toEntity(dto);
        entity.setDecisionId(null);
        entity.setDecisionDate(entity.getDecisionDate() == null ? OffsetDateTime.now() : entity.getDecisionDate());
        BankOfficeDecision saved = repository.save(entity);
        announceDecision(saved);
        return toDto(saved);
    }

    @Override
    public BankOfficeDecisionDTO update(Long decisionId, BankOfficeDecisionDTO dto) {
        BankOfficeDecision existing = repository.findByDecisionIdAndDeletedAtIsNull(decisionId)
                .orElseThrow(() -> new ResourceNotFoundException("No bank office decision found with id " + decisionId + "."));
        dto.setAppId(dto.getAppId() != null ? dto.getAppId() : existing.getAppId());
        validate(dto);

        /*
         * A final decision is not a draft. create() already refuses a second decision on
         * an application, but update() let anyone flip a saved APPROVED to REJECTED with
         * no trace - and, because a status change re-notifies, the customer would receive
         * "Loan approved" followed by "Loan application rejected".
         *
         * PENDING is the one status that is genuinely provisional, so moving off it is
         * allowed. Changing one settled outcome into another is not; that needs a fresh
         * decision with its own audit trail, not an edit in place.
         */
        String previousStatus = existing.getStatus() == null ? "PENDING" : existing.getStatus().toUpperCase();
        String incomingStatus = dto.getStatus() == null ? "PENDING" : dto.getStatus().toUpperCase();

        if (!"PENDING".equals(previousStatus) && !previousStatus.equals(incomingStatus)) {
            throw new ValidationException(
                    "Application " + existing.getAppId() + " has already been " + previousStatus.toLowerCase()
                            + " and that decision cannot be changed here. Raise a fresh review if it needs revisiting.");
        }

        BankOfficeDecision entity = toEntity(dto);
        entity.setDecisionId(decisionId);
        entity.setDecisionDate(entity.getDecisionDate() == null ? OffsetDateTime.now() : entity.getDecisionDate());
        BankOfficeDecision saved = repository.save(entity);

        // A decision that was revised - e.g. PENDING then APPROVED - still needs telling.
        if (!String.valueOf(existing.getStatus()).equalsIgnoreCase(String.valueOf(saved.getStatus()))) {
            announceDecision(saved);
        }
        return toDto(saved);
    }

    @Override
    public boolean softDelete(Long decisionId) {
        return repository.findByDecisionIdAndDeletedAtIsNull(decisionId)
                .map(entity -> {
                    entity.setDeletedAt(OffsetDateTime.now());
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    public boolean restore(Long decisionId) {
        return repository.findById(decisionId)
                .filter(entity -> entity.getDeletedAt() != null)
                .map(entity -> {
                    entity.setDeletedAt(null);
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    @Transactional(readOnly = true)
    public BankOfficeDecisionDTO findById(Long decisionId) {
        return repository.findByDecisionIdAndDeletedAtIsNull(decisionId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public BankOfficeDecisionDTO findByAppId(String appId) {
        Validators.required(appId, "appId");
        return repository.findByAppIdAndDeletedAtIsNull(appId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<BankOfficeDecisionDTO> findAll() {
        return repository.findByDeletedAtIsNull().stream().map(this::toDto).toList();
    }

    private void validate(BankOfficeDecisionDTO dto) {
        Validators.oneOf(dto.getStatus(), "status", VALID_STATUSES.toArray(new String[0]));
        Validators.required(dto.getOfficerEmail(), "officerEmail");
        if (appUserRepository.findByEmailAndActiveTrueAndDeletedAtIsNull(dto.getOfficerEmail()).isEmpty()) {
            throw new ValidationException("officerEmail " + dto.getOfficerEmail() + " is not a known active app_user.");
        }
        // US-EL-05: rejection or conditional approval must always be explained to the customer.
        if (!"APPROVED".equalsIgnoreCase(dto.getStatus())) {
            Validators.required(dto.getReason(), "reason");
        }
    }

    private BankOfficeDecision toEntity(BankOfficeDecisionDTO dto) {
        return BankOfficeDecision.builder()
                .decisionId(dto.getDecisionId())
                .appId(dto.getAppId())
                .status(dto.getStatus())
                .officerEmail(dto.getOfficerEmail())
                .decisionDate(dto.getDecisionDate())
                .reason(dto.getReason())
                .remarks(dto.getRemarks())
                .build();
    }

    private BankOfficeDecisionDTO toDto(BankOfficeDecision entity) {
        return BankOfficeDecisionDTO.builder()
                .decisionId(entity.getDecisionId())
                .appId(entity.getAppId())
                .status(entity.getStatus())
                .officerEmail(entity.getOfficerEmail())
                .decisionDate(entity.getDecisionDate())
                .reason(entity.getReason())
                .remarks(entity.getRemarks())
                .build();
    }
}
