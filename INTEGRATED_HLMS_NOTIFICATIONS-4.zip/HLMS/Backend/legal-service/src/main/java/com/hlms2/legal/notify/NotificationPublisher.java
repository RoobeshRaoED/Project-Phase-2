package com.hlms2.legal.notify;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Raises notifications for business events in this service.
 *
 * Every method here is best-effort and NEVER throws: a notification is a side effect of
 * the real work, so a notification-service outage must not roll back a loan submission or
 * fail a bid. Failures are logged and swallowed deliberately.
 *
 * Call these AFTER the state change has been persisted, so a user is never told about
 * something that then fails to save.
 */
@Component
public class NotificationPublisher {

    private static final Logger log = LoggerFactory.getLogger(NotificationPublisher.class);

    private final NotificationClient notificationClient;
    private final UserDirectoryClient userDirectoryClient;

    public NotificationPublisher(NotificationClient notificationClient,
                                 UserDirectoryClient userDirectoryClient) {
        this.notificationClient = notificationClient;
        this.userDirectoryClient = userDirectoryClient;
    }

    /** Notifies one person by email. No-op when the email is missing. */
    public void toUser(String userEmail, String title, String body) {
        if (userEmail == null || userEmail.isBlank() || title == null || title.isBlank()) {
            return;
        }
        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("userEmail", userEmail);
            payload.put("title", title);
            payload.put("body", body);
            notificationClient.send(payload);
        } catch (Exception ex) {
            log.warn("Notification to {} failed ({}) - continuing", userEmail, ex.toString());
        }
    }

    /**
     * Notifies everyone holding a role - e.g. every BANK_OFFICER when an application
     * lands for review. Needs the caller's JWT to read the user directory, so it is a
     * no-op in flows with no HTTP request context (scheduled jobs).
     */
    public void toRole(String role, String title, String body) {
        if (role == null || role.isBlank()) {
            return;
        }
        List<Map<String, Object>> users;
        try {
            users = userDirectoryClient.byRole(role);
        } catch (Exception ex) {
            log.warn("Could not resolve role {} for notification ({}) - skipping", role, ex.toString());
            return;
        }
        if (users == null) {
            return;
        }
        for (Map<String, Object> user : users) {
            Object email = user.get("email");
            Object active = user.get("active");
            // Skip deactivated staff - they should not keep receiving work items.
            if (email != null && !Boolean.FALSE.equals(active)) {
                toUser(String.valueOf(email), title, body);
            }
        }
    }
}
