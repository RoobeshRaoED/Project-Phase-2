# Testing loan approval, rejection and the other scenarios — click by click

This walks the real screens, in the order the application actually moves.

---

# Something I fixed while writing this

While tracing the screens I found the **frontend was already sending some notifications
itself** — four of them now duplicated the backend ones I added, so the customer would
have received two copies of each:

| Screen | Was sending | Now |
|---|---|---|
| Bank office → reject | "Application Rejected" | removed — legal-service raises it |
| Bank office → disburse | "Loan Amount Disbursed" | removed — loan-service raises it |
| Legal → decide | 3 verification messages | removed — legal-service raises them |
| Legal → issue notice | notice message | removed — legal-service raises it |

The backend version is the one to keep: it fires however the action was performed — this
screen, Swagger, or a future caller — and it also tells the *teams*, which the frontend
versions never did.

Four other frontend sends have **no** backend equivalent and were left alone: document
verified/rejected, NPA escalation, and legal recovery-proceedings updates.

The frontend still builds clean after these removals.

---

# Setup — 4 browser windows

You need to be signed in as several roles at once to watch hand-offs land live.

| Window | Role | Sign in as |
|---|---|---|
| 1 | Customer | `customer@hlms.com` |
| 2 | Bank Officer | `officer@hlms.com` |
| 3 | Legal | `legal@hlms.com` |
| 4 | Admin | your admin account |

Use one normal window plus three incognito windows (**Ctrl+Shift+N**), or separate browser
profiles. Same browser, same profile = you keep logging each other out.

**Creating the staff accounts:** public `/register` only offers Customer and Bidder. Sign
in as admin → **Employee Management** / **Legal Management** / **Bank Office Management**
→ add each one there.

**Login:** email + password → OTP screen. The code is printed on the page
("Your OTP is 123456 — demo display only"). Type that.

**Remember:** the bell polls every **30 seconds**. Clicking the bell forces a refresh.

---

# Step 1 — Customer submits (scenario 1)

**Window 1 — Customer**

1. Sidebar → **Apply for Loan**
2. Fill the form: product, amount, tenure, applicant name, PAN, address, employment,
   property details, account number
3. Click through to the end and **Submit**

**Check straight away:**

| Where | Expect |
|---|---|
| Window 1 bell | "Application submitted" |
| Window 2 bell (officer) | **"New application to review"** |

Write down the **tracking number** — it appears in every message from here on.

---

# Step 2 — Documents, and the hand-off to Legal (scenario 3) ⭐

Here is the thing that surprises people: **the bank officer cannot advance past document
verification.** Only the Legal team can.

**Window 2 — Bank Officer**

4. Sidebar → **Applications** → click the new application
5. You will see an orange banner:
   *"⏳ Awaiting Legal Team document verification — only the Legal & Valuation Team can
   verify documents and forward this stage"*
6. The **Move to Next Stage** button is hidden while that banner shows. This is correct,
   not a bug.

**Window 3 — Legal**

7. Sidebar → **Queue** → open the application
8. Verify each document with the **Verify** button
9. Once all are verified, **Forward to Legal Verification** appears — click it

**Check:**

| Where | Expect |
|---|---|
| Window 3 bell (legal) | **"New case for legal verification"** with the tracking number |
| Window 1 bell (customer) | status move |

That is your "bank officer allows it to move to the legal team" scenario. The trigger is
the Legal team forwarding the case, because that is who the screen gives the button to.

---

# Step 3 — Legal decides, officer is told (scenario 5) ⭐

**Window 3 — Legal**

10. Still on the case, work through the legal checklist
11. Add remarks → **Save Remarks**
12. Click **Approve** (the other options are **Query Raised** and **Reject**)

**Check:**

| Where | Expect |
|---|---|
| Window 2 (officer) | **"Legal verification complete — decision needed"** |
| Window 2 (officer) | also "Legal verification approved" |
| Window 1 (customer) | "Legal verification approved" |
| Window 3 (legal) | "Legal decision recorded" — their own confirmation |

Two officer messages is intentional: one says the *stage* arrived, one says what legal
*decided*.

---

# Step 4a — APPROVE, and the customer hears (scenario 6) ⭐

**Window 2 — Bank Officer**

13. Reopen the application. The orange banner is gone and **Move to Next Stage** is back
14. Click **Move to Next Stage** — it advances to Disbursement

**Check:**

| Where | Expect |
|---|---|
| Window 1 (customer) | "Application \<status\>" |
| Window 2 (officer) | **"Approved — ready to disburse"** |

**A note on the wording.** The current UI approves by advancing the stage, not by writing
an `APPROVED` decision row. The dedicated *"Loan approved — Good news…"* message fires
when a decision row with status `APPROVED` is saved. To see that exact message today, use
Swagger at `http://localhost:8084/swagger-ui.html`:

```
POST /api/bank-office/decisions
{ "appId": "<appId>", "status": "APPROVED", "officerEmail": "officer@hlms.com" }
```

The customer immediately gets **"Loan approved"**. If you want the officer's
**Move to Next Stage** button to write that row too, say so — it is a small change and it
would make approval and rejection symmetrical, which they currently are not.

---

# Step 4b — REJECT (scenario 6b) ⭐

Use a **second** application for this, so you can still disburse the first.

**Window 2 — Bank Officer**

15. Open the second application → **Reject Application**
16. Choose a **rejection reason** from the dropdown (required)
17. Type **remarks** — these go to the customer, so write something real (also required)
18. Click **Confirm Rejection**

**Check:**

| Where | Expect |
|---|---|
| Window 1 (customer) | **"Loan application rejected"** — "We are sorry… Reason: \<your reason\>" |
| Window 2 (officer) | "Decision recorded" |

**One copy, not two** — that is the duplicate fix above.

---

# Step 5 — Disbursement (scenario 8) ⭐

Back to the approved application.

**Window 2 — Bank Officer**

19. Sidebar → **Disbursement**
20. Find the application in "Ready to Disburse"
21. Enter amount, reference number, mode, bank details → **Disburse**

**Check:**

| Where | Expect |
|---|---|
| Window 1 (customer) | **"Loan disbursed"** — "Your loan has been disbursed. Reference: … Your repayment schedule is now active." |

---

# Step 6 — Service request reaches the bank (scenario 15) ⭐

**Window 1 — Customer**

22. Sidebar → **Support**
23. Request type e.g. `Statement`, add a description → **Submit Request**

**Check:**

| Where | Expect |
|---|---|
| Window 1 | "Service request raised" with the reference |
| Window 2 (officer) | **"New service request: Statement"** with your email, the application and the description |

24. Officer changes the request's status → customer is told.

---

# Step 7 — Bidder (scenarios 12, 13, 14)

Needs two bidder accounts. Register both at `/register` (Account Type = **Bidder**).

**Window 3 — Legal** (or officer)

25. Sidebar → **Auction**
26. Set an auction case's stage to **"Auction Scheduled"**, with a date and reserve price

**Window 4 — sign out of admin, sign in as `bidder1@hlms.com`**

27. Bell → **"New auction listed"** with date and reserve price
28. **Auction Listings** → open it → place a bid
29. Bell → "Bid placed"

**A fifth window — `bidder2@hlms.com`**

30. Place a **higher** bid on the same auction

**Check:**

| Where | Expect |
|---|---|
| bidder1 | **"You have been outbid"** ← the one bidders act on |
| Officer | "New auction bid" (for both) |

---

# Step 8 — EMI (scenarios 9, 10)

The disbursed loan now has a schedule.

31. Officer → **Portfolio** or **NPA** → mark an installment **PAID**
    → customer: "EMI payment received"
32. An installment past its due date becomes **OVERDUE**
    → customer *and* officer both told

---

# Full checklist

| # | Do this | Watch this bell |
|---|---|---|
| 1 | Customer submits | customer + officer |
| 2 | Legal forwards from documents | **legal** |
| 3 | Legal approves | **officer** ×2, customer, legal |
| 4 | Officer moves to next stage | officer, customer |
| 5 | POST an APPROVED decision | **customer: "Loan approved"** |
| 6 | Officer rejects with reason | **customer: "Loan application rejected"** |
| 7 | Officer disburses | **customer: "Loan disbursed"** |
| 8 | Customer raises support request | **officer** |
| 9 | Auction → "Auction Scheduled" | **bidders** |
| 10 | Second bidder outbids | **first bidder** |
| 11 | EMI paid / overdue | customer (+ officer if overdue) |
| 12 | Register anyone | **admin** |

---

# If something doesn't arrive

| Symptom | Cause |
|---|---|
| Nothing at all, any role | Not all 8 services running — events come from loan/legal/repayment/user, not notification-service |
| One role silent | No account with that role exists, so role fan-out finds nobody |
| Officer's "Move to Next Stage" missing | Correct — the case is with Legal. Read the orange banner |
| No "Loan approved" message | Advancing the stage is not the same as saving an `APPROVED` decision — see Step 4a |
| Toast never shows | First poll after sign-in is deliberately silent; trigger a *new* event with the tab open |
| Two copies of a message | Shouldn't happen now — if it does, tell me which screen |

Every publisher logs and continues on failure, so **check the service terminals**, not just
the UI. A missing notification never fails the underlying action.

---

# Two things still open

**Approve is not symmetrical with reject.** Rejection writes a decision row; approval
advances the stage. That is pre-existing UI behaviour, not something I changed — but it
means the "Loan approved" message only fires via the API today. One small change makes
them match, if you want it.

**`GET /api/notifications?userEmail=…` still doesn't check the caller.** Anyone signed in
can read anyone's notifications by editing the URL. That matters more now that these
messages carry rejection reasons and remarks. Worth closing before any demo.
