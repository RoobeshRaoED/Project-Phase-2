# Environment files

- `environment.ts`             — dev (used by default)
- `environment.prod.ts`        — production (swapped in by angular.json fileReplacements)
- `environment.development.ts` — re-export of `environment.ts`; the customer module's
                                 original project imported this filename
- `environment.production.ts`  — re-export of `environment.prod.ts`; the admin module's
                                 original project imported this filename

The two re-export files exist purely so no service from those projects had to
have its import path edited.
