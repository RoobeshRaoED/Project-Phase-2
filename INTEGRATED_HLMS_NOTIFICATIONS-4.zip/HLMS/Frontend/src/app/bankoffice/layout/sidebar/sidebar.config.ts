export interface NavItem {
  view: string;      // route segment under /app/
  icon: string;
  label: string;
}

/** This build only serves the Bank Office role, so there's a single nav set. */
export const BANK_OFFICE_NAV_ITEMS: NavItem[] = [
  { view: 'bodash', icon: '▦', label: 'Dashboard' },
  { view: 'boapplications', icon: '▤', label: 'Loan Applications' },
  { view: 'boportfolio', icon: '👥', label: 'Customer Portfolio' },
  { view: 'bodisbursement', icon: '💳', label: 'Disbursement Queue' },
  { view: 'bonpa', icon: '⚠', label: 'Overdue & NPA Tracking' },
  { view: 'bodocs', icon: '▯', label: 'Document Verification' },
  { view: 'boservicerequests', icon: '🛠', label: 'Service Requests' },
  { view: 'boauction', icon: '☆', label: 'Auction Management' },
  { view: 'boreports', icon: '📊', label: 'Reports & Analytics' },
  { view: 'bosettings', icon: '⚙', label: 'Settings' }
];
