// Standard reducing-balance EMI formula. Loan-service stores amount, rate and
// tenure on LoanApplication but does not persist a computed EMI value, so the
// Bank Office UI derives it client-side for display purposes only.
export function calculateEmi(principal?: number, annualRatePct?: number, tenureYears?: number): number {
  if (!principal || !tenureYears) return 0;
  const months = tenureYears * 12;
  if (!annualRatePct) return Math.round(principal / months);
  const r = annualRatePct / 12 / 100;
  const emi = (principal * r * Math.pow(1 + r, months)) / (Math.pow(1 + r, months) - 1);
  return Math.round(emi);
}
