export interface Notification {
  notificationId?: number;
  userEmail: string;
  title: string;
  body: string;
  read: boolean;
  createdAt?: string;
}

export interface ServiceRequest {
  requestId?: string;
  refNo?: string;
  appId?: string;
  userEmail: string;
  requestType: string;
  description: string;
  status?: string;
  createdAt?: string;
}
