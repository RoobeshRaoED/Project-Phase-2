import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, of } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { LegalVerification, LegalChecklistItem, LegalNotice, BankOfficeDecision } from '../models/legal.model';

@Injectable({ providedIn: 'root' })
export class LegalService {
  private readonly verifications = `${environment.apiBaseUrl}/legal-service/api/legal/verifications`;
  private readonly checklist = `${environment.apiBaseUrl}/legal-service/api/legal/checklist-items`;
  private readonly notices = `${environment.apiBaseUrl}/legal-service/api/legal-notices`;
  private readonly decisions = `${environment.apiBaseUrl}/legal-service/api/bank-office/decisions`;

  constructor(private http: HttpClient) {}

  // ---- Verifications ----
  // LegalVerificationController's "/by-application/{appId}" returns a single
  // object (app_id is unique on legal_verification), not an array - and 404s
  // if none exists yet, which we treat as "no verification yet" (null).
  getVerificationForApp(appId: string): Observable<LegalVerification | null> {
    return this.http.get<LegalVerification>(`${this.verifications}/by-application/${appId}`).pipe(
      catchError(() => of(null))
    );
  }

  getAllVerifications(): Observable<LegalVerification[]> {
    return this.http.get<LegalVerification[]>(this.verifications);
  }

  createVerification(payload: Partial<LegalVerification>): Observable<LegalVerification> {
    return this.http.post<LegalVerification>(this.verifications, payload);
  }

  updateVerification(id: number, payload: Partial<LegalVerification>): Observable<LegalVerification> {
    return this.http.put<LegalVerification>(`${this.verifications}/${id}`, payload);
  }

  deleteVerification(id: number): Observable<void> {
    return this.http.delete<void>(`${this.verifications}/${id}`);
  }

  // ---- Checklist items ----
  getChecklistItems(): Observable<LegalChecklistItem[]> {
    return this.http.get<LegalChecklistItem[]>(this.checklist);
  }

  createChecklistItem(payload: Partial<LegalChecklistItem>): Observable<LegalChecklistItem> {
    return this.http.post<LegalChecklistItem>(this.checklist, payload);
  }

  updateChecklistItem(id: string, payload: Partial<LegalChecklistItem>): Observable<LegalChecklistItem> {
    return this.http.put<LegalChecklistItem>(`${this.checklist}/${id}`, payload);
  }

  // ---- Legal notices ----
  getNotices(): Observable<LegalNotice[]> {
    return this.http.get<LegalNotice[]>(this.notices);
  }

  createNotice(payload: Partial<LegalNotice>): Observable<LegalNotice> {
    return this.http.post<LegalNotice>(this.notices, payload);
  }

  updateNotice(id: string, payload: Partial<LegalNotice>): Observable<LegalNotice> {
    return this.http.put<LegalNotice>(`${this.notices}/${id}`, payload);
  }

  // ---- Bank office decisions ----
  // BankOfficeDecisionController's "/by-application/{appId}" returns a single
  // object (app_id is unique on bank_office_decision) and 404s if the app
  // hasn't had a decision recorded yet - treated as null here.
  getDecisionForApp(appId: string): Observable<BankOfficeDecision | null> {
    return this.http.get<BankOfficeDecision>(`${this.decisions}/by-application/${appId}`).pipe(
      catchError(() => of(null))
    );
  }

  getAllDecisions(): Observable<BankOfficeDecision[]> {
    return this.http.get<BankOfficeDecision[]>(this.decisions);
  }

  createDecision(payload: Partial<BankOfficeDecision>): Observable<BankOfficeDecision> {
    return this.http.post<BankOfficeDecision>(this.decisions, payload);
  }

  updateDecision(decisionId: number, payload: Partial<BankOfficeDecision>): Observable<BankOfficeDecision> {
    return this.http.put<BankOfficeDecision>(`${this.decisions}/${decisionId}`, payload);
  }

  // Convenience: bank_office_decision has one row per application (app_id is
  // unique), so recording a decision is an upsert - create if none exists
  // yet for this app, otherwise update the existing row.
  recordDecision(appId: string, payload: Partial<BankOfficeDecision>): Observable<BankOfficeDecision> {
    return new Observable((subscriber) => {
      this.getDecisionForApp(appId).subscribe((existing) => {
        const req = existing?.decisionId
          ? this.updateDecision(existing.decisionId, { ...payload, appId })
          : this.createDecision({ ...payload, appId });
        req.subscribe({
          next: (v) => { subscriber.next(v); subscriber.complete(); },
          error: (e) => subscriber.error(e)
        });
      });
    });
  }
}
