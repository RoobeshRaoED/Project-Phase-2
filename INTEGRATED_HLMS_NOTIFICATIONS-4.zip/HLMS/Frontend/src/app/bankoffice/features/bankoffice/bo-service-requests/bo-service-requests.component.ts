import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { NotificationService } from '../../../core/services/notification.service';
import { ToastService } from '../../../core/services/toast.service';
import { ServiceRequest } from '../../../core/models/notification.model';

/**
 * Bank office queue for post-disbursement service requests (Feature 9).
 *
 * Officers were already notified when a customer raised a request, but there was no
 * screen anywhere in the app to act on one - the notification led nowhere and the
 * request sat in the database. This is that screen.
 *
 * Every action here writes back through PATCH /api/service-requests/{id}/status, which
 * raises the customer's notification, so the customer always learns the outcome.
 */
@Component({
  selector: 'app-bo-service-requests',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="page">
      <h1>Service Requests</h1>
      <p class="sub">
        Post-disbursement requests raised by customers. Acting on a request notifies the
        customer straight away.
      </p>

      <div class="filters">
        <button
          type="button"
          class="chip"
          [class.active]="filter() === 'OPEN'"
          (click)="filter.set('OPEN')">
          Open ({{ openCount() }})
        </button>
        <button
          type="button"
          class="chip"
          [class.active]="filter() === 'ALL'"
          (click)="filter.set('ALL')">
          All ({{ requests().length }})
        </button>
        <button type="button" class="chip ghost" (click)="load()">Refresh</button>
      </div>

      @if (loading()) {
        <div class="empty">Loading requests…</div>
      } @else if (!visible().length) {
        <div class="empty">
          {{ filter() === 'OPEN' ? 'No open service requests. ' : 'No service requests yet. ' }}
        </div>
      } @else {
        <div class="card">
          @for (r of visible(); track r.requestId) {
            <div class="row">
              <div class="row-main">
                <div class="row-top">
                  <span class="type">{{ r.requestType }}</span>
                  <span class="status" [class]="statusClass(r.status)">{{ r.status }}</span>
                </div>
                <div class="meta">
                  {{ r.refNo }} · {{ r.userEmail }}
                  @if (r.appId) { · {{ r.appId }} }
                  @if (r.createdAt) { · {{ r.createdAt | date: 'medium' }} }
                </div>
                @if (r.description) {
                  <div class="desc">{{ r.description }}</div>
                }
              </div>

              @if (isOpen(r)) {
                <div class="row-actions">
                  @if (activeId() !== r.requestId) {
                    @if (!isInProgress(r)) {
                      <button
                        type="button"
                        class="btn"
                        [disabled]="busyId() === r.requestId"
                        (click)="act(r, 'In Progress')">
                        Accept
                      </button>
                    } @else {
                      <button
                        type="button"
                        class="btn"
                        [disabled]="busyId() === r.requestId"
                        (click)="act(r, 'Completed')">
                        Mark completed
                      </button>
                    }
                    <button type="button" class="btn danger" (click)="openDecline(r)">
                      Decline
                    </button>
                  } @else {
                    <!-- Declining without a reason is not much use to the customer,
                         so the note is required on this path only. -->
                    <div class="decline">
                      <label>Reason for declining</label>
                      <textarea
                        rows="2"
                        [(ngModel)]="note"
                        placeholder="This is sent to the customer"></textarea>
                      <div class="decline-actions">
                        <button
                          type="button"
                          class="btn danger"
                          [disabled]="!note.trim() || busyId() === r.requestId"
                          (click)="act(r, 'Rejected', note)">
                          Confirm decline
                        </button>
                        <button type="button" class="btn ghost" (click)="cancelDecline()">
                          Cancel
                        </button>
                      </div>
                    </div>
                  }
                </div>
              }
            </div>
          }
        </div>
      }
    </section>
  `,
  styles: [
    `
      .page { padding: 22px 26px; }
      h1 { margin: 0 0 4px; font-size: 22px; }
      .sub { margin: 0 0 18px; color: #6b7280; font-size: 13.5px; }

      .filters { display: flex; gap: 8px; margin-bottom: 14px; flex-wrap: wrap; }
      .chip {
        border: 1px solid rgba(0,0,0,.12);
        background: #fff;
        border-radius: 999px;
        padding: 6px 14px;
        font-size: 13px;
        cursor: pointer;
      }
      .chip.active { background: #0f766e; border-color: #0f766e; color: #fff; }
      .chip.ghost { color: #0f766e; }

      .card {
        background: #fff;
        border: 1px solid rgba(0,0,0,.09);
        border-radius: 12px;
        overflow: hidden;
      }
      .row {
        display: flex;
        gap: 16px;
        align-items: flex-start;
        justify-content: space-between;
        padding: 14px 16px;
        border-bottom: 1px solid rgba(0,0,0,.06);
      }
      .row:last-child { border-bottom: none; }
      .row-main { min-width: 0; flex: 1; }
      .row-top { display: flex; align-items: center; gap: 10px; }
      .type { font-weight: 600; font-size: 14.5px; }
      .meta { font-size: 12px; color: #9ca3af; margin-top: 3px; }
      .desc { font-size: 13px; color: #4b5563; margin-top: 6px; }

      .status {
        font-size: 11px;
        font-weight: 600;
        border-radius: 999px;
        padding: 2px 9px;
        text-transform: uppercase;
        letter-spacing: .02em;
      }
      .s-requested { background: #fef3c7; color: #92400e; }
      .s-progress { background: #dbeafe; color: #1e40af; }
      .s-done { background: #d1fae5; color: #065f46; }
      .s-rejected { background: #fee2e2; color: #991b1b; }

      .row-actions { display: flex; gap: 8px; align-items: flex-start; }
      .btn {
        border: 1px solid #0f766e;
        background: #0f766e;
        color: #fff;
        border-radius: 8px;
        padding: 7px 14px;
        font-size: 13px;
        cursor: pointer;
        white-space: nowrap;
      }
      .btn:disabled { opacity: .55; cursor: not-allowed; }
      .btn.danger { background: #b91c1c; border-color: #b91c1c; }
      .btn.ghost { background: none; color: #6b7280; border-color: rgba(0,0,0,.15); }

      .decline { width: 300px; }
      .decline label { display: block; font-size: 12px; color: #6b7280; margin-bottom: 4px; }
      .decline textarea {
        width: 100%;
        border: 1px solid rgba(0,0,0,.15);
        border-radius: 8px;
        padding: 7px 9px;
        font: inherit;
        font-size: 13px;
        resize: vertical;
      }
      .decline-actions { display: flex; gap: 8px; margin-top: 8px; }

      .empty {
        background: #fff;
        border: 1px solid rgba(0,0,0,.09);
        border-radius: 12px;
        padding: 40px;
        text-align: center;
        color: #6b7280;
        font-size: 14px;
      }
    `
  ]
})
export class BoServiceRequestsComponent implements OnInit {
  private notifications = inject(NotificationService);
  private toast = inject(ToastService);

  requests = signal<ServiceRequest[]>([]);
  loading = signal(true);
  filter = signal<'OPEN' | 'ALL'>('OPEN');

  /** The request whose decline form is open, if any. */
  activeId = signal<string | null>(null);
  /** The request currently being written, so its buttons can be disabled. */
  busyId = signal<string | null>(null);
  note = '';

  private static readonly CLOSED = ['completed', 'resolved', 'closed', 'rejected', 'declined'];

  visible = computed(() =>
    this.filter() === 'ALL' ? this.requests() : this.requests().filter((r) => this.isOpen(r))
  );

  openCount = computed(() => this.requests().filter((r) => this.isOpen(r)).length);

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.notifications.getAllRequests().subscribe({
      next: (list) => {
        this.requests.set(list || []);
        this.loading.set(false);
      },
      error: (err) => {
        this.loading.set(false);
        this.requests.set([]);
        this.toast.show('Could not load service requests', this.describeError(err), 'error');
      }
    });
  }

  isOpen(r: ServiceRequest): boolean {
    const s = (r.status || '').toLowerCase();
    return !BoServiceRequestsComponent.CLOSED.includes(s);
  }

  isInProgress(r: ServiceRequest): boolean {
    return (r.status || '').toLowerCase().replace('_', ' ') === 'in progress';
  }

  statusClass(status?: string): string {
    const s = (status || '').toLowerCase().replace('_', ' ');
    if (s === 'in progress') return 's-progress';
    if (['completed', 'resolved', 'closed'].includes(s)) return 's-done';
    if (['rejected', 'declined'].includes(s)) return 's-rejected';
    return 's-requested';
  }

  openDecline(r: ServiceRequest): void {
    this.activeId.set(r.requestId ?? null);
    this.note = '';
  }

  cancelDecline(): void {
    this.activeId.set(null);
    this.note = '';
  }

  act(r: ServiceRequest, status: string, note?: string): void {
    if (!r.requestId) return;

    this.busyId.set(r.requestId);
    this.notifications.updateRequestStatus(r.requestId, status, note).subscribe({
      next: (updated) => {
        this.busyId.set(null);
        this.activeId.set(null);
        this.note = '';
        // Patch the row in place so the list does not jump while the officer works.
        this.requests.update((list) =>
          list.map((x) => (x.requestId === r.requestId ? { ...x, ...updated } : x))
        );
        this.toast.show(
          'Request updated',
          `${r.requestType} is now "${status}". The customer has been notified.`,
          'success'
        );
      },
      error: (err) => {
        this.busyId.set(null);
        this.toast.show('Could not update request', this.describeError(err), 'error');
      }
    });
  }

  /** Pulls the most useful message out of an HttpErrorResponse. */
  private describeError(err: any): string {
    const body = err?.error;
    if (typeof body === 'string' && body.trim()) return body;
    if (body?.message) return body.message;
    if (body?.error) return body.error;
    if (err?.status === 0) {
      return 'Could not reach the notification service. Check that it is running.';
    }
    if (err?.status) return `The server returned ${err.status}. Please try again.`;
    return 'An unexpected error occurred. Please try again.';
  }
}
