import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { BidderSidebarComponent } from '../sidebar/sidebar.component';
import { BidderTopbarComponent } from '../topbar/topbar.component';

/** Same shell structure the Bank Office portal uses, so the global
 *  topbar/sidebar/main CSS in styles.css applies unchanged. */
@Component({
  selector: 'app-bidder-shell',
  standalone: true,
  imports: [RouterOutlet, BidderSidebarComponent, BidderTopbarComponent],
  template: `
    <div id="app">
      <app-bidder-topbar (toggleSidebar)="sidebarOpen = !sidebarOpen"></app-bidder-topbar>
      <app-bidder-sidebar [class.open]="sidebarOpen"></app-bidder-sidebar>
      <div class="main">
        <router-outlet></router-outlet>
      </div>
      <footer class="app-footer">HLMS Bidder Portal — connected to HLMS microservices backend.</footer>
    </div>
  `
})
export class BidderShellComponent {
  sidebarOpen = false;
}
