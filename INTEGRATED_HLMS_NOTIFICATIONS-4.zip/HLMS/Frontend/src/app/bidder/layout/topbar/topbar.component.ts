import { Component, EventEmitter, Output, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { BidderAuthService } from '../../core/services/auth.service';
import { NotificationBellComponent } from '../../../core/notifications/notification-bell.component';
import { NotificationToastComponent } from '../../../core/notifications/notification-toast.component';

@Component({
  selector: 'app-bidder-topbar',
  standalone: true,
  imports: [CommonModule, NotificationBellComponent, NotificationToastComponent],
  template: `
    <div class="topbar">
      <button class="hamburger" (click)="toggleSidebar.emit()">☰</button>
      <div class="brand">
        <div class="logo"><img src="assets/images/favicon.png" width="40px" style="border-radius:2px;" /></div>
        <div>
          <div class="title">HLMS</div>
          <div class="subtitle">Housing Loan Management System</div>
        </div>
      </div>
      <div class="topbar-search"></div>
      <div class="topbar-right">
        <app-notification-bell [userEmail]="auth.email()" />
        <div class="user-chip" (click)="goSettings()">
          <div class="user-avatar">{{ initials() }}</div>
          <div class="user-name">{{ auth.currentUser()?.name || 'Bidder' }}</div>
        </div>
      </div>
    </div>

    <app-notification-toast />
  `
})
export class BidderTopbarComponent {
  @Output() toggleSidebar = new EventEmitter<void>();

  auth = inject(BidderAuthService);
  private router = inject(Router);

  initials(): string {
    const name = this.auth.currentUser()?.name || 'Bidder';
    return name.split(' ').map((p) => p[0]).join('').slice(0, 2).toUpperCase();
  }

  goSettings(): void {
    this.router.navigate(['/bidder', 'biddersettings']);
  }
}
