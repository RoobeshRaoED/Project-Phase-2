import { Routes } from '@angular/router';
import { bidderAuthGuard } from './core/guards/auth.guard';
import { bidderRoleGuard } from './core/guards/role.guard';

/**
 * Bidder Portal, mounted at /bidder.
 *
 * Route segment names are the same view keys the Updated-UI prototype used
 * (bidderdash / bidderlistings / bidderlistingdetail / bidderbids /
 * biddersettings), and the guard layout matches the Bank Office portal.
 *
 * There are deliberately NO login / register / forgot-password routes here:
 * a bidder signs in through the one shared /login page, and SessionService
 * lands them on /bidder/bidderdash.
 */
export const BIDDER_ROUTES: Routes = [
  {
    path: '',
    canActivate: [bidderAuthGuard],
    loadComponent: () => import('./layout/shell/shell.component').then((m) => m.BidderShellComponent),
    children: [
      {
        path: 'bidderdash',
        canActivate: [bidderRoleGuard],
        data: { roles: ['BIDDER'] },
        loadComponent: () =>
          import('./features/bidder/bidder-dashboard/bidder-dashboard.component').then(
            (m) => m.BidderDashboardComponent
          )
      },
      {
        path: 'bidderlistings',
        canActivate: [bidderRoleGuard],
        data: { roles: ['BIDDER'] },
        loadComponent: () =>
          import('./features/bidder/bidder-listings/bidder-listings.component').then(
            (m) => m.BidderListingsComponent
          )
      },
      {
        path: 'bidderlistingdetail/:appId',
        canActivate: [bidderRoleGuard],
        data: { roles: ['BIDDER'] },
        loadComponent: () =>
          import('./features/bidder/bidder-listing-detail/bidder-listing-detail.component').then(
            (m) => m.BidderListingDetailComponent
          )
      },
      {
        path: 'bidderbids',
        canActivate: [bidderRoleGuard],
        data: { roles: ['BIDDER'] },
        loadComponent: () =>
          import('./features/bidder/bidder-bids/bidder-bids.component').then(
            (m) => m.BidderBidsComponent
          )
      },
      {
        path: 'biddersettings',
        canActivate: [bidderRoleGuard],
        data: { roles: ['BIDDER'] },
        loadComponent: () =>
          import('./features/bidder/bidder-settings/bidder-settings.component').then(
            (m) => m.BidderSettingsComponent
          )
      },
      { path: '', pathMatch: 'full', redirectTo: 'bidderdash' }
    ]
  }
];
