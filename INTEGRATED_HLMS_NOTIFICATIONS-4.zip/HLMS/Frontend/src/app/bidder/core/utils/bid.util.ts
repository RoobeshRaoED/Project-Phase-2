import { AuctionCase, Bid } from '../models/auction.model';

/**
 * Client-side mirror of repayment-service's BidServiceImpl.validate().
 *
 * The backend rules (US-AM-02..04) are:
 *   1. the auction case must exist and not be soft-deleted,
 *   2. bidAmount >= auction_case.reserve_price,
 *   3. bidAmount > the current highest undeleted bid for that app_id.
 *
 * These helpers reproduce 2 and 3 so the user gets instant feedback, but the
 * server stays the source of truth -- a bid that passes here is still sent
 * and the backend's ValidationException message is surfaced if it disagrees
 * (e.g. someone else out-bid us between page load and submit).
 */

/** Start of today, for comparing against a "yyyy-MM-dd" LocalDate. */
function startOfToday(): number {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
}

function auctionDayMs(auction: AuctionCase): number | null {
  if (!auction.auctionDate) return null;
  const parts = auction.auctionDate.slice(0, 10).split('-').map(Number);
  if (parts.length !== 3 || parts.some(isNaN)) return null;
  return new Date(parts[0], parts[1] - 1, parts[2]).getTime();
}

/** Open while the auction date has not passed; an auction dated today is still open. */
export function isAuctionOpen(auction: AuctionCase): boolean {
  const day = auctionDayMs(auction);
  return day !== null && day >= startOfToday();
}

/** Whole days remaining; 0 means "closing today". */
export function daysLeft(auction: AuctionCase): number {
  const day = auctionDayMs(auction);
  if (day === null) return 0;
  return Math.max(0, Math.round((day - startOfToday()) / 86400000));
}

/** Highest bid for a set of bids on one auction, or null when there are none. */
export function highestBid(bids: Bid[]): Bid | null {
  if (!bids.length) return null;
  return bids.reduce((top, b) => (b.bidAmount > top.bidAmount ? b : top), bids[0]);
}

/** Sorted highest-first, then oldest-first among equal amounts. */
export function sortBids(bids: Bid[]): Bid[] {
  return bids.slice().sort(
    (a, b) =>
      b.bidAmount - a.bidAmount ||
      new Date(a.createdAt || 0).getTime() - new Date(b.createdAt || 0).getTime()
  );
}

/**
 * The lowest amount the BACKEND will actually accept. Used for validation.
 * With no bids yet the reserve price itself is acceptable (>=); once there is
 * a highest bid the new one must strictly exceed it.
 */
export function minimumAcceptableBid(auction: AuctionCase, highest: Bid | null): number {
  const reserve = auction.reservePrice ?? 0;
  if (!highest) return reserve;
  return Math.max(reserve, highest.bidAmount + 1);
}

/**
 * A friendlier amount to pre-fill / suggest: the reserve price, or the
 * current highest plus a round increment. Purely cosmetic -- the Updated-UI
 * prototype enforced this step as a hard minimum, but the backend does not,
 * so enforcing it here would reject bids the server would happily accept.
 */
export function suggestedBid(auction: AuctionCase, highest: Bid | null): number {
  const reserve = auction.reservePrice ?? 0;
  if (!highest) return reserve;
  const step = Math.max(5000, Math.round((reserve * 0.01) / 1000) * 1000);
  return highest.bidAmount + step;
}

/**
 * Borrower and bidder identities are withheld from the public listing per
 * bank policy, so other bidders' emails are shown masked. Your own bids are
 * labelled "You".
 */
export function bidderDisplayName(bid: Bid, currentEmail: string | null): string {
  if (currentEmail && bid.bidderEmail?.toLowerCase() === currentEmail.toLowerCase()) return 'You';
  const local = (bid.bidderEmail || '').split('@')[0] || 'Bidder';
  const parts = local.split(/[._-]+/).filter(Boolean);
  const first = (parts[0] || 'b')[0].toUpperCase();
  const last = parts.length > 1 ? ' ' + parts[parts.length - 1][0].toUpperCase() + '.' : '';
  return `${first}***${last}`;
}
