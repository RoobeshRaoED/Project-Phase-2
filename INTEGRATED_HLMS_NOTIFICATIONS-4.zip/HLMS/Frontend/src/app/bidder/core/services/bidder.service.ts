import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, forkJoin, map, of, shareReplay } from 'rxjs';

import { environment } from '../../../../environments/environment';
import {
  AuctionCase,
  AuctionListing,
  AuctionNote,
  Bid,
  ListingProperty
} from '../models/auction.model';

/**
 * Every Bidder Portal read/write goes through here:
 *
 *   component -> BidderService -> HttpClient -> API gateway
 *             -> AuctionCaseController / BidController (repayment-service)
 *             -> AuctionCaseServiceImpl / BidServiceImpl -> repository -> DB
 *
 * No endpoint was added to the backend for this portal -- all of the routes
 * below already existed. See BIDDER_PORTAL_README.md for the full inventory
 * and for the gaps that had to be worked around on the client.
 */
@Injectable({ providedIn: 'root' })
export class BidderService {
  private http = inject(HttpClient);

  private readonly auctions = `${environment.apiBaseUrl}${environment.services.repayment}/api/auctions`;
  private readonly bids = `${environment.apiBaseUrl}${environment.services.repayment}/api/bids`;
  private readonly applications = `${environment.apiBaseUrl}${environment.services.loan}/api/loan-applications`;

  /** Stage that means "live on the Bidder Portal" (set by Legal / Bank Office). */
  static readonly LISTED_STAGE = 'Auction Scheduled';

  // ---- Auction cases ----

  getAuctions(): Observable<AuctionCase[]> {
    return this.http.get<AuctionCase[]>(this.auctions);
  }

  /** AuctionCaseController returns a single object here -- app_id is unique. */
  getAuctionForApp(appId: string): Observable<AuctionCase> {
    return this.http.get<AuctionCase>(`${this.auctions}/by-application/${encodeURIComponent(appId)}`);
  }

  // ---- Bids ----

  getBidsForApp(appId: string): Observable<Bid[]> {
    return this.http.get<Bid[]>(`${this.auctions}/${encodeURIComponent(appId)}/bids`);
  }

  /**
   * POST /api/auctions/{appId}/bids. The controller sets dto.appId from the
   * path itself, but it is sent in the body too so the payload matches BidDTO
   * exactly. bidId and createdAt are server-generated and must not be sent.
   */
  placeBid(appId: string, bidderEmail: string, bidAmount: number): Observable<Bid> {
    const body: Bid = { appId, bidderEmail, bidAmount };
    return this.http.post<Bid>(`${this.auctions}/${encodeURIComponent(appId)}/bids`, body);
  }

  /**
   * BidController's GET /api/bids returns every undeleted bid -- it has no
   * bidder filter, so the narrowing happens here. Fine at demo scale; a
   * "?bidderEmail=" query param is the right server-side fix and is listed in
   * the README.
   */
  getMyBids(bidderEmail: string): Observable<Bid[]> {
    const wanted = bidderEmail.toLowerCase();
    return this.http.get<Bid[]>(this.bids).pipe(
      map((all) => (all || []).filter((b) => (b.bidderEmail || '').toLowerCase() === wanted)),
      map((mine) =>
        mine.sort(
          (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
        )
      )
    );
  }

  // ---- Auction notes (public case notes shown on the listing detail) ----

  getNotes(appId: string): Observable<AuctionNote[]> {
    return this.http.get<AuctionNote[]>(`${this.auctions}/${encodeURIComponent(appId)}/notes`);
  }

  // ---- Property enrichment ----

  /**
   * appId -> property facts, fetched once per session.
   *
   * GET /api/loan-applications/{appId} is @RequireAppOwner and a BIDDER is not
   * privileged there, so it 403s. /all is unannotated and is used instead,
   * with only the listing-safe fields carried across (see ListingProperty).
   * A failure degrades to an empty map so listings still render from the
   * auction case alone rather than showing an error page.
   */
  private propertyMap$?: Observable<Record<string, ListingProperty>>;
  getPropertyMap(): Observable<Record<string, ListingProperty>> {
    if (!this.propertyMap$) {
      this.propertyMap$ = this.http.get<Record<string, unknown>[]>(`${this.applications}/all`).pipe(
        map((apps) =>
          Object.fromEntries(
            (apps || [])
              .filter((a) => a['appId'] != null)
              .map((a) => {
                const appId = String(a['appId']);
                const property: ListingProperty = {
                  appId,
                  trackingNo: a['trackingNo'] as string | undefined,
                  address: a['propertyAddress'] as string | undefined,
                  type: a['propertyType'] as string | undefined,
                  value: a['propertyValue'] as number | undefined
                };
                return [appId, property];
              })
          )
        ),
        catchError(() => of({} as Record<string, ListingProperty>)),
        shareReplay(1)
      );
    }
    return this.propertyMap$;
  }

  // ---- Composed views ----

  /**
   * Every case the bank has posted for e-auction, newest auction date last,
   * with its property joined in. Cases still at Notice Issued / Possession /
   * Resolved are not listings and are filtered out.
   */
  getListings(): Observable<AuctionListing[]> {
    return forkJoin({
      auctions: this.getAuctions(),
      properties: this.getPropertyMap()
    }).pipe(
      map(({ auctions, properties }) =>
        (auctions || [])
          .filter((a) => a.stage === BidderService.LISTED_STAGE)
          .map((auction) => ({
            auction,
            property: properties[auction.appId] ?? { appId: auction.appId }
          }))
          .sort(
            (x, y) =>
              new Date(x.auction.auctionDate || 0).getTime() -
              new Date(y.auction.auctionDate || 0).getTime()
          )
      )
    );
  }

  /** One listing plus its bids and notes, for the detail page. */
  getListingDetail(appId: string): Observable<{
    listing: AuctionListing;
    bids: Bid[];
    notes: AuctionNote[];
  }> {
    return forkJoin({
      auction: this.getAuctionForApp(appId),
      properties: this.getPropertyMap(),
      bids: this.getBidsForApp(appId).pipe(catchError(() => of([] as Bid[]))),
      notes: this.getNotes(appId).pipe(catchError(() => of([] as AuctionNote[])))
    }).pipe(
      map(({ auction, properties, bids, notes }) => ({
        listing: {
          auction,
          property: properties[auction.appId] ?? { appId: auction.appId }
        },
        bids,
        notes
      }))
    );
  }
}
