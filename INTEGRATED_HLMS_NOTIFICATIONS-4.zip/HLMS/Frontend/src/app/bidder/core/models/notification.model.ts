/** Mirrors notification-service's Notification entity (isRead() -> "read"). */
export interface BidderNotification {
  notificationId?: string;
  userEmail: string;
  title: string;
  body: string;
  channels?: string[];
  read?: boolean;
  createdAt?: string;
}
