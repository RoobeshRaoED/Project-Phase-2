import { Routes } from '@angular/router';
import { AUTH_ROUTES } from './auth/auth.routes';

/**
 * Top-level router for the integrated HLMS application.
 *
 *   /            Home        (auth module)
 *   /login       Login       (auth module -- single sign-on for every role)
 *   /register    Register    (auth module)
 *   /customer/*  Customer portal
 *   /admin/*     Admin console
 *   /bidder/*    Bidder portal (e-auction listings and bidding)
 *   /officer/*   Bank Office portal
 *   /legal/*     Legal & Valuation Team portal
 *
 * Each portal is lazy-loaded behind its own wrapper component, which is the
 * original app root from that project (router-outlet + that module's toast
 * host), so per-module toasts keep working exactly as before.
 */
export const routes: Routes = [
  ...AUTH_ROUTES,
  {
    path: 'customer',
    loadComponent: () => import('./customer/customer-root').then((m) => m.App),
    loadChildren: () => import('./customer/customer.routes').then((m) => m.CUSTOMER_ROUTES),
    title: 'HLMS | Customer Portal'
  },
  {
    path: 'admin',
    loadComponent: () => import('./admin/admin-root').then((m) => m.App),
    loadChildren: () => import('./admin/admin.routes').then((m) => m.ADMIN_ROUTES),
    title: 'HLMS | Admin Console'
  },
  {
    path: 'officer',
    loadComponent: () => import('./bankoffice/bankoffice-root.component').then((m) => m.AppComponent),
    loadChildren: () => import('./bankoffice/bankoffice.routes').then((m) => m.BANKOFFICE_ROUTES),
    title: 'HLMS | Bank Office Portal'
  },
  {
    path: 'bidder',
    loadComponent: () => import('./bidder/bidder-root.component').then((m) => m.AppComponent),
    loadChildren: () => import('./bidder/bidder.routes').then((m) => m.BIDDER_ROUTES),
    title: 'HLMS | Bidder Portal'
  },
  {
    path: 'legal',
    loadComponent: () => import('./legal/legal-root.component').then((m) => m.AppComponent),
    loadChildren: () => import('./legal/legal.routes').then((m) => m.LEGAL_ROUTES),
    title: 'HLMS | Legal & Valuation Portal'
  },
  { path: '**', redirectTo: '' }
];
