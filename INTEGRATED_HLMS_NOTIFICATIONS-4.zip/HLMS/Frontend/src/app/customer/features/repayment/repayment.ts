import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';

import { AuthService } from '../../core/services/auth.service';
import { LoanService } from '../../core/services/loan.service';
import { RepaymentService } from '../../core/services/repayment.service';
import { ToastService } from '../../core/services/toast.service';

import {
  Disbursement,
  EmiInstallment,
  InsurancePolicy,
  LoanApplication
} from '../../core/models/models';

@Component({
  selector: 'app-repayment',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page-head">
      <h1>Repayment</h1>
      <p>View your EMI schedule, disbursement details and insurance policy status.</p>
    </div>

    @if (!appId()) {
      <div class="card">
        @if (listLoading()) {
          <div class="page-loading">
            <span class="spinner dark"></span> Loading your applications…
          </div>
        } @else if (eligibleApps().length === 0) {
          <div class="empty-state">
            <p>No disbursed loans found yet. Repayment details appear here once your loan is disbursed.</p>
          </div>
        } @else {
          <p class="muted">Select an application to view its repayment schedule.</p>

          <table>
            <thead>
              <tr>
                <th>App ID</th>
                <th>Product</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>

            <tbody>
              @for (a of eligibleApps(); track a.appId) {
                <tr class="clickable-row" [routerLink]="['/customer/repayment', a.appId]">
                  <td>{{ a.trackingNo || a.appId }}</td>
                  <td>{{ a.productId }}</td>
                  <td>
                    <span class="badge badge-green">{{ a.status }}</span>
                  </td>
                  <td>
                    <span class="btn-link">View →</span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        }
      </div>
    } @else {
      <button class="back-link" routerLink="/customer/repayment">
        ← All Applications
      </button>

      @if (errorMsg()) {
        <div class="inline-error">{{ errorMsg() }}</div>
      }

      @if (disbursement(); as d) {
        <div class="card">
          <h3>💰 Disbursement</h3>

          <div class="grid grid-4">
            <div class="stat">
              <span class="lbl">Amount</span>
              <span class="val teal">₹{{ d.amount | number: '1.0-0' }}</span>
            </div>

            <div class="stat">
              <span class="lbl">Date</span>
              <span class="val">{{ d.disbursedDate | date }}</span>
            </div>

            <div class="stat">
              <span class="lbl">Reference No.</span>
              <span class="val">{{ d.refNo }}</span>
            </div>

            <div class="stat">
              <span class="lbl">Mode</span>
              <span class="val">{{ d.mode }}</span>
            </div>
          </div>
        </div>
      }

      <div class="card">
        <h3>📅 EMI Schedule</h3>

        @if (scheduleLoading()) {
          <div class="page-loading">
            <span class="spinner dark"></span> Loading schedule…
          </div>
        } @else if (schedule().length === 0) {
          <div class="empty-state">
            <p>No EMI schedule found for this application yet.</p>
          </div>
        } @else {
          <div class="muted" style="margin-bottom:12px;">
            Showing {{ pageStart() }} - {{ pageEnd() }} of {{ schedule().length }} installments.
            Next payable EMI:
            @if (nextPayableInstallmentNo()) {
              #{{ nextPayableInstallmentNo() }}
            } @else {
              All EMIs paid
            }
          </div>

          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>Due Date</th>
                <th>EMI</th>
                <th>Principal</th>
                <th>Interest</th>
                <th>Balance</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>
              @for (i of pagedSchedule(); track i.installmentId || i.installmentNo) {
                <tr>
                  <td>{{ i.installmentNo }}</td>
                  <td>{{ i.dueDate | date }}</td>
                  <td>₹{{ i.emiAmount | number: '1.0-0' }}</td>
                  <td>₹{{ i.principalComponent | number: '1.0-0' }}</td>
                  <td>₹{{ i.interestComponent | number: '1.0-0' }}</td>
                  <td>₹{{ i.closingBalance | number: '1.0-0' }}</td>

                  <td>
                    <span
                      class="badge"
                      [class.badge-green]="i.status === 'Paid'"
                      [class.badge-red]="i.status === 'Overdue'"
                      [class.badge-orange]="i.status !== 'Paid' && i.status !== 'Overdue'">
                      {{ i.status || 'Pending' }}
                    </span>
                  </td>

                  <td>
                    @if (i.status === 'Paid') {
                      <button class="btn btn-outline btn-sm" disabled>
                        Paid
                      </button>
                    } @else if (canPay(i)) {
                      <button
                        class="btn btn-teal btn-sm"
                        (click)="pay(i)"
                        [disabled]="paying() === i.installmentId">
                        @if (paying() === i.installmentId) {
                          <span class="spinner"></span>
                        } @else {
                          Pay Now
                        }
                      </button>
                    } @else {
                      <button class="btn btn-outline btn-sm" disabled>
                        Pay Previous EMI First
                      </button>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>

          <div
            style="display:flex;align-items:center;justify-content:space-between;margin-top:16px;gap:12px;flex-wrap:wrap;">

            <div class="muted">
              Page {{ currentPage() }} of {{ totalPages() }}
            </div>

            <div style="display:flex;align-items:center;gap:8px;">
              <button
                type="button"
                class="btn btn-outline btn-sm"
                (click)="prevPage()"
                [disabled]="currentPage() === 1">
                Previous
              </button>

              <button
                type="button"
                class="btn btn-outline btn-sm"
                (click)="nextPage()"
                [disabled]="currentPage() === totalPages()">
                Next
              </button>
            </div>
          </div>
        }
      </div>

      @if (insurancePolicies().length > 0) {
        <div class="card">
          <h3>🛡 Insurance Policies</h3>

          <table>
            <thead>
              <tr>
                <th>Policy ID</th>
                <th>Type</th>
                <th>Status</th>
                <th>Valid Till</th>
              </tr>
            </thead>

            <tbody>
              @for (p of insurancePolicies(); track p.policyId) {
                <tr>
                  <td>{{ p.policyId }}</td>
                  <td>{{ p.policyType }}</td>
                  <td>
                    <span class="policy-status">{{ p.status }}</span>
                  </td>
                  <td>{{ p.validTill | date }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      }
    }
  `
})
export class Repayment {
  private auth = inject(AuthService);
  private loanSvc = inject(LoanService);
  private repaySvc = inject(RepaymentService);
  private toast = inject(ToastService);
  private route = inject(ActivatedRoute);

  appId = signal<string | null>(null);

  listLoading = signal(true);
  eligibleApps = signal<LoanApplication[]>([]);

  errorMsg = signal('');
  scheduleLoading = signal(true);
  schedule = signal<EmiInstallment[]>([]);

  currentPage = signal(1);
  pageSize = 10;

  disbursement = signal<Disbursement | null>(null);
  insurancePolicies = signal<InsurancePolicy[]>([]);
  paying = signal<string | null>(null);

  constructor() {
    const routeAppId = this.route.snapshot.paramMap.get('appId');

    if (routeAppId) {
      this.appId.set(routeAppId);
      this.loadDetail(routeAppId);
      this.listLoading.set(false);
      return;
    }

    const email = this.auth.currentUser()?.email;

    if (!email) {
      this.listLoading.set(false);
      return;
    }

    this.loanSvc.listForUser(email).subscribe({
      next: (list) => {
        this.eligibleApps.set(
          (list || []).filter((a) => a.status === 'Active' || a.status === 'Disbursed')
        );

        this.listLoading.set(false);
      },
      error: () => {
        this.listLoading.set(false);
      }
    });
  }

  private loadDetail(appId: string): void {
    this.errorMsg.set('');
    this.scheduleLoading.set(true);
    this.schedule.set([]);
    this.currentPage.set(1);

    this.loadDisbursement(appId);
    this.loadSchedule(appId);
    this.loadInsurance(appId);
  }

  private loadDisbursement(appId: string): void {
    this.repaySvc.disbursementByApp(appId).subscribe({
      next: (d) => {
        this.disbursement.set(d);
      },
      error: () => {
        this.disbursement.set(null);
      }
    });
  }

  private loadSchedule(appId: string): void {
    this.repaySvc.schedule(appId).subscribe({
      next: (s) => {
        const sorted = (s || []).sort(
          (a, b) => (a.installmentNo || 0) - (b.installmentNo || 0)
        );

        this.schedule.set(sorted);
        this.currentPage.set(1);
        this.scheduleLoading.set(false);
      },
      error: () => {
        this.schedule.set([]);
        this.currentPage.set(1);
        this.scheduleLoading.set(false);
      }
    });
  }

  private loadInsurance(appId: string): void {
    this.repaySvc.allInsurancePolicies().subscribe({
      next: (all) => {
        this.insurancePolicies.set((all || []).filter((p) => p.appId === appId));
      },
      error: () => {
        this.insurancePolicies.set([]);
      }
    });
  }

  totalPages(): number {
    return Math.max(1, Math.ceil(this.schedule().length / this.pageSize));
  }

  pagedSchedule(): EmiInstallment[] {
    const start = (this.currentPage() - 1) * this.pageSize;
    const end = start + this.pageSize;

    return this.schedule().slice(start, end);
  }

  pageStart(): number {
    if (this.schedule().length === 0) {
      return 0;
    }

    return (this.currentPage() - 1) * this.pageSize + 1;
  }

  pageEnd(): number {
    return Math.min(this.currentPage() * this.pageSize, this.schedule().length);
  }

  prevPage(): void {
    this.currentPage.update((page) => Math.max(1, page - 1));
  }

  nextPage(): void {
    this.currentPage.update((page) => Math.min(this.totalPages(), page + 1));
  }

  nextPayableInstallmentNo(): number | null {
    const next = this.schedule()
      .filter((i) => i.status !== 'Paid')
      .sort((a, b) => (a.installmentNo || 0) - (b.installmentNo || 0))[0];

    return next?.installmentNo ?? null;
  }

  canPay(installment: EmiInstallment): boolean {
    if (installment.status === 'Paid') {
      return false;
    }

    const nextNo = this.nextPayableInstallmentNo();

    if (!nextNo) {
      return false;
    }

    return installment.installmentNo === nextNo;
  }

  pay(installment: EmiInstallment): void {
    if (!installment.installmentId) {
      return;
    }

    if (!this.canPay(installment)) {
      this.toast.error(
        'Payment blocked',
        'Please pay previous EMI installments first.'
      );
      return;
    }

    this.paying.set(installment.installmentId);

    this.repaySvc.markInstallmentPaid(installment).subscribe({
      next: (updated) => {
        const normalizedUpdated: EmiInstallment = {
          ...installment,
          ...updated,
          status: 'Paid',
          paidDate: updated.paidDate || new Date().toISOString().slice(0, 10)
        };

        this.schedule.update((list) =>
          list.map((i) =>
            i.installmentId === normalizedUpdated.installmentId
              ? normalizedUpdated
              : i
          )
        );

        this.paying.set(null);

        this.toast.success(
          'EMI paid',
          `Installment #${installment.installmentNo} marked as paid.`
        );
      },
      error: () => {
        this.paying.set(null);
        this.toast.error('Payment failed', 'Please try again.');
      }
    });
  }
}