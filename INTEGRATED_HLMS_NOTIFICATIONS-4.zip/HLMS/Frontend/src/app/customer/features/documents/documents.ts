import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';

import { AuthService } from '../../core/services/auth.service';
import { LoanService } from '../../core/services/loan.service';
import {
  DocumentService,
  downloadBase64File
} from '../../core/services/document.service';
import { ToastService } from '../../core/services/toast.service';

import { ApplicationDocument, LoanApplication } from '../../core/models/models';

@Component({
  selector: 'app-documents',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page-head">
      <h1>Documents</h1>
      <p>View and download the documents submitted for your housing loan application.</p>
    </div>

    @if (!appId()) {
      <div class="card">
        @if (listLoading()) {
          <div class="page-loading">
            <span class="spinner dark"></span> Loading your applications...
          </div>
        } @else if (apps().length === 0) {
          <div class="empty-state">
            <p>No submitted applications found for document viewing.</p>
            <button class="btn btn-primary btn-sm" routerLink="/customer/apply">
              Apply for a Loan
            </button>
          </div>
        } @else {
          <p class="muted">Select an application to view submitted documents.</p>

          <table>
            <thead>
              <tr>
                <th>Application</th>
                <th>Product</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>

            <tbody>
              @for (a of apps(); track a.appId) {
                <tr class="clickable-row" [routerLink]="['/customer/documents', a.appId]">
                  <td>{{ a.trackingNo || a.appId }}</td>
                  <td>{{ a.productId || 'Not selected' }}</td>
                  <td>
                    <span
                      class="badge"
                      [class.badge-green]="a.status === 'Active' || a.status === 'Disbursed'"
                      [class.badge-orange]="a.status !== 'Active' && a.status !== 'Disbursed'">
                      {{ a.status || 'Submitted' }}
                    </span>
                  </td>
                  <td>
                    <span class="btn-link">View Documents</span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        }
      </div>
    } @else {
      <button class="back-link" routerLink="/customer/documents">
        ← All Applications
      </button>

      @if (errorMsg()) {
        <div class="inline-error">{{ errorMsg() }}</div>
      }

      <div class="card">
        <h3>Submitted Documents</h3>
        <p class="muted">
          These are the documents submitted for this loan application. You can download your uploaded documents here.
        </p>

        @if (docsLoading()) {
          <div class="page-loading">
            <span class="spinner dark"></span> Loading documents...
          </div>
        } @else if (docs().length === 0) {
          <div class="empty-state">
            <p>No documents uploaded for this application.</p>
          </div>
        } @else {
          <table>
            <thead>
              <tr>
                <th>Document Type</th>
                <th>File Name</th>
                <th>Uploaded</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>

            <tbody>
              @for (d of docs(); track d.documentId || d.fileName) {
                <tr>
                  <td>{{ d.docType }}</td>
                  <td>{{ d.fileName }}</td>
                  <td>{{ d.uploadedAt ? (d.uploadedAt | date: 'medium') : '—' }}</td>
                  <td>
                    <span
                      class="badge"
                      [class.badge-green]="d.verificationStatus === 'Verified'"
                      [class.badge-red]="d.verificationStatus === 'Rejected'"
                      [class.badge-orange]="!d.verificationStatus || d.verificationStatus === 'Pending'">
                      {{ d.verificationStatus || 'Pending' }}
                    </span>
                  </td>
                  <td style="white-space: nowrap;">
                    <button class="btn btn-outline btn-sm" (click)="download(d)">
                      Download
                    </button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        }
      </div>
    }
  `
})
export class Documents {
  private auth = inject(AuthService);
  private loanSvc = inject(LoanService);
  private docSvc = inject(DocumentService);
  private toast = inject(ToastService);
  private route = inject(ActivatedRoute);

  appId = signal<string | null>(null);

  listLoading = signal(true);
  apps = signal<LoanApplication[]>([]);

  docsLoading = signal(false);
  docs = signal<ApplicationDocument[]>([]);
  errorMsg = signal('');

  constructor() {
    const routeAppId = this.route.snapshot.paramMap.get('appId');

    if (routeAppId) {
      this.appId.set(routeAppId);
      this.listLoading.set(false);
      this.verifyAndLoadDocs(routeAppId);
      return;
    }

    this.loadApplications();
  }

  private loadApplications(): void {
    const email = this.auth.currentUser()?.email;

    if (!email) {
      this.listLoading.set(false);
      this.errorMsg.set('User session not found. Please login again.');
      return;
    }

    this.loanSvc.listForUser(email).subscribe({
      next: (list) => {
        this.apps.set(
          (list || []).filter((a) => a.status !== 'Draft')
        );

        this.listLoading.set(false);
      },
      error: () => {
        this.listLoading.set(false);
        this.errorMsg.set('Could not load your applications.');
      }
    });
  }

  private verifyAndLoadDocs(appId: string): void {
    const email = this.auth.currentUser()?.email;

    if (!email) {
      this.errorMsg.set('User session not found. Please login again.');
      return;
    }

    this.docsLoading.set(true);

    this.loanSvc.getApplication(appId).subscribe({
      next: (app) => {
        if ((app.userEmail || '').toLowerCase() !== email.toLowerCase()) {
          this.docsLoading.set(false);
          this.docs.set([]);
          this.errorMsg.set('You are not allowed to view documents for this application.');
          return;
        }

        if (app.status === 'Draft') {
          this.docsLoading.set(false);
          this.docs.set([]);
          this.errorMsg.set('Documents can be viewed here only after the application is submitted.');
          return;
        }

        this.loadDocs(appId);
      },
      error: () => {
        this.docsLoading.set(false);
        this.docs.set([]);
        this.errorMsg.set('Could not verify this application.');
      }
    });
  }

  private loadDocs(appId: string): void {
    this.docsLoading.set(true);

    this.docSvc.listByApp(appId).subscribe({
      next: (list) => {
        this.docs.set(list || []);
        this.docsLoading.set(false);
      },
      error: (err) => {
        this.docs.set([]);
        this.docsLoading.set(false);

        this.errorMsg.set(
          err?.error?.message ||
            err?.error?.error ||
            err?.error ||
            err?.message ||
            'Could not load documents for this application.'
        );

        console.error('Document list failed:', err);
      }
    });
  }

  download(doc: ApplicationDocument): void {
    if (!doc.fileData) {
      this.toast.error('Download unavailable', 'File data is missing.');
      return;
    }

    const mimeType = this.mimeTypeForFile(doc.fileName || '');

    downloadBase64File(
      doc.fileData,
      doc.fileName || `${doc.docType || 'document'}.pdf`,
      mimeType
    );
  }

  private mimeTypeForFile(fileName: string): string {
    const extension = fileName.split('.').pop()?.toLowerCase();

    if (extension === 'pdf') {
      return 'application/pdf';
    }

    if (extension === 'jpg' || extension === 'jpeg') {
      return 'image/jpeg';
    }

    if (extension === 'png') {
      return 'image/png';
    }

    return 'application/octet-stream';
  }
}