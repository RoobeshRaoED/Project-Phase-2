import { Component, inject } from '@angular/core';
import { ToastService } from '../../../core/services/toast.service';

@Component({
  selector: 'app-toast-host',
  standalone: true,
  template: `
    <div class="toast-wrap">
      @for (t of toastSvc.toasts(); track t.id) {
        <div class="toast" [class.success]="t.type === 'success'" [class.error]="t.type === 'error'">
          <strong>{{ t.title }}</strong>
          @if (t.message) {
            <div>{{ t.message }}</div>
          }
        </div>
      }
    </div>
  `
})
export class ToastHost {
  toastSvc = inject(ToastService);
}
