import { Component, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { NotificationBellComponent } from '../../../../core/notifications/notification-bell.component';
import { NotificationToastComponent } from '../../../../core/notifications/notification-toast.component';

@Component({
  selector: 'app-topbar',
  standalone: true,
  imports: [RouterLink, NotificationBellComponent, NotificationToastComponent],
  template: `
    <div class="topbar">
      <button class="hamburger" (click)="sidebarOpen.set(!sidebarOpen())">☰</button>
      <a routerLink="/customer/dashboard" class="brand" style="text-decoration:none;">
        <div class="logo">
          <img src="assets/images/logo.png" width="34" style="border-radius:8px;" alt="HLMS" />
        </div>
        <div>
          <div class="title">HLMS</div>
          <div class="subtitle">Housing Loan Management System</div>
        </div>
      </a>
      <div class="topbar-search">
        <input placeholder="Search anything..." disabled title="Search coming soon" />
      </div>
      <div class="topbar-right">
        <app-notification-bell [userEmail]="auth.currentUser()?.email" />
        <a routerLink="/customer/profile" class="user-chip" style="text-decoration:none;">
          <div class="user-avatar">{{ initials() }}</div>
          <div class="user-name">{{ auth.currentUser()?.name || 'User' }}</div>
        </a>
        <button class="btn btn-outline btn-sm" (click)="logout()">Log Out</button>
      </div>
    </div>

    <app-notification-toast />
  `
})
export class Topbar {
  auth = inject(AuthService);

  sidebarOpen = signal(false);

  initials(): string {
    const name = this.auth.currentUser()?.name || 'U';
    return name
      .split(' ')
      .map((p) => p[0])
      .join('')
      .slice(0, 2)
      .toUpperCase();
  }

  logout(): void {
    this.auth.logout();
  }
}
