import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';

import { AuthService } from '../services/auth.service';
import { environment } from '../../../../environments/environment';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  const isApiCall = req.url.startsWith(environment.apiBase);
  const token = auth.token();

  const publicApiUrls = [
    '/loan-service/api/loan-products',
    '/loan-service/api/loan-products/',
    '/loan-service/api/loan-guidance/recommendations',
    '/loan-service/api/loan-guidance/emi-assistant'
  ];

  const isPublicApi = publicApiUrls.some((url) => req.url.includes(url));

  const authReq =
    isApiCall && token && !isPublicApi
      ? req.clone({
          setHeaders: {
            Authorization: `Bearer ${token}`
          }
        })
      : req;

  return next(authReq).pipe(
    catchError((err) => {
      if (isApiCall && err?.status === 401 && !isPublicApi) {
        auth.logout(false);

        router.navigate(['/login'], {
          queryParams: {
            sessionExpired: 1
          }
        });
      }

      return throwError(() => err);
    })
  );
};