import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

/**
 * Application root. Deliberately minimal: each module supplies its own wrapper
 * (with its own toast host) through the router, so nothing module-specific
 * belongs here.
 */
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  template: '<router-outlet />'
})
export class AppComponent {}
