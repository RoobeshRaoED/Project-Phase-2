import { Injectable, computed, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap, switchMap, catchError, throwError, of } from 'rxjs';

import { environment } from '../../../../environments/environment';
import { AppUser, JwtPayload, LoginRequest, LoginResponse } from '../models/user.model';
import { clearHlmsSession } from '../../../core/session/session-keys';

const TOKEN_KEY = 'hlms_admin_token';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly base = `${environment.apiBaseUrl}${environment.services.user}/api/users`;

  /** Currently signed-in user's full profile (fetched after login/refresh). */
  private readonly _currentUser = signal<AppUser | null>(null);
  readonly currentUser = this._currentUser.asReadonly();
  readonly isLoggedIn = computed(() => !!this._currentUser());

  constructor(private http: HttpClient) {}

  /** POST /user-service/api/users/login -> { token } (open endpoint, no auth header needed) */
  login(request: LoginRequest): Observable<AppUser> {
    return this.http.post<LoginResponse>(`${this.base}/login`, request).pipe(
      tap((res) => localStorage.setItem(TOKEN_KEY, res.token)),
      switchMap(() => this.loadCurrentUser()),
      catchError((err) => {
        this.clearSession();
        return throwError(() => err);
      })
    );
  }

  /** Re-hydrates the session on app start / page refresh from a stored JWT. */
  restoreSession(): Observable<AppUser | null> {
    const token = this.getToken();
    if (!token || this.isTokenExpired(token)) {
      this.clearSession();
      return of(null);
    }
    return this.loadCurrentUser().pipe(catchError(() => { this.clearSession(); return of(null); }));
  }

  /** GET /user-service/api/users/{email} for the email in the current JWT. */
  private loadCurrentUser(): Observable<AppUser> {
    const payload = this.decodeToken();
    const email = payload?.sub;
    if (!email) {
      return throwError(() => new Error('No valid session token.'));
    }
    return this.http.get<AppUser>(`${this.base}/${encodeURIComponent(email)}`).pipe(
      tap((user) => this._currentUser.set({ ...user, role: (payload!.role as AppUser['role']) }))
    );
  }

  logout(): void {
    this.clearSession();
  }

  private clearSession(): void {
    // INTEGRATION CHANGE: also clear the other modules' session keys, otherwise
    // signing out here would leave the other portals still reachable.
    clearHlmsSession();
    localStorage.removeItem(TOKEN_KEY);
    this._currentUser.set(null);
  }

  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  decodeToken(): JwtPayload | null {
    const token = this.getToken();
    if (!token) return null;
    try {
      const payloadSegment = token.split('.')[1];
      const json = atob(payloadSegment.replace(/-/g, '+').replace(/_/g, '/'));
      return JSON.parse(json) as JwtPayload;
    } catch {
      return null;
    }
  }

  isTokenExpired(token: string): boolean {
    try {
      const payloadSegment = token.split('.')[1];
      const json = atob(payloadSegment.replace(/-/g, '+').replace(/_/g, '/'));
      const payload = JSON.parse(json) as JwtPayload;
      return payload.exp * 1000 < Date.now();
    } catch {
      return true;
    }
  }

  isAdmin(): boolean {
    return this._currentUser()?.role === 'ADMIN';
  }
}
