import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, ValidatorFn, Validators, AbstractControl } from '@angular/forms';

import { AuthService } from '../../../core/services/auth.service';
import { UserService } from '../../../core/services/user.service';
import { ToastService } from '../../../shared/toast/toast.service';
import { ROLE_LABELS } from '../../../core/models/user.model';

const MOBILE_RE = /^[6-9]\d{9}$/;
const PASSWORD_RE = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_\-+=]).{8,}$/;

function matchOther(otherControlName: string): ValidatorFn {
  return (control: AbstractControl) => {
    const parent = control.parent;
    if (!parent) return null;
    const other = parent.get(otherControlName);
    return other && control.value !== other.value ? { mismatch: true } : null;
  };
}

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent {
  private fb = inject(FormBuilder);
  auth = inject(AuthService);
  private userService = inject(UserService);
  private toast = inject(ToastService);

  roleLabels = ROLE_LABELS;
  savingPersonal = false;
  savingPassword = false;

  personalForm = this.fb.nonNullable.group({
    name: [this.auth.currentUser()?.name ?? '', [Validators.required, Validators.minLength(3)]],
    mobile: [this.auth.currentUser()?.mobile ?? '', [Validators.required, Validators.pattern(MOBILE_RE)]]
  });

  passwordForm = this.fb.nonNullable.group({
    newPassword: ['', [Validators.required, Validators.pattern(PASSWORD_RE)]],
    confirmPassword: ['', [Validators.required, matchOther('newPassword')]]
  });

  savePersonal(): void {
    if (this.personalForm.invalid) {
      this.personalForm.markAllAsTouched();
      return;
    }
    const email = this.auth.currentUser()?.email;
    if (!email) return;
    this.savingPersonal = true;
    this.userService.updateProfile(email, this.personalForm.getRawValue()).subscribe({
      next: () => {
        this.savingPersonal = false;
        this.toast.success('Profile Updated', 'Your personal information has been saved.');
      },
      error: (err) => {
        this.savingPersonal = false;
        this.toast.error('Could not save changes', err?.error?.message || 'Please try again.');
      }
    });
  }

  changePassword(): void {
    if (this.passwordForm.invalid) {
      this.passwordForm.markAllAsTouched();
      return;
    }
    const email = this.auth.currentUser()?.email;
    if (!email) return;
    const { newPassword } = this.passwordForm.getRawValue();
    this.savingPassword = true;
    // No authenticated "current + new password" endpoint exists yet — see
    // README → Missing / Broken Endpoints #3. We use the OTP-based
    // forgot/reset flow as the closest working substitute.
    this.userService.requestPasswordOtp(email).subscribe({
      next: (otp) => {
        this.userService.resetPassword(email, otp, newPassword).subscribe({
          next: () => {
            this.savingPassword = false;
            this.passwordForm.reset();
            this.toast.success('Password Updated', 'Your password has been changed.');
          },
          error: (err) => {
            this.savingPassword = false;
            this.toast.error('Could not update password', err?.error?.message || 'Please try again.');
          }
        });
      },
      error: (err) => {
        this.savingPassword = false;
        this.toast.error('Could not update password', err?.error?.message || 'Please try again.');
      }
    });
  }
}
