import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { switchMap } from 'rxjs';

import { UserService } from '../../../core/services/user.service';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../shared/toast/toast.service';
import { AddStaffModalComponent } from './add-staff-modal.component';
import { AppUser, ROLE_LABELS, UiRole } from '../../../core/models/user.model';

interface TabDef {
  key: UiRole;
  label: string;
  route: string;
}

@Component({
  selector: 'app-staff-management',
  standalone: true,
  imports: [CommonModule, RouterLink, AddStaffModalComponent],
  templateUrl: './staff-management.component.html',
  styleUrl: './staff-management.component.css'
})
export class StaffManagementComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private userService = inject(UserService);
  private auth = inject(AuthService);
  private toast = inject(ToastService);

  pageTitle = '';
  pageDesc = '';

  tabs: TabDef[] = [];
  visibleTabs: TabDef[] = [];

  activeTab: UiRole = 'BIDDER';
  roleLabels = ROLE_LABELS;

  loading = signal(true);
  users = signal<AppUser[]>([]);
  showAddModal = signal(false);

  ngOnInit(): void {
    this.route.data
      .pipe(
        switchMap((data) => {
          this.pageTitle = data['pageTitle'];
          this.pageDesc = data['pageDesc'];

          this.tabs = data['tabs'] || [];

          this.visibleTabs = this.tabs.filter((tab) => tab.key !== 'EMPLOYEE');

          this.activeTab = data['activeTab'];

          if (this.activeTab === 'EMPLOYEE') {
            const firstAvailableTab = this.visibleTabs[0];

            if (firstAvailableTab) {
              this.activeTab = firstAvailableTab.key;
              this.router.navigate([firstAvailableTab.route], {
                relativeTo: this.route.parent
              });
            }
          }

          this.loading.set(true);
          this.users.set([]);

          return this.userService.listByRole(this.activeTab);
        })
      )
      .subscribe({
        next: (list) => {
          this.users.set(this.filterUsersByActiveTab(list));
          this.loading.set(false);
        },
        error: () => {
          this.users.set([]);
          this.loading.set(false);
        }
      });
  }

  get activeLabel(): string {
    return this.roleLabels[this.activeTab] ?? this.activeTab;
  }

  refresh(): void {
    this.loading.set(true);

    this.userService.listByRole(this.activeTab).subscribe({
      next: (list) => {
        this.users.set(this.filterUsersByActiveTab(list));
        this.loading.set(false);
      },
      error: () => {
        this.users.set([]);
        this.loading.set(false);
      }
    });
  }

  onCreated(): void {
    this.showAddModal.set(false);
    this.refresh();
  }

  toggleActive(user: AppUser): void {
    if (user.email === this.auth.currentUser()?.email) {
      this.toast.error('Action Blocked', 'You cannot deactivate your own account.');
      return;
    }

    this.userService.setActive(user.email, !user.active).subscribe({
      next: () => {
        this.toast.success(
          'Status Updated',
          `${user.name} is now ${!user.active ? 'active' : 'inactive'}.`
        );

        this.refresh();
      },
      error: (err) => {
        this.toast.error(
          'Could not update status',
          err?.status === 404
            ? 'This backend does not expose a status-toggle endpoint yet.'
            : err?.error?.message || 'Please try again.'
        );
      }
    });
  }

  deleteUser(user: AppUser): void {
    if (user.email === this.auth.currentUser()?.email) {
      this.toast.error('Action Blocked', 'You cannot delete your own account.');
      return;
    }

    if (!confirm(`Delete ${user.name} (${user.email})? This cannot be undone.`)) {
      return;
    }

    this.userService.deleteUser(user.email).subscribe({
      next: () => {
        this.toast.success(
          'User Deleted',
          `${user.name}'s account has been removed.`
        );

        this.refresh();
      },
      error: (err) => {
        this.toast.error(
          'Could not delete user',
          err?.error?.message || 'Please try again.'
        );
      }
    });
  }

  private filterUsersByActiveTab(list: AppUser[]): AppUser[] {
    if (!list) {
      return [];
    }

    return list.filter((user) => {
      const userRole = String(user.role || '').toUpperCase();
      const activeRole = String(this.activeTab || '').toUpperCase();

      return userRole === activeRole;
    });
  }
}