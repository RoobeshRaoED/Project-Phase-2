import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ToastComponent } from './shared/toast/toast.component';

@Component({
  // INTEGRATION CHANGE: renamed from 'app-root' -- this component is now the
  // wrapper for this module's routes, not the application root.
  selector: 'app-admin-root',
  standalone: true,
  imports: [RouterOutlet, ToastComponent],
  template: `
    <router-outlet></router-outlet>
    <app-toast></app-toast>
  `
})
export class App {}
