export type UserRole = 'CUSTOMER' | 'BIDDER' | 'ADMIN' | 'BANK_OFFICER' | 'LEGAL';
export type AccountType = 'CUSTOMER' | 'BIDDER';

// Matches the backend app_user columns/service mapping: name and mobile.
// accountType is included for frontend selection. If your backend DTO does not support it,
// remove accountType from the payload in register.component.ts.
export interface RegisterRequestDTO {
  name: string;
  email: string;
  mobile: string;
  password: string;
  role: UserRole;
  accountType?: AccountType;
}

export interface LoginRequestDTO {
  email: string;
  password: string;
}

export interface LoginResponseDTO {
  token?: string;
  jwtToken?: string;
  accessToken?: string;
  email?: string;
  name?: string;
  role?: string;
  message?: string;
}

export interface ApiUser {
  email: string;
  name?: string;
  mobile?: string;
  role?: string;
  accountType?: AccountType;
  active?: boolean;
  prefEmail?: boolean;
  prefSms?: boolean;
  prefInapp?: boolean;
}

export interface ForgotPasswordDTO {
  email: string;
}


export interface ResetPasswordDTO {
  email: string;
  otpCode: string;
  newPassword: string;
}
