import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { ApiUser, ForgotPasswordDTO, LoginRequestDTO, LoginResponseDTO, RegisterRequestDTO, ResetPasswordDTO } from '../models/auth.models';
import { clearHlmsSession } from '../../../core/session/session-keys';

@Injectable({ providedIn: 'root' })
export class AuthService {
  // INTEGRATION CHANGE: was `${environment.apiBaseUrl}/api`, which pointed
  // straight at user-service on port 8081 (see the original proxy.conf.json).
  // The other four modules all go through the Spring Cloud API Gateway on 8080
  // using the "/user-service" prefix, so this now matches them. Same endpoints,
  // same payloads -- only the base path changed.
  private readonly apiBase = `${environment.apiBaseUrl}${environment.services.user}/api`;
  private readonly tokenKey = 'hlms_auth_token';
  private readonly userKey = 'hlms_user';

  constructor(private http: HttpClient) {}

  register(payload: RegisterRequestDTO): Observable<ApiUser> {
    return this.http.post<ApiUser>(`${this.apiBase}/users/register`, payload);
  }

  login(payload: LoginRequestDTO): Observable<LoginResponseDTO> {
    return this.http.post<LoginResponseDTO>(`${this.apiBase}/users/login`, payload).pipe(
      tap((response) => this.saveLogin(response))
    );
  }

  getUser(email: string): Observable<ApiUser> {
    return this.http.get<ApiUser>(`${this.apiBase}/users/${encodeURIComponent(email)}`);
  }

  forgotPassword(payload: ForgotPasswordDTO): Observable<string> {
    return this.http.post(`${this.apiBase}/users/forgot-password`, payload, { responseType: 'text' });
  }

  resetPassword(payload: ResetPasswordDTO): Observable<string> {
    return this.http.post(`${this.apiBase}/users/reset-password`, payload, { responseType: 'text' });
  }



  logout(): void {
    // INTEGRATION CHANGE: also clear the other modules' session keys, otherwise
    // signing out here would leave the other portals still reachable.
    clearHlmsSession();
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem(this.userKey);
  }

  get token(): string | null {
    return localStorage.getItem(this.tokenKey);
  }

  private saveLogin(response: LoginResponseDTO): void {
    const token = response.token || response.jwtToken || response.accessToken;
    if (token) localStorage.setItem(this.tokenKey, token);
    localStorage.setItem(this.userKey, JSON.stringify(response));
  }
}
