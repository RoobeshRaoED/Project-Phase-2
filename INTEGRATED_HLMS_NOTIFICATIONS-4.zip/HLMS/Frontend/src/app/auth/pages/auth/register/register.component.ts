import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { AuthService } from '../../../core/services/auth.service';
import { readableApiError } from '../../../core/services/api-error.util';
import { AccountType } from '../../../core/models/auth.models';
import { HlmsValidators } from '../../../core/validators/hlms-validators';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterLink],
  templateUrl: './register.component.html'
})
export class RegisterComponent {
  showPassword = false;
  showConfirmPassword = false;
  showPolicy = false;
  policyScrolled = false;
  policyAcceptedTemp = false;
  loading = false;
  apiError = '';
  successMessage = '';

  form = this.fb.nonNullable.group({
    fullName: ['', [Validators.required, HlmsValidators.fullName()]],
    mobile: ['', [Validators.required, HlmsValidators.mobile()]],
    email: ['', [Validators.required, Validators.email, Validators.maxLength(100)]],
    accountType: ['CUSTOMER' as AccountType, [Validators.required]],
    password: ['', [Validators.required, HlmsValidators.password()]],
    confirmPassword: ['', [Validators.required]],
    acceptPrivacyPolicy: [false, [Validators.requiredTrue]]
  }, { validators: [HlmsValidators.matchPassword()] });

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {}

  openPolicy(): void {
    this.showPolicy = true;
    this.policyScrolled = false;
    this.policyAcceptedTemp = this.form.controls.acceptPrivacyPolicy.value;
  }

  closePolicy(): void {
    this.showPolicy = false;
    this.policyAcceptedTemp = this.form.controls.acceptPrivacyPolicy.value;
  }

  onPolicyScroll(event: Event): void {
    const element = event.target as HTMLElement;
    const reachedBottom = element.scrollTop + element.clientHeight >= element.scrollHeight - 8;
    if (reachedBottom) this.policyScrolled = true;
  }

  savePolicy(): void {
    if (!this.policyScrolled || !this.policyAcceptedTemp) return;
    this.form.controls.acceptPrivacyPolicy.setValue(true);
    this.form.controls.acceptPrivacyPolicy.markAsTouched();
    this.showPolicy = false;
  }

  submit(): void {
    this.apiError = '';
    this.successMessage = '';

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const value = this.form.getRawValue();
    this.loading = true;

    this.authService.register({
      name: value.fullName.trim(),
      mobile: value.mobile.trim(),
      email: value.email.trim(),
      password: value.password,
      // Role is saved based on selected account type.
      // Customer -> CUSTOMER, Bidder -> BIDDER
      role: value.accountType,
      accountType: value.accountType
    }).pipe(finalize(() => (this.loading = false))).subscribe({
      next: () => {
        this.successMessage = 'Registration successful. Redirecting to login.';
        setTimeout(() => this.router.navigateByUrl('/login'), 900);
      },
      error: (error) => {
        this.apiError = readableApiError(error, 'Registration failed. Please check backend DTO names: name, mobile, email, password, role, and accountType.');
      }
    });
  }

  hasError(field: 'fullName' | 'mobile' | 'email' | 'accountType' | 'password' | 'confirmPassword' | 'acceptPrivacyPolicy', error: string): boolean {
    const control = this.form.controls[field];
    return control.touched && control.hasError(error);
  }

  hasPasswordRule(rule: 'min8' | 'uppercase' | 'lowercase' | 'number' | 'special'): boolean {
    const errors = this.form.controls.password.errors?.['weakPassword'];
    return !!errors?.[rule];
  }

  get passwordMismatch(): boolean {
    return this.form.touched && this.form.hasError('passwordMismatch');
  }
}
