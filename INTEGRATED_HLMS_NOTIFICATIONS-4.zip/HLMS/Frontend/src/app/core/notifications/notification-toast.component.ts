import { Component, OnDestroy, effect, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HlmsNotificationService } from './notification.service';
import { HlmsNotification } from './notification.model';

/**
 * INTEGRATION LAYER - the pop-up shown when a notification arrives while the user is
 * already looking at the app.
 *
 * Sits next to the bell in each portal's topbar and renders fixed to the viewport, so
 * one instance per portal is enough. It only ever shows notifications the service
 * flagged as newly arrived - the first poll after sign-in is deliberately silent, or
 * every user would be greeted by a wall of toasts for their whole history.
 *
 * Legal already had its own generic ToastService for form feedback; that is left alone.
 * This one is specific to arriving notifications.
 */
@Component({
  selector: 'app-notification-toast',
  standalone: true,
  imports: [CommonModule],
  template: `
    @if (visible().length) {
      <div class="ntoast-wrap" role="status" aria-live="polite">
        @for (t of visible(); track t.notificationId) {
          <div class="ntoast" (click)="dismiss(t)">
            <div class="ntoast-ic">🔔</div>
            <div class="ntoast-text">
              <div class="ntoast-title">{{ t.title }}</div>
              @if (t.body) { <div class="ntoast-body">{{ t.body }}</div> }
            </div>
            <button class="ntoast-x" type="button" aria-label="Dismiss">×</button>
          </div>
        }
      </div>
    }
  `,
  styles: [
    `
      .ntoast-wrap {
        position: fixed;
        right: 20px;
        bottom: 20px;
        z-index: 2000;
        display: flex;
        flex-direction: column;
        gap: 10px;
        max-width: 360px;
      }
      .ntoast {
        display: flex;
        align-items: flex-start;
        gap: 10px;
        background: #0f172a;
        color: #f8fafc;
        border-radius: 12px;
        padding: 12px 14px;
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.3);
        cursor: pointer;
        animation: ntoast-in 0.22s ease-out;
      }
      @keyframes ntoast-in {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
      }
      .ntoast-ic { font-size: 17px; line-height: 1.3; }
      .ntoast-text { flex: 1; min-width: 0; }
      .ntoast-title { font-weight: 600; font-size: 13.5px; }
      .ntoast-body {
        font-size: 12.5px;
        color: #cbd5e1;
        margin-top: 3px;
        line-height: 1.45;
      }
      .ntoast-x {
        background: none;
        border: none;
        color: #94a3b8;
        font-size: 18px;
        line-height: 1;
        cursor: pointer;
        padding: 0 2px;
      }
      .ntoast-x:hover { color: #f8fafc; }

      @media (prefers-reduced-motion: reduce) {
        .ntoast { animation: none; }
      }
    `
  ]
})
export class NotificationToastComponent implements OnDestroy {
  private svc = inject(HlmsNotificationService);

  /** How long each toast stays on screen. */
  private static readonly DISMISS_MS = 6000;

  visible = signal<HlmsNotification[]>([]);
  private timers: ReturnType<typeof setTimeout>[] = [];

  constructor() {
    effect(() => {
      const arrivals = this.svc.justArrived();
      if (!arrivals.length) return;

      // Cap the burst: if eight things happened at once, showing eight stacked toasts
      // buries the page. The rest are still in the dropdown.
      const batch = arrivals.slice(0, 3);
      this.visible.update((current) => [...current, ...batch]);
      this.svc.clearArrivals();

      for (const item of batch) {
        this.timers.push(
          setTimeout(() => this.dismiss(item), NotificationToastComponent.DISMISS_MS)
        );
      }
    });
  }

  dismiss(t: HlmsNotification): void {
    this.visible.update((list) => list.filter((n) => n.notificationId !== t.notificationId));
  }

  ngOnDestroy(): void {
    for (const t of this.timers) clearTimeout(t);
    this.timers = [];
  }
}
