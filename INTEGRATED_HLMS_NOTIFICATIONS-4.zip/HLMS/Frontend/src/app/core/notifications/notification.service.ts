import { Injectable, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subscription, timer } from 'rxjs';
import { switchMap } from 'rxjs/operators';

import { environment } from '../../../environments/environment';
import { HlmsNotification, isUnread } from './notification.model';

/**
 * INTEGRATION LAYER - one notification service for all five portals.
 *
 * The five source projects each grew their own copy (customer, legal, bidder and
 * bank-office had one; admin had none at all), which is why the bell behaved
 * differently in every portal. This replaces them.
 *
 * Role-relevance is handled by the BACKEND, not here: notification-service stores one
 * row per recipient email, and each service raises events addressed to the people who
 * care (a customer hears about their own application, bank officers hear about work
 * arriving, bidders hear about being outbid, admins hear about registrations). So the
 * frontend only ever asks "what is addressed to me?" - it never filters by role, and
 * cannot accidentally show one role another's messages.
 */
@Injectable({ providedIn: 'root' })
export class HlmsNotificationService {
  private http = inject(HttpClient);

  private readonly base = `${environment.apiBaseUrl}${environment.services.notification}/api/notifications`;

  /** How often to re-poll while a portal is open. */
  private static readonly POLL_MS = 30_000;

  readonly notifications = signal<HlmsNotification[]>([]);
  readonly unreadCount = computed(() => this.notifications().filter(isUnread).length);

  /** Emits notifications that arrived since the last poll, for the toast to show. */
  readonly justArrived = signal<HlmsNotification[]>([]);

  /** True once a load has completed at least once - lets the UI tell "empty" from "loading". */
  readonly loaded = signal(false);

  private pollSub?: Subscription;
  private currentEmail: string | null = null;
  private seenIds = new Set<string>();
  /** First load must not toast the entire history at the user. */
  private primed = false;

  /**
   * Starts (or restarts) polling for one user. Safe to call from every portal's topbar
   * on init; calling it again with the same email is a no-op so switching routes inside
   * a portal does not restart the timer.
   */
  start(userEmail: string | null | undefined): void {
    if (!userEmail) return;
    if (this.currentEmail === userEmail && this.pollSub) return;

    this.stop();
    this.currentEmail = userEmail;
    this.primed = false;
    this.seenIds.clear();

    this.pollSub = timer(0, HlmsNotificationService.POLL_MS)
      .pipe(switchMap(() => this.fetch(userEmail)))
      .subscribe({
        next: (list) => this.absorb(list || []),
        // A notification failure must never break the portal it is embedded in.
        error: () => this.loaded.set(true)
      });
  }

  /** Stops polling - call on logout so the next user does not inherit this stream. */
  stop(): void {
    this.pollSub?.unsubscribe();
    this.pollSub = undefined;
    this.currentEmail = null;
    this.notifications.set([]);
    this.justArrived.set([]);
    this.seenIds.clear();
    this.primed = false;
    this.loaded.set(false);
  }

  /** Forces an immediate refresh outside the poll interval. */
  refresh(): void {
    if (!this.currentEmail) return;
    this.fetch(this.currentEmail).subscribe({
      next: (list) => this.absorb(list || []),
      error: () => {}
    });
  }

  markRead(notificationId: string): void {
    if (!notificationId) return;

    // Update locally first so the badge responds immediately; the poll will correct it
    // if the server disagrees.
    this.notifications.update((list) =>
      list.map((n) => (n.notificationId === notificationId ? { ...n, isRead: true, read: true } : n))
    );

    this.http
      .patch<HlmsNotification>(`${this.base}/${encodeURIComponent(notificationId)}/read`, {})
      .subscribe({ error: () => this.refresh() });
  }

  markAllRead(): void {
    for (const n of this.notifications().filter(isUnread)) {
      if (n.notificationId) this.markRead(n.notificationId);
    }
  }

  /** Clears the toast queue once it has been displayed. */
  clearArrivals(): void {
    this.justArrived.set([]);
  }

  private fetch(userEmail: string): Observable<HlmsNotification[]> {
    return this.http.get<HlmsNotification[]>(this.base, { params: { userEmail } });
  }

  private absorb(list: HlmsNotification[]): void {
    // Newest first, regardless of the order the backend returned them in.
    const sorted = [...list].sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
    this.notifications.set(sorted);
    this.loaded.set(true);

    const fresh: HlmsNotification[] = [];
    for (const n of sorted) {
      const id = n.notificationId;
      if (!id) continue;
      if (!this.seenIds.has(id)) {
        this.seenIds.add(id);
        // Only toast genuinely new AND unread ones, and never on the very first load.
        if (this.primed && isUnread(n)) fresh.push(n);
      }
    }

    this.primed = true;
    if (fresh.length) {
      this.justArrived.set(fresh);
    }
  }
}
