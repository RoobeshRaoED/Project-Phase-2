import { Component, ElementRef, HostListener, effect, inject, input, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HlmsNotificationService } from './notification.service';
import { HlmsNotification, isUnread } from './notification.model';

/**
 * INTEGRATION LAYER - the notification bell + dropdown, shared by all five portals.
 *
 * Drop `<app-notification-bell [userEmail]="..."/>` into any topbar. It renders the
 * same markup classes the five portals already style (`icon-btn`, `icon-dot`), so it
 * inherits each portal's own look without needing per-portal CSS.
 *
 * Styles are inline-scoped to this component rather than added to the global
 * stylesheets, because the five portals scope their CSS differently (admin wraps
 * everything in `.admin-scope`) and a global rule would leak between them.
 */
@Component({
  selector: 'app-notification-bell',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="notif-root">
      <button
        class="icon-btn"
        type="button"
        title="Notifications"
        [attr.aria-expanded]="open()"
        aria-haspopup="true"
        (click)="toggle($event)">
        🔔<span class="icon-dot">{{ svc.unreadCount() }}</span>
      </button>

      @if (open()) {
        <div class="notif-panel" role="menu">
          <div class="notif-head">
            <strong>Notifications</strong>
            @if (svc.unreadCount() > 0) {
              <button class="notif-link" type="button" (click)="markAll($event)">
                Mark all read
              </button>
            }
          </div>

          @if (!svc.notifications().length) {
            <div class="notif-empty">
              <div class="notif-empty-ic">📭</div>
              {{ svc.loaded() ? 'No notifications yet.' : 'Loading…' }}
            </div>
          } @else {
            <div class="notif-list">
              @for (n of svc.notifications(); track n.notificationId) {
                <button
                  class="notif-item"
                  type="button"
                  [class.unread]="unread(n)"
                  (click)="pick(n, $event)">
                  <div class="notif-item-top">
                    <span class="notif-title">{{ n.title }}</span>
                    @if (unread(n)) { <span class="notif-new">New</span> }
                  </div>
                  @if (n.body) { <div class="notif-body">{{ n.body }}</div> }
                  <div class="notif-time">{{ n.createdAt | date: 'medium' }}</div>
                </button>
              }
            </div>
          }
        </div>
      }
    </div>
  `,
  styles: [
    `
      .notif-root {
        position: relative;
        display: inline-flex;
      }
      .notif-panel {
        position: absolute;
        top: calc(100% + 10px);
        right: 0;
        width: 340px;
        max-height: 60vh;
        display: flex;
        flex-direction: column;
        background: #fff;
        border: 1px solid rgba(0, 0, 0, 0.1);
        border-radius: 12px;
        box-shadow: 0 12px 32px rgba(0, 0, 0, 0.18);
        z-index: 1200;
        overflow: hidden;
        color: #1f2937;
      }
      .notif-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 12px 14px;
        border-bottom: 1px solid rgba(0, 0, 0, 0.08);
        font-size: 14px;
      }
      .notif-link {
        background: none;
        border: none;
        color: #0f766e;
        font-size: 12.5px;
        cursor: pointer;
        padding: 0;
      }
      .notif-link:hover { text-decoration: underline; }
      .notif-list { overflow-y: auto; }
      .notif-item {
        display: block;
        width: 100%;
        text-align: left;
        background: none;
        border: none;
        border-bottom: 1px solid rgba(0, 0, 0, 0.06);
        padding: 11px 14px;
        cursor: pointer;
        font: inherit;
        color: inherit;
      }
      .notif-item:hover { background: #f6f8fa; }
      .notif-item.unread { background: #f0fdfa; }
      .notif-item.unread:hover { background: #ccfbf1; }
      .notif-item-top {
        display: flex;
        align-items: center;
        gap: 7px;
      }
      .notif-title { font-weight: 600; font-size: 13.5px; }
      .notif-new {
        font-size: 10.5px;
        font-weight: 600;
        color: #fff;
        background: #0f766e;
        border-radius: 999px;
        padding: 1px 7px;
      }
      .notif-body {
        font-size: 12.5px;
        color: #4b5563;
        margin-top: 3px;
        line-height: 1.45;
      }
      .notif-time { font-size: 11px; color: #9ca3af; margin-top: 4px; }
      .notif-empty { padding: 30px 14px; text-align: center; color: #6b7280; font-size: 13px; }
      .notif-empty-ic { font-size: 26px; margin-bottom: 6px; }
    `
  ]
})
export class NotificationBellComponent {
  /** The signed-in user's email. Polling starts as soon as a non-empty value arrives. */
  readonly userEmail = input<string | null | undefined>(null);

  svc = inject(HlmsNotificationService);
  private host = inject(ElementRef<HTMLElement>);

  open = signal(false);

  constructor() {
    // input() is a signal, so this effect re-runs when the topbar resolves the email
    // asynchronously - several portals restore their session after the first render,
    // so the email is null on the initial pass. start() ignores repeat calls for the
    // same address, so this settles after one real invocation.
    effect(() => {
      const email = this.userEmail();
      if (email) this.svc.start(email);
    });
  }

  unread = isUnread;

  toggle(event: Event): void {
    event.stopPropagation();
    const next = !this.open();
    this.open.set(next);
    if (next) this.svc.refresh();
  }

  markAll(event: Event): void {
    event.stopPropagation();
    this.svc.markAllRead();
  }

  pick(n: HlmsNotification, event: Event): void {
    event.stopPropagation();
    if (n.notificationId && isUnread(n)) {
      this.svc.markRead(n.notificationId);
    }
  }

  /** Clicking anywhere else closes the dropdown, the way a menu should behave. */
  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent): void {
    if (!this.open()) return;
    if (!this.host.nativeElement.contains(event.target as Node)) {
      this.open.set(false);
    }
  }

  @HostListener('document:keydown.escape')
  onEscape(): void {
    this.open.set(false);
  }
}
