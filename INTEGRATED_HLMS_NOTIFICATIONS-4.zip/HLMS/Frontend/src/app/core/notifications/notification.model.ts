/**
 * INTEGRATION LAYER - the one notification shape for all five portals.
 *
 * Mirrors notification-service's Notification entity. Note that the backend
 * publishes the read flag under BOTH names:
 *
 *   "isRead" - the real accessor (getIsRead)
 *   "read"   - a back-compat alias kept for callers written against the old
 *              isRead() accessor, which Jackson used to expose as "read"
 *
 * Both are declared optional here and `isUnread()` below reads whichever is
 * present, so this keeps working whichever one the backend sends.
 */
export interface HlmsNotification {
  notificationId?: string;
  userEmail: string;
  title: string;
  body?: string;
  channels?: string[];
  isRead?: boolean;
  read?: boolean;
  createdAt?: string;
  deletedAt?: string | null;
}

/** True when the notification has not been read yet, whichever key the backend used. */
export function isUnread(n: HlmsNotification): boolean {
  if (typeof n.isRead === 'boolean') return !n.isRead;
  if (typeof n.read === 'boolean') return !n.read;
  return true;
}
