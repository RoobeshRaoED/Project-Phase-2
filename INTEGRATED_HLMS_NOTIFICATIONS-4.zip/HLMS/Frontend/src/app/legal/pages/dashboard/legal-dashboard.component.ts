import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { forkJoin } from 'rxjs';
import { AuthService } from '../../core/services/auth.service';
import { LegalDataService } from '../../core/services/legal-data.service';
import { AuctionService } from '../../core/services/auction.service';
import { LegalNoticeService } from '../../core/services/legal-notice.service';
import { ToastService } from '../../core/services/toast.service';
import { LegalQueueRow, OverdueAccount } from '../../core/models/models';

@Component({
  selector: 'app-legal-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './legal-dashboard.component.html'
})
export class LegalDashboardComponent implements OnInit {
  loading = signal(true);
  queue = signal<LegalQueueRow[]>([]);
  verifiedThisMonth = signal(0);
  activeAuctions = signal(0);
  activeNotices = signal(0);
  overdueAccounts = signal<OverdueAccount[]>([]);

  constructor(
    public auth: AuthService,
    private legalData: LegalDataService,
    private auctionSvc: AuctionService,
    private noticeSvc: LegalNoticeService,
    private toast: ToastService
  ) {}

  ngOnInit(): void {
    forkJoin({
      queue: this.legalData.getQueue(),
      resolved: this.legalData.getRecentlyActioned(),
      auctions: this.auctionSvc.listAll(),
      notices: this.noticeSvc.listAll(),
      overdue: this.legalData.getOverdueAccounts()
    }).subscribe({
      next: ({ queue, resolved, auctions, notices, overdue }) => {
        this.queue.set(queue.ready);
        const now = new Date();
        this.verifiedThisMonth.set(
          resolved.filter((r) =>
            r.verification?.decision === 'Approved' &&
            r.verification.decisionDate &&
            new Date(r.verification.decisionDate).getMonth() === now.getMonth() &&
            new Date(r.verification.decisionDate).getFullYear() === now.getFullYear()
          ).length
        );
        this.activeAuctions.set(auctions.filter((a) => a.stage !== 'None' && a.stage !== 'Resolved').length);
        this.activeNotices.set(notices.filter((n) => n.status === 'Active').length);
        this.overdueAccounts.set(overdue);
        this.loading.set(false);
      },
      // Belt-and-braces: the individual services already swallow their own errors, but if
      // anything still slips through, stop the spinner instead of leaving it stuck forever.
      error: () => {
        this.loading.set(false);
        this.toast.error('Could not load dashboard', 'Please refresh the page to try again.');
      }
    });
  }

  firstName(): string {
    const name = this.auth.currentUser()?.name || '';
    return name.split(' ')[0] || 'there';
  }

  auctionBadgeClass(stage: string): string {
    if (stage === 'Notice Issued') return 'badge-orange';
    if (stage === 'Possession' || stage === 'Auction Scheduled') return 'badge-red';
    if (stage === 'Resolved') return 'badge-green';
    return 'badge-gray';
  }
}
