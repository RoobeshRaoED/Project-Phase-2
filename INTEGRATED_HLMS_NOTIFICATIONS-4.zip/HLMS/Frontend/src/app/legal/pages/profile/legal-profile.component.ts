import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';
import { environment } from '../../../../environments/environment';
import { AppUser } from '../../core/models/models';

@Component({
  selector: 'app-legal-profile',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './legal-profile.component.html'
})
export class LegalProfileComponent {
  saving = signal(false);
  mobileDraft = '';
  prefSms = true;
  prefEmail = true;
  prefInapp = true;

  constructor(public auth: AuthService, private toast: ToastService, private http: HttpClient) {
    const u = this.auth.currentUser();
    this.mobileDraft = u?.mobile || '';
    this.prefSms = u?.prefSms ?? true;
    this.prefEmail = u?.prefEmail ?? true;
    this.prefInapp = u?.prefInapp ?? true;
  }

  initials(): string {
    const name = this.auth.currentUser()?.name || '';
    return name.split(' ').filter(Boolean).map((p) => p[0]).slice(0, 2).join('').toUpperCase() || 'LT';
  }

  save(): void {
    const user = this.auth.currentUser();
    if (!user) return;
    this.saving.set(true);
    const updated: AppUser = { ...user, mobile: this.mobileDraft, prefSms: this.prefSms, prefEmail: this.prefEmail, prefInapp: this.prefInapp };
    this.http.put<AppUser>(`${environment.apiBase}/user-service/api/users/${encodeURIComponent(user.email)}`, updated).subscribe({
      next: () => {
        this.saving.set(false);
        this.auth.refreshCurrentUser();
        this.toast.success('Profile Updated');
      },
      error: () => {
        this.saving.set(false);
        this.toast.error('Could not update profile', 'Please try again.');
      }
    });
  }

  logout(): void { this.auth.logout(); }
}
