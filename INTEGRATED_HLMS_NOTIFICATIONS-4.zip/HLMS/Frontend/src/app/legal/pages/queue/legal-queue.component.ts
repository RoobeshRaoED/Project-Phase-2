import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { forkJoin } from 'rxjs';
import { LegalDataService } from '../../core/services/legal-data.service';
import { LoanApplicationService } from '../../core/services/loan-application.service';
import { ToastService } from '../../core/services/toast.service';
import { LegalQueueRow } from '../../core/models/models';

@Component({
  selector: 'app-legal-queue',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './legal-queue.component.html'
})
export class LegalQueueComponent implements OnInit {
  loading = signal(true);
  documentQueue = signal<LegalQueueRow[]>([]);
  ready = signal<LegalQueueRow[]>([]);
  locked = signal<LegalQueueRow[]>([]);
  resolved = signal<LegalQueueRow[]>([]);
  productNames = signal<Record<string, string>>({});

  constructor(
    private legalData: LegalDataService,
    private loanSvc: LoanApplicationService,
    private toast: ToastService
  ) {}

  ngOnInit(): void {
    this.loanSvc.getProductNameMap().subscribe({
      next: (map) => this.productNames.set(map),
      error: () => this.productNames.set({})
    });
    forkJoin({
      documentQueue: this.legalData.getDocumentQueue(),
      queue: this.legalData.getQueue(),
      resolved: this.legalData.getRecentlyActioned()
    }).subscribe({
      next: ({ documentQueue, queue, resolved }) => {
        this.documentQueue.set(documentQueue);
        this.ready.set(queue.ready);
        this.locked.set(queue.locked);
        this.resolved.set(
          resolved.slice().sort((a, b) => {
            const ad = a.verification?.decisionDate ? new Date(a.verification.decisionDate).getTime() : 0;
            const bd = b.verification?.decisionDate ? new Date(b.verification.decisionDate).getTime() : 0;
            return bd - ad;
          }).slice(0, 10)
        );
        this.loading.set(false);
      },
      error: () => {
        this.loading.set(false);
        this.toast.error('Could not load queue', 'Please refresh the page to try again.');
      }
    });
  }

  productName(productId?: string): string {
    if (!productId) return '—';
    return this.productNames()[productId] ?? productId;
  }

  decisionBadgeClass(decision: string | null | undefined): string {
    if (decision === 'Approved') return 'badge-green';
    if (decision === 'Rejected') return 'badge-red';
    if (decision === 'Query Raised') return 'badge-orange';
    return 'badge-gray';
  }
}
