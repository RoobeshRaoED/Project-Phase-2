import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, of } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { BankOfficeDecisionDTO } from '../models/models';

@Injectable({ providedIn: 'root' })
export class BankOfficeDecisionService {
  private base = `${environment.apiBase}/legal-service/api/bank-office/decisions`;

  constructor(private http: HttpClient) {}

  getByApplication(appId: string): Observable<BankOfficeDecisionDTO | null> {
    return this.http.get<BankOfficeDecisionDTO>(`${this.base}/by-application/${appId}`).pipe(
      catchError(() => of(null))
    );
  }
}
