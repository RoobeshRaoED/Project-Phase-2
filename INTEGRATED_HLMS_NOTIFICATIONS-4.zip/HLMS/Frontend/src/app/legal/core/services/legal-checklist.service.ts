import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { LegalChecklistItemDTO } from '../models/models';

@Injectable({ providedIn: 'root' })
export class LegalChecklistService {
  private base = `${environment.apiBase}/legal-service/api/legal/checklist-items`;

  constructor(private http: HttpClient) {}

  /**
   * NOTE: legal-service does not expose a `/by-application/{appId}` endpoint for
   * checklist items (unlike verifications, bank-office decisions and auctions,
   * which all have one). Until that's added, we fetch the full list and filter
   * client-side — see README_API_GAPS.md. Fine for demo/small data volumes,
   * but should be replaced with a server-side filter for production scale.
   */
  listByApplication(appId: string): Observable<LegalChecklistItemDTO[]> {
    return this.http.get<LegalChecklistItemDTO[]>(this.base).pipe(
      map((items) => items.filter((i) => i.appId === appId))
    );
  }

  create(dto: LegalChecklistItemDTO): Observable<LegalChecklistItemDTO> {
    return this.http.post<LegalChecklistItemDTO>(this.base, dto);
  }

  update(checklistItemId: string, dto: LegalChecklistItemDTO): Observable<LegalChecklistItemDTO> {
    return this.http.put<LegalChecklistItemDTO>(`${this.base}/${checklistItemId}`, dto);
  }
}
