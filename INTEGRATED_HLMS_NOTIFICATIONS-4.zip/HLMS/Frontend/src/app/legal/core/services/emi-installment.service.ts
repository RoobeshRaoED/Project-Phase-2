import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, of } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { EmiInstallmentDTO } from '../models/models';

@Injectable({ providedIn: 'root' })
export class EmiInstallmentService {
  private base = `${environment.apiBase}/repayment-service/api/emi`;

  constructor(private http: HttpClient) {}

  // Fanned out per-account inside LegalDataService.getOverdueAccounts()'s forkJoin - a loan
  // with no schedule generated yet (or a backend 404) must not take down the whole request.
  getSchedule(appId: string): Observable<EmiInstallmentDTO[]> {
    return this.http.get<EmiInstallmentDTO[]>(`${this.base}/${appId}/schedule`).pipe(
      catchError(() => of([] as EmiInstallmentDTO[]))
    );
  }
}
