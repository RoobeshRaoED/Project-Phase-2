import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { environment } from '../../../../environments/environment';

/**
 * Attaches "Authorization: Bearer <jwt>" to every request that targets the
 * HLMS API gateway (every backend endpoint requires this except
 * /user-service/api/users/login|register|forgot-password|reset-password).
 * On a 401 the session is treated as invalid and the user is sent back to /login.
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  const token = auth.getToken();
  const isApiCall = req.url.startsWith(environment.apiBase);
  const authedReq = (isApiCall && token)
    ? req.clone({ setHeaders: { Authorization: `Bearer ${token}` } })
    : req;

  return next(authedReq).pipe(
    catchError((err) => {
      if (isApiCall && err?.status === 401) {
        auth.logout();
        router.navigate(['/login']);
      }
      return throwError(() => err);
    })
  );
};
