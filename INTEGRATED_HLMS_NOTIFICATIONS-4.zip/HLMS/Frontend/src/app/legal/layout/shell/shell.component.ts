import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterOutlet, RouterLink, NavigationEnd } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { LoanApplicationService } from '../../core/services/loan-application.service';
import { DocumentService } from '../../core/services/document.service';
import { LEGAL_CHECKLIST } from '../../core/models/models';
import { NotificationBellComponent } from '../../../core/notifications/notification-bell.component';
import { NotificationToastComponent } from '../../../core/notifications/notification-toast.component';

interface NavItem { view: string; path: string; ic: string; label: string; badge: string | null; }

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, NotificationBellComponent, NotificationToastComponent],
  templateUrl: './shell.component.html'
})
export class ShellComponent {
  sidebarOpen = signal(false);
  activePath = signal('dashboard');
  pendingReviewCount = signal<number | null>(null);
  pendingDocsCount = signal<number | null>(null);

  navItems: NavItem[] = [
    { view: 'legaldash', path: 'dashboard', ic: '▦', label: 'Dashboard', badge: null },
    { view: 'legalqueue', path: 'queue', ic: '☑', label: 'Legal Review Queue', badge: null },
    { view: 'legaldocuments', path: 'documents', ic: '▯', label: 'Document Center', badge: null },
    { view: 'legalauction', path: 'auction', ic: '☆', label: 'Auction & SARFAESI', badge: null },
    // { view: 'legalnotices', path: 'notices', ic: '✉', label: 'Legal Notices Log', badge: null },
    { view: 'profile', path: 'profile', ic: '◍', label: 'Profile Settings', badge: null }
  ];

  constructor(
    public auth: AuthService,
    private router: Router,
    private loanSvc: LoanApplicationService,
    private docSvc: DocumentService
  ) {
    this.router.events.subscribe((e) => {
      if (e instanceof NavigationEnd) {
        const seg = this.router.url.split('/').filter(Boolean)[0] || 'dashboard';
        this.activePath.set(seg);
        this.sidebarOpen.set(false);
      }
    });
    this.loadBadgeCounts();
  }

  private loadBadgeCounts(): void {
    this.loanSvc.workflowStages().subscribe((stages) => {
      const legalStageIndex = stages.findIndex((s) => s.toLowerCase().includes('legal'));
      this.loanSvc.listAll().subscribe((apps) => {
        const pending = apps.filter((a) => a.stageIndex === legalStageIndex && a.status === 'Under Review');
        this.pendingReviewCount.set(pending.length);
      });
    });
    this.docSvc.listAllPostDisbursementDocuments().subscribe((docs) => {
      this.pendingDocsCount.set(docs.filter((d) => d.status === 'Pending').length);
    });
  }

  badgeFor(path: string): string | null {
    if (path === 'queue') { const n = this.pendingReviewCount(); return n ? String(n) : null; }
    if (path === 'documents') { const n = this.pendingDocsCount(); return n ? String(n) : null; }
    return null;
  }

  initials(): string {
    const name = this.auth.currentUser()?.name || '';
    return name.split(' ').filter(Boolean).map((p) => p[0]).slice(0, 2).join('').toUpperCase() || 'LT';
  }

  toggleSidebar(): void { this.sidebarOpen.update((v) => !v); }

  logout(): void { this.auth.logout(); }
}
