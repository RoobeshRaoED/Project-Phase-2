package com.hlms.notification.service;

import com.hlms.notification.client.ApplicationSummaryResponse;
import com.hlms.notification.dto.ApplicationContextResponse;
import com.hlms.notification.dto.ServiceRequestDetailsResponse;
import com.hlms.notification.entity.ServiceRequest;
import com.hlms.notification.exception.BadRequestException;
import com.hlms.notification.exception.ResourceNotFoundException;
import com.hlms.notification.repository.ServiceRequestRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

/** Backs feature "9. Post-Disbursement Service Management". */
@Service
public class ServiceRequestService {

    private static final Logger log = LoggerFactory.getLogger(ServiceRequestService.class);

    private final ServiceRequestRepository repository;
    private final ApplicationContextService applicationContextService;
    private final NotificationService notificationService;

    public ServiceRequestService(ServiceRequestRepository repository,
                                 ApplicationContextService applicationContextService,
                                 NotificationService notificationService) {
        this.repository = repository;
        this.applicationContextService = applicationContextService;
        this.notificationService = notificationService;
    }

    @Transactional
    public ServiceRequest create(String appId, String userEmail, String requestType, String description) {
        if (appId == null || appId.isBlank()) {
            throw new BadRequestException("appId is required");
        }
        if (requestType == null || requestType.isBlank()) {
            throw new BadRequestException("requestType is required");
        }

        // Confirm the application exists before opening a request against it. Only a
        // definite 404 from loan-service blocks the request; an outage does not.
        if (applicationContextService.applicationDefinitelyMissing(appId)) {
            throw new BadRequestException("No such loan application: " + appId);
        }

        // FIX: userEmail arrived null from clients that only sent appId, then failed at
        // the DB. Fall back to the application's owner when loan-service can tell us.
        String effectiveEmail = userEmail;
        if (effectiveEmail == null || effectiveEmail.isBlank()) {
            ApplicationSummaryResponse application = applicationContextService.getApplication(appId);
            effectiveEmail = application == null ? null : application.userEmail();
        }
        if (effectiveEmail == null || effectiveEmail.isBlank()) {
            throw new BadRequestException("userEmail is required (and could not be resolved from " + appId + ")");
        }

        ServiceRequest sr = ServiceRequest.builder()
                .requestId("SR-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase())
                .refNo("SR-REF-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase())
                .appId(appId)
                .userEmail(effectiveEmail)
                .requestType(requestType)
                .description(description)
                .status("Requested")
                .build();

        ServiceRequest saved = repository.save(sr);
        notifyQuietly(saved, "Service request raised",
                "Your " + requestType + " request has been raised. Reference: " + saved.getRefNo());
        return saved;
    }

    public List<ServiceRequest> listForUser(String userEmail) {
        return repository.findByUserEmailAndDeletedAtIsNull(userEmail);
    }

    public List<ServiceRequest> listForApp(String appId) {
        return repository.findByAppIdAndDeletedAtIsNull(appId);
    }

    public ServiceRequest get(String requestId) {
        return repository.findById(requestId)
                .filter(r -> r.getDeletedAt() == null)
                .orElseThrow(() -> new ResourceNotFoundException("Service request not found: " + requestId));
    }

    /**
     * The request plus everything the other services know about its application.
     * This is what the four previously-unused Feign clients were built for.
     */
    public ServiceRequestDetailsResponse getWithDetails(String requestId) {
        ServiceRequest sr = get(requestId);
        ApplicationContextResponse context =
                sr.getAppId() == null ? null : applicationContextService.getFullContext(sr.getAppId());
        return new ServiceRequestDetailsResponse(sr, context);
    }

    @Transactional
    public ServiceRequest updateStatus(String requestId, String status) {
        if (status == null || status.isBlank()) {
            throw new BadRequestException("status is required");
        }
        ServiceRequest sr = get(requestId);
        sr.setStatus(status);
        ServiceRequest saved = repository.save(sr);
        notifyQuietly(saved, "Service request " + status,
                "Request " + saved.getRefNo() + " is now: " + status);
        return saved;
    }

    private void notifyQuietly(ServiceRequest sr, String title, String body) {
        try {
            notificationService.send(sr.getUserEmail(), title, body, null);
        } catch (Exception ex) {
            log.warn("Could not raise notification for service request {}: {}", sr.getRequestId(), ex.toString());
        }
    }
}
