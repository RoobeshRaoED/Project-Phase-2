package com.hlms.notification.entity;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * The converter is the piece that replaced the broken @ElementCollection mapping on
 * Notification.channels, so it has to read rows written by three different producers:
 * this service, another service over SQL, and whatever the old mapping left behind.
 */
class StringListConverterTest {

    private final StringListConverter converter = new StringListConverter();

    @Test
    @DisplayName("writes a list as a plain comma-separated column value")
    void writesCsv() {
        assertThat(converter.convertToDatabaseColumn(List.of("inapp", "email", "sms")))
                .isEqualTo("inapp,email,sms");
    }

    @Test
    @DisplayName("writes null for a null or empty list rather than an empty string")
    void writesNullForEmpty() {
        assertThat(converter.convertToDatabaseColumn(null)).isNull();
        assertThat(converter.convertToDatabaseColumn(new ArrayList<>())).isNull();
    }

    @Test
    @DisplayName("reads a plain CSV value")
    void readsCsv() {
        assertThat(converter.convertToEntityAttribute("inapp,email,sms"))
                .containsExactly("inapp", "email", "sms");
    }

    @Test
    @DisplayName("reads a Postgres array literal written by another service")
    void readsPostgresArrayLiteral() {
        assertThat(converter.convertToEntityAttribute("{inapp,sms}"))
                .containsExactly("inapp", "sms");
    }

    @Test
    @DisplayName("reads a quoted JSON-ish leftover from the old mapping")
    void readsQuotedLeftover() {
        assertThat(converter.convertToEntityAttribute("[\"inapp\",\"email\"]"))
                .containsExactly("inapp", "email");
    }

    @Test
    @DisplayName("trims surrounding whitespace on each channel")
    void trimsWhitespace() {
        assertThat(converter.convertToEntityAttribute("inapp , email ,  sms"))
                .containsExactly("inapp", "email", "sms");
    }

    @Test
    @DisplayName("returns an empty mutable list for null or blank, never null")
    void readsNullAsEmptyMutableList() {
        List<String> fromNull = converter.convertToEntityAttribute(null);
        List<String> fromBlank = converter.convertToEntityAttribute("   ");

        assertThat(fromNull).isEmpty();
        assertThat(fromBlank).isEmpty();
        // Notification.prePersist() and setChannels() both mutate this list, so it must
        // not be one of List.of()'s immutable instances.
        fromNull.add("inapp");
        assertThat(fromNull).containsExactly("inapp");
    }

    @Test
    @DisplayName("a value survives a write/read round trip unchanged")
    void roundTrips() {
        List<String> original = List.of("inapp", "email");
        assertThat(converter.convertToEntityAttribute(converter.convertToDatabaseColumn(original)))
                .isEqualTo(original);
    }
}
