package com.hlms.notification.exception;

import com.hlms.notification.entity.Notification;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.resource.NoResourceFoundException;
import org.springframework.http.HttpMethod;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * These cover the gap the service shipped with: malformed JSON, unknown URLs, a wrong
 * verb and missing query parameters all fell through to @ExceptionHandler(Exception.class)
 * and were reported as 500 Internal Server Error, which blamed the server for what were
 * caller mistakes.
 */
class GlobalExceptionHandlerTest {

    /** Minimal stand-in with the same shapes as NotificationController. */
    @RestController
    @RequestMapping("/api/notifications")
    static class StubController {
        @PostMapping
        public String send(@RequestBody Map<String, Object> body) {
            return "ok";
        }

        @GetMapping
        public List<Notification> list(@RequestParam String userEmail) {
            return List.of();
        }

        @GetMapping("/page")
        public String paged(@RequestParam String userEmail, @RequestParam int size) {
            return "ok";
        }
    }

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(new StubController())
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    @Test
    @DisplayName("malformed JSON is 400, not 500")
    void malformedJsonIsBadRequest() throws Exception {
        mockMvc.perform(post("/api/notifications")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"userEmail\": \"a@hlms.com\", "))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status").value(400))
                .andExpect(jsonPath("$.error").value("Bad Request"));
    }

    @Test
    @DisplayName("the 400 body does not leak the Jackson parser message")
    void malformedJsonDoesNotLeakParserDetail() throws Exception {
        String body = mockMvc.perform(post("/api/notifications")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{ not json at all "))
                .andExpect(status().isBadRequest())
                .andReturn().getResponse().getContentAsString();

        assertThat(body)
                .doesNotContain("com.fasterxml.jackson")
                .doesNotContain("java.util.LinkedHashMap");
    }

    @Test
    @DisplayName("an absent body is 400, not 500")
    void missingBodyIsBadRequest() throws Exception {
        mockMvc.perform(post("/api/notifications").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("a missing required query parameter is 400 and names the parameter")
    void missingQueryParamIsBadRequest() throws Exception {
        mockMvc.perform(get("/api/notifications"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("userEmail")));
    }

    @Test
    @DisplayName("a non-numeric value for a numeric parameter is 400")
    void badParamTypeIsBadRequest() throws Exception {
        mockMvc.perform(get("/api/notifications/page")
                        .param("userEmail", "a@hlms.com")
                        .param("size", "abc"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status").value(400));
    }

    @Test
    @DisplayName("the wrong verb on a real path is 405 and advertises the allowed ones")
    void wrongVerbIsMethodNotAllowed() throws Exception {
        mockMvc.perform(delete("/api/notifications"))
                .andExpect(status().isMethodNotAllowed())
                .andExpect(header().exists("Allow"));
    }

    @Test
    @DisplayName("an unknown URL is 404, not 500")
    void unknownUrlIsNotFound() {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/does-not-exist");
        NoResourceFoundException ex =
                new NoResourceFoundException(HttpMethod.GET, "/api/does-not-exist");

        ResponseEntity<ApiError> response =
                new GlobalExceptionHandler().handleNoResource(ex, request);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().status()).isEqualTo(404);
        assertThat(response.getBody().path()).isEqualTo("/api/does-not-exist");
    }

    @Test
    @DisplayName("a domain ResourceNotFoundException is still 404")
    void resourceNotFoundIsNotFound() {
        MockHttpServletRequest request = new MockHttpServletRequest("PATCH", "/api/notifications/NOPE/read");

        ResponseEntity<ApiError> response = new GlobalExceptionHandler()
                .handleNotFound(new ResourceNotFoundException("Notification not found: NOPE"), request);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        assertThat(response.getBody().message()).contains("NOPE");
    }

    @Test
    @DisplayName("an unexpected exception is still 500 — the catch-all is intact")
    void unexpectedIsStillServerError() {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/notifications");

        ResponseEntity<ApiError> response = new GlobalExceptionHandler()
                .handleGeneric(new IllegalStateException("connection pool exhausted"), request);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(response.getBody().status()).isEqualTo(500);
    }
}
