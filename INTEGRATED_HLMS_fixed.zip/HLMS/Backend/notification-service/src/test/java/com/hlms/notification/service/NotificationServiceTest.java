package com.hlms.notification.service;

import com.hlms.notification.entity.AppUser;
import com.hlms.notification.entity.Notification;
import com.hlms.notification.exception.BadRequestException;
import com.hlms.notification.exception.ResourceNotFoundException;
import com.hlms.notification.repository.AppUserRepository;
import com.hlms.notification.repository.NotificationRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificationServiceTest {

    @Mock
    private NotificationRepository repository;
    @Mock
    private AppUserRepository userRepository;
    @Mock
    private NotificationGateway gateway;

    @InjectMocks
    private NotificationService service;

    private static AppUser userWithPrefs(String email, boolean inapp, boolean email_, boolean sms) {
        AppUser u = new AppUser();
        u.setEmail(email);
        u.setPrefInapp(inapp);
        u.setPrefEmail(email_);
        u.setPrefSms(sms);
        return u;
    }

    // --- validation -------------------------------------------------------

    @Test
    @DisplayName("a missing userEmail is rejected before the DB is touched")
    void rejectsMissingUserEmail() {
        assertThatThrownBy(() -> service.send(null, "Title", "Body", null))
                .isInstanceOf(BadRequestException.class)
                .hasMessageContaining("userEmail");

        assertThatThrownBy(() -> service.send("   ", "Title", "Body", null))
                .isInstanceOf(BadRequestException.class);

        verifyNoInteractions(repository, gateway);
    }

    @Test
    @DisplayName("a missing title is rejected before the DB is touched")
    void rejectsMissingTitle() {
        assertThatThrownBy(() -> service.send("a@hlms.com", " ", "Body", null))
                .isInstanceOf(BadRequestException.class)
                .hasMessageContaining("title");

        verifyNoInteractions(repository, gateway);
    }

    // --- channel resolution (US-NM-04) ------------------------------------

    @Test
    @DisplayName("an explicit channel list from the caller overrides the user's preferences")
    void explicitChannelsWin() {
        when(repository.save(any(Notification.class))).thenAnswer(i -> i.getArgument(0));

        service.send("a@hlms.com", "Title", "Body", List.of("sms"));

        ArgumentCaptor<Notification> saved = ArgumentCaptor.forClass(Notification.class);
        verify(repository).save(saved.capture());
        assertThat(saved.getValue().getChannels()).containsExactly("sms");
        // preferences must not even be looked up when the caller was explicit
        verifyNoInteractions(userRepository);
    }

    @Test
    @DisplayName("with no explicit channels the recipient's preference flags decide")
    void fallsBackToUserPreferences() {
        when(userRepository.findByEmailAndDeletedAtIsNull("a@hlms.com"))
                .thenReturn(Optional.of(userWithPrefs("a@hlms.com", true, true, false)));
        when(repository.save(any(Notification.class))).thenAnswer(i -> i.getArgument(0));

        service.send("a@hlms.com", "Title", "Body", null);

        ArgumentCaptor<Notification> saved = ArgumentCaptor.forClass(Notification.class);
        verify(repository).save(saved.capture());
        assertThat(saved.getValue().getChannels()).containsExactly("inapp", "email");
    }

    @Test
    @DisplayName("an unknown recipient, or one who opted out of everything, still gets in-app")
    void fallsBackToInapp() {
        when(userRepository.findByEmailAndDeletedAtIsNull("ghost@hlms.com")).thenReturn(Optional.empty());
        when(repository.save(any(Notification.class))).thenAnswer(i -> i.getArgument(0));

        service.send("ghost@hlms.com", "Title", "Body", null);

        ArgumentCaptor<Notification> saved = ArgumentCaptor.forClass(Notification.class);
        verify(repository).save(saved.capture());
        assertThat(saved.getValue().getChannels()).containsExactly("inapp");
    }

    // --- persistence and dispatch -----------------------------------------

    @Test
    @DisplayName("a saved notification gets a NOTIF- id and starts unread")
    void savesUnreadWithGeneratedId() {
        when(repository.save(any(Notification.class))).thenAnswer(i -> i.getArgument(0));

        Notification result = service.send("a@hlms.com", "Title", "Body", List.of("inapp"));

        assertThat(result.getNotificationId()).startsWith("NOTIF-");
        assertThat(result.getIsRead()).isFalse();
        assertThat(result.getUserEmail()).isEqualTo("a@hlms.com");
    }

    @Test
    @DisplayName("the gateway is called once per effective channel")
    void dispatchesOnEveryChannel() {
        when(repository.save(any(Notification.class))).thenAnswer(i -> i.getArgument(0));

        service.send("a@hlms.com", "Title", "Body", List.of("inapp", "email", "sms"));

        verify(gateway).dispatch(eq("inapp"), eq("a@hlms.com"), anyString(), any());
        verify(gateway).dispatch(eq("email"), eq("a@hlms.com"), anyString(), any());
        verify(gateway).dispatch(eq("sms"), eq("a@hlms.com"), anyString(), any());
        verifyNoMoreInteractions(gateway);
    }

    @Test
    @DisplayName("a gateway failure does not lose the row or block the other channels")
    void gatewayFailureIsNonFatal() {
        when(repository.save(any(Notification.class))).thenAnswer(i -> i.getArgument(0));
        doThrow(new RuntimeException("SMS provider down"))
                .when(gateway).dispatch(eq("sms"), anyString(), anyString(), any());

        Notification result = service.send("a@hlms.com", "Title", "Body", List.of("sms", "inapp"));

        // this is the whole point of saving before dispatching: the bell still shows it
        assertThat(result.getNotificationId()).isNotNull();
        verify(repository).save(any(Notification.class));
        verify(gateway).dispatch(eq("inapp"), anyString(), anyString(), any());
    }

    // --- markRead ---------------------------------------------------------

    @Test
    @DisplayName("markRead flips isRead and persists")
    void markReadFlipsFlag() {
        Notification existing = Notification.builder()
                .notificationId("NOTIF-1").userEmail("a@hlms.com").title("T")
                .isRead(false).createdAt(OffsetDateTime.now()).build();
        when(repository.findById("NOTIF-1")).thenReturn(Optional.of(existing));
        when(repository.save(any(Notification.class))).thenAnswer(i -> i.getArgument(0));

        assertThat(service.markRead("NOTIF-1").getIsRead()).isTrue();
    }

    @Test
    @DisplayName("markRead on an unknown id is a 404, not a bare NoSuchElementException")
    void markReadUnknownIdIsNotFound() {
        when(repository.findById("NOPE")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.markRead("NOPE"))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("NOPE");
    }

    @Test
    @DisplayName("markRead on a soft-deleted notification is also a 404")
    void markReadSoftDeletedIsNotFound() {
        Notification deleted = Notification.builder()
                .notificationId("NOTIF-2").userEmail("a@hlms.com").title("T")
                .isRead(false).deletedAt(OffsetDateTime.now()).build();
        when(repository.findById("NOTIF-2")).thenReturn(Optional.of(deleted));

        assertThatThrownBy(() -> service.markRead("NOTIF-2"))
                .isInstanceOf(ResourceNotFoundException.class);
        verify(repository, never()).save(any());
    }

    // --- reads ------------------------------------------------------------

    @Test
    @DisplayName("listForUser asks for newest-first and excludes soft-deleted rows")
    void listForUserDelegatesToOrderedQuery() {
        service.listForUser("a@hlms.com");
        verify(repository).findByUserEmailAndDeletedAtIsNullOrderByCreatedAtDesc("a@hlms.com");
    }

    @Test
    @DisplayName("listUnread asks only for isRead=false")
    void listUnreadDelegatesWithFalse() {
        service.listUnread("a@hlms.com");
        verify(repository).findByUserEmailAndIsReadAndDeletedAtIsNull("a@hlms.com", false);
    }
}
