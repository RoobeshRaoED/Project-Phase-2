# Fixes applied on top of the swapped backend

This is on top of `NOTIFICATION_SERVICE_FIXES.md` (your own notification-service repairs,
carried over unchanged). Everything below was applied after the swap.

---

## 1. `BANKOFFICE` role — two endpoints no token could reach

**Files:** `loan-service/.../controller/MortgageController.java` (line 41),
`loan-service/.../controller/StatusTrackingController.java` (line 50)

`UserPrincipal` builds authorities as `ROLE_ + role.toUpperCase()`, and `roleEnum` only
ever produces `BANK_OFFICER`. So the authority is always `ROLE_BANK_OFFICER`, while
`hasAnyRole('BANKOFFICE')` requires `ROLE_BANKOFFICE` — an authority nothing in the system
can issue. Both endpoints returned 403 for every caller including a real bank officer.

```diff
- @PreAuthorize("hasAnyRole('BANKOFFICE','LEGAL','ADMIN')")   // POST /{appId}/evaluate-property
+ @PreAuthorize("hasAnyRole('BANK_OFFICER','LEGAL','ADMIN')")

- @PreAuthorize("hasAnyRole('ADMIN','BANKOFFICE')")           // GET /turnaround-report
+ @PreAuthorize("hasAnyRole('ADMIN','BANK_OFFICER')")
```

Fixed at the controllers rather than by adding `BANKOFFICE` to `roleEnum`, because the
enum, `customerEmploymentProfileController`, and `AppOwnerSecurityAspect` already agree on
`BANK_OFFICER` — these two lines were the only dissenters. Adding a second spelling to the
enum would have meant two role values meaning the same thing and rows in `app_user`
splitting between them. No DB change is needed with this fix.

`grep -rn "BANKOFFICE" --include=*.java .` now returns nothing.

## 2. notification-service returned 500 for caller mistakes

**File:** `notification-service/.../exception/GlobalExceptionHandler.java`

Anything without a specific `@ExceptionHandler` fell into
`@ExceptionHandler(Exception.class)` and came back as 500 Internal Server Error. Added,
each replacing a wrong 500:

| Exception | Was | Now |
|---|---|---|
| `HttpMessageNotReadableException` | 500 | **400** — malformed or missing JSON body |
| `NoResourceFoundException` | 500 | **404** — unknown URL |
| `HttpRequestMethodNotSupportedException` | 500 | **405** + `Allow` header |
| `MissingServletRequestParameterException` | 500 | **400** — names the missing param |
| `MethodArgumentTypeMismatchException` | 500 | **400** — e.g. `?page=abc` |

The 400 for a malformed body deliberately does **not** echo Jackson's message back — that
message contains the parser's view of the payload and the target class name. It is logged
at WARN instead and the client gets a fixed string. There is a test asserting the response
body contains neither.

The catch-all 500 is untouched, so a genuine server fault still reports as one.

The last two rows matter directly for the bell: `GET /api/notifications` with no
`userEmail`, and `/page?size=abc`, are both easy front-end mistakes that previously looked
like the notification service had crashed.

## 3. notification-service had zero tests — 30 added

**New files** under `notification-service/src/test/java/com/hlms/notification/`:

- `entity/StringListConverterTest.java` (8) — the converter that replaced the broken
  `@ElementCollection` mapping. Covers CSV, Postgres array literal `{inapp,sms}`, quoted
  JSON leftovers, whitespace, round-trip, and that a null column yields an **empty mutable**
  list (`prePersist()` and `setChannels()` both mutate it, so `List.of()` would throw).
- `service/NotificationServiceTest.java` (13, Mockito) — blank `userEmail`/`title` rejected
  before the repository is touched; explicit channels beat stored preferences; preference
  flags honoured; unknown recipient falls back to in-app; generated `NOTIF-` id and unread
  default; one `gateway.dispatch` per channel; **a gateway failure does not lose the row or
  block other channels**; `markRead` on unknown *and* soft-deleted ids raises
  `ResourceNotFoundException`.
- `exception/GlobalExceptionHandlerTest.java` (9) — MockMvc standalone for the status codes
  above, plus direct invocation for `NoResourceFoundException` (not reproducible under
  standalone MockMvc), plus one asserting the catch-all still returns 500.

No new dependencies — `spring-boot-starter-test` was already present and brings JUnit 5,
Mockito, AssertJ and Hamcrest.

Run them: `mvn -pl notification-service test`

## 4. `document-service` set `ddl-auto` twice

**File:** `document-service/src/main/resources/application.properties`

`spring.jpa.hibernate.ddl-auto=update` appeared on line 5 and again on line 10. Same value,
so no behaviour change, but the later one silently wins — meaning a future edit to line 5
would have had no effect and been very annoying to debug. Removed the stray first one.

## 5. `PostDisbursementDocumentEntity` — kept your version, not the swap's

**File:** `document-service/.../entity/PostDisbursementDocumentEntity.java`

Your integrated copy used `String fileData` + `@Column(columnDefinition = "TEXT")`; the
incoming backend used `byte[]` + `@Lob`. Yours was kept. Reasons in the previous message —
short version: `ApplicationDocumentEntity` in the same service uses `String`/`TEXT` in both
copies, and with `ddl-auto=update` against an existing Postgres DB, Hibernate 6 maps
`@Lob byte[]` to `oid` and will not migrate an existing `TEXT` column.

Say the word and I'll flip it; it's a one-file change.

---

## Not fixed — flagging, not touching

**`/internal/**` is reachable from the public internet through the gateway.**
`api-gateway` routes `/notification-service/**` to the service with `StripPrefix=1`, and
`SecurityConfig` `permitAll()`s `/internal/**` so `InternalApiKeyFilter` can guard it. Net
effect: `POST http://localhost:8080/notification-service/internal/notifications` with
`X-Internal-Api-Key: test-key` works from any browser, no login. Anyone who can read the
repo can post a notification to any user's bell.

For your demo this is fine and it's genuinely useful for testing Task 4. Before anything
real, one of: exclude `/internal/**` at the gateway predicate, or move the key to an env
var. I'd want your go-ahead before changing a gateway route, so I've left it.

**Every service ships the same placeholder `hlms.jwt.secret`**
(`change-this-to-a-long-random-base64-secret-...`), committed in all six
`application.properties`. Consistent, which is what matters for tokens to validate — just
not a secret. Same story: fine for the demo.

**DB credentials are committed too** (`Housing_Loan_user` / `Loan_Tata@123`, host
`10.23.240.29`) in all seven services. Noting it rather than changing it, since moving
these to env vars would break your VS Code run config, which is Task 4's whole subject.
