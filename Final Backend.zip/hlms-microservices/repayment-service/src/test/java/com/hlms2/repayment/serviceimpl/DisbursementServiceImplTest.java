package com.hlms2.repayment.serviceimpl;

import com.hlms2.repayment.client.LoanServiceClient;
import com.hlms2.repayment.dto.DisbursementDTO;
import com.hlms2.repayment.entity.Disbursement;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.exception.ValidationException;
import com.hlms2.repayment.repository.DisbursementRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DisbursementServiceImplTest {

    @Mock
    private DisbursementRepository repository;

    @Mock
    private LoanServiceClient loanServiceClient;

    private DisbursementServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new DisbursementServiceImpl(repository, loanServiceClient, null, null);
    }

    private DisbursementDTO validDto() {
        DisbursementDTO dto = new DisbursementDTO();
        dto.setAppId("APP-1");
        dto.setAmount(BigDecimal.valueOf(500000));
        dto.setRefNo("REF-001");
        dto.setMode("NEFT");
        dto.setBankDetails("HDFC Bank, A/C 123456");
        return dto;
    }

    // ---------- create() ----------

    @Test
    void create_positive_savesAndDefaultsDisbursedDate() {
        DisbursementDTO dto = validDto();
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        when(repository.save(any(Disbursement.class))).thenAnswer(inv -> {
            Disbursement e = inv.getArgument(0);
            e.setDisbursementId(1L);
            return e;
        });

        DisbursementDTO result = service.create(dto);

        assertThat(result.getDisbursementId()).isEqualTo(1L);
        assertThat(result.getDisbursedDate()).isNotNull();
    }

    @Test
    void create_edge_keepsProvidedDisbursedDate() {
        DisbursementDTO dto = validDto();
        OffsetDateTime past = OffsetDateTime.now().minusDays(2);
        dto.setDisbursedDate(past);
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        when(repository.save(any(Disbursement.class))).thenAnswer(inv -> inv.getArgument(0));

        DisbursementDTO result = service.create(dto);

        assertThat(result.getDisbursedDate()).isEqualTo(past);
    }

    @Test
    void create_negative_missingAppId_throws() {
        DisbursementDTO dto = validDto();
        dto.setAppId(null);

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
        verifyNoInteractions(repository);
    }

    @Test
    void create_negative_duplicateAppId_throws() {
        DisbursementDTO dto = validDto();
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1"))
                .thenReturn(Optional.of(Disbursement.builder().disbursementId(9L).appId("APP-1").build()));

        assertThatThrownBy(() -> service.create(dto))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("already exists");
    }

    @Test
    void create_negative_nonPositiveAmount_throws() {
        DisbursementDTO dto = validDto();
        dto.setAmount(BigDecimal.ZERO);
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_missingRefNo_throws() {
        DisbursementDTO dto = validDto();
        dto.setRefNo(null);
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_invalidMode_throws() {
        DisbursementDTO dto = validDto();
        dto.setMode("CASH");
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_missingBankDetails_throws() {
        DisbursementDTO dto = validDto();
        dto.setBankDetails(null);
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_disbursedDateInFuture_throws() {
        DisbursementDTO dto = validDto();
        dto.setDisbursedDate(OffsetDateTime.now().plusDays(1));
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.create(dto))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("future");
    }

    @Test
    void create_edge_allValidModesAccepted() {
        for (String mode : List.of("NEFT", "RTGS", "CHEQUE", "UPI")) {
            DisbursementDTO dto = validDto();
            dto.setMode(mode);
            when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
            when(repository.save(any(Disbursement.class))).thenAnswer(inv -> inv.getArgument(0));

            assertThat(service.create(dto).getMode()).isEqualTo(mode);
        }
    }

    // ---------- update() ----------

    @Test
    void update_positive_updatesExisting() {
        DisbursementDTO dto = validDto();
        Disbursement existing = Disbursement.builder().disbursementId(1L).appId("APP-1").build();
        when(repository.findByDisbursementIdAndDeletedAtIsNull(1L)).thenReturn(Optional.of(existing));
        when(repository.save(any(Disbursement.class))).thenAnswer(inv -> inv.getArgument(0));

        DisbursementDTO result = service.update(1L, dto);

        assertThat(result.getAppId()).isEqualTo("APP-1");
    }

    @Test
    void update_edge_keepsExistingAppIdWhenDtoAppIdNull() {
        Disbursement existing = Disbursement.builder().disbursementId(1L).appId("APP-1").build();
        when(repository.findByDisbursementIdAndDeletedAtIsNull(1L)).thenReturn(Optional.of(existing));
        when(repository.save(any(Disbursement.class))).thenAnswer(inv -> inv.getArgument(0));

        DisbursementDTO dto = validDto();
        dto.setAppId(null);

        assertThat(service.update(1L, dto).getAppId()).isEqualTo("APP-1");
    }

    @Test
    void update_negative_notFound_throws() {
        when(repository.findByDisbursementIdAndDeletedAtIsNull(404L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.update(404L, validDto())).isInstanceOf(ResourceNotFoundException.class);
    }

    // ---------- softDelete() / restore() ----------

    @Test
    void softDelete_positive_returnsTrue() {
        Disbursement existing = Disbursement.builder().disbursementId(1L).appId("APP-1").build();
        when(repository.findByDisbursementIdAndDeletedAtIsNull(1L)).thenReturn(Optional.of(existing));

        assertThat(service.softDelete(1L)).isTrue();
        assertThat(existing.getDeletedAt()).isNotNull();
    }

    @Test
    void softDelete_negative_notFound_returnsFalse() {
        when(repository.findByDisbursementIdAndDeletedAtIsNull(404L)).thenReturn(Optional.empty());

        assertThat(service.softDelete(404L)).isFalse();
    }

    @Test
    void restore_positive_returnsTrue() {
        Disbursement existing = Disbursement.builder().disbursementId(1L).appId("APP-1")
                .deletedAt(OffsetDateTime.now()).build();
        when(repository.findById(1L)).thenReturn(Optional.of(existing));

        assertThat(service.restore(1L)).isTrue();
    }

    @Test
    void restore_edge_notDeleted_returnsFalse() {
        Disbursement existing = Disbursement.builder().disbursementId(1L).appId("APP-1").build();
        when(repository.findById(1L)).thenReturn(Optional.of(existing));

        assertThat(service.restore(1L)).isFalse();
    }

    // ---------- findById / findByAppId / findAll ----------

    @Test
    void findById_negative_notFound_returnsNull() {
        when(repository.findByDisbursementIdAndDeletedAtIsNull(404L)).thenReturn(Optional.empty());

        assertThat(service.findById(404L)).isNull();
    }

    @Test
    void findByAppId_negative_missingAppId_throws() {
        assertThatThrownBy(() -> service.findByAppId(null)).isInstanceOf(ValidationException.class);
    }

    @Test
    void findByAppId_positive_returnsDto() {
        Disbursement existing = Disbursement.builder().disbursementId(1L).appId("APP-1").build();
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.of(existing));

        assertThat(service.findByAppId("APP-1")).isNotNull();
    }

    @Test
    void findAll_edge_empty() {
        when(repository.findByDeletedAtIsNull()).thenReturn(List.of());

        assertThat(service.findAll()).isEmpty();
    }
}
