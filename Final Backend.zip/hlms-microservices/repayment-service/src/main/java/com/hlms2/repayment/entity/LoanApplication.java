package com.hlms2.repayment.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;

/**
 * JPA entity for 'loan_application'. Ported from hlms2.entity.LoanApplication,
 * trimmed to the columns this service actually reads (it doesn't own this
 * table - that's loan-service's - so this is a read-mostly reference,
 * same treatment as AppUser). Every table this service does own
 * (emi_installment, auction_case, disbursement, insurance_policy) has an
 * app_id foreign key into this one.
 */
@Entity
@Table(name = "loan_application")
public class LoanApplication {

    @Id
    @Column(name = "app_id", length = 50)
    private String appId;

    @JsonIgnore
    @OneToMany(mappedBy = "loanApplication", fetch = FetchType.LAZY)
    private List<EmiInstallment> emiInstallments;

    @JsonIgnore
    @OneToMany(mappedBy = "loanApplication", fetch = FetchType.LAZY)
    private List<InsurancePolicy> insurancePolicies;

    @JsonIgnore
    @OneToOne(mappedBy = "loanApplication", fetch = FetchType.LAZY)
    private AuctionCase auctionCase;

    @JsonIgnore
    @OneToOne(mappedBy = "loanApplication", fetch = FetchType.LAZY)
    private Disbursement disbursement;

    public List<EmiInstallment> getEmiInstallments() {
        return emiInstallments;
    }

    public List<InsurancePolicy> getInsurancePolicies() {
        return insurancePolicies;
    }

    public AuctionCase getAuctionCase() {
        return auctionCase;
    }

    public Disbursement getDisbursement() {
        return disbursement;
    }

    @Column(name = "tracking_no", length = 50)
    private String trackingNo;

    @Column(name = "user_email")
    private String userEmail;

    @Column(name = "product_id")
    private String productId;

    @Column(name = "loan_amount")
    private BigDecimal loanAmount;

    @Column(name = "tenure_years")
    private Integer tenureYears;

    @Column(name = "interest_rate")
    private BigDecimal interestRate;

    @Column(name = "status", length = 30)
    private String status;

    @Column(name = "stage_index")
    private Integer stageIndex;

    @Column(name = "created_at")
    private OffsetDateTime createdAt;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    public LoanApplication() {
    }

    public LoanApplication(String appId, String trackingNo, String userEmail, String productId, BigDecimal loanAmount, Integer tenureYears, BigDecimal interestRate, String status, Integer stageIndex, OffsetDateTime createdAt, OffsetDateTime deletedAt) {
        this.appId = appId;
        this.trackingNo = trackingNo;
        this.userEmail = userEmail;
        this.productId = productId;
        this.loanAmount = loanAmount;
        this.tenureYears = tenureYears;
        this.interestRate = interestRate;
        this.status = status;
        this.stageIndex = stageIndex;
        this.createdAt = createdAt;
        this.deletedAt = deletedAt;
    }

    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public String getTrackingNo() {
        return trackingNo;
    }
    public void setTrackingNo(String trackingNo) {
        this.trackingNo = trackingNo;
    }
    public String getUserEmail() {
        return userEmail;
    }
    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
    public String getProductId() {
        return productId;
    }
    public void setProductId(String productId) {
        this.productId = productId;
    }
    public BigDecimal getLoanAmount() {
        return loanAmount;
    }
    public void setLoanAmount(BigDecimal loanAmount) {
        this.loanAmount = loanAmount;
    }
    public Integer getTenureYears() {
        return tenureYears;
    }
    public void setTenureYears(Integer tenureYears) {
        this.tenureYears = tenureYears;
    }
    public BigDecimal getInterestRate() {
        return interestRate;
    }
    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public Integer getStageIndex() {
        return stageIndex;
    }
    public void setStageIndex(Integer stageIndex) {
        this.stageIndex = stageIndex;
    }
    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }
    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }
    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String appId;
        private String trackingNo;
        private String userEmail;
        private String productId;
        private BigDecimal loanAmount;
        private Integer tenureYears;
        private BigDecimal interestRate;
        private String status;
        private Integer stageIndex;
        private OffsetDateTime createdAt;
        private OffsetDateTime deletedAt;

        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }
        public Builder trackingNo(String trackingNo) {
            this.trackingNo = trackingNo;
            return this;
        }
        public Builder userEmail(String userEmail) {
            this.userEmail = userEmail;
            return this;
        }
        public Builder productId(String productId) {
            this.productId = productId;
            return this;
        }
        public Builder loanAmount(BigDecimal loanAmount) {
            this.loanAmount = loanAmount;
            return this;
        }
        public Builder tenureYears(Integer tenureYears) {
            this.tenureYears = tenureYears;
            return this;
        }
        public Builder interestRate(BigDecimal interestRate) {
            this.interestRate = interestRate;
            return this;
        }
        public Builder status(String status) {
            this.status = status;
            return this;
        }
        public Builder stageIndex(Integer stageIndex) {
            this.stageIndex = stageIndex;
            return this;
        }
        public Builder createdAt(OffsetDateTime createdAt) {
            this.createdAt = createdAt;
            return this;
        }
        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public LoanApplication build() {
            return new LoanApplication(appId, trackingNo, userEmail, productId, loanAmount, tenureYears, interestRate, status, stageIndex, createdAt, deletedAt);
        }
    }
}
