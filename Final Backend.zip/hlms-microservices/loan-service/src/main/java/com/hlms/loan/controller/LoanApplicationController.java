package com.hlms.loan.controller;

import com.hlms.loan.dto.SubmitApplicationRequest;
import com.hlms.loan.entity.LoanApplication;
import com.hlms.loan.service.LoanApplicationService;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.hlms.loan.security.RequireAppOwner;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/loan-applications")
public class LoanApplicationController {

    private final LoanApplicationService service;

    public LoanApplicationController(LoanApplicationService service) {
        this.service = service;
    }

    @GetMapping
    public List<Map<String, Object>> listForUser(@RequestParam String userEmail) {
        return service.listForUser(userEmail)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @GetMapping("/all")
    public List<Map<String, Object>> listAll() {
        return service.listAll()
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @GetMapping("/all/page")
    public Page<Map<String, Object>> listAllPaged(@PageableDefault(size = 20) Pageable pageable) {
        return service.listAll(pageable)
                .map(this::toResponse);
    }

    @GetMapping("/page")
    public Page<Map<String, Object>> listForUserPaged(
            @RequestParam String userEmail,
            @PageableDefault(size = 20) Pageable pageable) {

        return service.listForUser(userEmail, pageable)
                .map(this::toResponse);
    }

    @RequireAppOwner
    @GetMapping("/{appId}")
    public Map<String, Object> get(@PathVariable String appId) {
        return toResponse(service.get(appId));
    }
    @RequireAppOwner
    @GetMapping("/track/{trackingNo}")
    public Map<String, Object> track(@PathVariable String trackingNo) {
        return toResponse(service.getByTrackingNo(trackingNo));
    }

    @GetMapping("/workflow-stages")
    public List<String> workflowStages() {
        return service.workflowStages();
    }

    @PostMapping("/draft")
    public Map<String, Object> saveDraft(
            @RequestParam(required = false) String appId,
            @RequestParam String userEmail,
            @RequestParam(defaultValue = "1") int currentStep,
            @RequestBody SubmitApplicationRequest req) {

        LoanApplication saved = service.saveDraft(appId, userEmail, req, currentStep);
        return toResponse(saved);
    }
    @RequireAppOwner
    @PostMapping("/{appId}/submit")
    public Map<String, Object> submit(@PathVariable String appId) {
        return toResponse(service.submit(appId));
    }
    @RequireAppOwner
    @PatchMapping("/{appId}/stage")
    public Map<String, Object> updateStage(
            @PathVariable String appId,
            @RequestBody Map<String, Object> body) {

        int stageIndex = Number.class.isInstance(body.get("stageIndex"))
                ? ((Number) body.get("stageIndex")).intValue()
                : Integer.parseInt(String.valueOf(body.get("stageIndex")));

        String status = body.get("status") == null
                ? null
                : String.valueOf(body.get("status"));

        return toResponse(service.updateStage(appId, stageIndex, status));
    }

    @RequireAppOwner
    @DeleteMapping("/{appId}")
    public ResponseEntity<Void> withdraw(@PathVariable String appId) {
        service.withdraw(appId);
        return ResponseEntity.noContent().build();
    }

    private Map<String, Object> toResponse(LoanApplication app) {
        Map<String, Object> response = new LinkedHashMap<>();

        response.put("appId", app.getAppId());
        response.put("trackingNo", app.getTrackingNo());
        response.put("userEmail", app.getUserEmail());
        response.put("productId", app.getProductId());

        response.put("loanAmount", app.getLoanAmount());
        response.put("tenureYears", app.getTenureYears());
        response.put("purpose", app.getPurpose());
        response.put("interestRate", app.getInterestRate());

        response.put("status", app.getStatus());
        response.put("stageIndex", app.getStageIndex());
        response.put("currentStep", app.getCurrentStep());
        response.put("formData", app.getFormData());

        response.put("savedAt", app.getSavedAt());
        response.put("createdAt", app.getCreatedAt());

        response.put("applicantName", app.getApplicantName());
        response.put("applicantMobile", app.getApplicantMobile());
        response.put("applicantPan", app.getApplicantPan());

        response.put("addrDoorNo", app.getAddrDoorNo());
        response.put("addrStreet", app.getAddrStreet());
        response.put("addrCity", app.getAddrCity());
        response.put("addrState", app.getAddrState());
        response.put("addrPincode", app.getAddrPincode());

        response.put("employmentType", app.getEmploymentType());
        response.put("employer", app.getEmployer());
        response.put("monthlyIncome", app.getMonthlyIncome());
        response.put("otherEmis", app.getOtherEmis());

        response.put("propertyAddress", app.getPropertyAddress());
        response.put("propertyType", app.getPropertyType());
        response.put("propertyValue", app.getPropertyValue());

        response.put("deletedAt", app.getDeletedAt());
        response.put("accountNumber", app.getAccountNumber());

        return response;
    }
}