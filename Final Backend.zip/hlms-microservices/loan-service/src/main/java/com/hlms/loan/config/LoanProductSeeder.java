package com.hlms.loan.config;

import com.hlms.loan.entity.LoanProduct;
import com.hlms.loan.repository.LoanProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class LoanProductSeeder implements CommandLineRunner {

    private final LoanProductRepository loanProductRepository;

    public LoanProductSeeder(LoanProductRepository loanProductRepository) {
        this.loanProductRepository = loanProductRepository;
    }

    @Override
    public void run(String... args) {

        if (loanProductRepository.count() > 0) {
            return;
        }

        loanProductRepository.save(
                LoanProduct.builder()
                        .productId("HL_PURCHASE")
                        .name("Home Purchase Loan")
                        .category("PURCHASE")
                        .interestRate(new BigDecimal("8.50"))
                        .maxTenureYears(30)
                        .maxLtv("80%")
                        .description("Loan for purchasing a new or resale residential property.")
                        .deletedAt(null)
                        .build()
        );

        loanProductRepository.save(
                LoanProduct.builder()
                        .productId("HL_CONSTRUCTION")
                        .name("Home Construction Loan")
                        .category("CONSTRUCTION")
                        .interestRate(new BigDecimal("8.75"))
                        .maxTenureYears(25)
                        .maxLtv("75%")
                        .description("Loan for constructing a house on owned land.")
                        .deletedAt(null)
                        .build()
        );

        loanProductRepository.save(
                LoanProduct.builder()
                        .productId("HL_BALANCE_TRANSFER")
                        .name("Balance Transfer Loan")
                        .category("BALANCE_TRANSFER")
                        .interestRate(new BigDecimal("8.40"))
                        .maxTenureYears(25)
                        .maxLtv("80%")
                        .description("Transfer your existing home loan from another lender to HLMS.")
                        .deletedAt(null)
                        .build()
        );

        loanProductRepository.save(
                LoanProduct.builder()
                        .productId("HL_TOPUP")
                        .name("Home Loan Top-up")
                        .category("TOPUP")
                        .interestRate(new BigDecimal("9.25"))
                        .maxTenureYears(15)
                        .maxLtv("60%")
                        .description("Additional loan amount for eligible existing home loan customers.")
                        .deletedAt(null)
                        .build()
        );
    }
}