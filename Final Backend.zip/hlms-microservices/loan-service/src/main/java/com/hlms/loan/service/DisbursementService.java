package com.hlms.loan.service;

import com.hlms.loan.entity.Disbursement;
import com.hlms.loan.entity.LoanApplication;
import com.hlms.loan.exception.BadRequestException;
import com.hlms.loan.exception.ResourceNotFoundException;
import com.hlms.loan.repository.DisbursementRepository;
import com.hlms.loan.repository.LoanApplicationRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class DisbursementService {

    private final DisbursementRepository disbursementRepository;
    private final LoanApplicationRepository loanApplicationRepository;

    public DisbursementService(
            DisbursementRepository disbursementRepository,
            LoanApplicationRepository loanApplicationRepository) {

        this.disbursementRepository = disbursementRepository;
        this.loanApplicationRepository = loanApplicationRepository;
    }

    public List<Disbursement> listAll() {
        return disbursementRepository.findAll()
                .stream()
                .filter(disbursement -> disbursement.getDeletedAt() == null)
                .toList();
    }

    public Disbursement getByAppId(String appId) {
        return disbursementRepository.findByAppIdAndDeletedAtIsNull(appId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Disbursement not found for application: " + appId));
    }

    @Transactional
    public Disbursement createOrUpdate(Disbursement req) {
        if (req == null) {
            throw new BadRequestException("Disbursement request is required.");
        }

        if (req.getAppId() == null || req.getAppId().trim().isEmpty()) {
            throw new BadRequestException("Application ID is required.");
        }

        LoanApplication app = loanApplicationRepository.findById(req.getAppId())
                .filter(loanApplication -> loanApplication.getDeletedAt() == null)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Loan application not found: " + req.getAppId()));

        if (app.getAccountNumber() == null || app.getAccountNumber().trim().isEmpty()) {
            throw new BadRequestException("Customer bank account number is missing in loan application.");
        }

        Disbursement disbursement = disbursementRepository
                .findByAppIdAndDeletedAtIsNull(req.getAppId())
                .orElseGet(Disbursement::new);

        disbursement.setAppId(req.getAppId());

        if (req.getAmount() != null) {
            disbursement.setAmount(req.getAmount());
        } else {
            disbursement.setAmount(app.getLoanAmount());
        }

        if (req.getDisbursedDate() != null) {
            disbursement.setDisbursedDate(req.getDisbursedDate());
        } else {
            disbursement.setDisbursedDate(OffsetDateTime.now());
        }

        if (req.getRefNo() != null && !req.getRefNo().trim().isEmpty()) {
            disbursement.setRefNo(req.getRefNo());
        } else if (disbursement.getRefNo() == null || disbursement.getRefNo().trim().isEmpty()) {
            disbursement.setRefNo(generateReferenceNumber());
        }

        if (req.getMode() != null && !req.getMode().trim().isEmpty()) {
            disbursement.setMode(req.getMode());
        } else if (disbursement.getMode() == null || disbursement.getMode().trim().isEmpty()) {
            disbursement.setMode("BANK_TRANSFER");
        }

        /*
         * Customer account number is collected during Apply Loan.
         * Here it is copied from loan_application.account_number
         * into disbursement.bank_details.
         */
        disbursement.setBankDetails(app.getAccountNumber());

        Disbursement saved = disbursementRepository.save(disbursement);

        /*
         * After disbursement, the loan application becomes Active.
         */
        app.setStatus("Active");
        app.setStageIndex(6);
        loanApplicationRepository.save(app);

        return saved;
    }

    @Transactional
    public void deleteByAppId(String appId) {
        Disbursement disbursement = getByAppId(appId);
        disbursement.setDeletedAt(OffsetDateTime.now());
        disbursementRepository.save(disbursement);
    }

    private String generateReferenceNumber() {
        return "DISB-" + UUID.randomUUID()
                .toString()
                .substring(0, 8)
                .toUpperCase();
    }
}