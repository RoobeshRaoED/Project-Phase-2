package com.hlms.loan.controller;

import com.hlms.loan.entity.Disbursement;
import com.hlms.loan.service.DisbursementService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/disbursements")
public class DisbursementController {

    private final DisbursementService service;

    public DisbursementController(DisbursementService service) {
        this.service = service;
    }

    @GetMapping
    public List<Map<String, Object>> listAll() {
        return service.listAll()
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @GetMapping("/app/{appId}")
    public Map<String, Object> getByAppId(@PathVariable String appId) {
        return toResponse(service.getByAppId(appId));
    }

    @PostMapping
    public Map<String, Object> createOrUpdate(@RequestBody Disbursement req) {
        return toResponse(service.createOrUpdate(req));
    }

    @DeleteMapping("/app/{appId}")
    public ResponseEntity<Void> deleteByAppId(@PathVariable String appId) {
        service.deleteByAppId(appId);
        return ResponseEntity.noContent().build();
    }

    private Map<String, Object> toResponse(Disbursement disbursement) {
        Map<String, Object> response = new LinkedHashMap<>();

        response.put("disbursementId", disbursement.getDisbursementId());
        response.put("appId", disbursement.getAppId());
        response.put("disbursedDate", disbursement.getDisbursedDate());
        response.put("amount", disbursement.getAmount());
        response.put("refNo", disbursement.getRefNo());
        response.put("mode", disbursement.getMode());
        response.put("bankDetails", disbursement.getBankDetails());
        response.put("deletedAt", disbursement.getDeletedAt());

        return response;
    }
}