# HLMS Angular 19 Home, Login, Register

This project is generated from scratch using Angular 19.0.0.

It contains only:

- Home page
- Login page
- Register page

The design uses the provided HLMS images exactly like the reference HTML/CSS:

- `src/assets/Designer (1).png` for navbar logo and favicon
- `src/assets/Designer.png` for hero image and auth side image

## Angular version

Pinned in `package.json`:

```json
"@angular/core": "19.0.0",
"@angular/cli": "19.0.0"
```


## If you see TS7016 for @angular/core

Do not install `@types/angular__core`. Angular packages already include their own `.d.ts` declaration files. This error usually means `node_modules` or `package-lock.json` was created with a broken or mismatched install.

Use this clean install sequence on Windows PowerShell from the project folder:

```powershell
rmdir /s /q node_modules
del package-lock.json
npm cache verify
npm install
npm start
```

Also check Node.js version:

```bash
node -v
```

Angular 19.0.x requires Node.js `^18.19.1 || ^20.11.1 || ^22.0.0` and TypeScript `>=5.5.0 <5.7.0`. This project uses TypeScript `~5.6.3`.

## Run frontend

```bash
npm install
npm start
```

`npm start` runs:

```bash
ng serve --proxy-config proxy.conf.json --open
```

## Why proxy is added

Your Angular app runs on:

```txt
http://localhost:4200
```

Your backend runs on:

```txt
http://localhost:8081
```

Even if `@CrossOrigin` is added in controller, Spring Security can still block preflight `OPTIONS` requests. The Angular proxy forwards frontend calls like this:

```txt
Angular: /api/users/register
Proxy:   http://localhost:8081/api/users/register
```

This avoids browser CORS during local development.

## Backend endpoints integrated

```txt
POST /api/users/register
POST /api/users/login
GET  /api/users/{email}
```

## Register payload sent by frontend

This project sends field names matching your database insert columns and the previous backend error:

```json
{
  "name": "Mohan Prasath R",
  "mobile": "9876543210",
  "email": "mohan@gmail.com",
  "password": "Password@123",
  "role": "CUSTOMER"
}
```

If your `RegisterRequestDTO` currently uses `fullName` or `mobileNumber`, either change the DTO to `name` and `mobile`, or map DTO values to entity fields in your service.

## Validations used from Team A List of Validation.docx

Only validations applicable to Home/Login/Register are implemented:

- VR01 Full Name
- VR02 Mobile Number
- VR03 Email Address
- VR04 Password
- VR05 Confirm Password

Not implemented because these fields are not present on Home/Login/Register:

- DOB
- Aadhaar
- PAN
- income
- loan amount
- document upload
- property details
- workflow, EMI, auction and repayment rules

## Recommended Spring Boot CORS with Spring Security

If you still want direct frontend to backend calls without proxy, add CORS in Spring Security, not only in controllers.

```java
package com.hlms.UserServices.Config;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@Configuration
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers(
                    "/api/users/register",
                    "/api/users/login",
                    "/api/users/forgot-password",
                    "/api/users/reset-password",
                    "/api/otp/generate",
                    "/api/otp/verify",
                    "/v3/api-docs/**",
                    "/swagger-ui/**",
                    "/swagger-ui.html"
                ).permitAll()
                .anyRequest().authenticated()
            );

        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(List.of("http://localhost:4200"));
        configuration.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(List.of("*"));
        configuration.setAllowCredentials(true);
        configuration.setExposedHeaders(List.of("Authorization"));

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/api/**", configuration);
        return source;
    }
}
```

## Controller-level CORS if you do not use Spring Security

```java
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/users")
public class appUserController {
}
```

## Common connection checklist

1. Start backend first on port 8081.
2. Start Angular with `npm start`, not `ng serve` directly, so proxy is enabled.
3. Check browser Network tab. The request URL should be `/api/users/register`, not `http://localhost:8081/api/users/register`.
4. If you still get 401 or 403, permit `/api/users/register` and `/api/users/login` in `SecurityConfig`.
5. If you get null `mobile`, check that backend accepts JSON field `mobile`.

## Latest requested updates

The register page now includes:

- Privacy Policy view and required acceptance checkbox.
- Account Type dropdown with `Customer` and `Bidder`.
- Register payload includes `accountType` along with existing fields.

The login page now includes:

- Two step login flow.
- Step 1: email and password validation.
- Step 2: static demo OTP verification.
- Static OTP displayed on screen: `123456`.
- Backend `/api/users/login` is called only after OTP is verified.

If your backend DTO does not have `accountType`, either add it in `RegisterRequestDTO`, or remove `accountType` from `register.component.ts` payload. Spring Boot usually ignores unknown JSON fields if configured with default Spring Boot Jackson settings, but custom configuration may reject it.

## Latest UI refinement

- Login no longer shows password rule bullets. It only shows the required error message.
- OTP screen now uses six individual OTP boxes and static OTP `881695`.
- Privacy Policy now opens as a modal popup.
- Privacy checkbox inside the modal remains disabled until the user scrolls to the end of the policy.
- Save is enabled only after scrolling and checking the policy acceptance box.

## Latest update: forgot password and OTP navigation

- Added Forgot Password modal on the login page.
- Forgot Password calls `POST /api/users/forgot-password` through the Angular proxy.
- Improved OTP keyboard navigation:
  - Typing a digit moves to the next box.
  - Backspace clears the current box or moves back and clears the previous box.
  - Left and right arrow keys move between OTP boxes.
  - Pasting a 6 digit OTP fills the OTP boxes automatically.
- Resend OTP now generates and displays a new random 6 digit demo OTP.

## Latest update: Forgot password OTP API flow

- Forgot Password now has email input, OTP generation, and OTP verification.
- The flow calls `POST /api/users/forgot-password` and `POST /api/otp/generate` when the user clicks Send OTP.
- The OTP displayed in the modal is parsed from the `/api/otp/generate` API response.
- OTP verification calls `POST /api/otp/verify` with `{ email, otpCode }`.
- OTP key navigation was changed to prevent one typed digit from being placed into two boxes.
- OTP boxes support digit typing, backspace, left/right arrows, and paste.

## Latest update: static OTP for login and forgot password

- Login OTP is generated inside `login.component.ts` using `generateOtpStatic()`.
- Forgot Password first calls the backend `POST /api/users/forgot-password` API.
- After the Forgot Password API succeeds, Angular generates and displays a demo OTP using `generateOtpStatic()`.
- OTP verification for Login and Forgot Password uses `verifyOtpStatic(generatedOtp, enteredOtp)`.
- OTP generation and verification APIs are not called from the UI.
- Resend OTP generates a new local random OTP.
- OTP box handling was changed so one typed digit fills only one box.


## Latest update: OTP input and guard folder

- Removed the visible API information note from the login screen.
- Added `src/app/core/guards/auth.guard.ts` for route protection structure.
- OTP key handling was adjusted so a single key press fills only the current OTP box, then moves to the next box.
- Backspace clears the current box or moves back correctly.
- Left and right arrow keys move between OTP boxes.


## Latest update: account type to backend role mapping

- Register page now sends backend `role` based on selected Account Type.
- If Account Type is `Customer`, payload sends `role: "CUSTOMER"`.
- If Account Type is `Bidder`, payload sends `role: "BIDDER"`.
- `UserRole` type now includes `BIDDER`.

Backend reminder: make sure your backend enum/entity accepts `BIDDER` as a valid role value, otherwise the database insert will fail.

## Latest update: fixed OTP validation and reset password flow

- OTP input uses one `input` handler for digits and one `keydown` handler for navigation only to prevent duplicate focus movement.
- OTP verification combines all six digits and compares exactly with the generated OTP.
- OTP expiry is enforced for 5 minutes.
- Forgot Password now calls `/api/users/forgot-password`, then verifies a demo OTP in Angular.
- After OTP verification, the user can enter New Password and Confirm Password.
- Reset Password calls `/api/users/reset-password` with email, otpCode, and newPassword.
- Backend must hash the password before saving it and must update the correct user record.
