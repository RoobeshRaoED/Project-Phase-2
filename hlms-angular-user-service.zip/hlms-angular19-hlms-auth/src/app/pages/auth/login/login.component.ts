import { CommonModule } from '@angular/common';
import { Component, ElementRef, QueryList, ViewChildren } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { AuthService } from '../../../core/services/auth.service';
import { readableApiError } from '../../../core/services/api-error.util';
import { HlmsValidators } from '../../../core/validators/hlms-validators';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './login.component.html'
})
export class LoginComponent {
  @ViewChildren('loginOtpBox') loginOtpInputs!: QueryList<ElementRef<HTMLInputElement>>;
  @ViewChildren('forgotOtpBox') forgotOtpInputs!: QueryList<ElementRef<HTMLInputElement>>;

  showPassword = false;
  showResetPassword = false;
  showConfirmResetPassword = false;

  loading = false;
  apiError = '';
  successMessage = '';

  otpStep = false;
  currentOtp = '';
  loginOtpGeneratedAt = 0;
  otpDigits = ['', '', '', '', '', ''];
  readonly otpExpiryMs = 5 * 60 * 1000;

  showForgotPassword = false;
  forgotLoading = false;
  forgotVerifying = false;
  resetLoading = false;
  forgotMessage = '';
  forgotError = '';
  forgotOtpStep = false;
  forgotOtpVerified = false;
  forgotGeneratedOtp = '';
  forgotOtpGeneratedAt = 0;
  forgotOtpDigits = ['', '', '', '', '', ''];

  form = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.email, Validators.maxLength(100)]],
    password: ['', [Validators.required, HlmsValidators.password()]]
  });

  forgotForm = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.email, Validators.maxLength(100)]]
  });

  resetForm = this.fb.nonNullable.group({
    newPassword: ['', [Validators.required, HlmsValidators.password()]],
    confirmPassword: ['', [Validators.required]]
  }, { validators: [HlmsValidators.matchPassword('newPassword', 'confirmPassword')] });

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {}

  continueToOtp(): void {
    this.apiError = '';
    this.successMessage = '';
    this.form.markAllAsTouched();
    if (this.form.invalid) return;

    this.currentOtp = this.generateOtpStatic();
    this.loginOtpGeneratedAt = Date.now();
    this.otpStep = true;
    this.resetOtpBoxes(this.otpDigits, this.loginOtpInputs);
    setTimeout(() => this.focusOtp(this.loginOtpInputs, 0), 0);
  }

  submit(): void {
    if (!this.otpStep) {
      this.continueToOtp();
      return;
    }
    this.verifyOtpAndLogin();
  }

  onLoginOtpInput(event: Event, index: number): void {
    this.handleOtpInput(event, index, this.otpDigits, this.loginOtpInputs);
  }

  onLoginOtpKeydown(event: KeyboardEvent, index: number): void {
    this.handleOtpKeydown(event, index, this.otpDigits, this.loginOtpInputs);
  }

  onLoginOtpPaste(event: ClipboardEvent, index: number): void {
    this.handleOtpPaste(event, index, this.otpDigits, this.loginOtpInputs);
  }

  verifyOtpAndLogin(): void {
    this.apiError = '';
    this.successMessage = '';

    const enteredOtp = this.otpDigits.join('');
    const validationMessage = this.validateOtp(this.currentOtp, enteredOtp, this.loginOtpGeneratedAt);
    if (validationMessage) {
      this.apiError = validationMessage;
      return;
    }

    const value = this.form.getRawValue();
    this.loading = true;
    this.authService.login({
      email: value.email.trim(),
      password: value.password
    }).pipe(finalize(() => (this.loading = false))).subscribe({
      next: () => {
        this.successMessage = 'OTP verified successfully. Login successful.';
        setTimeout(() => this.router.navigateByUrl('/'), 700);
      },
      error: (error) => {
        this.apiError = readableApiError(error, 'Login failed. Please check email, password, backend port, and Spring Security settings.');
      }
    });
  }

  resendOtp(): void {
    this.currentOtp = this.generateOtpStatic();
    this.loginOtpGeneratedAt = Date.now();
    this.resetOtpBoxes(this.otpDigits, this.loginOtpInputs);
    this.apiError = '';
    this.successMessage = 'A new demo OTP has been generated.';
    setTimeout(() => this.focusOtp(this.loginOtpInputs, 0), 0);
  }

  backToCredentials(): void {
    this.otpStep = false;
    this.apiError = '';
    this.successMessage = '';
    this.currentOtp = '';
    this.loginOtpGeneratedAt = 0;
    this.resetOtpBoxes(this.otpDigits, this.loginOtpInputs);
  }

  openForgotPassword(): void {
    this.showForgotPassword = true;
    this.forgotError = '';
    this.forgotMessage = '';
    this.forgotOtpStep = false;
    this.forgotOtpVerified = false;
    this.forgotGeneratedOtp = '';
    this.forgotOtpGeneratedAt = 0;
    this.resetForm.reset();
    this.resetOtpBoxes(this.forgotOtpDigits, this.forgotOtpInputs);

    const email = this.form.controls.email.value.trim();
    if (email) this.forgotForm.controls.email.setValue(email);
    setTimeout(() => document.getElementById('forgotEmail')?.focus(), 0);
  }

  closeForgotPassword(): void {
    this.showForgotPassword = false;
    this.forgotError = '';
    this.forgotMessage = '';
    this.forgotOtpStep = false;
    this.forgotOtpVerified = false;
    this.forgotGeneratedOtp = '';
    this.forgotOtpGeneratedAt = 0;
    this.resetOtpBoxes(this.forgotOtpDigits, this.forgotOtpInputs);
  }

  sendForgotOtp(): void {
    this.forgotError = '';
    this.forgotMessage = '';
    this.forgotForm.markAllAsTouched();
    if (this.forgotForm.invalid) return;

    const email = this.forgotForm.controls.email.value.trim();
    this.forgotLoading = true;

    this.authService.forgotPassword({ email })
      .pipe(finalize(() => (this.forgotLoading = false)))
      .subscribe({
        next: (message) => {
          this.forgotGeneratedOtp = this.generateOtpStatic();
          this.forgotOtpGeneratedAt = Date.now();
          this.forgotOtpStep = true;
          this.forgotOtpVerified = false;
          this.forgotMessage = message || 'Forgot password request accepted. Use the demo OTP displayed above.';
          this.resetOtpBoxes(this.forgotOtpDigits, this.forgotOtpInputs);
          setTimeout(() => this.focusOtp(this.forgotOtpInputs, 0), 0);
        },
        error: (error) => {
          this.forgotError = readableApiError(error, 'Forgot password request failed. Please check the email and backend API.');
        }
      });
  }

  resendForgotOtp(): void {
    this.forgotError = '';
    this.forgotMessage = 'A new demo OTP has been generated.';
    this.forgotGeneratedOtp = this.generateOtpStatic();
    this.forgotOtpGeneratedAt = Date.now();
    this.forgotOtpVerified = false;
    this.resetForm.reset();
    this.resetOtpBoxes(this.forgotOtpDigits, this.forgotOtpInputs);
    setTimeout(() => this.focusOtp(this.forgotOtpInputs, 0), 0);
  }

  onForgotOtpInput(event: Event, index: number): void {
    this.handleOtpInput(event, index, this.forgotOtpDigits, this.forgotOtpInputs);
  }

  onForgotOtpKeydown(event: KeyboardEvent, index: number): void {
    this.handleOtpKeydown(event, index, this.forgotOtpDigits, this.forgotOtpInputs);
  }

  onForgotOtpPaste(event: ClipboardEvent, index: number): void {
    this.handleOtpPaste(event, index, this.forgotOtpDigits, this.forgotOtpInputs);
  }

  verifyForgotOtp(): void {
    this.forgotError = '';
    this.forgotMessage = '';

    const enteredOtp = this.forgotOtpDigits.join('');
    const validationMessage = this.validateOtp(this.forgotGeneratedOtp, enteredOtp, this.forgotOtpGeneratedAt);
    if (validationMessage) {
      this.forgotError = validationMessage;
      return;
    }

    this.forgotVerifying = true;
    setTimeout(() => {
      this.forgotVerifying = false;
      this.forgotOtpVerified = true;
      this.forgotMessage = 'OTP verified successfully. Enter your new password.';
      setTimeout(() => document.getElementById('newPassword')?.focus(), 0);
    }, 250);
  }

  resetPassword(): void {
    this.forgotError = '';
    this.forgotMessage = '';

    if (!this.forgotOtpVerified) {
      this.forgotError = 'OTP verification required before password reset.';
      return;
    }

    this.resetForm.markAllAsTouched();
    if (this.resetForm.invalid) return;

    const email = this.forgotForm.controls.email.value.trim();
    const value = this.resetForm.getRawValue();

    this.resetLoading = true;
    this.authService.resetPassword({
      email,
      otpCode: this.forgotGeneratedOtp,
      newPassword: value.newPassword
    }).pipe(finalize(() => (this.resetLoading = false))).subscribe({
      next: (message) => {
        this.forgotMessage = message || 'Password reset successful. You can log in with the new password.';
        setTimeout(() => this.closeForgotPassword(), 1200);
      },
      error: (error) => {
        this.forgotError = readableApiError(error, 'Password reset failed. Please verify backend reset-password implementation and database update.');
      }
    });
  }

  hasError(field: 'email' | 'password', error: string): boolean {
    const control = this.form.controls[field];
    return control.touched && control.hasError(error);
  }

  hasForgotEmailError(error: string): boolean {
    const control = this.forgotForm.controls.email;
    return control.touched && control.hasError(error);
  }

  hasResetError(field: 'newPassword' | 'confirmPassword', error: string): boolean {
    const control = this.resetForm.controls[field];
    return control.touched && control.hasError(error);
  }

  get resetPasswordMismatch(): boolean {
    return this.resetForm.touched && this.resetForm.hasError('passwordMismatch');
  }

  generateOtpStatic(): string {
    return Math.floor(100000 + Math.random() * 900000).toString();
  }

  verifyOtpStatic(generatedOtp: string, enteredOtp: string): boolean {
    return generatedOtp === enteredOtp;
  }

  private validateOtp(generatedOtp: string, enteredOtp: string, generatedAt: number): string {
    if (enteredOtp.length !== 6) return 'Enter the complete 6 digit OTP.';
    if (!generatedOtp || !generatedAt) return 'OTP not generated. Please resend OTP.';
    if (Date.now() - generatedAt > this.otpExpiryMs) return 'OTP expired. Please resend OTP.';
    if (!this.verifyOtpStatic(generatedOtp, enteredOtp)) return 'Invalid OTP';
    return '';
  }

  private handleOtpInput(event: Event, index: number, digits: string[], inputs: QueryList<ElementRef<HTMLInputElement>>): void {
    const input = event.target as HTMLInputElement;
    const numericValue = input.value.replace(/\D/g, '');

    if (!numericValue) {
      digits[index] = '';
      input.value = '';
      return;
    }

    if (numericValue.length > 1) {
      this.fillOtpFromText(numericValue, index, digits, inputs);
      return;
    }

    digits[index] = numericValue;
    input.value = numericValue;

    if (index < digits.length - 1) {
      setTimeout(() => this.focusOtp(inputs, index + 1), 0);
    }
  }

  private handleOtpKeydown(event: KeyboardEvent, index: number, digits: string[], inputs: QueryList<ElementRef<HTMLInputElement>>): void {
    const allowedKeys = ['Tab', 'Shift', 'Home', 'End'];
    if (/^\d$/.test(event.key) || allowedKeys.includes(event.key)) return;

    if (event.key === 'Backspace') {
      event.preventDefault();
      if (digits[index]) {
        digits[index] = '';
        this.setOtpInputValue(inputs, index, '');
      } else if (index > 0) {
        digits[index - 1] = '';
        this.setOtpInputValue(inputs, index - 1, '');
        this.focusOtp(inputs, index - 1);
      }
      return;
    }

    if (event.key === 'ArrowLeft' && index > 0) {
      event.preventDefault();
      this.focusOtp(inputs, index - 1);
      return;
    }

    if (event.key === 'ArrowRight' && index < digits.length - 1) {
      event.preventDefault();
      this.focusOtp(inputs, index + 1);
      return;
    }

    event.preventDefault();
  }

  private handleOtpPaste(event: ClipboardEvent, index: number, digits: string[], inputs: QueryList<ElementRef<HTMLInputElement>>): void {
    event.preventDefault();
    const pastedText = event.clipboardData?.getData('text') || '';
    this.fillOtpFromText(pastedText, index, digits, inputs);
  }

  private fillOtpFromText(text: string, startIndex: number, digits: string[], inputs: QueryList<ElementRef<HTMLInputElement>>): void {
    const pastedDigits = text.replace(/\D/g, '').slice(0, digits.length - startIndex).split('');
    pastedDigits.forEach((digit, offset) => {
      const targetIndex = startIndex + offset;
      digits[targetIndex] = digit;
      this.setOtpInputValue(inputs, targetIndex, digit);
    });
    const nextIndex = Math.min(startIndex + pastedDigits.length, digits.length - 1);
    setTimeout(() => this.focusOtp(inputs, nextIndex), 0);
  }

  private focusOtp(inputs: QueryList<ElementRef<HTMLInputElement>>, index: number): void {
    const input = inputs.get(index)?.nativeElement;
    input?.focus();
    input?.select();
  }

  private setOtpInputValue(inputs: QueryList<ElementRef<HTMLInputElement>>, index: number, value: string): void {
    const input = inputs.get(index)?.nativeElement;
    if (input) input.value = value;
  }

  private resetOtpBoxes(digits: string[], inputs: QueryList<ElementRef<HTMLInputElement>>): void {
    digits.splice(0, digits.length, '', '', '', '', '', '');
    setTimeout(() => inputs?.forEach((input) => (input.nativeElement.value = '')), 0);
  }
}
