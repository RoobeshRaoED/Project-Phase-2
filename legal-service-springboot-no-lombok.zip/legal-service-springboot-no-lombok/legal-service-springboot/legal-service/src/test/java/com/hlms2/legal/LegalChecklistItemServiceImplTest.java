package com.hlms2.legal;

import com.hlms2.legal.dto.LegalChecklistItemDTO;
import com.hlms2.legal.entity.LegalChecklistItem;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.exception.ValidationException;
import com.hlms2.legal.repository.LegalChecklistItemRepository;
import com.hlms2.legal.serviceimpl.LegalChecklistItemServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LegalChecklistItemServiceImplTest {

    @Mock
    private LegalChecklistItemRepository repository;

    @InjectMocks
    private LegalChecklistItemServiceImpl service;

    private LegalChecklistItemDTO validDto;

    @BeforeEach
    void setUp() {
        validDto = LegalChecklistItemDTO.builder()
                .appId("APP-1")
                .checklistKey("TITLE_DEED_VERIFIED")
                .build();
    }

    private void stubSaveReturnsArgument() {
        when(repository.save(any(LegalChecklistItem.class))).thenAnswer(inv -> inv.getArgument(0));
    }

    // ---------- create() ----------

    @Test
    void create_success_generatesChecklistItemId_whenNull() {
        stubSaveReturnsArgument();

        LegalChecklistItemDTO result = service.create(validDto);

        assertNotNull(result.getChecklistItemId());
        assertTrue(result.getChecklistItemId().startsWith("CHK-"));
    }

    @Test
    void create_success_generatesChecklistItemId_whenBlank() {
        validDto.setChecklistItemId("   ");
        stubSaveReturnsArgument();

        LegalChecklistItemDTO result = service.create(validDto);

        assertNotNull(result.getChecklistItemId());
        assertTrue(result.getChecklistItemId().startsWith("CHK-"));
    }

    @Test
    void create_usesProvidedChecklistItemId() {
        validDto.setChecklistItemId("CHK-CUSTOM01");
        stubSaveReturnsArgument();

        LegalChecklistItemDTO result = service.create(validDto);

        assertEquals("CHK-CUSTOM01", result.getChecklistItemId());
    }

    @Test
    void create_defaultsStatusToPending_whenNotProvided() {
        stubSaveReturnsArgument();

        LegalChecklistItemDTO result = service.create(validDto);

        assertEquals("PENDING", result.getStatus());
    }

    @Test
    void create_usesProvidedStatus() {
        validDto.setStatus("COMPLETED");
        stubSaveReturnsArgument();

        LegalChecklistItemDTO result = service.create(validDto);

        assertEquals("COMPLETED", result.getStatus());
    }

    @Test
    void create_missingAppId_throwsValidationException() {
        validDto.setAppId(null);

        assertThrows(ValidationException.class, () -> service.create(validDto));
        verifyNoInteractions(repository);
    }

    @Test
    void create_missingChecklistKey_throwsValidationException() {
        validDto.setChecklistKey(null);

        assertThrows(ValidationException.class, () -> service.create(validDto));
    }

    @Test
    void create_invalidStatus_throwsValidationException_whenProvided() {
        validDto.setStatus("NOT_A_REAL_STATUS");

        assertThrows(ValidationException.class, () -> service.create(validDto));
    }

    // ---------- update() ----------

    @Test
    void update_success() {
        validDto.setChecklistItemId("CHK-1");
        when(repository.findByChecklistItemIdAndDeletedAtIsNull("CHK-1"))
                .thenReturn(Optional.of(LegalChecklistItem.builder().checklistItemId("CHK-1").build()));
        stubSaveReturnsArgument();

        LegalChecklistItemDTO result = service.update(validDto);

        assertEquals("CHK-1", result.getChecklistItemId());
    }

    @Test
    void update_missingChecklistItemId_throwsValidationException() {
        assertThrows(ValidationException.class, () -> service.update(validDto));
        verifyNoInteractions(repository);
    }

    @Test
    void update_notFound_throwsResourceNotFoundException() {
        validDto.setChecklistItemId("CHK-404");
        when(repository.findByChecklistItemIdAndDeletedAtIsNull("CHK-404")).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.update(validDto));
    }

    @Test
    void update_invalidStatus_throwsValidationException() {
        validDto.setChecklistItemId("CHK-1");
        validDto.setStatus("BOGUS");
        when(repository.findByChecklistItemIdAndDeletedAtIsNull("CHK-1"))
                .thenReturn(Optional.of(LegalChecklistItem.builder().checklistItemId("CHK-1").build()));

        assertThrows(ValidationException.class, () -> service.update(validDto));
    }

    // ---------- softDelete() ----------

    @Test
    void softDelete_found_returnsTrue() {
        LegalChecklistItem existing = LegalChecklistItem.builder().checklistItemId("CHK-1").build();
        when(repository.findByChecklistItemIdAndDeletedAtIsNull("CHK-1")).thenReturn(Optional.of(existing));
        ArgumentCaptor<LegalChecklistItem> captor = ArgumentCaptor.forClass(LegalChecklistItem.class);
        when(repository.save(captor.capture())).thenAnswer(inv -> inv.getArgument(0));

        assertTrue(service.softDelete("CHK-1"));
        assertNotNull(captor.getValue().getDeletedAt());
    }

    @Test
    void softDelete_notFound_returnsFalse() {
        when(repository.findByChecklistItemIdAndDeletedAtIsNull("CHK-404")).thenReturn(Optional.empty());

        assertFalse(service.softDelete("CHK-404"));
    }

    // ---------- restore() ----------

    @Test
    void restore_foundAndDeleted_returnsTrue() {
        LegalChecklistItem existing = LegalChecklistItem.builder().checklistItemId("CHK-1")
                .deletedAt(OffsetDateTime.now()).build();
        when(repository.findById("CHK-1")).thenReturn(Optional.of(existing));
        ArgumentCaptor<LegalChecklistItem> captor = ArgumentCaptor.forClass(LegalChecklistItem.class);
        when(repository.save(captor.capture())).thenAnswer(inv -> inv.getArgument(0));

        assertTrue(service.restore("CHK-1"));
        assertNull(captor.getValue().getDeletedAt());
    }

    @Test
    void restore_foundButNotDeleted_returnsFalse() {
        LegalChecklistItem existing = LegalChecklistItem.builder().checklistItemId("CHK-1").deletedAt(null).build();
        when(repository.findById("CHK-1")).thenReturn(Optional.of(existing));

        assertFalse(service.restore("CHK-1"));
    }

    @Test
    void restore_notFound_returnsFalse() {
        when(repository.findById("CHK-404")).thenReturn(Optional.empty());

        assertFalse(service.restore("CHK-404"));
    }

    // ---------- findById() ----------

    @Test
    void findById_missingId_throwsValidationException() {
        assertThrows(ValidationException.class, () -> service.findById(null));
        verifyNoInteractions(repository);
    }

    @Test
    void findById_found_returnsDto() {
        when(repository.findByChecklistItemIdAndDeletedAtIsNull("CHK-1"))
                .thenReturn(Optional.of(LegalChecklistItem.builder().checklistItemId("CHK-1").appId("APP-1").build()));

        LegalChecklistItemDTO result = service.findById("CHK-1");

        assertNotNull(result);
        assertEquals("APP-1", result.getAppId());
    }

    @Test
    void findById_notFound_returnsNull() {
        when(repository.findByChecklistItemIdAndDeletedAtIsNull("CHK-404")).thenReturn(Optional.empty());

        assertNull(service.findById("CHK-404"));
    }

    // ---------- findAll() ----------

    @Test
    void findAll_returnsMappedList() {
        when(repository.findByDeletedAtIsNull()).thenReturn(List.of(
                LegalChecklistItem.builder().checklistItemId("CHK-1").build(),
                LegalChecklistItem.builder().checklistItemId("CHK-2").build()));

        assertEquals(2, service.findAll().size());
    }

    @Test
    void findAll_empty_returnsEmptyList() {
        when(repository.findByDeletedAtIsNull()).thenReturn(List.of());

        assertTrue(service.findAll().isEmpty());
    }
}
