package com.hlms2.legal.entity;

import jakarta.persistence.*;

import java.time.OffsetDateTime;

/**
 * JPA entity for 'legal_verification'.
 *
 * CHG(v2): switched from app_id-as-PK to a surrogate verification_id
 * (BIGSERIAL). app_id is now a unique FK column instead of the primary
 * key, since the schema update makes this an "IDENTITY" style table.
 * Also adds the info-request workflow columns and the deleted_at soft
 * delete marker introduced in hlms_schema_updated_v2.sql.
 */
@Entity
@Table(name = "legal_verification")
public class LegalVerification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "verification_id")
    private Long verificationId;

    @Column(name = "app_id", length = 50, nullable = false, unique = true)
    private String appId;

    @Column(name = "decision", length = 30)
    private String decision;

    @Column(name = "decision_date")
    private OffsetDateTime decisionDate;

    @Column(name = "officer")
    private String officerEmail;

    @Column(name = "remarks", columnDefinition = "TEXT")
    private String remarks;

    // CHG(v2): info-request workflow - legal team can ask the customer
    // for more documents/clarification without rejecting the application.
    @Column(name = "info_requested", nullable = false)
    private Boolean infoRequested;

    @Column(name = "info_request_details", columnDefinition = "TEXT")
    private String infoRequestDetails;

    @Column(name = "info_requested_at")
    private OffsetDateTime infoRequestedAt;

    // CHG(v2): soft delete marker. NULL = active, timestamp = deleted.
    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    public LegalVerification() {
    }

    public LegalVerification(Long verificationId, String appId, String decision, OffsetDateTime decisionDate,
                              String officerEmail, String remarks, Boolean infoRequested,
                              String infoRequestDetails, OffsetDateTime infoRequestedAt,
                              OffsetDateTime deletedAt) {
        this.verificationId = verificationId;
        this.appId = appId;
        this.decision = decision;
        this.decisionDate = decisionDate;
        this.officerEmail = officerEmail;
        this.remarks = remarks;
        this.infoRequested = infoRequested;
        this.infoRequestDetails = infoRequestDetails;
        this.infoRequestedAt = infoRequestedAt;
        this.deletedAt = deletedAt;
    }

    public Long getVerificationId() {
        return verificationId;
    }

    public void setVerificationId(Long verificationId) {
        this.verificationId = verificationId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getDecision() {
        return decision;
    }

    public void setDecision(String decision) {
        this.decision = decision;
    }

    public OffsetDateTime getDecisionDate() {
        return decisionDate;
    }

    public void setDecisionDate(OffsetDateTime decisionDate) {
        this.decisionDate = decisionDate;
    }

    public String getOfficerEmail() {
        return officerEmail;
    }

    public void setOfficerEmail(String officerEmail) {
        this.officerEmail = officerEmail;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Boolean getInfoRequested() {
        return infoRequested;
    }

    public void setInfoRequested(Boolean infoRequested) {
        this.infoRequested = infoRequested;
    }

    public String getInfoRequestDetails() {
        return infoRequestDetails;
    }

    public void setInfoRequestDetails(String infoRequestDetails) {
        this.infoRequestDetails = infoRequestDetails;
    }

    public OffsetDateTime getInfoRequestedAt() {
        return infoRequestedAt;
    }

    public void setInfoRequestedAt(OffsetDateTime infoRequestedAt) {
        this.infoRequestedAt = infoRequestedAt;
    }

    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private Long verificationId;
        private String appId;
        private String decision;
        private OffsetDateTime decisionDate;
        private String officerEmail;
        private String remarks;
        private Boolean infoRequested;
        private String infoRequestDetails;
        private OffsetDateTime infoRequestedAt;
        private OffsetDateTime deletedAt;

        public Builder verificationId(Long verificationId) {
            this.verificationId = verificationId;
            return this;
        }

        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }

        public Builder decision(String decision) {
            this.decision = decision;
            return this;
        }

        public Builder decisionDate(OffsetDateTime decisionDate) {
            this.decisionDate = decisionDate;
            return this;
        }

        public Builder officerEmail(String officerEmail) {
            this.officerEmail = officerEmail;
            return this;
        }

        public Builder remarks(String remarks) {
            this.remarks = remarks;
            return this;
        }

        public Builder infoRequested(Boolean infoRequested) {
            this.infoRequested = infoRequested;
            return this;
        }

        public Builder infoRequestDetails(String infoRequestDetails) {
            this.infoRequestDetails = infoRequestDetails;
            return this;
        }

        public Builder infoRequestedAt(OffsetDateTime infoRequestedAt) {
            this.infoRequestedAt = infoRequestedAt;
            return this;
        }

        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public LegalVerification build() {
            return new LegalVerification(verificationId, appId, decision, decisionDate, officerEmail, remarks,
                    infoRequested, infoRequestDetails, infoRequestedAt, deletedAt);
        }
    }
}
