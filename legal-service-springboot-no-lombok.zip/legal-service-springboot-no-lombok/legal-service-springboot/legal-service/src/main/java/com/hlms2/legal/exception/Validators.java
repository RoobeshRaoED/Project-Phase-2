package com.hlms2.legal.exception;

import java.time.LocalDate;
import java.util.Arrays;

/**
 * Ported from hlms.util.Validators - trimmed down to just the checks the
 * legal-domain ServiceImpl classes use (required / oneOf / afterOrEqual).
 * Throws the unchecked ValidationException instead of the checked one.
 */
public final class Validators {

    private Validators() {
    }

    public static void required(Object value, String fieldName) {
        if (value == null || (value instanceof String && ((String) value).trim().isEmpty())) {
            throw new ValidationException(fieldName + " is required.");
        }
    }

    public static void oneOf(String value, String fieldName, String... allowed) {
        required(value, fieldName);
        if (Arrays.stream(allowed).noneMatch(a -> a.equalsIgnoreCase(value))) {
            throw new ValidationException(fieldName + " must be one of " + Arrays.toString(allowed) + ".");
        }
    }

    public static void afterOrEqual(LocalDate later, LocalDate earlier, String laterField, String earlierField) {
        if (later != null && earlier != null && later.isBefore(earlier)) {
            throw new ValidationException(laterField + " must be on or after " + earlierField + ".");
        }
    }
}
