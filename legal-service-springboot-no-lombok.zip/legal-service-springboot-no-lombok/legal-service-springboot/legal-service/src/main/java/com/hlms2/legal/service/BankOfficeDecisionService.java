package com.hlms2.legal.service;

import com.hlms2.legal.dto.BankOfficeDecisionDTO;

import java.util.List;

public interface BankOfficeDecisionService {
    BankOfficeDecisionDTO create(BankOfficeDecisionDTO dto);
    BankOfficeDecisionDTO update(Long decisionId, BankOfficeDecisionDTO dto);
    boolean softDelete(Long decisionId);
    boolean restore(Long decisionId);
    BankOfficeDecisionDTO findById(Long decisionId);
    BankOfficeDecisionDTO findByAppId(String appId);
    List<BankOfficeDecisionDTO> findAll();
}
