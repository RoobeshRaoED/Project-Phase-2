package com.hlms2.legal.dto;

import java.time.OffsetDateTime;

public class BankOfficeDecisionDTO {
    private Long decisionId;
    private String appId;
    private String status;
    private String officerEmail;
    private OffsetDateTime decisionDate;
    private String reason;
    private String remarks;

    public BankOfficeDecisionDTO() {
    }

    public BankOfficeDecisionDTO(Long decisionId, String appId, String status, String officerEmail,
                                  OffsetDateTime decisionDate, String reason, String remarks) {
        this.decisionId = decisionId;
        this.appId = appId;
        this.status = status;
        this.officerEmail = officerEmail;
        this.decisionDate = decisionDate;
        this.reason = reason;
        this.remarks = remarks;
    }

    public Long getDecisionId() {
        return decisionId;
    }

    public void setDecisionId(Long decisionId) {
        this.decisionId = decisionId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOfficerEmail() {
        return officerEmail;
    }

    public void setOfficerEmail(String officerEmail) {
        this.officerEmail = officerEmail;
    }

    public OffsetDateTime getDecisionDate() {
        return decisionDate;
    }

    public void setDecisionDate(OffsetDateTime decisionDate) {
        this.decisionDate = decisionDate;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private Long decisionId;
        private String appId;
        private String status;
        private String officerEmail;
        private OffsetDateTime decisionDate;
        private String reason;
        private String remarks;

        public Builder decisionId(Long decisionId) {
            this.decisionId = decisionId;
            return this;
        }

        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }

        public Builder status(String status) {
            this.status = status;
            return this;
        }

        public Builder officerEmail(String officerEmail) {
            this.officerEmail = officerEmail;
            return this;
        }

        public Builder decisionDate(OffsetDateTime decisionDate) {
            this.decisionDate = decisionDate;
            return this;
        }

        public Builder reason(String reason) {
            this.reason = reason;
            return this;
        }

        public Builder remarks(String remarks) {
            this.remarks = remarks;
            return this;
        }

        public BankOfficeDecisionDTO build() {
            return new BankOfficeDecisionDTO(decisionId, appId, status, officerEmail, decisionDate, reason, remarks);
        }
    }
}
