package com.hlms2.legal.entity;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.OffsetDateTime;

/**
 * JPA entity for 'legal_notice'.
 * Ported from hlms2.entity.LegalNotice (plain JDBC version).
 */
@Entity
@Table(name = "legal_notice")
public class LegalNotice {

    @Id
    @Column(name = "notice_id", length = 50)
    private String noticeId;

    @Column(name = "notice_no", length = 50, nullable = false, unique = true)
    private String noticeNo;

    @Column(name = "app_id", nullable = false)
    private String appId;

    @Column(name = "notice_type", length = 50, nullable = false)
    private String noticeType;

    @Column(name = "issue_date", nullable = false)
    private LocalDate issueDate;

    @Column(name = "due_date")
    private LocalDate dueDate;

    @Column(name = "status", length = 30, nullable = false)
    private String status;

    @Column(name = "officer")
    private String officerEmail;

    @Column(name = "content", columnDefinition = "TEXT")
    private String content;

    // CHG(v2): soft delete marker. NULL = active, timestamp = deleted.
    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    public LegalNotice() {
    }

    public LegalNotice(String noticeId, String noticeNo, String appId, String noticeType, LocalDate issueDate,
                        LocalDate dueDate, String status, String officerEmail, String content,
                        OffsetDateTime deletedAt) {
        this.noticeId = noticeId;
        this.noticeNo = noticeNo;
        this.appId = appId;
        this.noticeType = noticeType;
        this.issueDate = issueDate;
        this.dueDate = dueDate;
        this.status = status;
        this.officerEmail = officerEmail;
        this.content = content;
        this.deletedAt = deletedAt;
    }

    public String getNoticeId() {
        return noticeId;
    }

    public void setNoticeId(String noticeId) {
        this.noticeId = noticeId;
    }

    public String getNoticeNo() {
        return noticeNo;
    }

    public void setNoticeNo(String noticeNo) {
        this.noticeNo = noticeNo;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getNoticeType() {
        return noticeType;
    }

    public void setNoticeType(String noticeType) {
        this.noticeType = noticeType;
    }

    public LocalDate getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(LocalDate issueDate) {
        this.issueDate = issueDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOfficerEmail() {
        return officerEmail;
    }

    public void setOfficerEmail(String officerEmail) {
        this.officerEmail = officerEmail;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String noticeId;
        private String noticeNo;
        private String appId;
        private String noticeType;
        private LocalDate issueDate;
        private LocalDate dueDate;
        private String status;
        private String officerEmail;
        private String content;
        private OffsetDateTime deletedAt;

        public Builder noticeId(String noticeId) {
            this.noticeId = noticeId;
            return this;
        }

        public Builder noticeNo(String noticeNo) {
            this.noticeNo = noticeNo;
            return this;
        }

        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }

        public Builder noticeType(String noticeType) {
            this.noticeType = noticeType;
            return this;
        }

        public Builder issueDate(LocalDate issueDate) {
            this.issueDate = issueDate;
            return this;
        }

        public Builder dueDate(LocalDate dueDate) {
            this.dueDate = dueDate;
            return this;
        }

        public Builder status(String status) {
            this.status = status;
            return this;
        }

        public Builder officerEmail(String officerEmail) {
            this.officerEmail = officerEmail;
            return this;
        }

        public Builder content(String content) {
            this.content = content;
            return this;
        }

        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public LegalNotice build() {
            return new LegalNotice(noticeId, noticeNo, appId, noticeType, issueDate, dueDate, status, officerEmail,
                    content, deletedAt);
        }
    }
}
