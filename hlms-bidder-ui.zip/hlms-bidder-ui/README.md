# HLMS Bidder UI

The bidder-role portion of the HLMS (Housing Loan Management System) Angular UI,
extracted into a standalone Angular 19 application. It talks to the same
Spring Cloud microservices backend through the API Gateway on `localhost:8080`.

---

## Screens

| Route | Component | What it does |
|---|---|---|
| `/app/bidderdash` | `BidderDashboardComponent` | Live listing count, own bid count, highest bid placed, table of active auctions |
| `/app/bidderlistings` | `BidderListingsComponent` | Card grid of every auction listing, each linking through to detail |
| `/app/bidderlistingdetail/:auctionId` | `BidderListingDetailComponent` | Property detail, place-a-bid form, bid history for that application |
| `/app/bidderbids` | `BidderBidsComponent` | Every bid the signed-in bidder has placed |
| `/app/biddersettings` | `BidderSettingsComponent` | Edit full name and mobile number |

`/` redirects to `/app/bidderdash`. The `/app/...` prefix and every child path
are unchanged from the parent project, so these components stay drop-in
compatible if the module is merged back.

---

## Running it

```bash
npm install
npm start        # http://localhost:4200
```

`npm start` uses `proxy.conf.json`, which forwards the three service prefixes
this module needs to the API Gateway:

| Prefix | Used for |
|---|---|
| `/user-service` | profile read/update, JWT login flow that issues the token |
| `/repayment-service` | auctions and bids |
| `/notification-service` | the topbar notification badge |

Start the gateway and those services first, or every screen renders its empty
state and the error toast fires.

---

## Authentication — read this first

**Auth is deliberately out of scope for this module.** There are no login,
register, OTP, or password-reset screens here. The app assumes the visitor
arrives already authenticated as a `BIDDER`, and consumes the team's existing
`AuthService` / token / role mechanism unchanged.

Concretely, it reads two `localStorage` keys that the main HLMS shell writes at
login:

| Key | Contents |
|---|---|
| `hlms_token` | The raw JWT from `POST /user-service/api/users/login`. `authInterceptor` attaches it as `Authorization: Bearer …` on every request. |
| `hlms_session_v1` | JSON `AppUser` — `{ fullName, email, phone, role, active, createdAt }`. `role` must be `"bidder"`. |

If either is missing, `authGuard` sends the browser to `environment.loginUrl`
(the main shell's login page) rather than routing internally.

### Running this app on its own during development

Log in through the main HLMS shell as a real bidder account, then copy both
keys across — the token must come from the real user-service login flow, so
do **not** hand-craft a JWT. From the browser console on the main app:

```js
copy(JSON.stringify({
  token: localStorage.getItem('hlms_token'),
  session: localStorage.getItem('hlms_session_v1')
}));
```

Then in the console on this app (`localhost:4200`), paste that object in as
`s` and run:

```js
localStorage.setItem('hlms_token', s.token);
localStorage.setItem('hlms_session_v1', s.session);
location.reload();
```

A JWT signed by user-service is the only thing the gateway will accept, so a
fabricated one fails at the first API call regardless of what the guards think.

---

## Layout of the extraction

```
src/app/
├── app.component.ts        router outlet + toast host
├── app.config.ts           router, HttpClient + both interceptors, animations
├── app.routes.ts           bidder routes only
├── core/
│   ├── guards/             authGuard, roleGuard (data: { roles: ['bidder'] })
│   ├── interceptors/       authInterceptor (Bearer token), errorInterceptor (toast on failure)
│   ├── models/             auction, user, notification, repayment
│   └── services/           auth, repayment, notification, toast
├── layout/                 shell, topbar, sidebar (bidder nav only)
├── shared/components/toast
└── features/bidder/        the five components above, unmodified
```

### What changed from the parent project

- Routes trimmed to the five bidder screens; customer, admin, legal, bank-office
  and auth routes removed, along with their components and services
  (`loan`, `legal`, `document`, `user-admin`).
- `sidebar.config.ts` no longer switches on role — it returns the bidder nav.
- `topbar.goProfile()` goes straight to `biddersettings`.
- `authGuard` / `roleGuard` redirect out to `environment.loginUrl` instead of an
  internal `/auth/login` route, which no longer exists here.
- `environment.ts` gains `loginUrl`. Point it at your deployment's HLMS shell.
- `proxy.conf.json` trimmed from six services to the three the bidder uses.

### What was kept verbatim

- All five bidder components, HTML and TypeScript, untouched.
- `auth.service.ts` in full, including the login/register/OTP methods this app
  never calls. It is the team's shared service — keeping it identical means no
  merge conflict when the module goes back into the main project.
- `repayment.service.ts` in full, including the EMI, disbursement and insurance
  methods, for the same reason. The bidder screens use `getAuctions`,
  `getAuction`, `getBidsForApp`, `getMyBids` and `placeBid`.
- `styles.scss` in full — the bidder templates use the shared design tokens and
  `card` / `table` / `badge` / `btn` classes defined there.

---

## Known backend gaps carried over

- `GET /repayment-service/api/bids` returns every bid with no bidder filter, so
  `RepaymentService.getMyBids()` filters client-side on `bidderEmail`. Worth a
  `?bidderEmail=` query param server-side.
- The topbar bell shows an unread count but has no dropdown panel yet —
  `openNotifications()` is a stub, and `notifService.notifications()` already
  holds the list to render.
- Bid history on the detail screen is fetched per application ID, and
  `refreshBids()` runs before `getAuction` resolves on first load, so it is the
  post-bid call that populates it. Chaining the two would fill it on arrival.
