export const environment = {
  production: false,
  // Dev: left empty so every service URL is relative (e.g. "/user-service/api/...").
  // Those relative requests hit the Angular dev server (localhost:4200), which
  // proxy.conf.json forwards to the API Gateway on localhost:8080 - see "npm start".
  apiBaseUrl: '',

  // Login/register are out of scope for the bidder module - it has no auth
  // screens of its own. When there is no valid BIDDER session, the guard and
  // the sidebar's Log Out send the browser here, to the main HLMS shell.
  loginUrl: 'http://localhost:4200/auth/login'
};
