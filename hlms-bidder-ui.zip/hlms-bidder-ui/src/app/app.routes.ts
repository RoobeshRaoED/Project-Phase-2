import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { roleGuard } from './core/guards/role.guard';

/**
 * Bidder-only route table, extracted from the full HLMS UI.
 *
 * The '/app/...' prefix and every child path are kept exactly as they are in
 * the parent project so these components (and their hardcoded
 * router.navigate(['/app/bidderlistingdetail', id]) calls) stay drop-in
 * compatible if this module is merged back.
 *
 * Auth is out of scope for this module: there are no login/register routes.
 * A user is expected to arrive already authenticated as BIDDER - see README.
 */
export const routes: Routes = [
  {
    path: 'app',
    canActivate: [authGuard],
    loadComponent: () => import('./layout/shell/shell.component').then(m => m.ShellComponent),
    children: [
      {
        path: 'bidderdash',
        canActivate: [roleGuard],
        data: { roles: ['bidder'] },
        loadComponent: () => import('./features/bidder/bidder-dashboard/bidder-dashboard.component').then(m => m.BidderDashboardComponent)
      },
      {
        path: 'bidderlistings',
        canActivate: [roleGuard],
        data: { roles: ['bidder'] },
        loadComponent: () => import('./features/bidder/bidder-listings/bidder-listings.component').then(m => m.BidderListingsComponent)
      },
      {
        path: 'bidderlistingdetail/:auctionId',
        canActivate: [roleGuard],
        data: { roles: ['bidder'] },
        loadComponent: () => import('./features/bidder/bidder-listing-detail/bidder-listing-detail.component').then(m => m.BidderListingDetailComponent)
      },
      {
        path: 'bidderbids',
        canActivate: [roleGuard],
        data: { roles: ['bidder'] },
        loadComponent: () => import('./features/bidder/bidder-bids/bidder-bids.component').then(m => m.BidderBidsComponent)
      },
      {
        path: 'biddersettings',
        canActivate: [roleGuard],
        data: { roles: ['bidder'] },
        loadComponent: () => import('./features/bidder/bidder-settings/bidder-settings.component').then(m => m.BidderSettingsComponent)
      },

      { path: '', pathMatch: 'full', redirectTo: 'bidderdash' }
    ]
  },
  { path: '', pathMatch: 'full', redirectTo: 'app/bidderdash' },
  { path: '**', redirectTo: 'app/bidderdash' }
];
