import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';

@Component({
  selector: 'app-bidder-settings',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './bidder-settings.component.html'
})
export class BidderSettingsComponent {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private toast = inject(ToastService);

  saving = signal(false);
  user = this.auth.currentUser();

  form = this.fb.nonNullable.group({
    fullName: [this.user?.fullName ?? '', Validators.required],
    phone: [this.user?.phone ?? '', Validators.required]
  });

  save() {
    if (this.form.invalid || !this.user) {
      this.form.markAllAsTouched();
      return;
    }
    this.saving.set(true);
    this.auth.updateProfile(this.user.email, this.form.getRawValue()).subscribe({
      next: () => {
        this.saving.set(false);
        this.toast.show('Settings saved', 'Your profile has been updated.', 'success');
      },
      error: () => this.saving.set(false)
    });
  }
}
