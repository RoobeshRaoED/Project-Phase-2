import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { RepaymentService } from '../../../core/services/repayment.service';
import { AuctionCase } from '../../../core/models/auction.model';

@Component({
  selector: 'app-bidder-listings',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bidder-listings.component.html'
})
export class BidderListingsComponent implements OnInit {
  private repaymentService = inject(RepaymentService);
  private router = inject(Router);

  auctions = signal<AuctionCase[]>([]);
  loading = signal(true);

  ngOnInit(): void {
    this.repaymentService.getAuctions().subscribe({
      next: (list) => { this.auctions.set(list); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  view(auctionId?: number) {
    if (auctionId) this.router.navigate(['/app/bidderlistingdetail', auctionId]);
  }
}
