export interface AuctionCase {
  auctionId?: number;
  appId: number;
  propertyAddress: string;
  reservePrice: number;
  auctionDate: string;
  stage: 'Notice Issued' | 'Scheduled' | 'In Progress' | 'Sold' | 'Cancelled';
}

export interface Bid {
  bidId?: number;
  auctionId: number;
  bidderEmail: string;
  amount: number;
  placedAt?: string;
}
