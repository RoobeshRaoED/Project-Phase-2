import { inject } from '@angular/core';
import { CanActivateFn } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { environment } from '../../../environments/environment';

/**
 * The bidder module ships no login screen, so an unauthenticated visitor is
 * handed off to the main HLMS shell rather than routed internally.
 */
export const authGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  if (auth.isLoggedIn()) return true;
  window.location.href = environment.loginUrl;
  return false;
};
