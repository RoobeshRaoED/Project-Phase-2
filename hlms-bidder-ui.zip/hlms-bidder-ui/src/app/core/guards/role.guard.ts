import { inject } from '@angular/core';
import { CanActivateFn } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { UserRole } from '../models/user.model';
import { environment } from '../../../environments/environment';

/** Usage in routes: data: { roles: ['bidder'] } */
export const roleGuard: CanActivateFn = (route) => {
  const auth = inject(AuthService);
  const allowed = route.data['roles'] as UserRole[] | undefined;
  const role = auth.role();

  if (!auth.isLoggedIn() || (allowed && role && !allowed.includes(role))) {
    // Signed in as some other role (or not at all): this app only serves
    // bidders, so bounce back to the main shell.
    window.location.href = environment.loginUrl;
    return false;
  }
  return true;
};
