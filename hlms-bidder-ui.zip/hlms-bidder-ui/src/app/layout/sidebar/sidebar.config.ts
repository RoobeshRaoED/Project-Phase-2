export interface NavItem {
  view: string;      // route segment under /app/
  icon: string;
  label: string;
}

/**
 * Bidder navigation. The parent project switches on UserRole here; this build
 * only ever serves bidders, so the signature is kept but the branch is not.
 */
export function sidebarItemsFor(): NavItem[] {
  return [
    { view: 'bidderdash', icon: '▦', label: 'Dashboard' },
    { view: 'bidderlistings', icon: '☆', label: 'Auction Listings' },
    { view: 'bidderbids', icon: '💰', label: 'My Bids' },
    { view: 'biddersettings', icon: '⚙', label: 'Settings' }
  ];
}
