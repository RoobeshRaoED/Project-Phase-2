package com.hlms.user.controller;
import com.hlms.user.dto.AuthResponse;
import com.hlms.user.dto.LoginRequest;
import com.hlms.user.dto.RegisterRequest;
import com.hlms.user.dto.VerifyOtpRequest;
import com.hlms.user.entity.AppUser;
import com.hlms.user.security.JwtService;
import com.hlms.user.service.OtpService;
import com.hlms.user.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
/**
 * US-UM-02 Registration, US-UM-03 Secure Login (password + OTP), US-UM-04 Password Management.
 *
 * Login is two steps:
 *   1. POST /api/auth/login/initiate  {email, password}       -> validates password, sends an OTP, no token yet
 *   2. POST /api/auth/login/verify-otp {email, otp}            -> validates the OTP, returns a JWT
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private static final String LOGIN_PURPOSE = "LOGIN";
    private final UserService userService;
    private final OtpService otpService;
    private final JwtService jwtService;
    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody RegisterRequest req) {
        AppUser user = userService.register(req);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(AuthResponse.withoutToken(user.getEmail(), user.getName(), user.getRole(), "Registration successful."));
    }
    @PostMapping("/login/initiate")
    public ResponseEntity<AuthResponse> initiateLogin(@Valid @RequestBody LoginRequest req) {
        AppUser user = userService.authenticate(req.getEmail(), req.getPassword());
        otpService.generateAndSend(user.getEmail(), LOGIN_PURPOSE);
        return ResponseEntity.ok(AuthResponse.withoutToken(user.getEmail(), user.getName(), user.getRole(),
                "Password verified. An OTP has been sent to your registered mobile/email."));
    }
    @PostMapping("/login/verify-otp")
    public ResponseEntity<AuthResponse> verifyOtpAndIssueToken(@Valid @RequestBody VerifyOtpRequest req) {
        otpService.verify(req.getEmail(), req.getOtp(), LOGIN_PURPOSE);
        AppUser user = userService.getByEmail(req.getEmail());
        String token = jwtService.generateToken(user.getEmail(), user.getRole());
        return ResponseEntity.ok(new AuthResponse(user.getEmail(), user.getName(), user.getRole(),
                "Login successful.", token));
    }
    @PostMapping("/change-password")
    public ResponseEntity<Void> changePassword(@RequestParam String email,
                                                @RequestParam String currentPassword,
                                                @RequestParam String newPassword) {
        userService.changePassword(email, currentPassword, newPassword);
        return ResponseEntity.noContent().build();
    }

    public AuthController(UserService userService, OtpService otpService, JwtService jwtService) {
        this.userService = userService;
        this.otpService = otpService;
        this.jwtService = jwtService;
    }
}