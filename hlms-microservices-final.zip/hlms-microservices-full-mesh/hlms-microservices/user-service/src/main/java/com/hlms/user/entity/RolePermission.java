package com.hlms.user.entity;
import jakarta.persistence.*;
@Entity
@Table(name = "role_permission", uniqueConstraints = @UniqueConstraint(columnNames = {"role", "module"}))
public class RolePermission {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "permission_id")
    private Long permissionId;
    @Column(name = "role", length = 30, nullable = false)
    private String role;
    @Column(name = "module", length = 50, nullable = false)
    private String module;
    @Column(name = "can_view", nullable = false)
    private Boolean canView = false;
    @Column(name = "can_add", nullable = false)
    private Boolean canAdd = false;
    @Column(name = "can_edit", nullable = false)
    private Boolean canEdit = false;
    @Column(name = "can_delete", nullable = false)
    private Boolean canDelete = false;

    public RolePermission() {
    }

    public RolePermission(Long permissionId, String role, String module, Boolean canView, Boolean canAdd, Boolean canEdit, Boolean canDelete) {
        this.permissionId = permissionId;
        this.role = role;
        this.module = module;
        this.canView = canView;
        this.canAdd = canAdd;
        this.canEdit = canEdit;
        this.canDelete = canDelete;
    }

    public Long getPermissionId() {
        return permissionId;
    }
    public void setPermissionId(Long permissionId) {
        this.permissionId = permissionId;
    }
    public String getRole() {
        return role;
    }
    public void setRole(String role) {
        this.role = role;
    }
    public String getModule() {
        return module;
    }
    public void setModule(String module) {
        this.module = module;
    }
    public Boolean isCanView() {
        return canView;
    }
    public void setCanView(Boolean canView) {
        this.canView = canView;
    }
    public Boolean isCanAdd() {
        return canAdd;
    }
    public void setCanAdd(Boolean canAdd) {
        this.canAdd = canAdd;
    }
    public Boolean isCanEdit() {
        return canEdit;
    }
    public void setCanEdit(Boolean canEdit) {
        this.canEdit = canEdit;
    }
    public Boolean isCanDelete() {
        return canDelete;
    }
    public void setCanDelete(Boolean canDelete) {
        this.canDelete = canDelete;
    }

    public static Builder builder() {
        return new Builder();
    }
    public static class Builder {
        private Long permissionId;
        private String role;
        private String module;
        private Boolean canView = false;
        private Boolean canAdd = false;
        private Boolean canEdit = false;
        private Boolean canDelete = false;

        public Builder permissionId(Long permissionId) {
            this.permissionId = permissionId;
            return this;
        }
        public Builder role(String role) {
            this.role = role;
            return this;
        }
        public Builder module(String module) {
            this.module = module;
            return this;
        }
        public Builder canView(Boolean canView) {
            this.canView = canView;
            return this;
        }
        public Builder canAdd(Boolean canAdd) {
            this.canAdd = canAdd;
            return this;
        }
        public Builder canEdit(Boolean canEdit) {
            this.canEdit = canEdit;
            return this;
        }
        public Builder canDelete(Boolean canDelete) {
            this.canDelete = canDelete;
            return this;
        }

        public RolePermission build() {
            return new RolePermission(permissionId, role, module, canView, canAdd, canEdit, canDelete);
        }
    }
}