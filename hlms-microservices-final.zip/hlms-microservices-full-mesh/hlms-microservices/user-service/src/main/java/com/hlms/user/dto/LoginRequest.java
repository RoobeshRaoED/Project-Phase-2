package com.hlms.user.dto;
import jakarta.validation.constraints.NotBlank;
public class LoginRequest {
    @NotBlank
    private String email;
    @NotBlank
    private String password;
    // Placeholder for OTP-based 2nd factor (US-UM-03). Wire up an OTP
    // provider/service and validate this before issuing a token.
    private String otp;

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getOtp() {
        return otp;
    }
    public void setOtp(String otp) {
        this.otp = otp;
    }
}