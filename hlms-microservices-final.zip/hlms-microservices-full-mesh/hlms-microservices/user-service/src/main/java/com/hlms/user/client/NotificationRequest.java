package com.hlms.user.client;

import java.util.List;

/** Request body shape for notification-service's internal send endpoint. */
public record NotificationRequest(String userEmail, String title, String body, List<String> channels) { }
