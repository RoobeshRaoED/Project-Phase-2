package com.hlms.user.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Calls loan-service's internal (service-to-service) endpoint. Looks up basic loan application facts (owner, product, amount, status) from loan-service for an appId this service already holds.
 * "loan-service" is resolved via Eureka; see FeignClientConfig for the
 * internal API key header that authenticates this call.
 */
@FeignClient(name = "loan-service", configuration = FeignClientConfig.class)
public interface LoanApplicationClient {

    @GetMapping("/internal/applications/{appId}")
    ApplicationSummaryResponse getApplication(@PathVariable("appId") String appId);
}
