package com.hlms.user.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Calls notification-service's internal (service-to-service) endpoint so
 * user-service can send OTP codes without depending on notification-service's code.
 * "notification-service" is resolved via Eureka; see FeignClientConfig for the
 * internal API key header that authenticates this call.
 */
@FeignClient(name = "notification-service", configuration = FeignClientConfig.class)
public interface NotificationClient {

    @PostMapping("/internal/notifications")
    void send(@RequestBody NotificationRequest request);
}
