import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RepaymentService } from '../../../core/services/repayment.service';
import { LoanService } from '../../../core/services/loan.service';
import { NotificationService } from '../../../core/services/notification.service';
import { ToastService } from '../../../core/services/toast.service';
import { BalanceEligibility, Disbursement, EmiInstallment } from '../../../core/models/repayment.model';
import { LoanApplication, WORKFLOW_STAGES } from '../../../core/models/loan-application.model';

// Product IDs seeded by loan-service's LoanProductSeeder that are disbursed
// in tranches. Kept as a list so adding e.g. a plot+construction composite
// product later is a one-line change.
const CONSTRUCTION_PRODUCT_IDS = ['HL_CONSTRUCTION'];

// Default share of the sanctioned amount credited in the first tranche. The
// officer can override it per application before confirming.
const DEFAULT_FIRST_TRANCHE_PCT = 70;

@Component({
  selector: 'app-bo-disbursement',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './bo-disbursement.component.html'
})
export class BoDisbursementComponent implements OnInit {
  private repaymentService = inject(RepaymentService);
  private loanService = inject(LoanService);
  private notificationService = inject(NotificationService);
  private toast = inject(ToastService);

  disbursements = signal<Disbursement[]>([]);
  applications = signal<LoanApplication[]>([]);
  loading = signal(true);
  processingAppId = signal<string | null>(null);

  // The application currently being disbursed via the inline form.
  activeApp: LoanApplication | null = null;
  newAmount: number | null = null;
  newMode = 'NEFT';
  newRefNo = '';
  newBankDetails = '';

  // Construction-loan tranche inputs (only shown when activeApp is one).
  firstTranchePct = DEFAULT_FIRST_TRANCHE_PCT;

  // Balance-release form state, keyed by the app being released.
  releasingAppId = signal<string | null>(null);
  balanceRefNo = '';
  balanceMode = 'NEFT';

  // Server-side eligibility answers for every disbursement still awaiting
  // its balance tranche, keyed by appId.
  eligibility = signal<Record<string, BalanceEligibility>>({});
  eligibilityLoading = signal<Record<string, boolean>>({});

  recent = computed(() =>
    this.disbursements()
      .slice()
      .sort((a, b) => new Date(b.disbursedDate).getTime() - new Date(a.disbursedDate).getTime())
      .slice(0, 10)
  );

  // Construction loans whose first tranche is credited and whose balance is
  // still withheld pending the engineer's-sign verification.
  awaitingBalance = computed(() =>
    this.disbursements()
      .filter((d) => d.trancheStatus === 'AWAITING_ENGINEER_SIGN' && (d.pendingAmount ?? 0) > 0)
      .sort((a, b) => new Date(b.disbursedDate).getTime() - new Date(a.disbursedDate).getTime())
  );

  // appId of the disbursement whose EMI schedule is currently expanded, if any.
  expandedAppId = signal<string | null>(null);
  expandedSchedule = signal<EmiInstallment[]>([]);
  scheduleLoading = signal(false);

  // An application becomes eligible for disbursement as soon as it has
  // cleared "Final Approval" (the second-to-last workflow stage) - it does
  // NOT need to have already been moved onto the "Disbursement" stage first.
  // That final stage move now happens as part of confirmDisburse() itself,
  // together with creating the disbursement record and generating the EMI
  // schedule, so the two can never happen out of sync with each other.
  // 'Partially Disbursed' is excluded because those applications have already
  // had their first tranche credited - they belong to the balance-release
  // queue below, not back at the top of this one.
  readyToDisburse = computed(() =>
    this.applications().filter(
      (a) =>
        (a.stageIndex ?? -1) >= WORKFLOW_STAGES.length - 2 &&
        a.status !== 'Disbursed' &&
        a.status !== 'Partially Disbursed' &&
        a.status !== 'Rejected'
    )
  );

  ngOnInit(): void {
    this.refresh();
    this.loadApplications();
  }

  private loadApplications(): void {
    this.loanService.getAllApplications().subscribe({
      next: (apps) => this.applications.set(apps),
      error: () => this.applications.set([])
    });
  }

  refresh() {
    this.repaymentService.getAllDisbursements().subscribe({
      next: (list) => {
        this.disbursements.set(list);
        this.loading.set(false);
        this.loadEligibility();
      },
      error: () => this.loading.set(false)
    });
  }

  // Asks the server, per pending application, whether the balance can go out
  // yet. Doing this server-side keeps one source of truth for the rule.
  private loadEligibility(): void {
    for (const d of this.awaitingBalance()) {
      const appId = d.appId;

      this.eligibilityLoading.update((map) => ({ ...map, [appId]: true }));

      this.repaymentService.getBalanceEligibility(appId).subscribe({
        next: (result) => {
          this.eligibility.update((map) => ({ ...map, [appId]: result }));
          this.eligibilityLoading.update((map) => ({ ...map, [appId]: false }));
        },
        error: () => {
          this.eligibilityLoading.update((map) => ({ ...map, [appId]: false }));
        }
      });
    }
  }

  eligibilityFor(appId: string): BalanceEligibility | undefined {
    return this.eligibility()[appId];
  }

  isEligibilityLoading(appId: string): boolean {
    return !!this.eligibilityLoading()[appId];
  }

  applicantFor(appId: string): string {
    const app = this.applications().find((a) => String(a.appId) === String(appId));
    return app?.applicantName || app?.trackingNo || appId;
  }

  applicationFor(appId: string): LoanApplication | undefined {
    return this.applications().find((a) => String(a.appId) === String(appId));
  }

  isConstruction(app: LoanApplication | undefined | null): boolean {
    return !!app?.productId && CONSTRUCTION_PRODUCT_IDS.includes(app.productId);
  }

  // ---- First tranche ----

  startDisburse(app: LoanApplication) {
    this.activeApp = app;
    this.newMode = 'NEFT';
    this.newRefNo = 'DISB-' + Date.now();
    this.newBankDetails = '';
    this.firstTranchePct = DEFAULT_FIRST_TRANCHE_PCT;

    // A construction loan is credited in two parts: the officer sends a share
    // now and the rest only after the engineer's sign is verified. Everything
    // else is credited in full, exactly as before.
    this.newAmount = this.isConstruction(app)
      ? this.roundRupees((app.loanAmount ?? 0) * (DEFAULT_FIRST_TRANCHE_PCT / 100))
      : app.loanAmount;
  }

  // Officer moved the percentage slider/input - recompute the rupee amount.
  onTranchePctChange(app: LoanApplication) {
    const pct = Math.min(Math.max(this.firstTranchePct || 0, 1), 100);
    this.firstTranchePct = pct;
    this.newAmount = this.roundRupees((app.loanAmount ?? 0) * (pct / 100));
  }

  // Officer typed a rupee amount directly - keep the percentage display honest.
  onTrancheAmountChange(app: LoanApplication) {
    const sanctioned = app.loanAmount ?? 0;
    if (!sanctioned || !this.newAmount) {
      return;
    }
    this.firstTranchePct = Math.round((this.newAmount / sanctioned) * 100);
  }

  pendingForActive(): number {
    if (!this.activeApp || !this.newAmount) {
      return 0;
    }
    return Math.max((this.activeApp.loanAmount ?? 0) - this.newAmount, 0);
  }

  cancelDisburse() {
    this.activeApp = null;
    this.newAmount = null;
    this.newRefNo = '';
    this.newBankDetails = '';
    this.firstTranchePct = DEFAULT_FIRST_TRANCHE_PCT;
  }

  confirmDisburse() {
    const app = this.activeApp;
    if (!app?.appId || !this.newAmount || !this.newBankDetails.trim()) {
      this.toast.show('Missing details', 'Please enter the disbursement amount and beneficiary bank details.', 'error');
      return;
    }

    const sanctioned = app.loanAmount ?? 0;

    if (this.newAmount > sanctioned) {
      this.toast.show('Amount too high', 'The disbursement amount cannot exceed the sanctioned loan amount.', 'error');
      return;
    }

    const partial = this.isConstruction(app) && this.newAmount < sanctioned;
    const pending = sanctioned - this.newAmount;

    this.processingAppId.set(app.appId);
    this.repaymentService.createDisbursement({
      appId: app.appId,
      amount: this.newAmount,
      sanctionedAmount: sanctioned,
      disbursedDate: new Date().toISOString(),
      refNo: this.newRefNo,
      mode: this.newMode,
      bankDetails: this.newBankDetails
    }).subscribe({
      next: () => {
        this.processingAppId.set(null);

        this.toast.show(
          partial ? 'First tranche disbursed' : 'Disbursement recorded',
          partial
            ? `₹${this.newAmount} credited for ${app.trackingNo ?? app.appId}. ₹${pending} is held back until the engineer's sign is uploaded and verified.`
            : `Funds disbursed for ${app.trackingNo ?? app.appId} and the EMI schedule has been generated.`,
          'success'
        );

        // repayment-service already pushes the stage/status (including
        // "Partially Disbursed" for a held-back tranche) as part of creating
        // the disbursement, so the stage, status and EMI schedule can never
        // drift apart. This client-side advance is kept only for the fully
        // disbursed case, matching the previous behaviour.
        if (!partial) {
          this.loanService
            .advanceStage(app.appId!, WORKFLOW_STAGES.length - 1, 'Disbursed')
            .subscribe({ error: () => {} });
        }

        if (app.userEmail) {
          this.notificationService.send(
            app.userEmail,
            partial ? 'First Instalment of Your Loan Disbursed' : 'Loan Amount Disbursed',
            partial
              ? `₹${this.newAmount} has been credited for your construction loan ${app.trackingNo ?? ''} (Ref: ${this.newRefNo}). The remaining ₹${pending} will be released once your engineer's sign document is uploaded and verified.`
              : `₹${this.newAmount} has been disbursed for your loan application ${app.trackingNo ?? ''}. Ref: ${this.newRefNo}.`
          ).subscribe({ error: () => {} });
        }

        this.cancelDisburse();
        this.refresh();
        this.loadApplications();
      },
      error: (err) => {
        this.processingAppId.set(null);

        this.toast.show(
          'Error',
          err?.error?.message ||
            err?.error?.error ||
            err?.error ||
            'Could not record disbursement.',
          'error'
        );

        console.error('Disbursement failed:', err);
      }
    });
  }

  // ---- Balance tranche ----

  startRelease(d: Disbursement) {
    this.releasingAppId.set(d.appId);
    this.balanceRefNo = 'BAL-' + Date.now();
    this.balanceMode = d.mode || 'NEFT';
  }

  cancelRelease() {
    this.releasingAppId.set(null);
    this.balanceRefNo = '';
  }

  confirmRelease(d: Disbursement) {
    const check = this.eligibilityFor(d.appId);

    if (!check?.eligible) {
      this.toast.show('Not yet releasable', check?.reason || 'The engineer\u2019s sign has not been verified yet.', 'error');
      return;
    }

    const app = this.applicationFor(d.appId);
    const pending = d.pendingAmount ?? 0;

    this.processingAppId.set(d.appId);
    this.repaymentService.releaseBalance(d.appId, {
      balanceRefNo: this.balanceRefNo,
      mode: this.balanceMode
    }).subscribe({
      next: () => {
        this.processingAppId.set(null);

        this.toast.show(
          'Balance released',
          `₹${pending} credited for ${app?.trackingNo ?? d.appId}. The EMI schedule has been rebuilt on the full sanctioned amount.`,
          'success'
        );

        if (app?.userEmail) {
          this.notificationService.send(
            app.userEmail,
            'Remaining Loan Amount Disbursed',
            `Your engineer's sign has been verified and the remaining ₹${pending} has been credited for loan ${app.trackingNo ?? ''} (Ref: ${this.balanceRefNo}). Your EMI schedule has been updated to reflect the full loan amount.`
          ).subscribe({ error: () => {} });
        }

        this.cancelRelease();
        this.refresh();
        this.loadApplications();
      },
      error: (err) => {
        this.processingAppId.set(null);

        this.toast.show(
          'Error',
          err?.error?.message ||
            err?.error?.error ||
            err?.error ||
            'Could not release the balance amount.',
          'error'
        );

        console.error('Balance release failed:', err);
      }
    });
  }

  // ---- Shared ----

  toggleSchedule(appId: string) {
    if (this.expandedAppId() === appId) {
      this.expandedAppId.set(null);
      this.expandedSchedule.set([]);
      return;
    }
    this.expandedAppId.set(appId);
    this.scheduleLoading.set(true);
    this.repaymentService.getSchedule(appId).subscribe({
      next: (list) => { this.expandedSchedule.set(list); this.scheduleLoading.set(false); },
      error: () => { this.expandedSchedule.set([]); this.scheduleLoading.set(false); }
    });
  }

  private roundRupees(value: number): number {
    return Math.round(value);
  }
}
