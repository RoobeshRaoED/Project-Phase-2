import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { EmiInstallment, Disbursement, InsurancePolicy, BalanceEligibility } from '../models/repayment.model';
import { AuctionCase, Bid } from '../models/auction.model';

@Injectable({ providedIn: 'root' })
export class RepaymentService {
  private readonly emi = `${environment.apiBaseUrl}/repayment-service/api/emi`;
  private readonly disbursements = `${environment.apiBaseUrl}/repayment-service/api/disbursements`;
  private readonly insurance = `${environment.apiBaseUrl}/repayment-service/api/insurance-policies`;
  private readonly auctions = `${environment.apiBaseUrl}/repayment-service/api/auctions`;
  private readonly auctionNotes = `${environment.apiBaseUrl}/repayment-service/api/auction-notes`;
  private readonly bids = `${environment.apiBaseUrl}/repayment-service/api/bids`;
  private readonly defaultMgmt = `${environment.apiBaseUrl}/repayment-service/api/default-management`;

  constructor(private http: HttpClient) {}

  // ---- EMI ----
  getSchedule(appId: string): Observable<EmiInstallment[]> {
    return this.http.get<EmiInstallment[]>(`${this.emi}/${appId}/schedule`);
  }

  getInstallments(): Observable<EmiInstallment[]> {
    return this.http.get<EmiInstallment[]>(`${this.emi}/installments`);
  }

  getInstallment(id: string): Observable<EmiInstallment> {
    return this.http.get<EmiInstallment>(`${this.emi}/installments/${id}`);
  }

  createInstallment(payload: Partial<EmiInstallment>): Observable<EmiInstallment> {
    return this.http.post<EmiInstallment>(`${this.emi}/installments`, payload);
  }

  updateInstallment(id: string, payload: Partial<EmiInstallment>): Observable<EmiInstallment> {
    return this.http.put<EmiInstallment>(`${this.emi}/installments/${id}`, payload);
  }

  // ---- Disbursements ----
  getDisbursementsForApp(appId: string): Observable<Disbursement[]> {
    return this.http.get<Disbursement[]>(`${this.disbursements}/by-application/${appId}`);
  }

  getAllDisbursements(): Observable<Disbursement[]> {
    return this.http.get<Disbursement[]>(this.disbursements);
  }

  createDisbursement(payload: Partial<Disbursement>): Observable<Disbursement> {
    return this.http.post<Disbursement>(this.disbursements, payload);
  }

  // ---- Construction-loan balance tranche ----

  // Non-mutating pre-check: is the withheld balance releasable yet, and if
  // not, why not? The server owns the reason text.
  getBalanceEligibility(appId: string): Observable<BalanceEligibility> {
    return this.http.get<BalanceEligibility>(
      `${this.disbursements}/by-application/${encodeURIComponent(appId)}/balance-eligibility`
    );
  }

  // Credits the withheld balance. The engineer's-sign gate is enforced
  // server-side too, so this cannot be bypassed from the client.
  releaseBalance(appId: string, payload: Partial<Disbursement> = {}): Observable<Disbursement> {
    return this.http.post<Disbursement>(
      `${this.disbursements}/by-application/${encodeURIComponent(appId)}/release-balance`,
      payload
    );
  }

  // ---- Insurance ----
  getInsurancePolicies(): Observable<InsurancePolicy[]> {
    return this.http.get<InsurancePolicy[]>(this.insurance);
  }

  createInsurancePolicy(payload: Partial<InsurancePolicy>): Observable<InsurancePolicy> {
    return this.http.post<InsurancePolicy>(this.insurance, payload);
  }

  // ---- Auctions & bids ----
  getAuctions(): Observable<AuctionCase[]> {
    return this.http.get<AuctionCase[]>(this.auctions);
  }

  // AuctionCaseController's "/by-application/{appId}" returns a single object
  // (app_id is unique on auction_case), not an array.
  getAuctionForApp(appId: string): Observable<AuctionCase> {
    return this.http.get<AuctionCase>(`${this.auctions}/by-application/${appId}`);
  }

  getAuction(auctionId: number): Observable<AuctionCase> {
    return this.http.get<AuctionCase>(`${this.auctions}/${auctionId}`);
  }

  createAuction(payload: Partial<AuctionCase>): Observable<AuctionCase> {
    return this.http.post<AuctionCase>(this.auctions, payload);
  }

  updateAuction(auctionId: number, payload: Partial<AuctionCase>): Observable<AuctionCase> {
    return this.http.put<AuctionCase>(`${this.auctions}/${auctionId}`, payload);
  }

  placeBid(appId: string, payload: Partial<Bid>): Observable<Bid> {
    return this.http.post<Bid>(`${this.auctions}/${appId}/bids`, payload);
  }

  getBidsForApp(appId: string): Observable<Bid[]> {
    return this.http.get<Bid[]>(`${this.auctions}/${appId}/bids`);
  }

  // NOTE: BidController's GET /api/bids (repayment-service) returns every
  // bid - it doesn't support filtering by bidder. Filtering client-side here
  // until a "?bidderEmail=" query param is added server-side.
  getMyBids(bidderEmail: string): Observable<Bid[]> {
    return this.http.get<Bid[]>(this.bids).pipe(
      map((all) => all.filter((b) => b.bidderEmail === bidderEmail))
    );
  }

  // ---- Default management ----
  getDefaultStatus(appId: string): Observable<unknown> {
    return this.http.get(`${this.defaultMgmt}/status/${appId}`);
  }

  getEscalation(appId: string): Observable<unknown> {
    return this.http.get(`${this.defaultMgmt}/escalation/${appId}`);
  }

  // Returns the set of appIds (strings) that currently have at least one
  // OVERDUE installment - not rich rows. Callers join this against
  // getAllApplications() / getSchedule() for display.
  getOverdue(): Observable<string[]> {
    return this.http.get<string[]>(`${this.defaultMgmt}/overdue`);
  }
}
