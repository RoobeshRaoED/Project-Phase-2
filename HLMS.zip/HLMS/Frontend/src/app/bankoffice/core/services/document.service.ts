import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { ApplicationDocument, PostDisbursementDocument } from '../models/document.model';

@Injectable({ providedIn: 'root' })
export class DocumentService {
  private readonly appDocs = `${environment.apiBaseUrl}/document-service/api/application-documents`;
  private readonly postDisbDocs = `${environment.apiBaseUrl}/document-service/api/post-disbursement-documents`;
  private readonly auditLogs = `${environment.apiBaseUrl}/document-service/api/audit-logs`;

  constructor(private http: HttpClient) {}

  // ---- Application documents ----
  // NOTE: document-service has no "/context" aggregate endpoint - this call
  // will 404. Not currently invoked by any component; kept as a placeholder
  // for when/if that endpoint is added server-side.
  getContext(appId: string): Observable<unknown> {
    return this.http.get(`${this.appDocs}/app/${appId}/context`);
  }

  uploadDocument(payload: Partial<ApplicationDocument>): Observable<ApplicationDocument> {
    return this.http.post<ApplicationDocument>(this.appDocs, payload);
  }

  getDocument(documentId: string): Observable<ApplicationDocument> {
    return this.http.get<ApplicationDocument>(`${this.appDocs}/${documentId}`);
  }

  getDocumentsForApp(appId: string): Observable<ApplicationDocument[]> {
    return this.http.get<ApplicationDocument[]>(`${this.appDocs}/app/${appId}`);
  }

  getAllDocuments(): Observable<ApplicationDocument[]> {
    return this.http.get<ApplicationDocument[]>(this.appDocs);
  }

  // Bank Office document verification (Verify / Reject a single document).
  updateDocumentStatus(
    documentId: string,
    verificationStatus: 'Verified' | 'Rejected',
    verifiedBy: string,
    remarks = ''
  ): Observable<ApplicationDocument> {
    return this.http.patch<ApplicationDocument>(`${this.appDocs}/${documentId}/status`, {
      verificationStatus,
      verifiedBy,
      remarks
    });
  }

  deleteDocument(documentId: string): Observable<void> {
    return this.http.delete<void>(`${this.appDocs}/${documentId}`);
  }

  // ---- Post-disbursement documents ----
  uploadPostDisbDocument(payload: Partial<PostDisbursementDocument>): Observable<PostDisbursementDocument> {
    return this.http.post<PostDisbursementDocument>(this.postDisbDocs, payload);
  }

  getPostDisbDocument(documentId: number): Observable<PostDisbursementDocument> {
    return this.http.get<PostDisbursementDocument>(`${this.postDisbDocs}/${documentId}`);
  }

  getPostDisbDocumentsForApp(appId: number): Observable<PostDisbursementDocument[]> {
    return this.http.get<PostDisbursementDocument[]>(`${this.postDisbDocs}/app/${appId}`);
  }

  getAllPostDisbDocuments(): Observable<PostDisbursementDocument[]> {
    return this.http.get<PostDisbursementDocument[]>(this.postDisbDocs);
  }

  deletePostDisbDocument(documentId: number): Observable<void> {
    return this.http.delete<void>(`${this.postDisbDocs}/${documentId}`);
  }

  // ---- Audit logs ----
  getAuditLogs(): Observable<unknown[]> {
    return this.http.get<unknown[]>(this.auditLogs);
  }
}

/**
 * Reads a browser File into a base64 string without the data: prefix, so it
 * can be sent as ApplicationDocument.fileData. Mirrors the customer module's
 * helper of the same name.
 */
export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.split(',')[1] ?? result);
    };

    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}