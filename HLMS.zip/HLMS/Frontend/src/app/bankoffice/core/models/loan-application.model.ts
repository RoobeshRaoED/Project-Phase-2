export interface LoanApplication {
  // appId is a String business key (e.g. "APP1001") on loan-service's
  // schema, not a numeric id - keep this in sync with LoanApplication.java.
  appId?: string;
  trackingNo?: string;
  // The backend entity's field/JSON key is "userEmail", not "applicantEmail" -
  // LoanApplication.java has no separate "applicantEmail" column.
  userEmail: string;
  applicantName?: string;
  applicantMobile?: string;
  applicantPan?: string;
  // Backend field name is "productId" (LoanApplication.java) - "loanProductId"
  // is not a real field on the entity, so nothing should read/write it.
  productId?: string;
  interestRate?: number;
  loanAmount: number;
  tenureYears: number;
  monthlyIncome?: number;
  otherEMIs?: number;
  propertyAddress?: string;
  propertyType?: string;
  propertyValue?: number;
  stage?: string;
  stageIndex?: number;
  // 'Partially Disbursed' is set by repayment-service when the first tranche
  // of a construction loan is credited and the balance is still withheld
  // pending the engineer's-sign verification.
  status?: 'Draft' | 'Submitted' | 'In Progress' | 'Approved' | 'Rejected' | 'Partially Disbursed' | 'Disbursed' | 'Closed';
  submittedAt?: string;
  createdAt?: string;
  updatedAt?: string;
}

export const WORKFLOW_STAGES = [
  'Application Submitted',
  'Document Verification',
  'Eligibility & Credit Check',
  'Mortgage / Property Verification',
  'Final Approval',
  'Disbursement'
];
