// Field names/types below are kept in exact sync with repayment-service's
// DTOs (com.hlms2.repayment.dto.*) - appId is always the String business
// key (e.g. "APP1001"), and most primary ids there are String (UUID) too;
// only auctionId, decisionId, verificationId, disbursementId are numeric.

export interface EmiInstallment {
  installmentId?: string;
  appId: string;
  installmentNo: number;
  dueDate: string;
  emiAmount: number;
  principalComponent: number;
  interestComponent: number;
  closingBalance?: number;
  // EmiInstallmentServiceImpl validates against these exact uppercase values.
  status: 'PENDING' | 'PAID' | 'OVERDUE';
  paidDate?: string;
}

// Tranche vocabulary - mirrors the constants on DisbursementServiceImpl.
export type DisbursementType = 'FULL' | 'PARTIAL';
export type TrancheStatus = 'COMPLETED' | 'AWAITING_ENGINEER_SIGN';
export type EngineerSignStatus =
  | 'NOT_UPLOADED'
  | 'PENDING_VERIFICATION'
  | 'REJECTED'
  | 'VERIFIED'
  | 'UNKNOWN';

export interface Disbursement {
  disbursementId?: number;
  appId: string;
  // DisbursementDTO's JSON field is "disbursedDate", not "disbursementDate".
  disbursedDate: string;
  // `amount` is money actually credited so far - for a construction loan on
  // its first tranche that is the partial amount, not the sanctioned total.
  amount: number;
  refNo?: string;
  mode?: string;
  bankDetails?: string;

  // ---- construction-loan tranche fields ----
  sanctionedAmount?: number;
  disbursedAmount?: number;
  pendingAmount?: number;
  disbursementType?: DisbursementType;
  trancheStatus?: TrancheStatus;
  balanceRefNo?: string;
  balanceReleasedDate?: string;
}

// Response of GET /api/disbursements/by-application/{appId}/balance-eligibility.
// `reason` is written server-side and is meant to be shown to the officer
// verbatim, so the UI never has to guess why a release is blocked.
export interface BalanceEligibility {
  appId: string;
  eligible: boolean;
  reason: string;
  engineerSignStatus: EngineerSignStatus;
  trancheStatus?: TrancheStatus;
  sanctionedAmount?: number;
  disbursedAmount?: number;
  pendingAmount?: number;
}

export interface InsurancePolicy {
  policyId?: string;
  appId: string;
  policyType: string;
  status: string;
  validTill?: string;
}
