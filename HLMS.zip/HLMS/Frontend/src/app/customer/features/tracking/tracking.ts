import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';

import { AuthService } from '../../core/services/auth.service';
import { LoanService } from '../../core/services/loan.service';
import { ToastService } from '../../core/services/toast.service';

import {
  ExpectedCompletion,
  LoanApplication,
  StakeholderInfo,
  WorkflowTimelineResponse
} from '../../core/models/models';

@Component({
  selector: 'app-tracking',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './tracking.html'
})
export class Tracking {
  private auth = inject(AuthService);
  private loanSvc = inject(LoanService);
  private toast = inject(ToastService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  apps = signal<LoanApplication[]>([]);
  listLoading = signal(true);

  selectedId = signal<string | null>(null);
  detailLoading = signal(false);
  detailError = signal('');

  application = signal<LoanApplication | null>(null);
  stakeholder = signal<StakeholderInfo | null>(null);
  timeline = signal<WorkflowTimelineResponse | null>(null);
  expected = signal<ExpectedCompletion | null>(null);

  constructor() {
    const email = this.auth.currentUser()?.email;

    if (!email) {
      this.listLoading.set(false);
      return;
    }

    this.loanSvc.listForUser(email).subscribe({
      next: (list) => {
        this.apps.set(list || []);
        this.listLoading.set(false);

        const routeAppId = this.route.snapshot.paramMap.get('appId');

        if (routeAppId) {
          this.select(routeAppId);
        }
      },
      error: () => {
        this.apps.set([]);
        this.listLoading.set(false);
      }
    });
  }

  select(appId: string): void {
    this.selectedId.set(appId);
    this.detailLoading.set(true);
    this.detailError.set('');

    this.application.set(null);
    this.stakeholder.set(null);
    this.timeline.set(null);
    this.expected.set(null);

    this.loanSvc.getApplication(appId).subscribe({
      next: (app) => {
        this.application.set(app);
      },
      error: () => {
        this.detailError.set('Could not load this application.');
      }
    });

    this.loanSvc.stakeholder(appId).subscribe({
      next: (s) => {
        this.stakeholder.set(s);
      },
      error: () => {
        this.stakeholder.set(null);
      }
    });

    this.loanSvc.timeline(appId).subscribe({
      next: (t) => {
        this.timeline.set(t);
        this.detailLoading.set(false);
      },
      error: () => {
        this.timeline.set(null);
        this.detailLoading.set(false);
      }
    });

    this.loanSvc.expectedCompletion(appId).subscribe({
      next: (e) => {
        this.expected.set(e);
      },
      error: () => {
        this.expected.set(null);
      }
    });
  }

  deselect(): void {
    this.selectedId.set(null);
    this.router.navigate(['/customer/tracking']);
  }

  withdraw(appId: string): void {
    if (!confirm('Are you sure you want to withdraw this application? This cannot be undone.')) {
      return;
    }

    this.loanSvc.withdraw(appId).subscribe({
      next: () => {
        this.toast.success('Application withdrawn');

        this.apps.update((list) =>
          list.filter((a) => a.appId !== appId)
        );

        this.deselect();
      },
      error: () => {
        this.toast.error('Could not withdraw', 'Please try again.');
      }
    });
  }

  badgeClass(status: string | null | undefined): string {
    const s = (status || '').trim().toLowerCase();

    if (
      s.includes('reject') ||
      s.includes('decline') ||
      s.includes('failed') ||
      s.includes('cancel') ||
      s.includes('withdraw')
    ) {
      return 'badge-red';
    }

    if (
      s.includes('active') ||
      s.includes('disbursed') ||
      s.includes('approved') ||
      s.includes('completed') ||
      s.includes('verified') ||
      s.includes('paid')
    ) {
      return 'badge-green';
    }

    if (
      s.includes('draft') ||
      s.includes('submitted') ||
      s.includes('pending') ||
      s.includes('verification') ||
      s.includes('review') ||
      s.includes('decision') ||
      s.includes('processing')
    ) {
      return 'badge-orange';
    }

    return 'badge-gray';
  }

  isRejected(status: string | null | undefined): boolean {
    const s = (status || '').trim().toLowerCase();

    return (
      s.includes('reject') ||
      s.includes('decline') ||
      s.includes('failed') ||
      s.includes('cancel') ||
      s.includes('withdraw')
    );
  }

timelineStepClass(
  stepStatus: string | null | undefined,
  appStatus: string | null | undefined,
  stepIndex: number | null | undefined,
  appStageIndex: number | null | undefined
): string {
  if (this.isRejected(appStatus)) {
    if (stepIndex === appStageIndex || stepStatus === 'current') {
      return 'rejected';
    }
  }

  if (stepStatus === 'completed') {
    return 'done';
  }

  if (stepStatus === 'current') {
    return 'current';
  }

  return '';
}
}