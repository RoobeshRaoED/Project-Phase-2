import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { AuthService } from '../../core/services/auth.service';
import { LoanService } from '../../core/services/loan.service';
import { DocumentService, fileToBase64 } from '../../core/services/document.service';
import { ToastService } from '../../core/services/toast.service';
import { ApplicationDocument, LoanApplication, LoanProduct } from '../../core/models/models';

const STEP_LABELS = [
  'Loan Details',
  'Applicant Info',
  'Employment',
  'Property',
  'Documents',
  'Review & Submit'
];

const MOBILE_RE = /^[6-9]\d{9}$/;
const PAN_RE = /^[A-Z]{5}[0-9]{4}[A-Z]$/;
const PINCODE_RE = /^[1-9][0-9]{5}$/;
const NAME_RE = /^[A-Za-z ]{3,}$/;
const ACCOUNT_NUMBER_RE = /^[0-9]{9,18}$/;
const ALLOWED_EXTENSIONS = ['pdf', 'jpg', 'jpeg', 'png'];
const MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024;

interface RequiredDoc {
  type: string;
  title: string;
  description: string;
}

function maskAccountNumber(accountNumber: string): string {
  if (!accountNumber || accountNumber.length <= 4) {
    return accountNumber;
  }

  return 'XXXX XXXX ' + accountNumber.slice(-4);
}
const REQUIRED_DOCS: RequiredDoc[] = [
  {
    type: 'PAN Card',
    title: 'PAN Card',
    description: 'Required for identity and tax verification.'
  },
  {
    type: 'Identity Proof',
    title: 'Identity Proof',
    description: 'Upload Aadhaar, passport, voter ID, or driving license.'
  },
  {
    type: 'Address Proof',
    title: 'Address Proof',
    description: 'Upload electricity bill, rental agreement, passport, or other valid address proof.'
  },
  {
    type: 'Income Proof',
    title: 'Income Proof',
    description: 'Upload salary slip, Form 16, ITR, or business income proof.'
  },
  {
    type: 'Bank Statement',
    title: 'Bank Statement',
    description: 'Upload recent salary or operating account bank statement.'
  },
  {
    type: 'Property Papers',
    title: 'Property Papers',
    description: 'Upload sale agreement, title proof, allotment letter, or property document.'
  },
  {
    type: 'Photograph',
    title: 'Photograph',
    description: 'Upload recent passport-size photograph.'
  }
];

@Component({
  selector: 'app-apply',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './apply.html'
})
export class Apply {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private loanSvc = inject(LoanService);
  private docSvc = inject(DocumentService);
  private toast = inject(ToastService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  stepLabels = STEP_LABELS;
  requiredDocs = REQUIRED_DOCS;

  step = signal(1);
  loadingInitial = signal(true);
  saving = signal(false);
  submitting = signal(false);
  errorMsg = signal('');

  products = signal<LoanProduct[]>([]);
  appId = signal<string | null>(null);

docs = signal<ApplicationDocument[]>([]);
docsLoading = signal(false);
uploadingDoc = signal(false);
uploadingDocType = signal<string | null>(null);
docError = signal('');
form = this.fb.nonNullable.group({
  productId: ['', [Validators.required]],
  loanAmount: [3000000, [Validators.required, Validators.min(100000), Validators.max(50000000)]],
  tenureYears: [20, [Validators.required, Validators.min(1), Validators.max(30)]],
  purpose: ['PURCHASE', [Validators.required]],

  applicantName: [this.auth.currentUser()?.name || '', [Validators.required, Validators.pattern(NAME_RE)]],
  applicantMobile: [this.auth.currentUser()?.mobile || '', [Validators.required, Validators.pattern(MOBILE_RE)]],
  applicantPan: ['', [Validators.required, Validators.pattern(PAN_RE)]],

  addrDoorNo: ['', [Validators.required]],
  addrStreet: ['', [Validators.required]],
  addrCity: ['', [Validators.required]],
  addrState: ['', [Validators.required]],
  addrPincode: ['', [Validators.required, Validators.pattern(PINCODE_RE)]],

  employmentType: ['SALARIED', [Validators.required]],
  employer: ['', [Validators.required, Validators.minLength(2)]],
  monthlyIncome: [80000, [Validators.required, Validators.min(10000)]],
  otherEmis: [0, [Validators.required, Validators.min(0)]],

  propertyAddress: ['', [Validators.required]],
  propertyType: ['APARTMENT', [Validators.required]],
  propertyValue: [4000000, [Validators.required, Validators.min(100000)]],
  accountNumber: ['', [Validators.required, Validators.pattern(ACCOUNT_NUMBER_RE)]],
  confirmAccountNumber: ['', [Validators.required]]
});

  constructor() {
    this.loanSvc.listProducts().subscribe({
      next: (p) => this.products.set(p),
      error: () => this.errorMsg.set('Could not load loan products.')
    });

    const routeAppId = this.route.snapshot.paramMap.get('appId');

    if (routeAppId) {
      this.appId.set(routeAppId);

      this.loanSvc.getApplication(routeAppId).subscribe({
        next: (app) => {
          this.form.patchValue(app as any);
          this.step.set(app.currentStep && app.currentStep > 0 ? app.currentStep : 1);
          this.loadDocs(routeAppId);
          this.loadingInitial.set(false);
        },
        error: () => {
          this.errorMsg.set('Could not load this draft application.');
          this.loadingInitial.set(false);
        }
      });
    } else {
      this.loadingInitial.set(false);
    }
  }

  isInvalid(controlName: string): boolean {
    const control = this.form.get(controlName);
    return !!control && control.invalid && (control.touched || control.dirty);
  }

  uppercasePan(): void {
    const value = this.form.controls.applicantPan.value || '';
    this.form.controls.applicantPan.setValue(value.toUpperCase(), { emitEvent: false });
  }

  reviewRows() {
    const v = this.form.getRawValue();

    return [
      { label: 'Loan Product', value: v.productId },
      { label: 'Loan Amount', value: v.loanAmount ? `₹${v.loanAmount}` : '' },
      { label: 'Tenure', value: v.tenureYears ? `${v.tenureYears} years` : '' },
      { label: 'Purpose', value: v.purpose },
      { label: 'Applicant', value: v.applicantName },
      { label: 'Mobile', value: v.applicantMobile },
      { label: 'PAN', value: v.applicantPan },
      {
        label: 'Address',
        value: [v.addrDoorNo, v.addrStreet, v.addrCity, v.addrState, v.addrPincode]
          .filter(Boolean)
          .join(', ')
      },
      { label: 'Employment', value: v.employmentType },
      { label: 'Employer', value: v.employer },
      { label: 'Monthly Income', value: v.monthlyIncome ? `₹${v.monthlyIncome}` : '' },
      { label: 'Other EMIs', value: v.otherEmis !== null && v.otherEmis !== undefined ? `₹${v.otherEmis}` : '' },
      { label: 'Property Address', value: v.propertyAddress },
      { label: 'Property Type', value: v.propertyType },
{ label: 'Property Value', value: v.propertyValue ? `₹${v.propertyValue}` : '' },
{ label: 'Bank Account Number', value: v.accountNumber ? maskAccountNumber(v.accountNumber) : '' }    ];
  }

  next(): void {
    this.uppercasePan();

    if (!this.validateCurrentStep()) {
      return;
    }

    const nextStep = Math.min(this.step() + 1, this.stepLabels.length);

    this.saveDraft(() => {
      this.step.set(nextStep);

      if (nextStep === 5 && this.appId()) {
        this.loadDocs(this.appId() as string);
      }

      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, nextStep);
  }

  prev(): void {
    this.errorMsg.set('');
    this.docError.set('');
    this.step.update((s) => Math.max(s - 1, 1));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  saveDraft(after?: () => void, stepToSave = this.step()): void {
    this.uppercasePan();

    const email = this.auth.currentUser()?.email;

    if (!email) {
      this.errorMsg.set('User email not found. Please login again.');
      return;
    }

    if (this.step() <= 4 && !this.validateCurrentStep(false)) {
      this.errorMsg.set('Please correct the current section before saving.');
      return;
    }

    this.saving.set(true);
    this.errorMsg.set('');

    this.loanSvc.saveDraft(email, stepToSave, this.form.getRawValue(), this.appId() ?? undefined).subscribe({
      next: (app: LoanApplication) => {
        this.appId.set(app.appId);
        this.saving.set(false);
        this.toast.show('Draft saved', '', 'success');
        after?.();
      },
      error: (err) => {
        this.saving.set(false);

        this.errorMsg.set(
          err?.error?.message ||
            err?.error?.error ||
            'Could not save your draft. Please check your connection and try again.'
        );
      }
    });
  }

  submit(): void {
    this.uppercasePan();

    if (!this.validateAllForSubmit()) {
      return;
    }

    if (!this.allRequiredDocsUploaded()) {
      this.step.set(5);
      this.errorMsg.set('Please upload all required documents before submitting.');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    const id = this.appId();

    if (!id) {
      this.errorMsg.set('Please save the draft before submitting.');
      return;
    }

    this.submitting.set(true);
    this.errorMsg.set('');

    this.loanSvc.submitApplication(id).subscribe({
      next: () => {
        this.submitting.set(false);
        this.toast.success('Application submitted!', 'You can track its progress from the Tracking page.');
        this.router.navigate(['/customer/tracking', id]);
      },
      error: (err) => {
        this.submitting.set(false);

        this.errorMsg.set(
          err?.error?.message ||
            err?.error?.error ||
            'Could not submit your application right now. Please try again.'
        );
      }
    });
  }

  private validateCurrentStep(showSpecificMessage = true): boolean {
    if (this.step() === 5) {
      if (!this.allRequiredDocsUploaded()) {
        if (showSpecificMessage) {
          this.errorMsg.set('Please upload all required documents before continuing.');
        }

        window.scrollTo({ top: 0, behavior: 'smooth' });
        return false;
      }

      this.errorMsg.set('');
      return true;
    }

    const controls = this.controlsForStep(this.step());

    controls.forEach((name) => {
      const control = this.form.get(name);
      control?.markAsTouched();
      control?.updateValueAndValidity();
    });

    const invalid = controls.some((name) => this.form.get(name)?.invalid);

    if (this.step() === 4) {
  const accountNumber = this.form.controls.accountNumber.value;
  const confirmAccountNumber = this.form.controls.confirmAccountNumber.value;

  if (accountNumber !== confirmAccountNumber) {
    this.form.controls.confirmAccountNumber.markAsTouched();

    if (showSpecificMessage) {
      this.errorMsg.set('Bank account number and confirm account number must match.');
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
    return false;
  }
}
    if (invalid) {
      if (showSpecificMessage) {
        this.errorMsg.set(this.messageForStep(this.step()));
      }

      window.scrollTo({ top: 0, behavior: 'smooth' });
      return false;
    }

    this.errorMsg.set('');
    return true;
  }

  private validateAllForSubmit(): boolean {
    for (let s = 1; s <= 4; s++) {
      const controls = this.controlsForStep(s);

      controls.forEach((name) => {
        const control = this.form.get(name);
        control?.markAsTouched();
        control?.updateValueAndValidity();
      });

      const invalid = controls.some((name) => this.form.get(name)?.invalid);

      if (invalid) {
        this.step.set(s);
        this.errorMsg.set(this.messageForStep(s));
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return false;
      }
    }

    this.errorMsg.set('');
    return true;
  }

  allStepsValid(): boolean {
    return [1, 2, 3, 4].every((s) =>
      this.controlsForStep(s).every((name) => this.form.get(name)?.valid)
    );
  }

  private controlsForStep(step: number): string[] {
    if (step === 1) {
      return ['productId', 'loanAmount', 'tenureYears', 'purpose'];
    }

    if (step === 2) {
      return [
        'applicantName',
        'applicantMobile',
        'applicantPan',
        'addrDoorNo',
        'addrStreet',
        'addrCity',
        'addrState',
        'addrPincode'
      ];
    }

    if (step === 3) {
      return ['employmentType', 'employer', 'monthlyIncome', 'otherEmis'];
    }

if (step === 4) {
  return [
    'propertyAddress',
    'propertyType',
    'propertyValue',
    'accountNumber',
    'confirmAccountNumber'
  ];
}

    return [];
  }

  private messageForStep(step: number): string {
    if (step === 1) {
      return 'Please complete Loan Details before continuing.';
    }

    if (step === 2) {
      return 'Please complete Applicant Info with valid mobile, PAN, and address.';
    }

    if (step === 3) {
      return 'Please complete Employment Details before continuing.';
    }

    if (step === 4) {
      return 'Please complete Property Details before continuing.';
    }

    if (step === 5) {
      return 'Please upload all required documents before continuing.';
    }

    return 'Please complete all required details.';
  }

  private loadDocs(appId: string): void {
    this.docsLoading.set(true);

    this.docSvc.listByApp(appId).subscribe({
      next: (list) => {
        this.docs.set(list || []);
        this.docsLoading.set(false);
      },
      error: () => {
        this.docs.set([]);
        this.docsLoading.set(false);
      }
    });
  }

  hasDoc(type: string): boolean {
    return this.docs().some((d) => d.docType === type);
  }

  uploadedRequiredDocCount(): number {
    return this.requiredDocs.filter((d) => this.hasDoc(d.type)).length;
  }

  allRequiredDocsUploaded(): boolean {
    return this.uploadedRequiredDocCount() === this.requiredDocs.length;
  }

  existingDocName(docType: string): string {
  return this.docs().find((d) => d.docType === docType)?.fileName || 'Uploaded';
}

onFile(evt: Event, docType: string): void {
  const input = evt.target as HTMLInputElement;
  const file = input.files?.[0] ?? null;

  this.docError.set('');

  if (!file) {
    this.docError.set('Please select a file.');
    input.value = '';
    return;
  }

  const extension = file.name.split('.').pop()?.toLowerCase() || '';

  if (!ALLOWED_EXTENSIONS.includes(extension)) {
    this.docError.set('Invalid file type. Please upload PDF, JPG, JPEG, or PNG.');
    input.value = '';
    return;
  }

  if (file.size > MAX_FILE_SIZE_BYTES) {
    this.docError.set('File size must not exceed 10 MB.');
    input.value = '';
    return;
  }

  this.uploadDocFile(docType, file);
  input.value = '';
}

private async uploadDocFile(docType: string, file: File): Promise<void> {
  const appId = this.appId();

  if (!appId) {
    this.docError.set('Application draft not found. Please save previous sections first.');
    return;
  }

  if (this.hasDoc(docType)) {
    this.docError.set(`${docType} is already uploaded. Delete it first if you want to upload again.`);
    return;
  }

  this.uploadingDoc.set(true);
  this.uploadingDocType.set(docType);
  this.docError.set('');

  try {
    const fileData = await fileToBase64(file);

    const payload = {
      appId,
      docType,
      fileName: file.name,
      fileData,
      fileSize: file.size,
      verificationStatus: 'Pending'
    } as ApplicationDocument;

    this.docSvc.upload(payload).subscribe({
      next: (savedDoc) => {
        this.uploadingDoc.set(false);
        this.uploadingDocType.set(null);

        const uploadedDoc: ApplicationDocument = {
          ...payload,
          ...(savedDoc || {}),
          appId,
          docType,
          fileName: file.name,
          fileData,
          fileSize: file.size,
          verificationStatus: savedDoc?.verificationStatus || 'Pending',
          uploadedAt: savedDoc?.uploadedAt || new Date().toISOString()
        } as ApplicationDocument;

        this.docs.update((list) => [
          ...list.filter((d) => d.docType !== docType),
          uploadedDoc
        ]);

        this.toast.success('Document uploaded');
      },
      error: (err) => {
        this.uploadingDoc.set(false);
        this.uploadingDocType.set(null);

        this.docError.set(
          err?.error?.message ||
            err?.error?.error ||
            'Upload failed. Please try again.'
        );
      }
    });
  } catch {
    this.uploadingDoc.set(false);
    this.uploadingDocType.set(null);
    this.docError.set('Could not read the selected file.');
  }
}

removeExistingDoc(docType: string): void {
  const existing = this.docs().find((d) => d.docType === docType);

  if (!existing || !existing.documentId) {
    return;
  }

  if (!confirm(`Delete "${existing.fileName}"?`)) {
    return;
  }

  this.docSvc.remove(existing.documentId).subscribe({
    next: () => {
      this.docs.update((list) =>
        list.filter((d) => d.documentId !== existing.documentId)
      );

      this.toast.success('Document deleted');
    },
    error: () => {
      this.toast.error('Could not delete document');
    }
  });
}
}