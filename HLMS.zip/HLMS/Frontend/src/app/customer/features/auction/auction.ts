import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { LoanService } from '../../core/services/loan.service';
import { LegalService } from '../../core/services/legal.service';
import { RepaymentService } from '../../core/services/repayment.service';
import { AuctionCase, AuctionNote, Bid, LegalNotice, LoanApplication } from '../../core/models/models';

@Component({
  selector: 'app-auction',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './auction.html'
})
export class Auction {
  private auth = inject(AuthService);
  private loanSvc = inject(LoanService);
  private legalSvc = inject(LegalService);
  private repaySvc = inject(RepaymentService);
  private route = inject(ActivatedRoute);

  appId = signal<string | null>(null);
  listLoading = signal(true);
  apps = signal<LoanApplication[]>([]);

  notices = signal<LegalNotice[]>([]);
  auctionCase = signal<AuctionCase | null>(null);
  loadingAuction = signal(true);
  notes = signal<AuctionNote[]>([]);
  bids = signal<Bid[]>([]);

constructor() {
  const routeAppId = this.route.snapshot.paramMap.get('appId');

  if (routeAppId) {
    this.appId.set(routeAppId);
    this.listLoading.set(false);
    this.loadDetail(routeAppId);
  } else {
    const email = this.auth.currentUser()?.email;

    if (email) {
      this.loanSvc.listForUser(email).subscribe({
        next: (list) => {
          this.apps.set(
            (list || []).filter((a) => {
              const status = (a.status || '').toUpperCase();
              return status !== 'DRAFT' && status !== 'REJECTED';
            })
          );

          this.listLoading.set(false);
        },
        error: () => this.listLoading.set(false)
      });
    } else {
      this.listLoading.set(false);
    }
  }
}

private loadDetail(appId: string): void {
  this.notices.set([]);
  this.auctionCase.set(null);
  this.notes.set([]);
  this.bids.set([]);
  this.loadingAuction.set(true);

  console.log('Loading legal/auction data for appId:', appId);

  this.legalSvc.noticesForApp(appId).subscribe({
    next: (list) => {
      console.log('Legal notices API response:', list);
      this.notices.set(list || []);
    },
    error: (err) => {
      this.notices.set([]);
      console.error('Legal notices API failed:', err);
    }
  });

  this.repaySvc.auctionByApp(appId).subscribe({
    next: (ac) => {
      console.log('Auction case API response:', ac);
      this.auctionCase.set(ac);
      this.loadingAuction.set(false);

      this.repaySvc.auctionNotes(appId).subscribe({
        next: (list) => {
          console.log('Auction notes API response:', list);
          this.notes.set(list || []);
        },
        error: (err) => {
          this.notes.set([]);
          console.error('Auction notes API failed:', err);
        }
      });

      this.repaySvc.auctionBids(appId).subscribe({
        next: (list) => {
          console.log('Auction bids API response:', list);
          this.bids.set(list || []);
        },
        error: (err) => {
          this.bids.set([]);
          console.error('Auction bids API failed:', err);
        }
      });
    },
    error: (err) => {
      this.auctionCase.set(null);
      this.notes.set([]);
      this.bids.set([]);
      this.loadingAuction.set(false);
      console.error('Auction case API failed:', err);
    }
  });
}
}
