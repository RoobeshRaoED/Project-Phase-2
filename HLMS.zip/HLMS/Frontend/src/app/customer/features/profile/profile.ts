import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { UserService } from '../../core/services/user.service';
import { ToastService } from '../../core/services/toast.service';
import { CustomerEmploymentProfile } from '../../core/models/models';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './profile.html'
})
export class Profile {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private userSvc = inject(UserService);
  private toast = inject(ToastService);

  savingUser = signal(false);
  userError = signal('');

  empLoading = signal(true);
  savingEmp = signal(false);
  empError = signal('');
  private empExists = false;

  userForm = this.fb.nonNullable.group({
    name: [this.auth.currentUser()?.name || ''],
    email: [this.auth.currentUser()?.email || ''],
    mobile: [this.auth.currentUser()?.mobile || '']
  });

  empForm = this.fb.nonNullable.group({
    employmentType: ['SALARIED'],
    employer: [''],
    monthlyIncome: [0],
    otherEmis: [0],
    desiredAmount: [0],
    pan: ['']
  });

  constructor() {
    const email = this.auth.currentUser()?.email;
    if (!email) {
      this.empLoading.set(false);
      return;
    }
    this.userSvc.getEmploymentProfile(email).subscribe({
      next: (p) => {
        this.empForm.patchValue(p as any);
        this.empExists = true;
        this.empLoading.set(false);
      },
      error: () => {
        // No profile yet — that's fine, the form starts blank and we POST on first save.
        this.empExists = false;
        this.empLoading.set(false);
      }
    });
  }

  saveUser(): void {
    const email = this.auth.currentUser()?.email;
    if (!email) return;
    this.savingUser.set(true);
    this.userError.set('');
    const { name, mobile } = this.userForm.getRawValue();
    this.userSvc.updateUser(email, { name, mobile }).subscribe({
      next: (user) => {
        this.savingUser.set(false);
        this.toast.success('Profile updated');
        localStorage.setItem('hlms_user', JSON.stringify(user));
      },
      error: () => {
        this.savingUser.set(false);
        this.userError.set('Could not update your profile. Please try again.');
      }
    });
  }

  saveEmployment(): void {
    const email = this.auth.currentUser()?.email;
    if (!email) return;
    this.savingEmp.set(true);
    this.empError.set('');
    const profile: CustomerEmploymentProfile = { userEmail: email, ...this.empForm.getRawValue() };
    const req = this.empExists
      ? this.userSvc.updateEmploymentProfile(email, profile)
      : this.userSvc.createEmploymentProfile(profile);
    req.subscribe({
      next: () => {
        this.savingEmp.set(false);
        this.empExists = true;
        this.toast.success('Employment profile saved');
      },
      error: () => {
        this.savingEmp.set(false);
        this.empError.set('Could not save your employment profile. Please try again.');
      }
    });
  }
}
