import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';

import { AuthService } from '../../core/services/auth.service';
import { LoanService } from '../../core/services/loan.service';
import {
  DocumentService,
  downloadBase64File
} from '../../core/services/document.service';
import { ToastService } from '../../core/services/toast.service';

import { ApplicationDocument, LoanApplication } from '../../core/models/models';

@Component({
  selector: 'app-documents',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl:'./documents.html' 
})
export class Documents {
  private auth = inject(AuthService);
  private loanSvc = inject(LoanService);
  private docSvc = inject(DocumentService);
  private toast = inject(ToastService);
  private route = inject(ActivatedRoute);

  appId = signal<string | null>(null);

  listLoading = signal(true);
  apps = signal<LoanApplication[]>([]);

  docsLoading = signal(false);
  docs = signal<ApplicationDocument[]>([]);
  errorMsg = signal('');

  constructor() {
    const routeAppId = this.route.snapshot.paramMap.get('appId');

    if (routeAppId) {
      this.appId.set(routeAppId);
      this.listLoading.set(false);
      this.verifyAndLoadDocs(routeAppId);
      return;
    }

    this.loadApplications();
  }

  private loadApplications(): void {
    const email = this.auth.currentUser()?.email;

    if (!email) {
      this.listLoading.set(false);
      this.errorMsg.set('User session not found. Please login again.');
      return;
    }

    this.loanSvc.listForUser(email).subscribe({
      next: (list) => {
        this.apps.set(
          (list || []).filter((a) => a.status !== 'Draft')
        );

        this.listLoading.set(false);
      },
      error: () => {
        this.listLoading.set(false);
        this.errorMsg.set('Could not load your applications.');
      }
    });
  }

  private verifyAndLoadDocs(appId: string): void {
    const email = this.auth.currentUser()?.email;

    if (!email) {
      this.errorMsg.set('User session not found. Please login again.');
      return;
    }

    this.docsLoading.set(true);

    this.loanSvc.getApplication(appId).subscribe({
      next: (app) => {
        if ((app.userEmail || '').toLowerCase() !== email.toLowerCase()) {
          this.docsLoading.set(false);
          this.docs.set([]);
          this.errorMsg.set('You are not allowed to view documents for this application.');
          return;
        }

        if (app.status === 'Draft') {
          this.docsLoading.set(false);
          this.docs.set([]);
          this.errorMsg.set('Documents can be viewed here only after the application is submitted.');
          return;
        }

        this.loadDocs(appId);
      },
      error: () => {
        this.docsLoading.set(false);
        this.docs.set([]);
        this.errorMsg.set('Could not verify this application.');
      }
    });
  }

  private loadDocs(appId: string): void {
    this.docsLoading.set(true);

    this.docSvc.listByApp(appId).subscribe({
      next: (list) => {
        this.docs.set(list || []);
        this.docsLoading.set(false);
      },
      error: (err) => {
        this.docs.set([]);
        this.docsLoading.set(false);

        this.errorMsg.set(
          err?.error?.message ||
            err?.error?.error ||
            err?.error ||
            err?.message ||
            'Could not load documents for this application.'
        );

        console.error('Document list failed:', err);
      }
    });
  }

  download(doc: ApplicationDocument): void {
    if (!doc.fileData) {
      this.toast.error('Download unavailable', 'File data is missing.');
      return;
    }

    const mimeType = this.mimeTypeForFile(doc.fileName || '');

    downloadBase64File(
      doc.fileData,
      doc.fileName || `${doc.docType || 'document'}.pdf`,
      mimeType
    );
  }

  private mimeTypeForFile(fileName: string): string {
    const extension = fileName.split('.').pop()?.toLowerCase();

    if (extension === 'pdf') {
      return 'application/pdf';
    }

    if (extension === 'jpg' || extension === 'jpeg') {
      return 'image/jpeg';
    }

    if (extension === 'png') {
      return 'image/png';
    }

    return 'application/octet-stream';
  }
}