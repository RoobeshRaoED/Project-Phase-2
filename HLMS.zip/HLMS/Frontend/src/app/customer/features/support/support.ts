import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../core/services/auth.service';
import { NotificationService } from '../../core/services/notification.service';
import { ToastService } from '../../core/services/toast.service';
import { Notification, ServiceRequest } from '../../core/models/models';

const REQUEST_TYPES = ['General Query', 'Complaint', 'Document Assistance', 'Payment Issue', 'Other'];

@Component({
  selector: 'app-support',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl:'./support.html'
})
export class Support {
  private auth = inject(AuthService);
  private notifSvc = inject(NotificationService);
  private toast = inject(ToastService);

  requestTypes = REQUEST_TYPES;
  requestType = REQUEST_TYPES[0];
  requestDesc = '';

  notifLoading = signal(true);
  notifications = signal<Notification[]>([]);

  reqsLoading = signal(true);
  requests = signal<ServiceRequest[]>([]);
  raising = signal(false);
  reqError = signal('');

  constructor() {
    const email = this.auth.currentUser()?.email;
    if (!email) {
      this.notifLoading.set(false);
      this.reqsLoading.set(false);
      return;
    }
    this.notifSvc.listForUser(email).subscribe({
      next: (list) => {
        this.notifications.set(list);
        this.notifLoading.set(false);
      },
      error: () => this.notifLoading.set(false)
    });
    this.loadRequests(email);
  }

  private loadRequests(email: string): void {
    this.reqsLoading.set(true);
    this.notifSvc.listServiceRequests(email).subscribe({
      next: (list) => {
        this.requests.set(list);
        this.reqsLoading.set(false);
      },
      error: () => this.reqsLoading.set(false)
    });
  }

  markRead(n: Notification): void {
    if (!n.notificationId) return;
    this.notifSvc.markRead(n.notificationId).subscribe({
      next: (updated) => {
        this.notifications.update((list) =>
          list.map((x) => (x.notificationId === updated.notificationId ? updated : x))
        );
      },
      error: () => this.toast.error('Could not mark as read')
    });
  }

  raiseRequest(): void {
    const email = this.auth.currentUser()?.email;
    if (!email) return;
    this.raising.set(true);
    this.reqError.set('');
    this.notifSvc.createServiceRequest({ userEmail: email, requestType: this.requestType, description: this.requestDesc }).subscribe({
      next: () => {
        this.raising.set(false);
        this.requestDesc = '';
        this.toast.success('Request submitted', 'Our team will get back to you shortly.');
        this.loadRequests(email);
      },
      error: () => {
        this.raising.set(false);
        this.reqError.set('Could not submit your request. Please try again.');
      }
    });
  }
}
