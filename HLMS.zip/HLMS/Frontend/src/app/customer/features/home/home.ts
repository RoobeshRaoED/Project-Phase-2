import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterLink],
  templateUrl:'./home.html' 
})
export class Home {
  year = new Date().getFullYear();

  features = [
    { icon: '📝', title: 'Simple Application', desc: 'Apply online in minutes with guided, step-by-step forms.' },
    { icon: '↗', title: 'Real-Time Tracking', desc: 'Follow your application through every stage — from submission to disbursement.' },
    { icon: '▯', title: 'Secure Document Vault', desc: 'Upload and manage KYC, income and property documents safely.' },
    { icon: 'Ⓡ', title: 'Smart Repayment', desc: 'View EMI schedules, outstanding balance and repayment history anytime.' },
    { icon: '☑', title: 'Instant Eligibility Check', desc: 'Know your loan eligibility and estimated EMI before you apply.' },
    { icon: '🔔', title: 'Timely Notifications', desc: 'Stay informed with in-app alerts at every milestone.' },
    { icon: '☆', title: 'Auction Transparency', desc: 'Track SARFAESI notices and auction listings with complete clarity.' },
    { icon: '?', title: 'Dedicated Support', desc: 'Reach our support team directly from your dashboard whenever you need help.' }
  ];
}
