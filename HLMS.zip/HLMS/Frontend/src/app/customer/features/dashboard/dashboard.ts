import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { LoanService } from '../../core/services/loan.service';
import { NotificationService } from '../../core/services/notification.service';
import { LoanApplication, Notification } from '../../core/models/models';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl:'./dashboard.html' 
})
export class Dashboard {
  auth = inject(AuthService);
  private loanSvc = inject(LoanService);
  private notifSvc = inject(NotificationService);

  loading = signal(true);
  loadError = signal('');
  apps = signal<LoanApplication[]>([]);
  unread = signal<Notification[]>([]);

  constructor() {
    const email = this.auth.currentUser()?.email;
    if (!email) {
      this.loading.set(false);
      return;
    }

    let pending = 2;
    const done = () => {
      pending -= 1;
      if (pending <= 0) this.loading.set(false);
    };

    this.loanSvc.listForUser(email).subscribe({
      next: (list) => {
        this.apps.set(list);
        done();
      },
      error: () => {
        this.loadError.set('Could not load your applications from loan-service. Is the backend running?');
        done();
      }
    });

    this.notifSvc.unread(email).subscribe({
      next: (list) => {
        this.unread.set(list);
        done();
      },
      error: () => done()
    });
  }

  activeCount(): number {
    return this.apps().filter((a) => !['Draft', 'Disbursed', 'Rejected', 'Withdrawn'].includes(a.status))
      .length;
  }

  disbursedCount(): number {
    return this.apps().filter((a) => a.status === 'Disbursed').length;
  }

  badgeClass(status: string): string {
    if (status === 'Disbursed') return 'badge-green';
    if (status === 'Rejected') return 'badge-red';
    if (status === 'Draft') return 'badge-gray';
    return 'badge-orange';
  }
}
