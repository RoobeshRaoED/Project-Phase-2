import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl :'./register.html'
})
export class Register {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private router = inject(Router);
  private toast = inject(ToastService);

  loading = signal(false);
  showPw = signal(false);
  errorMsg = signal('');

  form = this.fb.nonNullable.group({
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    mobile: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
    idType: ['PAN', Validators.required],
    idNumber: ['', Validators.required],
    password: ['', [Validators.required, Validators.minLength(8)]]
  });

  submit(): void {
    if (this.form.invalid) return;
    this.loading.set(true);
    this.errorMsg.set('');
    const { name, email, mobile, idType, idNumber, password } = this.form.getRawValue();
    this.auth
      .register({ name, email, mobile, idType, idNumber, password, role: 'CUSTOMER' })
      .subscribe({
        next: () => {
          this.loading.set(false);
          this.toast.success('Account created', 'You can now log in with your new account.');
          this.router.navigate(['/login']);
        },
        error: (err) => {
          this.loading.set(false);
          this.errorMsg.set(
            err?.status === 409
              ? 'An account with this email already exists.'
              : err?.error?.message || 'Registration failed. Please check the backend is running and try again.'
          );
        }
      });
  }
}
