import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './login.html'
})
export class Login {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private toast = inject(ToastService);

  loading = signal(false);
  showPw = signal(false);
  errorMsg = signal('');
  sessionExpired = false;

  form = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', Validators.required]
  });

  constructor() {
    this.sessionExpired = this.route.snapshot.queryParamMap.get('sessionExpired') === '1';
  }

  submit(): void {
    if (this.form.invalid) return;
    this.loading.set(true);
    this.errorMsg.set('');
    this.auth.login(this.form.getRawValue()).subscribe({
      next: (user) => {
        this.loading.set(false);
        if (user.role !== 'CUSTOMER') {
          this.auth.logout(false);
          this.errorMsg.set(
            `This portal is for customers only. Your account role is "${user.role}" — please use the appropriate staff portal.`
          );
          return;
        }
        this.toast.success('Welcome back', user.name || user.email);
        this.router.navigateByUrl('/customer/dashboard');
      },
      error: (err) => {
        this.loading.set(false);
        this.errorMsg.set(
          err?.status === 401 || err?.status === 403
            ? 'Incorrect email or password.'
            : err?.error?.message || 'Login failed. Please check the backend is running and try again.'
        );
      }
    });
  }
}
