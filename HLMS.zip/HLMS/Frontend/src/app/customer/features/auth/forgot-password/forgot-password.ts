import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl:'./forgot-password.html'
})
export class ForgotPassword {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private router = inject(Router);
  private toast = inject(ToastService);

  step = signal(1);
  loading = signal(false);
  errorMsg = signal('');

  emailForm = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.email]]
  });

  resetForm = this.fb.nonNullable.group({
    otpCode: ['', [Validators.required, Validators.pattern(/^\d{4,8}$/)]],
    newPassword: ['', [Validators.required, Validators.minLength(8)]]
  });

  sendOtp(): void {
    if (this.emailForm.invalid) return;
    this.loading.set(true);
    this.errorMsg.set('');
    this.auth.forgotPassword(this.emailForm.getRawValue().email).subscribe({
      next: () => {
        this.loading.set(false);
        this.toast.success('OTP sent', 'Check your email/SMS for the reset code.');
        this.step.set(2);
      },
      error: (err) => {
        this.loading.set(false);
        this.errorMsg.set(err?.error?.message || 'Could not send OTP. Please check the email and try again.');
      }
    });
  }

  reset(): void {
    if (this.resetForm.invalid) return;
    this.loading.set(true);
    this.errorMsg.set('');
    const { otpCode, newPassword } = this.resetForm.getRawValue();
    this.auth.resetPassword(this.emailForm.getRawValue().email, otpCode, newPassword).subscribe({
      next: () => {
        this.loading.set(false);
        this.toast.success('Password reset', 'You can now log in with your new password.');
        this.router.navigate(['/login']);
      },
      error: (err) => {
        this.loading.set(false);
        this.errorMsg.set(err?.error?.message || 'Reset failed. The OTP may be invalid or expired.');
      }
    });
  }
}
