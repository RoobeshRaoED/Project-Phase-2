import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';

import { AuthService } from '../../core/services/auth.service';
import { UserService } from '../../core/services/user.service';
import { ToastService } from '../../core/services/toast.service';

@Component({
  selector: 'app-change-password',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl:'./change-password.html'
})
export class ChangePassword {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private userSvc = inject(UserService);
  private toast = inject(ToastService);
  private router = inject(Router);

  sendingOtp = signal(false);
  resetting = signal(false);
  errorMsg = signal('');
  successMsg = signal('');
  otpPreview = signal('');

  form = this.fb.nonNullable.group({
    email: [this.auth.currentUser()?.email || '', [Validators.required, Validators.email]],
    otpCode: ['', [Validators.required]],
    newPassword: ['', [Validators.required, Validators.minLength(6)]],
    confirmPassword: ['', [Validators.required]]
  });

  isInvalid(controlName: string): boolean {
    const control = this.form.get(controlName);
    return !!control && control.invalid && (control.touched || control.dirty);
  }

  sendOtp(): void {
    const email = this.form.controls.email.value;

    if (!email) {
      this.errorMsg.set('User email not found. Please login again.');
      return;
    }

    this.sendingOtp.set(true);
    this.errorMsg.set('');
    this.successMsg.set('');
    this.otpPreview.set('');

    this.userSvc.forgotPassword(email).subscribe({
      next: (message) => {
        this.sendingOtp.set(false);

        const text = String(message || '').trim();
        const otpMatch = text.match(/\d{4,8}/);

        if (otpMatch) {
          this.otpPreview.set(otpMatch[0]);
          this.successMsg.set('OTP generated successfully.');
        } else {
          this.successMsg.set(text || 'OTP sent to your registered email.');
        }

        this.toast.success('OTP sent');
      },
      error: (err) => {
        this.sendingOtp.set(false);
        this.errorMsg.set(
          err?.error?.message ||
            err?.error?.error ||
            err?.error ||
            'Could not send OTP. Please try again.'
        );
      }
    });
  }

  resetPassword(): void {
    this.errorMsg.set('');
    this.successMsg.set('');

    const value = this.form.getRawValue();

    if (value.newPassword !== value.confirmPassword) {
      this.form.controls.confirmPassword.markAsTouched();
      this.errorMsg.set('New password and confirm password must match.');
      return;
    }

    this.resetting.set(true);

    this.userSvc.resetPassword(value.email, value.otpCode, value.newPassword).subscribe({
      next: (message) => {
        this.resetting.set(false);
        this.successMsg.set(message || 'Password changed successfully. Please login again.');
        this.otpPreview.set('');
        this.toast.success('Password changed');

        setTimeout(() => {
          this.auth.logout(false);
          this.router.navigateByUrl('/login');
        }, 1200);
      },
      error: (err) => {
        this.resetting.set(false);
        this.errorMsg.set(
          err?.error?.message ||
            err?.error?.error ||
            err?.error ||
            'Could not change password. Please check OTP and try again.'
        );
      }
    });
  }
}
