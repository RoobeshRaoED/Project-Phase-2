import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { LoanService } from '../../core/services/loan.service';
import { ToastService } from '../../core/services/toast.service';
import { EmiOption, LoanProduct, ProductRecommendation } from '../../core/models/models';

@Component({
  selector: 'app-guidance',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './guidance.html'
})
export class Guidance {
  private fb = inject(FormBuilder);
  private loanSvc = inject(LoanService);
  private toast = inject(ToastService);

  products = signal<LoanProduct[]>([]);
  productsLoading = signal(true);
  productsError = signal('');

  recommendations = signal<ProductRecommendation[]>([]);
  recLoading = signal(false);
  recError = signal('');

  emiOptions = signal<EmiOption[]>([]);
  emiLoading = signal(false);
  emiError = signal('');

  recForm = this.fb.nonNullable.group({
    purpose: ['PURCHASE'],
    monthlyIncome: [80000],
    otherEmis: [0],
    cibilScore: [750],
    requestedAmount: [3000000],
    tenureYears: [20]
  });

  emiForm = this.fb.nonNullable.group({
    loanAmount: [3000000],
    interestRate: [8.5],
    maxAffordableEmi: [null as number | null]
  });

  constructor() {
    this.loanSvc.listProducts().subscribe({
      next: (list) => {
        this.products.set(list);
        this.productsLoading.set(false);
      },
      error: () => {
        this.productsError.set('Could not load loan products from loan-service.');
        this.productsLoading.set(false);
      }
    });
  }

  getRecommendations(): void {
    this.recLoading.set(true);
    this.recError.set('');
    this.loanSvc.recommendProducts(this.recForm.getRawValue()).subscribe({
      next: (list) => {
        this.recommendations.set(list);
        this.recLoading.set(false);
        if (list.length === 0) this.toast.show('No matches found', 'Try adjusting your inputs.');
      },
      error: () => {
        this.recError.set('Could not fetch recommendations right now.');
        this.recLoading.set(false);
      }
    });
  }

  runEmiAssistant(): void {
    this.emiLoading.set(true);
    this.emiError.set('');
    const raw = this.emiForm.getRawValue();
    this.loanSvc
      .emiAssistant({
        loanAmount: raw.loanAmount,
        interestRate: raw.interestRate,
        maxAffordableEmi: raw.maxAffordableEmi ?? undefined
      })
      .subscribe({
        next: (list) => {
          this.emiOptions.set(list);
          this.emiLoading.set(false);
        },
        error: () => {
          this.emiError.set('Could not calculate EMI options right now.');
          this.emiLoading.set(false);
        }
      });
  }
}
