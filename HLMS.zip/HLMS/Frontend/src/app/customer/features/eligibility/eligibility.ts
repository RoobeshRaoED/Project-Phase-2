import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { LoanService } from '../../core/services/loan.service';
import { EligibilityAssessment, EligibilityResponse } from '../../core/models/models';

@Component({
  selector: 'app-eligibility',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './eligibility.html'
})
export class Eligibility {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private loanSvc = inject(LoanService);

  loading = signal(false);
  formError = signal('');
  result = signal<EligibilityResponse | null>(null);

  history = signal<EligibilityAssessment[]>([]);
  historyLoading = signal(true);

  form = this.fb.nonNullable.group({
    monthlyIncome: [80000],
    otherEmis: [0],
    cibilScore: [750],
    requestedAmount: [3000000],
    tenureYears: [20],
    interestRate: [8.5]
  });

  constructor() {
    this.loadHistory();
  }

  private loadHistory(): void {
    const email = this.auth.currentUser()?.email;
    if (!email) {
      this.historyLoading.set(false);
      return;
    }
    this.loanSvc.eligibilityHistory(email).subscribe({
      next: (list) => {
        this.history.set(list);
        this.historyLoading.set(false);
      },
      error: () => this.historyLoading.set(false)
    });
  }

  assess(): void {
    const email = this.auth.currentUser()?.email;
    if (!email || this.form.invalid) return;
    this.loading.set(true);
    this.formError.set('');
    this.loanSvc.assessEligibility(email, this.form.getRawValue()).subscribe({
      next: (res) => {
        this.result.set(res);
        this.loading.set(false);
        this.loadHistory();
      },
      error: () => {
        this.formError.set('Could not assess eligibility right now. Please try again.');
        this.loading.set(false);
      }
    });
  }
}
