import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';

import { AuthService } from '../../core/services/auth.service';
import { LoanService } from '../../core/services/loan.service';
import { RepaymentService } from '../../core/services/repayment.service';
import { ToastService } from '../../core/services/toast.service';

import {
  Disbursement,
  EmiInstallment,
  InsurancePolicy,
  LoanApplication
} from '../../core/models/models';

@Component({
  selector: 'app-repayment',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl:'./repayment .html'
})
export class Repayment {
  private auth = inject(AuthService);
  private loanSvc = inject(LoanService);
  private repaySvc = inject(RepaymentService);
  private toast = inject(ToastService);
  private route = inject(ActivatedRoute);

  appId = signal<string | null>(null);

  listLoading = signal(true);
  eligibleApps = signal<LoanApplication[]>([]);

  errorMsg = signal('');
  scheduleLoading = signal(true);
  schedule = signal<EmiInstallment[]>([]);

  currentPage = signal(1);
  pageSize = 10;

  disbursement = signal<Disbursement | null>(null);
  insurancePolicies = signal<InsurancePolicy[]>([]);
  paying = signal<string | null>(null);

  constructor() {
    const routeAppId = this.route.snapshot.paramMap.get('appId');

    if (routeAppId) {
      this.appId.set(routeAppId);
      this.loadDetail(routeAppId);
      this.listLoading.set(false);
      return;
    }

    const email = this.auth.currentUser()?.email;

    if (!email) {
      this.listLoading.set(false);
      return;
    }

    this.loanSvc.listForUser(email).subscribe({
      next: (list) => {
        this.eligibleApps.set(
          (list || []).filter((a) => a.status === 'Active' || a.status === 'Disbursed')
        );

        this.listLoading.set(false);
      },
      error: () => {
        this.listLoading.set(false);
      }
    });
  }

  private loadDetail(appId: string): void {
    this.errorMsg.set('');
    this.scheduleLoading.set(true);
    this.schedule.set([]);
    this.currentPage.set(1);

    this.loadDisbursement(appId);
    this.loadSchedule(appId);
    this.loadInsurance(appId);
  }

  private loadDisbursement(appId: string): void {
    this.repaySvc.disbursementByApp(appId).subscribe({
      next: (d) => {
        this.disbursement.set(d);
      },
      error: () => {
        this.disbursement.set(null);
      }
    });
  }

  private loadSchedule(appId: string): void {
    this.repaySvc.schedule(appId).subscribe({
      next: (s) => {
        const sorted = (s || [])
          .map((i) => ({
            ...i,
            status: this.normalizeStatus(i.status)
          }))
          .sort((a, b) => (a.installmentNo || 0) - (b.installmentNo || 0));

        this.schedule.set(sorted);
        this.currentPage.set(1);
        this.scheduleLoading.set(false);
      },
      error: () => {
        this.schedule.set([]);
        this.currentPage.set(1);
        this.scheduleLoading.set(false);
      }
    });
  }

  private loadInsurance(appId: string): void {
    this.repaySvc.allInsurancePolicies().subscribe({
      next: (all) => {
        this.insurancePolicies.set((all || []).filter((p) => p.appId === appId));
      },
      error: () => {
        this.insurancePolicies.set([]);
      }
    });
  }

  private normalizeStatus(status?: string): string {
    return (status || 'PENDING').toUpperCase();
  }

  statusLabel(status?: string): string {
    const normalized = this.normalizeStatus(status);

    if (normalized === 'PAID') {
      return 'PAID';
    }

    if (normalized === 'OVERDUE') {
      return 'OVERDUE';
    }

    return 'PENDING';
  }

  isPaid(installment: EmiInstallment): boolean {
    return this.normalizeStatus(installment.status) === 'PAID';
  }

  isOverdue(installment: EmiInstallment): boolean {
    return this.normalizeStatus(installment.status) === 'OVERDUE';
  }

  totalPages(): number {
    return Math.max(1, Math.ceil(this.schedule().length / this.pageSize));
  }

  pagedSchedule(): EmiInstallment[] {
    const start = (this.currentPage() - 1) * this.pageSize;
    const end = start + this.pageSize;

    return this.schedule().slice(start, end);
  }

  pageStart(): number {
    if (this.schedule().length === 0) {
      return 0;
    }

    return (this.currentPage() - 1) * this.pageSize + 1;
  }

  pageEnd(): number {
    return Math.min(this.currentPage() * this.pageSize, this.schedule().length);
  }

  prevPage(): void {
    this.currentPage.update((page) => Math.max(1, page - 1));
  }

  nextPage(): void {
    this.currentPage.update((page) => Math.min(this.totalPages(), page + 1));
  }

  nextPayableInstallmentNo(): number | null {
    const next = this.schedule()
      .filter((i) => !this.isPaid(i))
      .sort((a, b) => (a.installmentNo || 0) - (b.installmentNo || 0))[0];

    return next?.installmentNo ?? null;
  }

  canPay(installment: EmiInstallment): boolean {
    if (this.isPaid(installment)) {
      return false;
    }

    const nextNo = this.nextPayableInstallmentNo();

    if (!nextNo) {
      return false;
    }

    return installment.installmentNo === nextNo;
  }

  pay(installment: EmiInstallment): void {
    if (!installment.installmentId) {
      return;
    }

    if (!this.canPay(installment)) {
      this.toast.error(
        'Payment blocked',
        'Please pay previous EMI installments first.'
      );
      return;
    }

    this.paying.set(installment.installmentId);

    this.repaySvc.markInstallmentPaid(installment).subscribe({
      next: (updated) => {
        const normalizedUpdated: EmiInstallment = {
          ...installment,
          ...updated,
          status: 'PAID',
          paidDate: updated.paidDate || new Date().toISOString().slice(0, 10)
        };

        this.schedule.update((list) =>
          list.map((i) =>
            i.installmentId === normalizedUpdated.installmentId
              ? normalizedUpdated
              : i
          )
        );

        this.paying.set(null);

        this.toast.success(
          'EMI paid',
          `Installment #${installment.installmentNo} marked as paid.`
        );
      },
      error: () => {
        this.paying.set(null);
        this.toast.error('Payment failed', 'Please try again.');
      }
    });
  }
}