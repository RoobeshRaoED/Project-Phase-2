import { Injectable, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map, tap } from 'rxjs';

import { environment } from '../../../../environments/environment';
import { SessionService } from '../../../core/session/session.service';
import { BidderUser } from '../models/user.model';

/**
 * Auth is OUT OF SCOPE for the Bidder Portal -- there is no bidder login,
 * register, OTP or password-reset screen. A bidder signs in through the one
 * shared /login page owned by the auth module; SessionService then fans the
 * JWT out to every module's token key and stores the backend user record
 * under 'hlms_user'.
 *
 * This service therefore does NOT re-implement authentication. It reads the
 * session the shared login already established (via SessionService), and only
 * adds the two profile calls the Settings page needs.
 */
const USER_KEY = 'hlms_user';

@Injectable({ providedIn: 'root' })
export class BidderAuthService {
  private http = inject(HttpClient);
  private session = inject(SessionService);

  private readonly usersUrl = `${environment.apiBaseUrl}${environment.services.user}/api/users`;
  private readonly otpUrl = `${environment.apiBaseUrl}${environment.services.user}/api/otp`;

  readonly currentUser = signal<BidderUser | null>(this.restore());
  readonly email = computed(() => this.currentUser()?.email ?? null);

  /** Delegates to the shared session so token expiry is judged in one place. */
  isLoggedIn(): boolean {
    return this.session.isLoggedIn();
  }

  /** 'BIDDER' | 'CUSTOMER' | ... decoded from the JWT the shared login stored. */
  role(): string | null {
    // SessionService.role is a getter, not a method.
    return this.session.role;
  }

  private restore(): BidderUser | null {
    try {
      const raw = localStorage.getItem(USER_KEY);
      return raw ? (JSON.parse(raw) as BidderUser) : null;
    } catch {
      return null;
    }
  }

  private persist(user: BidderUser | null): void {
    if (user) localStorage.setItem(USER_KEY, JSON.stringify(user));
  }

  /**
   * Re-reads the profile from user-service. Used by Settings so the form is
   * never rendered from a stale localStorage copy.
   */
  refreshProfile(): Observable<BidderUser> {
    const email = this.email();
    if (!email) throw new Error('No signed-in bidder.');
    return this.http.get<BidderUser>(`${this.usersUrl}/${encodeURIComponent(email)}`).pipe(
      tap((user) => {
        this.currentUser.set(user);
        this.persist(user);
      })
    );
  }

  /**
   * appUserController.updateUser takes the whole appUserEntity back on
   * PUT /api/users/{email}, so the current record is spread in and only the
   * editable fields are overwritten -- sending a partial body would blank
   * out role/active/idType server-side.
   */
  updateProfile(changes: Partial<BidderUser>): Observable<BidderUser> {
    const current = this.currentUser();
    if (!current) throw new Error('No signed-in bidder.');
    const body: BidderUser = { ...current, ...changes, email: current.email };
    return this.http
      .put<BidderUser>(`${this.usersUrl}/${encodeURIComponent(current.email)}`, body)
      .pipe(
        tap((user) => {
          this.currentUser.set(user);
          this.persist(user);
        })
      );
  }

  /**
   * user-service has no authenticated "change password with current password"
   * endpoint -- the only password path is forgot-password (mails an OTP) then
   * reset-password (email + otpCode + newPassword). Settings uses that pair.
   * See BIDDER_PORTAL_README.md, "Missing backend endpoints".
   */
  requestPasswordOtp(): Observable<string> {
    const email = this.email();
    if (!email) throw new Error('No signed-in bidder.');
    return this.http
      .post(`${this.usersUrl}/forgot-password`, { email }, { responseType: 'text' })
      .pipe(map((res) => res));
  }

  resetPassword(otpCode: string, newPassword: string): Observable<string> {
    const email = this.email();
    if (!email) throw new Error('No signed-in bidder.');
    return this.http.post(
      `${this.usersUrl}/reset-password`,
      { email, otpCode, newPassword },
      { responseType: 'text' }
    );
  }

  /** Resends the OTP through otpVerificationController's own generator. */
  resendOtp(): Observable<string> {
    const email = this.email();
    if (!email) throw new Error('No signed-in bidder.');
    return this.http.post(
      `${this.otpUrl}/generate`,
      { email, purpose: 'PASSWORD_RESET' },
      { responseType: 'text' }
    );
  }

  /** Ends the session across every portal, exactly as the other modules do. */
  logout(): void {
    this.currentUser.set(null);
    this.session.logoutAll(false);
  }
}
