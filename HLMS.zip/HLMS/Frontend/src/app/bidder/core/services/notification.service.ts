import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';

import { environment } from '../../../../environments/environment';
import { BidderNotification } from '../models/notification.model';

/** notification-service's NotificationController, for the topbar bell. */
@Injectable({ providedIn: 'root' })
export class BidderNotificationService {
  private http = inject(HttpClient);
  private readonly url = `${environment.apiBaseUrl}${environment.services.notification}/api/notifications`;

  readonly notifications = signal<BidderNotification[]>([]);
  readonly unreadCount = signal(0);

  loadForUser(userEmail: string): Observable<BidderNotification[]> {
    return this.http.get<BidderNotification[]>(this.url, { params: { userEmail } }).pipe(
      tap((list) => {
        this.notifications.set(list || []);
        this.unreadCount.set((list || []).filter((n) => !n.read).length);
      })
    );
  }

  /** NotificationController exposes this as PATCH, not PUT. */
  markRead(notificationId: string): Observable<BidderNotification> {
    return this.http
      .patch<BidderNotification>(`${this.url}/${encodeURIComponent(notificationId)}/read`, {})
      .pipe(
        tap((updated) => {
          this.notifications.update((list) =>
            list.map((n) => (n.notificationId === updated.notificationId ? updated : n))
          );
          this.unreadCount.update((c) => Math.max(0, c - 1));
        })
      );
  }
}
