/**
 * user-service's appUserEntity as it serialises over the wire. The other
 * portals each keep their own UI-shaped user type; the Bidder Portal reads
 * the backend record directly because that is exactly what SessionService
 * already stores under 'hlms_user' at login time.
 */
export interface BidderUser {
  email: string;
  name: string;
  mobile: string;
  role: 'CUSTOMER' | 'LEGAL' | 'BANK_OFFICER' | 'BIDDER' | 'ADMIN';
  active?: boolean;
  idType?: string;
  idNumber?: string;
  prefSms?: boolean;
  prefEmail?: boolean;
  prefInapp?: boolean;
  createdAt?: string;
}

export const ROLE_LABELS: Record<BidderUser['role'], string> = {
  CUSTOMER: 'Customer',
  LEGAL: 'Legal Team',
  BANK_OFFICER: 'Bank Office',
  BIDDER: 'Bidder',
  ADMIN: 'Admin'
};
