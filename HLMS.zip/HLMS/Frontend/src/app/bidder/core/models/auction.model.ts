export interface AuctionCase {
  auctionId?: number;
  appId: string;
  /** auction_case.stage is a free VARCHAR(30); these are the values the
   *  Legal / Bank Office portals actually write. */
  stage: 'None' | 'Notice Issued' | 'Possession' | 'Auction Scheduled' | 'Resolved';
  noticeDate?: string;
  noticeDueDate?: string;
  demandAmount?: number;
  possessionDate?: string;
  /** LocalDate -> "yyyy-MM-dd" */
  auctionDate?: string;
  reservePrice?: number;
}

export interface Bid {
  bidId?: string;
  appId: string;
  bidderEmail: string;
  bidAmount: number;
  /** OffsetDateTime -> ISO-8601 string */
  createdAt?: string;
}

export interface AuctionNote {
  noteId?: string;
  appId: string;
  noteDate?: string;
  noteText: string;
}

/**
 * Property facts joined in from loan-service on the UI side.
 *
 * NOTE: loan-service's GET /api/loan-applications/{appId} is annotated
 * @RequireAppOwner and BIDDER is not one of its privileged roles, so it
 * returns 403 for a bidder. GET /api/loan-applications/all is not annotated
 * and is used instead, with the join done here on appId.
 *
 * Only the fields a public auction listing may show are carried over -- the
 * borrower's name, email, income and PAN are deliberately dropped (the bank
 * withholds borrower identity from the listing).
 */
export interface ListingProperty {
  appId: string;
  trackingNo?: string;
  address?: string;
  type?: string;
  value?: number;
}

/** One row of the Bidder Portal's auction listing = case + its property. */
export interface AuctionListing {
  auction: AuctionCase;
  property: ListingProperty;
}
