import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { BidderAuthService } from '../services/auth.service';

export const bidderAuthGuard: CanActivateFn = () => {
  const auth = inject(BidderAuthService);
  const router = inject(Router);
  if (auth.isLoggedIn()) return true;
  router.navigate(['/login']);
  return false;
};
