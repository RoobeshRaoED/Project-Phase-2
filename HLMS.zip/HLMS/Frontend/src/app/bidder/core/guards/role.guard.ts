import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { BidderAuthService } from '../services/auth.service';

/**
 * Usage in routes: data: { roles: ['BIDDER'] }
 *
 * Roles are compared in the backend's own casing (user-service roleEnum:
 * CUSTOMER / LEGAL / BANK_OFFICER / BIDDER / ADMIN) because the value comes
 * straight out of the JWT claim, not from a UI-shaped user record.
 *
 * A signed-in user with the wrong role is sent to the public home page rather
 * than to /bidder, which would redirect back into this guard and loop.
 */
export const bidderRoleGuard: CanActivateFn = (route) => {
  const auth = inject(BidderAuthService);
  const router = inject(Router);

  if (!auth.isLoggedIn()) {
    router.navigate(['/login']);
    return false;
  }

  const allowed = (route.data['roles'] as string[] | undefined)?.map((r) => r.toUpperCase());
  const role = auth.role()?.toUpperCase() ?? null;

  if (allowed && (!role || !allowed.includes(role))) {
    router.navigate(['/']);
    return false;
  }
  return true;
};
