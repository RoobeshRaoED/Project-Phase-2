import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { BidderAuthService } from '../../core/services/auth.service';
import { BIDDER_NAV_ITEMS } from './sidebar.config';

@Component({
  selector: 'app-bidder-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
    <div class="sidebar" id="sidebar">
      @for (item of items; track item.view) {
        <a class="nav-item" [routerLink]="['/bidder', item.view]"
           routerLinkActive="active" [class.active]="isForcedActive(item.view)">
          <span class="ic">{{ item.icon }}</span>{{ item.label }}
        </a>
      }
      <button class="nav-item" style="margin-top:14px;border-top:1px solid var(--border);padding-top:16px;color:var(--red);" (click)="logout()">
        <span class="ic" style="color:var(--red);">⏻</span>Log Out
      </button>
    </div>
  `
})
export class BidderSidebarComponent {
  private auth = inject(BidderAuthService);
  private router = inject(Router);
  items = BIDDER_NAV_ITEMS;

  /**
   * The listing detail page has no nav entry of its own (same as the
   * prototype), so "Auction Listings" stays highlighted while it is open.
   */
  isForcedActive(view: string): boolean {
    return view === 'bidderlistings' && this.router.url.includes('/bidder/bidderlistingdetail');
  }

  logout() {
    this.auth.logout();
    this.router.navigateByUrl('/login');
  }
}
