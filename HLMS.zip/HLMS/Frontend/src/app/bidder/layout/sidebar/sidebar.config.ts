export interface NavItem {
  view: string; // route segment under /bidder/
  icon: string;
  label: string;
}

/**
 * Taken verbatim from the Updated-UI prototype's bidder sidebar
 * (integration-2.js, renderSidebar() -> role === 'bidder'), including the
 * icons and label wording.
 */
export const BIDDER_NAV_ITEMS: NavItem[] = [
  { view: 'bidderdash', icon: '▦', label: 'Dashboard' },
  { view: 'bidderlistings', icon: '☆', label: 'Auction Listings' },
  { view: 'bidderbids', icon: '💰', label: 'My Bids' },
  { view: 'biddersettings', icon: '⚙', label: 'Settings' }
];
