import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { BidderToastComponent } from './shared/components/toast/toast.component';

/**
 * Wrapper for the Bidder Portal's routes, matching the pattern the other four
 * modules already follow: a router-outlet plus this module's own toast host.
 */
@Component({
  selector: 'app-bidder-root',
  standalone: true,
  imports: [RouterOutlet, BidderToastComponent],
  template: `
    <router-outlet></router-outlet>
    <app-bidder-toast></app-bidder-toast>
  `
})
export class AppComponent {}
