import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { catchError, forkJoin, of } from 'rxjs';

import { BidderService } from '../../../core/services/bidder.service';
import { BidderAuthService } from '../../../core/services/auth.service';
import { AuctionListing, Bid } from '../../../core/models/auction.model';
import { highestBid, isAuctionOpen } from '../../../core/utils/bid.util';

interface DashboardRow {
  listing: AuctionListing;
  highest: Bid | null;
}

@Component({
  selector: 'app-bidder-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './bidder-dashboard.component.html'
})
export class BidderDashboardComponent implements OnInit {
  private bidderService = inject(BidderService);
  private auth = inject(BidderAuthService);
  private router = inject(Router);

  loading = signal(true);
  loadError = signal('');

  rows = signal<DashboardRow[]>([]);
  myBids = signal<Bid[]>([]);

  firstName = computed(() => (this.auth.currentUser()?.name || 'Bidder').split(' ')[0]);

  /** Listings still accepting bids. */
  openRows = computed(() => this.rows().filter((r) => isAuctionOpen(r.listing.auction)));

  /** Auctions where my bid is currently on top. */
  winningCount = computed(() => {
    const email = (this.auth.email() || '').toLowerCase();
    if (!email) return 0;
    return this.openRows().filter(
      (r) => r.highest && r.highest.bidderEmail?.toLowerCase() === email
    ).length;
  });

  closingSoon = computed(() => this.openRows().slice(0, 5));

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    const email = this.auth.email();
    this.loading.set(true);
    this.loadError.set('');

    this.bidderService.getListings().subscribe({
      next: (listings) => {
        const bids$ = email
          ? this.bidderService.getMyBids(email).pipe(catchError(() => of([] as Bid[])))
          : of([] as Bid[]);

        if (!listings.length) {
          bids$.subscribe((mine) => {
            this.myBids.set(mine);
            this.rows.set([]);
            this.loading.set(false);
          });
          return;
        }

        // One bids call per live listing, so "current highest" is real data
        // rather than something derived on the client.
        forkJoin({
          perListing: forkJoin(
            listings.map((listing) =>
              this.bidderService
                .getBidsForApp(listing.auction.appId)
                .pipe(catchError(() => of([] as Bid[])))
            )
          ),
          mine: bids$
        }).subscribe({
          next: ({ perListing, mine }) => {
            this.rows.set(
              listings.map((listing, i) => ({ listing, highest: highestBid(perListing[i]) }))
            );
            this.myBids.set(mine);
            this.loading.set(false);
          },
          error: () => {
            this.loadError.set('Auction data could not be loaded. Please try again.');
            this.loading.set(false);
          }
        });
      },
      error: () => {
        this.loadError.set('Auction data could not be loaded. Please try again.');
        this.loading.set(false);
      }
    });
  }

  openListing(appId: string): void {
    this.router.navigate(['/bidder', 'bidderlistingdetail', appId]);
  }
}
