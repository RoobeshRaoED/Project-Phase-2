import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { catchError, forkJoin, of } from 'rxjs';

import { BidderService } from '../../../core/services/bidder.service';
import { BidderAuthService } from '../../../core/services/auth.service';
import { AuctionListing, Bid } from '../../../core/models/auction.model';
import { highestBid, isAuctionOpen } from '../../../core/utils/bid.util';

type BidStatus = 'Highest Bidder' | 'Outbid' | 'Won' | 'Not Won';

interface MyBidRow {
  bid: Bid;
  listing: AuctionListing | null;
  highest: Bid | null;
  status: BidStatus;
}

@Component({
  selector: 'app-bidder-bids',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './bidder-bids.component.html'
})
export class BidderBidsComponent implements OnInit {
  private bidderService = inject(BidderService);
  private auth = inject(BidderAuthService);
  private router = inject(Router);

  loading = signal(true);
  loadError = signal('');
  rows = signal<MyBidRow[]>([]);

  wonCount = computed(() => this.rows().filter((r) => r.status === 'Won').length);
  leadingCount = computed(() => this.rows().filter((r) => r.status === 'Highest Bidder').length);

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    const email = this.auth.email();
    if (!email) {
      this.rows.set([]);
      this.loading.set(false);
      return;
    }

    this.loading.set(true);
    this.loadError.set('');

    forkJoin({
      mine: this.bidderService.getMyBids(email),
      listings: this.bidderService.getListings().pipe(catchError(() => of([] as AuctionListing[])))
    }).subscribe({
      next: ({ mine, listings }) => {
        if (!mine.length) {
          this.rows.set([]);
          this.loading.set(false);
          return;
        }

        // Only the auctions I actually bid on need their bid list fetched.
        const appIds = Array.from(new Set(mine.map((b) => b.appId)));
        forkJoin(
          appIds.map((appId) =>
            this.bidderService.getBidsForApp(appId).pipe(catchError(() => of([] as Bid[])))
          )
        ).subscribe({
          next: (bidLists) => {
            const highestByApp = new Map<string, Bid | null>();
            appIds.forEach((appId, i) => highestByApp.set(appId, highestBid(bidLists[i])));

            this.rows.set(
              mine.map((bid) => {
                const listing = listings.find((l) => l.auction.appId === bid.appId) ?? null;
                const highest = highestByApp.get(bid.appId) ?? null;
                return {
                  bid,
                  listing,
                  highest,
                  status: this.statusFor(bid, listing, highest, email)
                };
              })
            );
            this.loading.set(false);
          },
          error: () => {
            this.loadError.set('Your bids could not be loaded. Please try again.');
            this.loading.set(false);
          }
        });
      },
      error: () => {
        this.loadError.set('Your bids could not be loaded. Please try again.');
        this.loading.set(false);
      }
    });
  }

  /**
   * Leading vs outbid while the auction is still open; won vs not won once
   * the auction date has passed. "Won" is the frontend's reading of who holds
   * the highest bid at close -- the backend has no award/allotment endpoint
   * (see BIDDER_PORTAL_README.md).
   */
  private statusFor(
    bid: Bid,
    listing: AuctionListing | null,
    highest: Bid | null,
    email: string
  ): BidStatus {
    const leading = !!highest && highest.bidderEmail?.toLowerCase() === email.toLowerCase();
    const stillOpen = listing ? isAuctionOpen(listing.auction) : false;
    if (stillOpen) return leading ? 'Highest Bidder' : 'Outbid';
    return leading ? 'Won' : 'Not Won';
  }

  statusBadge(status: BidStatus): string {
    if (status === 'Won') return 'badge-green';
    if (status === 'Highest Bidder') return 'badge-teal';
    if (status === 'Outbid') return 'badge-orange';
    return 'badge-gray';
  }

  openListing(appId: string): void {
    this.router.navigate(['/bidder', 'bidderlistingdetail', appId]);
  }
}
