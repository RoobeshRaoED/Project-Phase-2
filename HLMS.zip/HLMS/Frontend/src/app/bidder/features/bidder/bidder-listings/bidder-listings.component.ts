import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { catchError, forkJoin, of } from 'rxjs';

import { BidderService } from '../../../core/services/bidder.service';
import { AuctionListing, Bid } from '../../../core/models/auction.model';
import { highestBid, isAuctionOpen } from '../../../core/utils/bid.util';

interface ListingRow {
  listing: AuctionListing;
  bids: Bid[];
  highest: Bid | null;
}

const PAGE_SIZE = 6;

@Component({
  selector: 'app-bidder-listings',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './bidder-listings.component.html'
})
export class BidderListingsComponent implements OnInit {
  private bidderService = inject(BidderService);
  private router = inject(Router);

  loading = signal(true);
  loadError = signal('');
  rows = signal<ListingRow[]>([]);

  tab = signal<'open' | 'closed'>('open');
  search = signal('');
  page = signal(1);

  openRows = computed(() => this.rows().filter((r) => isAuctionOpen(r.listing.auction)));
  closedRows = computed(() => this.rows().filter((r) => !isAuctionOpen(r.listing.auction)));

  /** Tab + free-text filter over address, property type and tracking number. */
  filtered = computed(() => {
    const base = this.tab() === 'open' ? this.openRows() : this.closedRows();
    const term = this.search().trim().toLowerCase();
    if (!term) return base;
    return base.filter((r) => {
      const p = r.listing.property;
      return [p.address, p.type, p.trackingNo, r.listing.auction.appId]
        .filter(Boolean)
        .some((v) => String(v).toLowerCase().includes(term));
    });
  });

  totalPages = computed(() => Math.max(1, Math.ceil(this.filtered().length / PAGE_SIZE)));

  paged = computed(() => {
    const start = (this.page() - 1) * PAGE_SIZE;
    return this.filtered().slice(start, start + PAGE_SIZE);
  });

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.loadError.set('');
    this.bidderService.getListings().subscribe({
      next: (listings) => {
        if (!listings.length) {
          this.rows.set([]);
          this.loading.set(false);
          return;
        }
        forkJoin(
          listings.map((l) =>
            this.bidderService.getBidsForApp(l.auction.appId).pipe(catchError(() => of([] as Bid[])))
          )
        ).subscribe({
          next: (allBids) => {
            this.rows.set(
              listings.map((listing, i) => ({
                listing,
                bids: allBids[i],
                highest: highestBid(allBids[i])
              }))
            );
            this.loading.set(false);
          },
          error: () => {
            this.loadError.set('Auction listings could not be loaded. Please try again.');
            this.loading.set(false);
          }
        });
      },
      error: () => {
        this.loadError.set('Auction listings could not be loaded. Please try again.');
        this.loading.set(false);
      }
    });
  }

  setTab(tab: 'open' | 'closed'): void {
    this.tab.set(tab);
    this.page.set(1);
  }

  onSearch(value: string): void {
    this.search.set(value);
    this.page.set(1);
  }

  goToPage(p: number): void {
    if (p < 1 || p > this.totalPages()) return;
    this.page.set(p);
  }

  isOpen(row: ListingRow): boolean {
    return isAuctionOpen(row.listing.auction);
  }

  openListing(appId: string): void {
    this.router.navigate(['/bidder', 'bidderlistingdetail', appId]);
  }
}
