import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { finalize } from 'rxjs';

import { BidderAuthService } from '../../../core/services/auth.service';
import { BidderToastService } from '../../../core/services/toast.service';
import { readableApiError } from '../../../../auth/core/services/api-error.util';
import { HlmsValidators } from '../../../../auth/core/validators/hlms-validators';
import { ROLE_LABELS } from '../../../core/models/user.model';

@Component({
  selector: 'app-bidder-settings',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './bidder-settings.component.html'
})
export class BidderSettingsComponent implements OnInit {
  private fb = inject(FormBuilder);
  private auth = inject(BidderAuthService);
  private toast = inject(BidderToastService);

  user = this.auth.currentUser;
  loading = signal(true);

  savingProfile = signal(false);
  profileError = signal('');

  // Password change runs through the OTP pair user-service actually exposes.
  otpSent = signal(false);
  requestingOtp = signal(false);
  resettingPassword = signal(false);
  passwordError = signal('');
  passwordMessage = signal('');

  // Reuses the shared validators the auth module already defines, so the
  // rules here match the rest of HLMS exactly.
  profileForm = this.fb.nonNullable.group({
    name: ['', [Validators.required, HlmsValidators.fullName()]],
    mobile: ['', [Validators.required, HlmsValidators.mobile()]]
  });

  passwordForm = this.fb.nonNullable.group(
    {
      otpCode: ['', [Validators.required, Validators.pattern(/^\d{4,8}$/)]],
      newPassword: ['', [Validators.required, HlmsValidators.password()]],
      confirmPassword: ['', [Validators.required]]
    },
    { validators: [HlmsValidators.matchPassword('newPassword', 'confirmPassword')] }
  );

  ngOnInit(): void {
    this.patchFromUser();
    // Re-read the profile so the form never renders from a stale cached copy.
    this.auth
      .refreshProfile()
      .pipe(finalize(() => this.loading.set(false)))
      .subscribe({
        next: () => this.patchFromUser(),
        error: () => {} // keep the cached record; the form is still usable
      });
  }

  private patchFromUser(): void {
    const u = this.user();
    if (!u) return;
    this.profileForm.patchValue({ name: u.name || '', mobile: u.mobile || '' });
  }

  roleLabel(): string {
    const u = this.user();
    return u ? ROLE_LABELS[u.role] ?? u.role : '';
  }

  saveProfile(): void {
    this.profileError.set('');
    this.profileForm.markAllAsTouched();
    if (this.profileForm.invalid) return;

    const { name, mobile } = this.profileForm.getRawValue();
    this.savingProfile.set(true);
    this.auth
      .updateProfile({ name: name.trim(), mobile: mobile.trim() })
      .pipe(finalize(() => this.savingProfile.set(false)))
      .subscribe({
        next: () => this.toast.show('Profile Updated', 'Your account details have been saved.', 'success'),
        error: (err) => {
          this.profileError.set(readableApiError(err, 'Your details could not be saved.'));
          this.toast.show('Update Failed', this.profileError(), 'error');
        }
      });
  }

  requestOtp(): void {
    this.passwordError.set('');
    this.passwordMessage.set('');
    this.requestingOtp.set(true);
    this.auth
      .requestPasswordOtp()
      .pipe(finalize(() => this.requestingOtp.set(false)))
      .subscribe({
        next: () => {
          this.otpSent.set(true);
          this.passwordMessage.set('A one-time code has been sent to your registered email.');
        },
        error: (err) => this.passwordError.set(readableApiError(err, 'The code could not be sent.'))
      });
  }

  submitPassword(): void {
    this.passwordError.set('');
    this.passwordMessage.set('');
    this.passwordForm.markAllAsTouched();
    if (this.passwordForm.invalid) return;

    const { otpCode, newPassword } = this.passwordForm.getRawValue();
    this.resettingPassword.set(true);
    this.auth
      .resetPassword(otpCode.trim(), newPassword)
      .pipe(finalize(() => this.resettingPassword.set(false)))
      .subscribe({
        next: () => {
          this.passwordForm.reset();
          this.otpSent.set(false);
          this.toast.show('Password Updated', 'Your password has been changed.', 'success');
        },
        error: (err) => {
          this.passwordError.set(readableApiError(err, 'The password could not be updated.'));
        }
      });
  }
}
