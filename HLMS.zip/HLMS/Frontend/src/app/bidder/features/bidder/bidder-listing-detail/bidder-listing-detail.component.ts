import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { finalize } from 'rxjs';

import { BidderService } from '../../../core/services/bidder.service';
import { BidderAuthService } from '../../../core/services/auth.service';
import { BidderToastService } from '../../../core/services/toast.service';
import { readableApiError } from '../../../../auth/core/services/api-error.util';
import { AuctionListing, AuctionNote, Bid } from '../../../core/models/auction.model';
import {
  bidderDisplayName,
  daysLeft,
  highestBid,
  isAuctionOpen,
  minimumAcceptableBid,
  sortBids,
  suggestedBid
} from '../../../core/utils/bid.util';

@Component({
  selector: 'app-bidder-listing-detail',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './bidder-listing-detail.component.html'
})
export class BidderListingDetailComponent implements OnInit {
  private bidderService = inject(BidderService);
  private auth = inject(BidderAuthService);
  private toast = inject(BidderToastService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  appId = '';

  loading = signal(true);
  notFound = signal(false);
  loadError = signal('');

  listing = signal<AuctionListing | null>(null);
  bids = signal<Bid[]>([]);
  notes = signal<AuctionNote[]>([]);

  // Place-bid form state
  bidAmount: number | null = null;
  bidError = signal('');
  submitting = signal(false);

  sortedBids = computed(() => sortBids(this.bids()));
  highest = computed(() => highestBid(this.bids()));

  open = computed(() => {
    const l = this.listing();
    return !!l && isAuctionOpen(l.auction);
  });

  daysRemaining = computed(() => {
    const l = this.listing();
    return l ? daysLeft(l.auction) : 0;
  });

  iAmHighest = computed(() => {
    const hb = this.highest();
    const email = (this.auth.email() || '').toLowerCase();
    return !!hb && !!email && hb.bidderEmail?.toLowerCase() === email;
  });

  /** Lowest amount the backend will accept -- used for validation. */
  minimumBid = computed(() => {
    const l = this.listing();
    return l ? minimumAcceptableBid(l.auction, this.highest()) : 0;
  });

  /** Friendlier pre-filled amount -- suggestion only, not enforced. */
  suggested = computed(() => {
    const l = this.listing();
    return l ? suggestedBid(l.auction, this.highest()) : 0;
  });

  ngOnInit(): void {
    this.appId = this.route.snapshot.paramMap.get('appId') || '';
    if (!this.appId) {
      this.notFound.set(true);
      this.loading.set(false);
      return;
    }
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.loadError.set('');
    this.bidderService.getListingDetail(this.appId).subscribe({
      next: ({ listing, bids, notes }) => {
        // A case that is not (or no longer) posted for e-auction is not a
        // public listing, even though the auction case itself exists.
        if (listing.auction.stage !== BidderService.LISTED_STAGE) {
          this.notFound.set(true);
          this.loading.set(false);
          return;
        }
        this.listing.set(listing);
        this.bids.set(bids);
        this.notes.set(notes);
        this.bidAmount = this.suggested() || null;
        this.loading.set(false);
      },
      error: (err) => {
        if (err?.status === 404) this.notFound.set(true);
        else this.loadError.set(readableApiError(err, 'This listing could not be loaded.'));
        this.loading.set(false);
      }
    });
  }

  displayName(bid: Bid): string {
    return bidderDisplayName(bid, this.auth.email());
  }

  isMine(bid: Bid): boolean {
    const email = (this.auth.email() || '').toLowerCase();
    return !!email && bid.bidderEmail?.toLowerCase() === email;
  }

  placeBid(): void {
    const listing = this.listing();
    const email = this.auth.email();
    this.bidError.set('');

    if (!listing || !email) return;

    if (!this.open()) {
      this.toast.show('Auction Closed', 'This auction is no longer accepting bids.', 'error');
      return;
    }

    const amount = Number(this.bidAmount || 0);
    if (!amount || amount <= 0) {
      this.bidError.set('Enter a bid amount.');
      return;
    }

    // Mirrors BidServiceImpl: >= reserve price, and strictly above the
    // current highest. The server re-checks both, so a race just surfaces
    // its ValidationException message below.
    const reserve = listing.auction.reservePrice ?? 0;
    if (amount < reserve) {
      this.bidError.set(`Bid must be at least the reserve price of ₹${reserve.toLocaleString('en-IN')}.`);
      return;
    }
    const hb = this.highest();
    if (hb && amount <= hb.bidAmount) {
      this.bidError.set(`Bid must be higher than the current highest bid of ₹${hb.bidAmount.toLocaleString('en-IN')}.`);
      return;
    }

    this.submitting.set(true);
    this.bidderService
      .placeBid(listing.auction.appId, email, amount)
      .pipe(finalize(() => this.submitting.set(false)))
      .subscribe({
        next: (bid) => {
          this.toast.show(
            'Bid Placed',
            `Your bid of ₹${Number(bid.bidAmount).toLocaleString('en-IN')} has been recorded.`,
            'success'
          );
          this.bidAmount = null;
          this.refreshBids();
        },
        error: (err) => {
          // repayment-service's GlobalExceptionHandler returns { status, message }.
          this.bidError.set(readableApiError(err, 'Your bid could not be placed. Please try again.'));
          this.toast.show('Bid Rejected', this.bidError(), 'error');
        }
      });
  }

  /** Re-reads bids after a write so the history and highest bid stay truthful. */
  private refreshBids(): void {
    this.bidderService.getBidsForApp(this.appId).subscribe({
      next: (bids) => {
        this.bids.set(bids);
        this.bidAmount = this.suggested() || null;
      },
      error: () => {}
    });
  }

  backToListings(): void {
    this.router.navigate(['/bidder', 'bidderlistings']);
  }
}
