# HLMS — Bidder Portal Integration

The Bidder Portal has been added to the existing `hlms-integrated` Angular 19
frontend at **`/bidder`**, alongside the Customer, Admin, Bank Office and Legal
portals. It is wired to the existing Spring Cloud backend; **no backend
endpoint was added, changed or duplicated**.

---

## 1. Where the code lives

```
src/app/bidder/
├── bidder-root.component.ts          wrapper (router-outlet + this module's toast host)
├── bidder.routes.ts                  /bidder/* routes, guarded
├── core/
│   ├── guards/auth.guard.ts          signed in?  -> shared /login
│   ├── guards/role.guard.ts          role === BIDDER?  -> /
│   ├── models/auction.model.ts       AuctionCase / Bid / AuctionNote (mirror the DTOs)
│   ├── models/user.model.ts          appUserEntity as it serialises
│   ├── models/notification.model.ts
│   ├── services/auth.service.ts      reads the shared session; profile + password
│   ├── services/bidder.service.ts    every auction/bid call
│   ├── services/notification.service.ts
│   ├── services/toast.service.ts
│   └── utils/bid.util.ts             client mirror of BidServiceImpl's rules
├── layout/                           shell, sidebar, topbar
├── shared/components/toast/
└── features/bidder/
    ├── bidder-dashboard/
    ├── bidder-listings/
    ├── bidder-listing-detail/        property details, place bid, bid history
    ├── bidder-bids/
    └── bidder-settings/
```

Structure, naming, guard layout, signal usage and the per-module toast host all
follow the existing Bank Office portal.

---

## 2. Changes to existing files

Only two, both one-liners:

| File | Change | Why |
|---|---|---|
| `src/app/app.routes.ts` | added the `/bidder` route entry | mounts the portal |
| `src/app/core/session/session.service.ts` | `ROLE_HOME.BIDDER` changed from `null` to `/bidder/bidderdash` | a BIDDER login previously hit *"Your account role does not have a portal in this application yet."* |

Nothing else in Customer, Admin, Bank Office, Legal or Auth was touched.

---

## 3. Backend APIs used

All of these already existed. Everything below is reached through the API
gateway using the relative prefixes in `src/environments/environment.ts`.

### repayment-service — `AuctionCaseController`, `BidController`

| Method | Endpoint | Used by |
|---|---|---|
| GET | `/api/auctions` | listings, dashboard |
| GET | `/api/auctions/by-application/{appId}` | listing detail |
| GET | `/api/auctions/{appId}/bids` | bid history, current highest |
| POST | `/api/auctions/{appId}/bids` | **place a bid** |
| GET | `/api/auctions/{appId}/notes` | auction case notes on the detail page |
| GET | `/api/bids` | My Bids (filtered client-side — see 4.2) |

`POST /api/auctions/{appId}/bids` body is a `BidDTO`:

```json
{ "appId": "APP1001", "bidderEmail": "bidder@…", "bidAmount": 5200000 }
```

`bidId` and `createdAt` are server-generated and deliberately not sent.

`BidServiceImpl` enforces three rules, mirrored client-side in `bid.util.ts` for
instant feedback but always re-checked by the server:

1. the auction case must exist and not be soft-deleted,
2. `bidAmount >= auction_case.reserve_price`,
3. `bidAmount >` the current highest undeleted bid for that `app_id`.

Rejections come back from `GlobalExceptionHandler` as
`{ "status": 400, "message": "…" }` and are surfaced verbatim under the bid
field and as an error toast.

Only cases at **stage `Auction Scheduled`** are treated as public listings;
`None` / `Notice Issued` / `Possession` / `Resolved` are recovery states owned
by the Legal and Bank Office portals and are filtered out.

### loan-service — property details

| Method | Endpoint | Used by |
|---|---|---|
| GET | `/api/loan-applications/all` | property address / type / value per `appId` |

### user-service — Settings

| Method | Endpoint | Used by |
|---|---|---|
| GET | `/api/users/{email}` | load profile |
| PUT | `/api/users/{email}` | save name / mobile |
| POST | `/api/users/forgot-password` | send password-change OTP |
| POST | `/api/users/reset-password` | apply the new password |
| POST | `/api/otp/generate` | resend the code |

### notification-service — topbar bell

| Method | Endpoint |
|---|---|
| GET | `/api/notifications?userEmail=` |
| PATCH | `/api/notifications/{notificationId}/read` |

---

## 4. Backend gaps worked around on the client

### 4.1 `GET /api/loan-applications/{appId}` is unusable for a bidder

It is annotated `@RequireAppOwner`, and `AppOwnerSecurityAspect` treats only
`ADMIN`, `BANK_OFFICER` and `LEGAL` as privileged. A `BIDDER` is neither the
owner nor privileged, so the call returns **403**.

`GET /api/loan-applications/all` carries no such annotation and is used
instead, with the join done on `appId` in `BidderService.getPropertyMap()`
(fetched once per session, `shareReplay(1)`). If it fails the portal degrades
to rendering listings from the auction case alone rather than erroring out.

**Security note worth raising with the backend team:** `/all` returns *every*
application to *any* authenticated user, including applicant name, email,
mobile, PAN, employer and monthly income. The Bidder Portal deliberately
carries only `propertyAddress`, `propertyType`, `propertyValue` and
`trackingNo` into `ListingProperty` and never renders borrower identity — but
the data is still on the wire, and a bidder could read it from the network tab.
This is a backend authorization gap, not a frontend one, and fixing it properly
means either restricting `/all` by role or adding a public listing projection
(see 5).

### 4.2 `GET /api/bids` has no bidder filter

`BidController.findAll()` returns every undeleted bid in the system, so
"My Bids" filters by `bidderEmail` in `BidderService.getMyBids()`. Fine at demo
scale; it does not scale and it hands every bidder the full bid book.

### 4.3 No authenticated change-password endpoint

`user-service` has no endpoint that takes a *current* password. The only
password path is `forgot-password` (mails an OTP) → `reset-password`
(`email` + `otpCode` + `newPassword`). Settings therefore uses that pair, which
is why the Change Password card asks for an emailed code rather than the
current password as the Updated-UI prototype did.

### 4.4 No award / allotment concept

Nothing on the backend marks an auction as won. "Won" in My Bids is the
frontend's reading of *who holds the highest bid once the auction date has
passed*. If a real allotment workflow is added, that derived status should be
replaced with the server's.

---

## 5. Suggested backend additions

None are required for the portal to work — everything above is already
functional — but each would remove a client-side workaround:

1. `GET /api/bids?bidderEmail=…` — replaces the client-side filter in 4.2.
2. `GET /api/auctions/listings` — a public projection returning only auction
   case + property fields, joined server-side. Fixes 4.1 and 4.2's data
   exposure in one step and removes the `/all` dependency entirely.
3. Add `BIDDER` to the read-only privileged set in `AppOwnerSecurityAspect`,
   *or* expose a listing-safe `GET /api/loan-applications/{appId}/public`.
4. `POST /api/users/change-password` taking `{ currentPassword, newPassword }`
   for an authenticated user — removes the OTP detour in 4.3.
5. `POST /api/auctions/{appId}/award` plus a `winningBidId` on `auction_case`,
   so "Won" is authoritative rather than derived.

---

## 6. Behaviour differences from the Updated-UI prototype

Both come from rule 11 — the backend contract wins, the UX is preserved:

- **Bid increment.** The prototype enforced a ₹5,000-ish step as a *hard
  minimum*. The backend only requires *strictly greater than the current
  highest*, so enforcing the step client-side would reject bids the server
  would accept. The step is now a **suggested** pre-filled amount; validation
  uses the backend rule.
- **Change Password.** OTP-based, per 4.3.

Everything else — layout, sidebar, cards, tabs, status pills, empty states,
bid-history masking, the "binding offer" and "borrower identity withheld"
notices — follows the prototype, rebuilt with the global `styles.css` classes
the rest of HLMS already uses.

---

## 7. Auth

Out of scope by design, and unchanged. There is **no** bidder login, register,
OTP or password-reset screen. A bidder signs in through the single shared
`/login` page; `SessionService` fans the JWT out to every module's token key,
stores the user record under `hlms_user`, and now routes `BIDDER` to
`/bidder/bidderdash`. `BidderAuthService` only *reads* that session — it never
mints a token — and `hlmsAuthInterceptor` attaches the `Authorization` header
and handles 401 exactly as it does for the other portals.

---

## 8. Verification

`ng build` passes in both development and production configurations, with no
TypeScript errors and no new warnings (the one remaining warning,
`RouterLinkActive` unused in `AdminShellComponent`, pre-dates this work).

All five pages emit their own lazy chunk:

```
bidder-listing-detail-component   9.63 kB
bidder-settings-component         7.81 kB
bidder-listings-component         5.96 kB
bidder-dashboard-component        5.50 kB
bidder-bids-component             5.33 kB
```

Still to verify against a running backend (needs the services up, a `BIDDER`
account, and at least one auction case at stage `Auction Scheduled`):
end-to-end bid placement, the reserve-price and out-bid rejection paths,
notification loading, and the OTP password change.

### Running it

```bash
npm install
npm start          # ng serve --proxy-config proxy.conf.json
```

Sign in at `/login` with a `BIDDER` account; you land on `/bidder/bidderdash`.
To see a listing, a Bank Office or Legal user must first post a case for
e-auction (Auction Management → Post for e-Auction), which sets stage to
`Auction Scheduled` along with a reserve price and auction date.
