package com.hlms2.legal.repository;

import com.hlms2.legal.entity.BankOfficeDecision;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface BankOfficeDecisionRepository extends JpaRepository<BankOfficeDecision, Long> {
    Optional<BankOfficeDecision> findByAppIdAndDeletedAtIsNull(String appId);
    Optional<BankOfficeDecision> findByDecisionIdAndDeletedAtIsNull(Long decisionId);
    List<BankOfficeDecision> findByDeletedAtIsNull();
}
