package com.hlms2.legal.serviceimpl;

import com.hlms2.legal.dto.LegalChecklistItemDTO;
import com.hlms2.legal.entity.LegalChecklistItem;
import com.hlms2.legal.exception.ResourceNotFoundException;
import com.hlms2.legal.exception.Validators;
import com.hlms2.legal.repository.LegalChecklistItemRepository;
import com.hlms2.legal.service.LegalChecklistItemService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Ported from hlms2.serviceimpl.LegalChecklistItemServiceImpl (plain JDBC
 * version), then updated for hlms_schema_updated_v2.sql: delete is now a
 * soft delete (sets deleted_at), with a matching restore(). PK unchanged
 * (checklist_item_id remains the natural key).
 *
 * Business rules unchanged: checklist key/status validated, new items
 * default to PENDING.
 */
@Service
@Transactional
public class LegalChecklistItemServiceImpl implements LegalChecklistItemService {

    private static final List<String> VALID_STATUSES = List.of("PENDING", "COMPLETED", "NOT_APPLICABLE");

    private final LegalChecklistItemRepository repository;

    public LegalChecklistItemServiceImpl(LegalChecklistItemRepository repository) {
        this.repository = repository;
    }

    @Override
    public LegalChecklistItemDTO create(LegalChecklistItemDTO dto) {
        validate(dto);
        LegalChecklistItem entity = toEntity(dto);
        if (entity.getChecklistItemId() == null || entity.getChecklistItemId().isBlank()) {
            entity.setChecklistItemId("CHK-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        entity.setStatus(entity.getStatus() == null ? "PENDING" : entity.getStatus());
        return toDto(repository.save(entity));
    }

    @Override
    public LegalChecklistItemDTO update(LegalChecklistItemDTO dto) {
        Validators.required(dto.getChecklistItemId(), "checklistItemId");
        repository.findByChecklistItemIdAndDeletedAtIsNull(dto.getChecklistItemId())
                .orElseThrow(() -> new ResourceNotFoundException("Checklist item " + dto.getChecklistItemId() + " does not exist."));
        validate(dto);
        LegalChecklistItem entity = toEntity(dto);
        return toDto(repository.save(entity));
    }

    @Override
    public boolean softDelete(String checklistItemId) {
        return repository.findByChecklistItemIdAndDeletedAtIsNull(checklistItemId)
                .map(entity -> {
                    entity.setDeletedAt(OffsetDateTime.now());
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    public boolean restore(String checklistItemId) {
        return repository.findById(checklistItemId)
                .filter(entity -> entity.getDeletedAt() != null)
                .map(entity -> {
                    entity.setDeletedAt(null);
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    @Transactional(readOnly = true)
    public LegalChecklistItemDTO findById(String checklistItemId) {
        Validators.required(checklistItemId, "checklistItemId");
        return repository.findByChecklistItemIdAndDeletedAtIsNull(checklistItemId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<LegalChecklistItemDTO> findAll() {
        return repository.findByDeletedAtIsNull().stream().map(this::toDto).toList();
    }

    private void validate(LegalChecklistItemDTO dto) {
        Validators.required(dto.getAppId(), "appId");
        Validators.required(dto.getChecklistKey(), "checklistKey");
        if (dto.getStatus() != null) {
            Validators.oneOf(dto.getStatus(), "status", VALID_STATUSES.toArray(new String[0]));
        }
    }

    private LegalChecklistItem toEntity(LegalChecklistItemDTO dto) {
        return LegalChecklistItem.builder()
                .checklistItemId(dto.getChecklistItemId())
                .appId(dto.getAppId())
                .checklistKey(dto.getChecklistKey())
                .status(dto.getStatus())
                .build();
    }

    private LegalChecklistItemDTO toDto(LegalChecklistItem entity) {
        return LegalChecklistItemDTO.builder()
                .checklistItemId(entity.getChecklistItemId())
                .appId(entity.getAppId())
                .checklistKey(entity.getChecklistKey())
                .status(entity.getStatus())
                .build();
    }
}
