package com.hlms2.legal.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Map;

/**
 * Declarative REST client for loan-service.
 *
 * The "name" below ("loan-service") is loan-service's spring.application.name
 * - Eureka resolves it to an actual host:port at runtime, so nothing here is
 * hard-coded. This is how legal-service reaches across the process boundary
 * to loan-service; contrast this with {@link com.hlms2.legal.entity.LoanApplication},
 * which is a same-database read-only mirror used only for local JPA joins.
 */
@FeignClient(name = "loan-service", configuration = FeignAuthConfig.class)
public interface LoanServiceClient {

    @GetMapping("/api/loan-applications/{appId}")
    Map<String, Object> getLoanApplication(@PathVariable("appId") String appId);

    /**
     * Pushes the loan application's workflow stage/status forward in
     * loan-service after a legal decision is recorded here. Body must contain
     * "stageIndex" (int) and "status" (String), matching
     * LoanApplicationController#updateStage in loan-service.
     */
    @PatchMapping("/api/loan-applications/{appId}/stage")
    Map<String, Object> updateLoanStage(@PathVariable("appId") String appId, @RequestBody Map<String, Object> body);
}
