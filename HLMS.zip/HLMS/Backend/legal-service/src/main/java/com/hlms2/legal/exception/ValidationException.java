package com.hlms2.legal.exception;

/**
 * Ported from hlms.util.ValidationException. Unchecked here (Spring's
 * @ControllerAdvice maps it to a 400 response) instead of the checked
 * exception it was in the plain-Java version, since Spring service beans
 * don't declare checked throws on their interface methods.
 */
public class ValidationException extends RuntimeException {
    public ValidationException(String message) {
        super(message);
    }
}
