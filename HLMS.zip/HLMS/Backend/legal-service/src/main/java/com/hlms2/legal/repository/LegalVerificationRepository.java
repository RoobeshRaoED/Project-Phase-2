package com.hlms2.legal.repository;

import com.hlms2.legal.entity.LegalVerification;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface LegalVerificationRepository extends JpaRepository<LegalVerification, Long> {
    Optional<LegalVerification> findByAppIdAndDeletedAtIsNull(String appId);
    Optional<LegalVerification> findByVerificationIdAndDeletedAtIsNull(Long verificationId);
    List<LegalVerification> findByDeletedAtIsNull();
}
