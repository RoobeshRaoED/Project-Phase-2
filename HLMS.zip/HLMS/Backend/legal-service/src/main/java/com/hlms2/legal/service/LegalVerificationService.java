package com.hlms2.legal.service;

import com.hlms2.legal.dto.LegalVerificationDTO;

import java.util.List;

public interface LegalVerificationService {
    LegalVerificationDTO create(LegalVerificationDTO dto);
    LegalVerificationDTO update(Long verificationId, LegalVerificationDTO dto);
    boolean softDelete(Long verificationId);
    boolean restore(Long verificationId);
    LegalVerificationDTO findById(Long verificationId);
    LegalVerificationDTO findByAppId(String appId);
    List<LegalVerificationDTO> findAll();
}
