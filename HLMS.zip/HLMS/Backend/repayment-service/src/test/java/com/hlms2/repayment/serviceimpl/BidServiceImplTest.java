package com.hlms2.repayment.serviceimpl;

import com.hlms2.repayment.dto.BidDTO;
import com.hlms2.repayment.entity.AppUser;
import com.hlms2.repayment.entity.AuctionCase;
import com.hlms2.repayment.entity.Bid;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.exception.ValidationException;
import com.hlms2.repayment.repository.AppUserRepository;
import com.hlms2.repayment.repository.AuctionCaseRepository;
import com.hlms2.repayment.repository.BidRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BidServiceImplTest {

    @Mock
    private BidRepository repository;
    @Mock
    private AuctionCaseRepository auctionCaseRepository;
    @Mock
    private AppUserRepository appUserRepository;

    private BidServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new BidServiceImpl(repository, auctionCaseRepository, appUserRepository);
    }

    private BidDTO validDto() {
        BidDTO dto = new BidDTO();
        dto.setAppId("APP-1");
        dto.setBidderEmail("bidder@bank.com");
        dto.setBidAmount(BigDecimal.valueOf(60000));
        return dto;
    }

    private AuctionCase auctionCaseWithReserve(BigDecimal reserve) {
        return AuctionCase.builder().auctionId(1L).appId("APP-1").reservePrice(reserve).build();
    }

    private AppUser activeUser(String email) {
        AppUser user = new AppUser();
        user.setEmail(email);
        user.setActive(true);
        return user;
    }

    private void stubAuctionAndUser(BigDecimal reserve, boolean activeUserFound) {
        when(auctionCaseRepository.findByAppIdAndDeletedAtIsNull("APP-1"))
                .thenReturn(Optional.of(auctionCaseWithReserve(reserve)));
        when(appUserRepository.findByEmailAndActiveTrueAndDeletedAtIsNull("bidder@bank.com"))
                .thenReturn(activeUserFound ? Optional.of(activeUser("bidder@bank.com")) : Optional.empty());
    }

    // ---------- create() ----------

    @Test
    void create_positive_firstBidAtReservePrice_accepted() {
        BidDTO dto = validDto();
        dto.setBidAmount(BigDecimal.valueOf(50000));
        stubAuctionAndUser(BigDecimal.valueOf(50000), true);
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(List.of());
        when(repository.save(any(Bid.class))).thenAnswer(inv -> inv.getArgument(0));

        BidDTO result = service.create(dto);

        assertThat(result.getBidId()).startsWith("BID-");
        assertThat(result.getCreatedAt()).isNotNull();
    }

    @Test
    void create_positive_higherBidThanCurrentHighest_accepted() {
        BidDTO dto = validDto();
        dto.setBidAmount(BigDecimal.valueOf(70000));
        stubAuctionAndUser(BigDecimal.valueOf(50000), true);
        Bid existingBid = Bid.builder().bidId("BID-OLD").appId("APP-1").bidAmount(BigDecimal.valueOf(60000)).build();
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(List.of(existingBid));
        when(repository.save(any(Bid.class))).thenAnswer(inv -> inv.getArgument(0));

        BidDTO result = service.create(dto);

        assertThat(result.getBidAmount()).isEqualByComparingTo("70000");
    }

    @Test
    void create_negative_missingAppId_throws() {
        BidDTO dto = validDto();
        dto.setAppId(null);

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
        verifyNoInteractions(repository, auctionCaseRepository, appUserRepository);
    }

    @Test
    void create_negative_missingBidderEmail_throws() {
        BidDTO dto = validDto();
        dto.setBidderEmail(null);

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_nonPositiveBidAmount_throws() {
        BidDTO dto = validDto();
        dto.setBidAmount(BigDecimal.ZERO);

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_noAuctionCaseForApplication_throws() {
        BidDTO dto = validDto();
        when(auctionCaseRepository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.create(dto))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("No auction case found");
    }

    @Test
    void create_negative_belowReservePrice_throws() {
        BidDTO dto = validDto();
        dto.setBidAmount(BigDecimal.valueOf(10000));
        when(auctionCaseRepository.findByAppIdAndDeletedAtIsNull("APP-1"))
                .thenReturn(Optional.of(auctionCaseWithReserve(BigDecimal.valueOf(50000))));

        assertThatThrownBy(() -> service.create(dto))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("reserve price");
    }

    @Test
    void create_negative_bidderNotActiveUser_throws() {
        BidDTO dto = validDto();
        stubAuctionAndUser(BigDecimal.valueOf(50000), false);

        assertThatThrownBy(() -> service.create(dto))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("not a known active app_user");
    }

    @Test
    void create_negative_bidNotHigherThanCurrentHighest_throws() {
        BidDTO dto = validDto();
        dto.setBidAmount(BigDecimal.valueOf(60000));
        stubAuctionAndUser(BigDecimal.valueOf(50000), true);
        Bid existingBid = Bid.builder().bidId("BID-OLD").appId("APP-1").bidAmount(BigDecimal.valueOf(60000)).build();
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(List.of(existingBid));

        assertThatThrownBy(() -> service.create(dto))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("higher than the current highest bid");
    }

    @Test
    void create_edge_auctionCaseWithNullReservePrice_skipsReserveCheck() {
        BidDTO dto = validDto();
        stubAuctionAndUser(null, true);
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(List.of());
        when(repository.save(any(Bid.class))).thenAnswer(inv -> inv.getArgument(0));

        assertThat(service.create(dto)).isNotNull();
    }

    // ---------- update() ----------

    @Test
    void update_positive_updatesExisting() {
        BidDTO dto = validDto();
        dto.setBidId("BID-1");
        dto.setBidAmount(BigDecimal.valueOf(80000));
        Bid existing = Bid.builder().bidId("BID-1").appId("APP-1").bidderEmail("bidder@bank.com")
                .bidAmount(BigDecimal.valueOf(60000)).build();
        when(repository.findByBidIdAndDeletedAtIsNull("BID-1")).thenReturn(Optional.of(existing));
        stubAuctionAndUser(BigDecimal.valueOf(50000), true);
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(List.of(existing));
        when(repository.save(any(Bid.class))).thenAnswer(inv -> inv.getArgument(0));

        BidDTO result = service.update(dto);

        assertThat(result.getBidAmount()).isEqualByComparingTo("80000");
    }

    @Test
    void update_negative_missingBidId_throws() {
        assertThatThrownBy(() -> service.update(validDto())).isInstanceOf(ValidationException.class);
    }

    @Test
    void update_negative_notFound_throws() {
        BidDTO dto = validDto();
        dto.setBidId("BID-404");
        when(repository.findByBidIdAndDeletedAtIsNull("BID-404")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.update(dto)).isInstanceOf(ResourceNotFoundException.class);
    }

    // ---------- softDelete() / restore() ----------

    @Test
    void softDelete_positive_returnsTrue() {
        Bid existing = Bid.builder().bidId("BID-1").appId("APP-1").bidAmount(BigDecimal.TEN).build();
        when(repository.findByBidIdAndDeletedAtIsNull("BID-1")).thenReturn(Optional.of(existing));

        assertThat(service.softDelete("BID-1")).isTrue();
        assertThat(existing.getDeletedAt()).isNotNull();
    }

    @Test
    void softDelete_negative_notFound_returnsFalse() {
        when(repository.findByBidIdAndDeletedAtIsNull("BID-404")).thenReturn(Optional.empty());

        assertThat(service.softDelete("BID-404")).isFalse();
    }

    @Test
    void restore_positive_returnsTrue() {
        Bid existing = Bid.builder().bidId("BID-1").appId("APP-1").bidAmount(BigDecimal.TEN)
                .deletedAt(OffsetDateTime.now()).build();
        when(repository.findById("BID-1")).thenReturn(Optional.of(existing));

        assertThat(service.restore("BID-1")).isTrue();
    }

    @Test
    void restore_edge_notDeleted_returnsFalse() {
        Bid existing = Bid.builder().bidId("BID-1").appId("APP-1").bidAmount(BigDecimal.TEN).build();
        when(repository.findById("BID-1")).thenReturn(Optional.of(existing));

        assertThat(service.restore("BID-1")).isFalse();
    }

    // ---------- findById() / findAll() ----------

    @Test
    void findById_negative_missingBidId_throws() {
        assertThatThrownBy(() -> service.findById(null)).isInstanceOf(ValidationException.class);
    }

    @Test
    void findById_positive_returnsDto() {
        Bid existing = Bid.builder().bidId("BID-1").appId("APP-1").bidAmount(BigDecimal.TEN).build();
        when(repository.findByBidIdAndDeletedAtIsNull("BID-1")).thenReturn(Optional.of(existing));

        assertThat(service.findById("BID-1")).isNotNull();
    }

    @Test
    void findAll_edge_empty() {
        when(repository.findByDeletedAtIsNull()).thenReturn(List.of());

        assertThat(service.findAll()).isEmpty();
    }
}
