package com.hlms2.repayment.service;

import com.hlms2.repayment.dto.AuditLogDTO;

import java.util.List;

public interface AuditLogService {
    AuditLogDTO create(AuditLogDTO dto);
    // No update() - audit log entries are immutable (see AuditLogServiceImpl).
    boolean delete(Long logId);
    AuditLogDTO findById(Long logId);
    List<AuditLogDTO> findAll();
}
