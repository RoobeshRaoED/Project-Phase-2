package com.hlms2.repayment.controller;

import com.hlms2.repayment.service.EmiInstallmentService;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

/**
 * Exposes EmiInstallmentServiceImpl's default-detection methods
 * (US-DMNG-01, US-DMNG-04, US-DMNG-05) under their own path, mirroring
 * the /api/default-management routing used elsewhere in this project.
 */
@RestController
@RequestMapping("/api/default-management")
public class DefaultManagementController {

    private final EmiInstallmentService emiInstallmentService;

    public DefaultManagementController(EmiInstallmentService emiInstallmentService) {
        this.emiInstallmentService = emiInstallmentService;
    }

    @GetMapping("/status/{appId}")
    public String getDefaultStatus(@PathVariable String appId) {
        return emiInstallmentService.getDefaultStatus(appId);
    }

    @GetMapping("/escalation/{appId}")
    public String getEscalationLevel(@PathVariable String appId) {
        return emiInstallmentService.determineEscalationLevel(appId);
    }

    @GetMapping("/overdue")
    public Set<String> detectOverdueLoans() {
        return emiInstallmentService.detectOverdueLoans();
    }
}
