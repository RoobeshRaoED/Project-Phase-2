package com.hlms2.repayment.service;

import com.hlms2.repayment.dto.BalanceEligibilityDTO;
import com.hlms2.repayment.dto.DisbursementDTO;

import java.util.List;

public interface DisbursementService {
    DisbursementDTO create(DisbursementDTO dto);
    DisbursementDTO update(Long disbursementId, DisbursementDTO dto);
    boolean softDelete(Long disbursementId);
    boolean restore(Long disbursementId);
    DisbursementDTO findById(Long disbursementId);
    DisbursementDTO findByAppId(String appId);
    List<DisbursementDTO> findAll();

    /**
     * Construction loans only. Credits the remaining (pending) amount once
     * the engineer's-sign post-disbursement document has been uploaded and
     * verified, then rebuilds the EMI schedule on the full sanctioned
     * amount. Throws ValidationException if the loan is not awaiting a
     * balance release or the engineer's sign is not yet verified.
     *
     * @param dto optional - refNo / mode / bankDetails for the balance
     *            credit. Any field left null reuses the first tranche's value.
     */
    DisbursementDTO releaseBalance(String appId, DisbursementDTO dto);

    /** Non-mutating pre-check behind the officer's "Release Balance" button. */
    BalanceEligibilityDTO checkBalanceEligibility(String appId);
}
