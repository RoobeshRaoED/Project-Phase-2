package com.hlms2.repayment.exception;

/**
 * Ported from hlms.util.ValidationException. Unchecked here (Spring's
 * @ControllerAdvice maps it to a 400 response) instead of the checked
 * exception it was in the plain-Java version.
 */
public class ValidationException extends RuntimeException {
    public ValidationException(String message) {
        super(message);
    }
}
