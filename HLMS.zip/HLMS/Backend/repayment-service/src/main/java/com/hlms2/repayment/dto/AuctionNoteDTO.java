package com.hlms2.repayment.dto;

import java.time.OffsetDateTime;

public class AuctionNoteDTO {
    private String noteId;
    private String appId;
    private OffsetDateTime noteDate;
    private String noteText;

    public AuctionNoteDTO() {
    }

    public AuctionNoteDTO(String noteId, String appId, OffsetDateTime noteDate, String noteText) {
        this.noteId = noteId;
        this.appId = appId;
        this.noteDate = noteDate;
        this.noteText = noteText;
    }

    public String getNoteId() {
        return noteId;
    }
    public void setNoteId(String noteId) {
        this.noteId = noteId;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public OffsetDateTime getNoteDate() {
        return noteDate;
    }
    public void setNoteDate(OffsetDateTime noteDate) {
        this.noteDate = noteDate;
    }
    public String getNoteText() {
        return noteText;
    }
    public void setNoteText(String noteText) {
        this.noteText = noteText;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String noteId;
        private String appId;
        private OffsetDateTime noteDate;
        private String noteText;

        public Builder noteId(String noteId) {
            this.noteId = noteId;
            return this;
        }
        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }
        public Builder noteDate(OffsetDateTime noteDate) {
            this.noteDate = noteDate;
            return this;
        }
        public Builder noteText(String noteText) {
            this.noteText = noteText;
            return this;
        }

        public AuctionNoteDTO build() {
            return new AuctionNoteDTO(noteId, appId, noteDate, noteText);
        }
    }
}
