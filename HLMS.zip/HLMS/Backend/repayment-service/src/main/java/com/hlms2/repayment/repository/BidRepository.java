package com.hlms2.repayment.repository;

import com.hlms2.repayment.entity.Bid;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface BidRepository extends JpaRepository<Bid, String> {
    Optional<Bid> findByBidIdAndDeletedAtIsNull(String bidId);
    List<Bid> findByDeletedAtIsNull();
    List<Bid> findByAppIdAndDeletedAtIsNull(String appId);
}
