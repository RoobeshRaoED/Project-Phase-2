package com.hlms2.repayment.repository;

import com.hlms2.repayment.entity.InsurancePolicy;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface InsurancePolicyRepository extends JpaRepository<InsurancePolicy, String> {
    Optional<InsurancePolicy> findByPolicyIdAndDeletedAtIsNull(String policyId);
    List<InsurancePolicy> findByDeletedAtIsNull();
}
