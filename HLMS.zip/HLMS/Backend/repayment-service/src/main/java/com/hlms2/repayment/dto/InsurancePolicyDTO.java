package com.hlms2.repayment.dto;

import java.time.LocalDate;

public class InsurancePolicyDTO {
    private String policyId;
    private String appId;
    private String policyType;
    private String status;
    private LocalDate validTill;

    public InsurancePolicyDTO() {
    }

    public InsurancePolicyDTO(String policyId, String appId, String policyType, String status, LocalDate validTill) {
        this.policyId = policyId;
        this.appId = appId;
        this.policyType = policyType;
        this.status = status;
        this.validTill = validTill;
    }

    public String getPolicyId() {
        return policyId;
    }
    public void setPolicyId(String policyId) {
        this.policyId = policyId;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public String getPolicyType() {
        return policyType;
    }
    public void setPolicyType(String policyType) {
        this.policyType = policyType;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public LocalDate getValidTill() {
        return validTill;
    }
    public void setValidTill(LocalDate validTill) {
        this.validTill = validTill;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String policyId;
        private String appId;
        private String policyType;
        private String status;
        private LocalDate validTill;

        public Builder policyId(String policyId) {
            this.policyId = policyId;
            return this;
        }
        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }
        public Builder policyType(String policyType) {
            this.policyType = policyType;
            return this;
        }
        public Builder status(String status) {
            this.status = status;
            return this;
        }
        public Builder validTill(LocalDate validTill) {
            this.validTill = validTill;
            return this;
        }

        public InsurancePolicyDTO build() {
            return new InsurancePolicyDTO(policyId, appId, policyType, status, validTill);
        }
    }
}
