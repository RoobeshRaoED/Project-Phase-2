package com.hlms2.repayment.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.Map;

/**
 * Declarative REST client for document-service, resolved via Eureka using
 * document-service's spring.application.name.
 *
 * Used to confirm the engineer's-sign post-disbursement document has been
 * uploaded AND verified before the balance tranche of a construction loan
 * is released. Deliberately returns raw maps - repayment-service has no
 * build dependency on document-service's entity classes, and only three
 * fields (docType, status, deletedAt) are read.
 */
@FeignClient(name = "document-service", configuration = FeignAuthConfig.class)
public interface DocumentServiceClient {

    @GetMapping("/api/post-disbursement-documents/app/{appId}")
    List<Map<String, Object>> getPostDisbursementDocuments(@PathVariable("appId") String appId);
}
