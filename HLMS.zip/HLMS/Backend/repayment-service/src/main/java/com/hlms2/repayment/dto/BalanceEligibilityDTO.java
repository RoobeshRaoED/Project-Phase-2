package com.hlms2.repayment.dto;

import java.math.BigDecimal;

/**
 * Answers "can the balance tranche of this construction loan be released
 * right now, and if not, why not?" - so the officer UI can show a precise
 * reason instead of just greying a button out.
 *
 * engineerSignStatus is one of:
 *   NOT_UPLOADED | PENDING_VERIFICATION | REJECTED | VERIFIED | UNKNOWN
 * (UNKNOWN means document-service could not be reached.)
 */
public class BalanceEligibilityDTO {

    private String appId;
    private boolean eligible;
    private String reason;
    private String engineerSignStatus;
    private String trancheStatus;
    private BigDecimal sanctionedAmount;
    private BigDecimal disbursedAmount;
    private BigDecimal pendingAmount;

    public BalanceEligibilityDTO() {
    }

    public BalanceEligibilityDTO(String appId, boolean eligible, String reason, String engineerSignStatus,
                                 String trancheStatus, BigDecimal sanctionedAmount, BigDecimal disbursedAmount,
                                 BigDecimal pendingAmount) {
        this.appId = appId;
        this.eligible = eligible;
        this.reason = reason;
        this.engineerSignStatus = engineerSignStatus;
        this.trancheStatus = trancheStatus;
        this.sanctionedAmount = sanctionedAmount;
        this.disbursedAmount = disbursedAmount;
        this.pendingAmount = pendingAmount;
    }

    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public boolean isEligible() {
        return eligible;
    }
    public void setEligible(boolean eligible) {
        this.eligible = eligible;
    }
    public String getReason() {
        return reason;
    }
    public void setReason(String reason) {
        this.reason = reason;
    }
    public String getEngineerSignStatus() {
        return engineerSignStatus;
    }
    public void setEngineerSignStatus(String engineerSignStatus) {
        this.engineerSignStatus = engineerSignStatus;
    }
    public String getTrancheStatus() {
        return trancheStatus;
    }
    public void setTrancheStatus(String trancheStatus) {
        this.trancheStatus = trancheStatus;
    }
    public BigDecimal getSanctionedAmount() {
        return sanctionedAmount;
    }
    public void setSanctionedAmount(BigDecimal sanctionedAmount) {
        this.sanctionedAmount = sanctionedAmount;
    }
    public BigDecimal getDisbursedAmount() {
        return disbursedAmount;
    }
    public void setDisbursedAmount(BigDecimal disbursedAmount) {
        this.disbursedAmount = disbursedAmount;
    }
    public BigDecimal getPendingAmount() {
        return pendingAmount;
    }
    public void setPendingAmount(BigDecimal pendingAmount) {
        this.pendingAmount = pendingAmount;
    }
}
