package com.hlms2.repayment.entity;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * JPA entity for 'disbursement'.
 *
 * CHG(v2): switched from app_id-as-PK to a surrogate disbursement_id
 * (BIGSERIAL); app_id is now a unique FK column. Adds the deleted_at
 * soft delete marker.
 *
 * CHG(v4 - construction tranches): a construction loan is credited in two
 * tranches. app_id stays UNIQUE - there is still exactly one disbursement
 * row per application - and the tranche state lives in these columns:
 *
 *   sanctionedAmount   total approved loan amount
 *   disbursedAmount    credited so far (tranche 1, later tranche 1 + 2)
 *   pendingAmount      sanctioned - disbursed (0 once fully released)
 *   disbursementType   FULL | PARTIAL
 *   trancheStatus      COMPLETED | AWAITING_ENGINEER_SIGN
 *   balanceRefNo       bank reference for the balance credit
 *   balanceReleasedDate when the balance tranche was credited
 *
 * `amount` is kept in sync with disbursedAmount so every existing consumer
 * of this entity (officer list, customer views, EMI generation) keeps
 * reading "money actually credited" without any change.
 */
@Entity
@Table(name = "disbursement")
public class Disbursement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "disbursement_id")
    private Long disbursementId;

    @Column(name = "app_id", length = 50, nullable = false, unique = true)
    private String appId;

    @Column(name = "disbursed_date")
    private OffsetDateTime disbursedDate;

    @Column(name = "amount")
    private BigDecimal amount;

    @Column(name = "ref_no", length = 50)
    private String refNo;

    @Column(name = "mode", length = 30)
    private String mode;

    @Column(name = "bank_details", length = 150)
    private String bankDetails;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    // ---- construction-loan tranche columns (v4) ----

    @Column(name = "sanctioned_amount", precision = 14, scale = 2)
    private BigDecimal sanctionedAmount;

    @Column(name = "disbursed_amount", precision = 14, scale = 2)
    private BigDecimal disbursedAmount;

    @Column(name = "pending_amount", precision = 14, scale = 2)
    private BigDecimal pendingAmount;

    @Column(name = "disbursement_type", length = 20)
    private String disbursementType;

    @Column(name = "tranche_status", length = 30)
    private String trancheStatus;

    @Column(name = "balance_ref_no", length = 50)
    private String balanceRefNo;

    @Column(name = "balance_released_date")
    private OffsetDateTime balanceReleasedDate;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "app_id", referencedColumnName = "app_id", insertable = false, updatable = false)
    private LoanApplication loanApplication;

    public LoanApplication getLoanApplication() {
        return loanApplication;
    }

    public Disbursement() {
    }

    /** Pre-v4 constructor - kept so existing callers/tests still compile. */
    public Disbursement(Long disbursementId, String appId, OffsetDateTime disbursedDate, BigDecimal amount, String refNo, String mode, String bankDetails, OffsetDateTime deletedAt) {
        this.disbursementId = disbursementId;
        this.appId = appId;
        this.disbursedDate = disbursedDate;
        this.amount = amount;
        this.refNo = refNo;
        this.mode = mode;
        this.bankDetails = bankDetails;
        this.deletedAt = deletedAt;
    }

    public Disbursement(Long disbursementId, String appId, OffsetDateTime disbursedDate, BigDecimal amount,
                        String refNo, String mode, String bankDetails, OffsetDateTime deletedAt,
                        BigDecimal sanctionedAmount, BigDecimal disbursedAmount, BigDecimal pendingAmount,
                        String disbursementType, String trancheStatus, String balanceRefNo,
                        OffsetDateTime balanceReleasedDate) {
        this(disbursementId, appId, disbursedDate, amount, refNo, mode, bankDetails, deletedAt);
        this.sanctionedAmount = sanctionedAmount;
        this.disbursedAmount = disbursedAmount;
        this.pendingAmount = pendingAmount;
        this.disbursementType = disbursementType;
        this.trancheStatus = trancheStatus;
        this.balanceRefNo = balanceRefNo;
        this.balanceReleasedDate = balanceReleasedDate;
    }

    public Long getDisbursementId() {
        return disbursementId;
    }
    public void setDisbursementId(Long disbursementId) {
        this.disbursementId = disbursementId;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public OffsetDateTime getDisbursedDate() {
        return disbursedDate;
    }
    public void setDisbursedDate(OffsetDateTime disbursedDate) {
        this.disbursedDate = disbursedDate;
    }
    public BigDecimal getAmount() {
        return amount;
    }
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
    public String getRefNo() {
        return refNo;
    }
    public void setRefNo(String refNo) {
        this.refNo = refNo;
    }
    public String getMode() {
        return mode;
    }
    public void setMode(String mode) {
        this.mode = mode;
    }
    public String getBankDetails() {
        return bankDetails;
    }
    public void setBankDetails(String bankDetails) {
        this.bankDetails = bankDetails;
    }
    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }
    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public BigDecimal getSanctionedAmount() {
        return sanctionedAmount;
    }
    public void setSanctionedAmount(BigDecimal sanctionedAmount) {
        this.sanctionedAmount = sanctionedAmount;
    }
    public BigDecimal getDisbursedAmount() {
        return disbursedAmount;
    }
    public void setDisbursedAmount(BigDecimal disbursedAmount) {
        this.disbursedAmount = disbursedAmount;
    }
    public BigDecimal getPendingAmount() {
        return pendingAmount;
    }
    public void setPendingAmount(BigDecimal pendingAmount) {
        this.pendingAmount = pendingAmount;
    }
    public String getDisbursementType() {
        return disbursementType;
    }
    public void setDisbursementType(String disbursementType) {
        this.disbursementType = disbursementType;
    }
    public String getTrancheStatus() {
        return trancheStatus;
    }
    public void setTrancheStatus(String trancheStatus) {
        this.trancheStatus = trancheStatus;
    }
    public String getBalanceRefNo() {
        return balanceRefNo;
    }
    public void setBalanceRefNo(String balanceRefNo) {
        this.balanceRefNo = balanceRefNo;
    }
    public OffsetDateTime getBalanceReleasedDate() {
        return balanceReleasedDate;
    }
    public void setBalanceReleasedDate(OffsetDateTime balanceReleasedDate) {
        this.balanceReleasedDate = balanceReleasedDate;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private Long disbursementId;
        private String appId;
        private OffsetDateTime disbursedDate;
        private BigDecimal amount;
        private String refNo;
        private String mode;
        private String bankDetails;
        private OffsetDateTime deletedAt;
        private BigDecimal sanctionedAmount;
        private BigDecimal disbursedAmount;
        private BigDecimal pendingAmount;
        private String disbursementType;
        private String trancheStatus;
        private String balanceRefNo;
        private OffsetDateTime balanceReleasedDate;

        public Builder disbursementId(Long disbursementId) {
            this.disbursementId = disbursementId;
            return this;
        }
        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }
        public Builder disbursedDate(OffsetDateTime disbursedDate) {
            this.disbursedDate = disbursedDate;
            return this;
        }
        public Builder amount(BigDecimal amount) {
            this.amount = amount;
            return this;
        }
        public Builder refNo(String refNo) {
            this.refNo = refNo;
            return this;
        }
        public Builder mode(String mode) {
            this.mode = mode;
            return this;
        }
        public Builder bankDetails(String bankDetails) {
            this.bankDetails = bankDetails;
            return this;
        }
        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }
        public Builder sanctionedAmount(BigDecimal sanctionedAmount) {
            this.sanctionedAmount = sanctionedAmount;
            return this;
        }
        public Builder disbursedAmount(BigDecimal disbursedAmount) {
            this.disbursedAmount = disbursedAmount;
            return this;
        }
        public Builder pendingAmount(BigDecimal pendingAmount) {
            this.pendingAmount = pendingAmount;
            return this;
        }
        public Builder disbursementType(String disbursementType) {
            this.disbursementType = disbursementType;
            return this;
        }
        public Builder trancheStatus(String trancheStatus) {
            this.trancheStatus = trancheStatus;
            return this;
        }
        public Builder balanceRefNo(String balanceRefNo) {
            this.balanceRefNo = balanceRefNo;
            return this;
        }
        public Builder balanceReleasedDate(OffsetDateTime balanceReleasedDate) {
            this.balanceReleasedDate = balanceReleasedDate;
            return this;
        }

        public Disbursement build() {
            return new Disbursement(disbursementId, appId, disbursedDate, amount, refNo, mode, bankDetails,
                    deletedAt, sanctionedAmount, disbursedAmount, pendingAmount, disbursementType,
                    trancheStatus, balanceRefNo, balanceReleasedDate);
        }
    }
}
