package com.hlms2.repayment.service;

import com.hlms2.repayment.dto.EmiInstallmentDTO;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;

public interface EmiInstallmentService {
    EmiInstallmentDTO create(EmiInstallmentDTO dto);
    EmiInstallmentDTO update(EmiInstallmentDTO dto);
    boolean softDelete(String installmentId);
    boolean restore(String installmentId);
    EmiInstallmentDTO findById(String installmentId);
    List<EmiInstallmentDTO> findAll();

    List<EmiInstallmentDTO> getPaymentHistory(String appId);
    Set<String> detectOverdueLoans();
    String determineEscalationLevel(String appId);
    String getDefaultStatus(String appId);

    /**
     * US-DSB-02: builds and persists the full month-by-month EMI repayment
     * schedule for a loan once it has been disbursed, using the standard
     * reducing-balance EMI formula. Idempotent - if a (non-deleted)
     * schedule already exists for appId, the existing schedule is
     * returned unchanged rather than duplicated.
     *
     * @param appId        the loan application the schedule belongs to
     * @param principal    disbursed principal amount
     * @param annualRatePct annual interest rate, as a percentage (e.g. 8.5 for 8.5%)
     * @param tenureYears  loan tenure in years
     * @param firstDueDate due date of installment #1 (subsequent installments fall on the same day of each following month)
     */
    List<EmiInstallmentDTO> generateSchedule(String appId, BigDecimal principal, BigDecimal annualRatePct,
                                              Integer tenureYears, LocalDate firstDueDate);

    /**
     * CHG(v4 - construction tranches): rebuilds the schedule from scratch on
     * a new principal. Used when the balance tranche of a construction loan
     * is released and the customer's EMI must now reflect the full sanctioned
     * amount rather than tranche 1 alone.
     *
     * The previous schedule is soft-deleted (kept for audit), then a fresh
     * one is generated. Refuses with ValidationException if any installment
     * has already been marked PAID - rewriting a schedule the customer has
     * already paid against would silently destroy repayment history, so that
     * case is escalated to a human instead.
     */
    List<EmiInstallmentDTO> regenerateSchedule(String appId, BigDecimal principal, BigDecimal annualRatePct,
                                               Integer tenureYears, LocalDate firstDueDate);
}
