package com.hlms2.repayment.controller;

import com.hlms2.repayment.dto.BalanceEligibilityDTO;
import com.hlms2.repayment.dto.DisbursementDTO;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.service.DisbursementService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/disbursements")
public class DisbursementController {

    private final DisbursementService service;

    public DisbursementController(DisbursementService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<DisbursementDTO> create(@RequestBody DisbursementDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(dto));
    }

    @PutMapping("/{disbursementId}")
    public DisbursementDTO update(@PathVariable Long disbursementId, @RequestBody DisbursementDTO dto) {
        return service.update(disbursementId, dto);
    }

    @DeleteMapping("/{disbursementId}")
    public ResponseEntity<Void> softDelete(@PathVariable Long disbursementId) {
        return service.softDelete(disbursementId) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @PostMapping("/{disbursementId}/restore")
    public ResponseEntity<Void> restore(@PathVariable Long disbursementId) {
        return service.restore(disbursementId) ? ResponseEntity.ok().build() : ResponseEntity.notFound().build();
    }

    @GetMapping("/{disbursementId}")
    public DisbursementDTO findById(@PathVariable Long disbursementId) {
        DisbursementDTO dto = service.findById(disbursementId);
        if (dto == null) {
            throw new ResourceNotFoundException("No disbursement found with id " + disbursementId + ".");
        }
        return dto;
    }

    @GetMapping("/by-application/{appId}")
    public DisbursementDTO findByAppId(@PathVariable String appId) {
        DisbursementDTO dto = service.findByAppId(appId);
        if (dto == null) {
            throw new ResourceNotFoundException("No disbursement found for application " + appId + ".");
        }
        return dto;
    }

    @GetMapping
    public List<DisbursementDTO> findAll() {
        return service.findAll();
    }

    // ---- construction-loan balance tranche ----

    /**
     * Non-mutating check the officer UI calls before enabling its
     * "Release Balance" button, so the reason a release is blocked can be
     * shown verbatim instead of being guessed at client-side.
     */
    @GetMapping("/by-application/{appId}/balance-eligibility")
    public BalanceEligibilityDTO checkBalanceEligibility(@PathVariable String appId) {
        return service.checkBalanceEligibility(appId);
    }

    /**
     * Credits the withheld balance of a construction loan. The
     * engineer's-sign gate is enforced server-side, so this stays safe even
     * if the button is bypassed.
     */
    @PostMapping("/by-application/{appId}/release-balance")
    public DisbursementDTO releaseBalance(
            @PathVariable String appId,
            @RequestBody(required = false) DisbursementDTO dto) {

        return service.releaseBalance(appId, dto);
    }
}
