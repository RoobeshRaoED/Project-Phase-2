package com.hlms2.repayment.serviceimpl;

import com.hlms2.repayment.dto.AuctionCaseDTO;
import com.hlms2.repayment.entity.AuctionCase;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.exception.ValidationException;
import com.hlms2.repayment.exception.Validators;
import com.hlms2.repayment.repository.AuctionCaseRepository;
import com.hlms2.repayment.service.AuctionCaseService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.List;

/**
 * Ported from hlms2.serviceimpl.AuctionCaseServiceImpl (plain JDBC
 * version), then updated for hlms_schema_updated_v2.sql:
 *
 * - auction_id is now the surrogate PK; app_id is a unique lookup column
 *   (create() checks uniqueness on app_id, update()/findById key off
 *   auction_id).
 * - delete is now a soft delete (sets deleted_at), with a matching
 *   restore(). Note: the schema's trg_cascade_soft_delete_auction_case
 *   trigger automatically soft-deletes this case's auction_note and bid
 *   rows too, at the DB level, whenever deleted_at is set here.
 *
 * Business rules unchanged (US-AM-01, US-AM-02): the notice/possession/
 * auction dates must fall in a sane chronological order, and the stage
 * vocabulary matches the schema's CHECK constraint exactly.
 */
@Service
@Transactional
public class AuctionCaseServiceImpl implements AuctionCaseService {

    // Must match the "stage" CHECK constraint in the schema.
    private static final List<String> VALID_STAGES = List.of(
            "None", "Notice Issued", "Possession", "Auction Scheduled", "Resolved");

    private final AuctionCaseRepository repository;

    public AuctionCaseServiceImpl(AuctionCaseRepository repository) {
        this.repository = repository;
    }

    @Override
    public AuctionCaseDTO create(AuctionCaseDTO dto) {
        Validators.required(dto.getAppId(), "appId");
        if (repository.findByAppIdAndDeletedAtIsNull(dto.getAppId()).isPresent()) {
            throw new ValidationException("An auction case already exists for application " + dto.getAppId() + ".");
        }
        validate(dto);
        AuctionCase entity = toEntity(dto);
        entity.setAuctionId(null);
        entity.setStage(entity.getStage() == null ? "Notice Issued" : entity.getStage());
        return toDto(repository.save(entity));
    }

    @Override
    public AuctionCaseDTO update(Long auctionId, AuctionCaseDTO dto) {
        AuctionCase existing = repository.findByAuctionIdAndDeletedAtIsNull(auctionId)
                .orElseThrow(() -> new ResourceNotFoundException("No auction case found with id " + auctionId + "."));
        dto.setAppId(dto.getAppId() != null ? dto.getAppId() : existing.getAppId());
        validate(dto);
        AuctionCase entity = toEntity(dto);
        entity.setAuctionId(auctionId);
        return toDto(repository.save(entity));
    }

    @Override
    public boolean softDelete(Long auctionId) {
        return repository.findByAuctionIdAndDeletedAtIsNull(auctionId)
                .map(entity -> {
                    entity.setDeletedAt(OffsetDateTime.now());
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    public boolean restore(Long auctionId) {
        return repository.findById(auctionId)
                .filter(entity -> entity.getDeletedAt() != null)
                .map(entity -> {
                    entity.setDeletedAt(null);
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    @Transactional(readOnly = true)
    public AuctionCaseDTO findById(Long auctionId) {
        return repository.findByAuctionIdAndDeletedAtIsNull(auctionId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public AuctionCaseDTO findByAppId(String appId) {
        Validators.required(appId, "appId");
        return repository.findByAppIdAndDeletedAtIsNull(appId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AuctionCaseDTO> findAll() {
        return repository.findByDeletedAtIsNull().stream().map(this::toDto).toList();
    }

    private void validate(AuctionCaseDTO dto) {
        if (dto.getStage() != null) {
            Validators.oneOf(dto.getStage(), "stage", VALID_STAGES.toArray(new String[0]));
        }
        Validators.required(dto.getNoticeDate(), "noticeDate");
        Validators.afterOrEqual(dto.getNoticeDueDate(), dto.getNoticeDate(), "noticeDueDate", "noticeDate");
        Validators.positive(dto.getDemandAmount(), "demandAmount");
        Validators.positive(dto.getReservePrice(), "reservePrice");
        if (dto.getPossessionDate() != null) {
            Validators.afterOrEqual(dto.getPossessionDate(), dto.getNoticeDueDate(), "possessionDate", "noticeDueDate");
        }
        if (dto.getAuctionDate() != null && dto.getPossessionDate() != null) {
            Validators.afterOrEqual(dto.getAuctionDate(), dto.getPossessionDate(), "auctionDate", "possessionDate");
        }
    }

    private AuctionCase toEntity(AuctionCaseDTO dto) {
        return AuctionCase.builder()
                .auctionId(dto.getAuctionId())
                .appId(dto.getAppId())
                .stage(dto.getStage())
                .noticeDate(dto.getNoticeDate())
                .noticeDueDate(dto.getNoticeDueDate())
                .demandAmount(dto.getDemandAmount())
                .possessionDate(dto.getPossessionDate())
                .auctionDate(dto.getAuctionDate())
                .reservePrice(dto.getReservePrice())
                .build();
    }

    private AuctionCaseDTO toDto(AuctionCase entity) {
        return AuctionCaseDTO.builder()
                .auctionId(entity.getAuctionId())
                .appId(entity.getAppId())
                .stage(entity.getStage())
                .noticeDate(entity.getNoticeDate())
                .noticeDueDate(entity.getNoticeDueDate())
                .demandAmount(entity.getDemandAmount())
                .possessionDate(entity.getPossessionDate())
                .auctionDate(entity.getAuctionDate())
                .reservePrice(entity.getReservePrice())
                .build();
    }
}
