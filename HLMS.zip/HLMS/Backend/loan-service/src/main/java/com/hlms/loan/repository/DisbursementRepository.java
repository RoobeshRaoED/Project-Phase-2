package com.hlms.loan.repository;

import com.hlms.loan.entity.Disbursement;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface DisbursementRepository extends JpaRepository<Disbursement, Long> {
    Optional<Disbursement> findByAppIdAndDeletedAtIsNull(String appId);
}
