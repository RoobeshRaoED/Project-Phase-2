package com.hlms.loan.dto;

/** US-LT-07 Turnaround Time Tracking - one row of the per-stage duration report. */
public record TurnaroundReportEntry(
        String appId,
        String fromStage,
        String toStage,
        double hoursTaken
) {}
