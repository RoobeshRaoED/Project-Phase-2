package com.hlms.loan.repository;

import com.hlms.loan.entity.CustomerEmploymentProfile;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface CustomerEmploymentProfileRepository extends JpaRepository<CustomerEmploymentProfile, Long> {
    Optional<CustomerEmploymentProfile> findByUserEmailAndDeletedAtIsNull(String userEmail);
}
