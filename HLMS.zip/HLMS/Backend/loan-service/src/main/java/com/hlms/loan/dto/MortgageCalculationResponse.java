package com.hlms.loan.dto;

import java.math.BigDecimal;
import java.util.List;

public record MortgageCalculationResponse(
        BigDecimal requestedLoanAmount,
        BigDecimal propertyValue,
        BigDecimal unsecuredEligibleAmount,       // US-EL-08 / US-MRC-01: max loan without mortgage
        boolean mortgageRequired,
        BigDecimal mortgageValueRequired,          // amount of the loan that must be secured by the property
        String maxLtvAllowed,                      // from loan_product, e.g. "90%"
        BigDecimal loanToValueRatio,                // requested loan / property value, as a percentage
        boolean collateralSufficient,               // property value * max LTV >= requested loan
        List<String> notes
) {}
