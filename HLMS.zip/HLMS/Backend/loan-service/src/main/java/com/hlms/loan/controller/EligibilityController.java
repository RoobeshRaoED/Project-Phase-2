package com.hlms.loan.controller;

import com.hlms.loan.dto.EligibilityRequest;
import com.hlms.loan.dto.EligibilityResponse;
import com.hlms.loan.entity.EligibilityAssessment;
import com.hlms.loan.service.EligibilityService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** US-EL-01..08: Eligibility Assessment, CIBIL analysis, DTI, simulation, max loan, history. */
@RestController
@RequestMapping("/api/eligibility")
public class EligibilityController {

    private final EligibilityService eligibilityService;

    public EligibilityController(EligibilityService eligibilityService) {
        this.eligibilityService = eligibilityService;
    }

    /** Real eligibility check, tied to a customer and persisted for later reference. */
    @PostMapping("/assess")
    public EligibilityResponse assess(@RequestParam String userEmail, @RequestBody EligibilityRequest request) {
        return eligibilityService.assessAndSave(userEmail, request);
    }

    /** US-EL-07 Eligibility Simulation: stateless, try-before-you-apply scenarios (no history saved). */
    @PostMapping("/simulate")
    public EligibilityResponse simulate(@RequestBody EligibilityRequest request) {
        return eligibilityService.assess(request);
    }

    @GetMapping("/history")
    public List<EligibilityAssessment> history(@RequestParam String userEmail) {
        return eligibilityService.getHistory(userEmail);
    }
}
