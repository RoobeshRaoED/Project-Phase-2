# loan-service (standalone)

This is just the `loan-service` module from the HLMS microservices project,
repackaged so it can be built and run **on its own**, without eureka-server
or config-server. Nothing in its Java code calls another microservice
directly (verified: no Feign/RestTemplate/WebClient usage), so it's safe to
run in isolation.

## 1. Prerequisites
- Java 17
- Maven 3.9+
- PostgreSQL running locally, with a `hlms` database whose schema is already
  created (this module was split out of a monolith that shares one DB schema
  across all services — it does NOT create tables itself, `ddl-auto=validate`).
  You need your original HLMS base schema SQL, plus `sql/schema_additions_v3.sql`
  from the full project if you haven't applied it yet.

## 2. Configure
Edit `src/main/resources/application.properties` if your DB isn't at the
defaults (`localhost:5432/hlms`, user/pass `postgres`/`postgres`).

`hlms.jwt.secret` must match whatever issued the JWT you'll test with (e.g.
if you also run `user-service` to log in and get a token, both services need
the *same* secret).

## 3. Build
```bash
mvn clean package
```

## 4. Run
```bash
java -jar target/loan-service.jar
```
or, without building a jar first:
```bash
mvn spring-boot:run
```

The service starts on **http://localhost:8082**.

- Swagger UI: http://localhost:8082/swagger-ui.html
- OpenAPI JSON: http://localhost:8082/v3/api-docs

## Notes
- Eureka client and Spring Cloud Config client are fully **removed** here
  (not just disabled) — no `spring-cloud-starter-netflix-eureka-client`,
  no `spring-cloud-starter-config`, no `@EnableDiscoveryClient`, no
  `spring.config.import`. This is a plain Spring Boot app, same as the
  `legal-service` standalone package. If you ever want to reconnect it to
  the full microservices system, you'd need to add those dependencies back.
- Endpoints under `@PreAuthorize`/JWT-secured controllers still need a valid
  bearer token signed with `hlms.jwt.secret`. If you're testing standalone
  without `user-service`, you'll need to mint a test JWT yourself (same
  claims structure as `JwtService.java` produces: subject = email, `role`
  claim) or temporarily loosen `SecurityConfig.java`.
