package com.tcs.hlms.serviceImplementation;
import com.tcs.hlms.exceptions.InvalidRequestException;
import com.tcs.hlms.exceptions.ResourceNotFoundException;
import com.tcs.hlms.entity.PostDisbursementDocumentEntity;
import com.tcs.hlms.repository.PostDisbursementDocumentRepository;
import com.tcs.hlms.service.PostDisbursementDocumentService;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Set;

@Service
public class PostDisbursementDocumentServiceImpl
        implements PostDisbursementDocumentService {

    private final PostDisbursementDocumentRepository repository;

    public PostDisbursementDocumentServiceImpl(
            PostDisbursementDocumentRepository repository) {
        this.repository = repository;
    }

    @Override
    public PostDisbursementDocumentEntity saveDocument(
            PostDisbursementDocumentEntity document) {

        return repository.save(document);
    }

    @Override
    public PostDisbursementDocumentEntity getDocumentById(
            String documentId) {

        return repository.findById(documentId)
        		.orElseThrow(() ->
        	    new ResourceNotFoundException(
        	        "Post Disbursement Document not found : "
        	                + documentId));
    }

    @Override
    public List<PostDisbursementDocumentEntity> getDocumentsByAppId(
            String appId) {

        return repository.findByAppId(appId);
    }

    @Override
    public List<PostDisbursementDocumentEntity> getAllDocuments() {

        return repository.findAll();
    }

    @Override
    public void deleteDocument(String documentId) {

        repository.deleteById(documentId);
    }

    private static final Set<String> ALLOWED_STATUSES = Set.of("VERIFIED", "REJECTED");

    @Override
    public PostDisbursementDocumentEntity updateStatus(
            String documentId, String status, String verifiedBy, String remarks) {

        if (status == null || !ALLOWED_STATUSES.contains(status.trim().toUpperCase())) {
            throw new InvalidRequestException(
                    "status must be one of \"Verified\" or \"Rejected\".");
        }

        if (verifiedBy == null || verifiedBy.trim().isEmpty()) {
            throw new InvalidRequestException("verifiedBy is required.");
        }

        String normalized = status.trim().toUpperCase();
        boolean rejecting = "REJECTED".equals(normalized);

        if (rejecting && (remarks == null || remarks.trim().isEmpty())) {
            throw new InvalidRequestException("remarks is required when rejecting a document.");
        }

        PostDisbursementDocumentEntity document = getDocumentById(documentId);

        document.setStatus(rejecting ? "Rejected" : "Verified");
        document.setVerifiedBy(verifiedBy.trim());
        document.setVerifiedAt(OffsetDateTime.now());
        document.setRemarks(rejecting ? remarks.trim() : "");

        return repository.save(document);
    }
}