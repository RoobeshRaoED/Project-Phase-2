package com.tcs.hlms.dto;

/**
 * Body for PATCH /api/post-disbursement-documents/{documentId}/status.
 *
 * Kept deliberately narrow (status/verifiedBy/remarks only) so a caller can
 * never accidentally overwrite fileData, docType, etc. by re-posting a
 * partial or stale copy of the document - the previous integration used a
 * full POST re-save for this, which is what this endpoint replaces.
 */
public class PostDisbursementDocumentStatusUpdateRequest {

    /** Expected values: "Verified" or "Rejected". */
    private String status;

    private String verifiedBy;

    /** Optional for a verify, effectively required for a reject (enforced in the service). */
    private String remarks;

    public PostDisbursementDocumentStatusUpdateRequest() {
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getVerifiedBy() {
        return verifiedBy;
    }

    public void setVerifiedBy(String verifiedBy) {
        this.verifiedBy = verifiedBy;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
