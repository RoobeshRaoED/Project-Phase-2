package com.tcs.hlms.service;

import com.tcs.hlms.entity.PostDisbursementDocumentEntity;

import java.util.List;

public interface PostDisbursementDocumentService {

    PostDisbursementDocumentEntity saveDocument(
            PostDisbursementDocumentEntity document);

    PostDisbursementDocumentEntity getDocumentById(
            String documentId);

    List<PostDisbursementDocumentEntity> getDocumentsByAppId(
            String appId);

    List<PostDisbursementDocumentEntity> getAllDocuments();

    void deleteDocument(String documentId);

    /**
     * Verifies or rejects a document (e.g. the "Engineer Sign" doc a
     * construction-loan customer uploads to unlock the balance tranche).
     * Only status/verifiedBy/verifiedAt/remarks are touched - everything
     * else on the document (fileData, docType, etc.) is left untouched.
     *
     * @param status   "Verified" or "Rejected" (case-insensitive)
     * @param remarks  required when rejecting; ignored (cleared) when verifying
     */
    PostDisbursementDocumentEntity updateStatus(
            String documentId, String status, String verifiedBy, String remarks);
}