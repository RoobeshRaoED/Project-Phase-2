package com.tcs.hlms;

import com.tcs.hlms.entity.PostDisbursementDocumentEntity;
import com.tcs.hlms.exceptions.InvalidRequestException;
import com.tcs.hlms.exceptions.ResourceNotFoundException;
import com.tcs.hlms.repository.PostDisbursementDocumentRepository;
import com.tcs.hlms.serviceImplementation.PostDisbursementDocumentServiceImpl;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PostDisbursementDocumentServiceImplTest {

    @Mock
    private PostDisbursementDocumentRepository repository;

    @InjectMocks
    private PostDisbursementDocumentServiceImpl service;

    @Test
    void saveDocument_Success() {

        PostDisbursementDocumentEntity document =
                new PostDisbursementDocumentEntity();

        when(repository.save(document))
                .thenReturn(document);

        assertNotNull(
                service.saveDocument(document));
    }

    @Test
    void getDocumentById_Success() {

        PostDisbursementDocumentEntity document =
                new PostDisbursementDocumentEntity();

        when(repository.findById("PD1"))
                .thenReturn(Optional.of(document));

        assertNotNull(
                service.getDocumentById("PD1"));
    }

    @Test
    void getDocumentById_NotFound() {

        when(repository.findById("PD1"))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.getDocumentById("PD1"));
    }

    @Test
    void getDocumentsByAppId_Success() {

        when(repository.findByAppId("APP1"))
                .thenReturn(
                        List.of(
                                new PostDisbursementDocumentEntity()));

        assertEquals(
                1,
                service.getDocumentsByAppId("APP1")
                        .size());
    }

    @Test
    void getDocumentsByAppId_Empty() {

        when(repository.findByAppId("APP1"))
                .thenReturn(Collections.emptyList());

        assertTrue(
                service.getDocumentsByAppId("APP1")
                        .isEmpty());
    }

    @Test
    void getAllDocuments_Success() {

        when(repository.findAll())
                .thenReturn(
                        List.of(
                                new PostDisbursementDocumentEntity()));

        assertEquals(
                1,
                service.getAllDocuments().size());
    }

    @Test
    void getAllDocuments_Empty() {

        when(repository.findAll())
                .thenReturn(Collections.emptyList());

        assertTrue(
                service.getAllDocuments().isEmpty());
    }

    @Test
    void deleteDocument_Success() {

        doNothing()
                .when(repository)
                .deleteById("PD1");

        service.deleteDocument("PD1");

        verify(repository)
                .deleteById("PD1");
    }
    @Test
    void saveDocument_NullObject() {

        when(repository.save(null))
                .thenReturn(null);

        assertNull(
                service.saveDocument(null));
    }
    @Test
    void getDocumentsByAppId_NullAppId() {

        when(repository.findByAppId(null))
                .thenReturn(Collections.emptyList());

        List<PostDisbursementDocumentEntity> result =
                service.getDocumentsByAppId(null);

        assertNotNull(result);
    }
    @Test
    void getAllDocuments_MultipleRecords() {

        List<PostDisbursementDocumentEntity> list =
                Arrays.asList(
                        new PostDisbursementDocumentEntity(),
                        new PostDisbursementDocumentEntity());

        when(repository.findAll())
                .thenReturn(list);

        assertEquals(
                2,
                service.getAllDocuments().size());
    }
    @Test
    void deleteDocument_VerifyInvocation() {

        service.deleteDocument("PD001");

        verify(repository)
                .deleteById("PD001");
    }

    // ---- updateStatus ----

    @Test
    void updateStatus_Verify_Success() {

        PostDisbursementDocumentEntity document = new PostDisbursementDocumentEntity();
        document.setPdDocId("PD1");
        document.setStatus("Pending");

        when(repository.findById("PD1")).thenReturn(Optional.of(document));
        when(repository.save(any(PostDisbursementDocumentEntity.class)))
                .thenAnswer(inv -> inv.getArgument(0));

        PostDisbursementDocumentEntity result =
                service.updateStatus("PD1", "Verified", "legal.officer@bank.com", null);

        assertEquals("Verified", result.getStatus());
        assertEquals("legal.officer@bank.com", result.getVerifiedBy());
        assertNotNull(result.getVerifiedAt());
        assertEquals("", result.getRemarks());
    }

    @Test
    void updateStatus_Reject_Success() {

        PostDisbursementDocumentEntity document = new PostDisbursementDocumentEntity();
        document.setPdDocId("PD1");
        document.setStatus("Pending");

        when(repository.findById("PD1")).thenReturn(Optional.of(document));
        when(repository.save(any(PostDisbursementDocumentEntity.class)))
                .thenAnswer(inv -> inv.getArgument(0));

        PostDisbursementDocumentEntity result =
                service.updateStatus("PD1", "rejected", "legal.officer@bank.com", "Signature illegible");

        assertEquals("Rejected", result.getStatus());
        assertEquals("Signature illegible", result.getRemarks());
    }

    @Test
    void updateStatus_Reject_MissingRemarks_Throws() {

        assertThrows(
                InvalidRequestException.class,
                () -> service.updateStatus("PD1", "Rejected", "officer@bank.com", "  "));

        verify(repository, never()).findById(any());
    }

    @Test
    void updateStatus_InvalidStatus_Throws() {

        assertThrows(
                InvalidRequestException.class,
                () -> service.updateStatus("PD1", "Pending", "officer@bank.com", null));
    }

    @Test
    void updateStatus_MissingVerifiedBy_Throws() {

        assertThrows(
                InvalidRequestException.class,
                () -> service.updateStatus("PD1", "Verified", " ", null));
    }

    @Test
    void updateStatus_DocumentNotFound_Throws() {

        when(repository.findById("PD1")).thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.updateStatus("PD1", "Verified", "officer@bank.com", null));
    }
}