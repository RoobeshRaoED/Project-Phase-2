package com.hlms.notification.entity;
import jakarta.persistence.*;
import java.time.OffsetDateTime;
import java.util.List;
@Entity
@Table(name = "notification")
public class Notification {
    @Id
    @Column(name = "notification_id", length = 50)
    private String notificationId;
    @Column(name = "user_email", nullable = false)
    private String userEmail;
    @Column(name = "title", length = 150, nullable = false)
    private String title;
    @Column(name = "body", columnDefinition = "TEXT")
    private String body;
    @ElementCollection(fetch = FetchType.EAGER)
    @Column(name = "channels")
    private List<String> channels = List.of("inapp"); // inapp, sms, email
    @Column(name = "is_read", nullable = false)
    private Boolean isRead = false;
    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;
    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
    @PrePersist
    public void prePersist() {
        if (createdAt == null) createdAt = OffsetDateTime.now();
    }

    public Notification() {
    }

    public Notification(String notificationId, String userEmail, String title, String body, List<String> channels, Boolean isRead, OffsetDateTime createdAt, OffsetDateTime deletedAt) {
        this.notificationId = notificationId;
        this.userEmail = userEmail;
        this.title = title;
        this.body = body;
        this.channels = channels;
        this.isRead = isRead;
        this.createdAt = createdAt;
        this.deletedAt = deletedAt;
    }

    public String getNotificationId() {
        return notificationId;
    }
    public void setNotificationId(String notificationId) {
        this.notificationId = notificationId;
    }
    public String getUserEmail() {
        return userEmail;
    }
    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getBody() {
        return body;
    }
    public void setBody(String body) {
        this.body = body;
    }
    public List<String> getChannels() {
        return channels;
    }
    public void setChannels(List<String> channels) {
        this.channels = channels;
    }
    public Boolean isRead() {
        return isRead;
    }
    public void setIsRead(Boolean isRead) {
        this.isRead = isRead;
    }
    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }
    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }
    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static Builder builder() {
        return new Builder();
    }
    public static class Builder {
        private String notificationId;
        private String userEmail;
        private String title;
        private String body;
        private List<String> channels = List.of("inapp");
        private Boolean isRead = false;
        private OffsetDateTime createdAt;
        private OffsetDateTime deletedAt;

        public Builder notificationId(String notificationId) {
            this.notificationId = notificationId;
            return this;
        }
        public Builder userEmail(String userEmail) {
            this.userEmail = userEmail;
            return this;
        }
        public Builder title(String title) {
            this.title = title;
            return this;
        }
        public Builder body(String body) {
            this.body = body;
            return this;
        }
        public Builder channels(List<String> channels) {
            this.channels = channels;
            return this;
        }
        public Builder isRead(Boolean isRead) {
            this.isRead = isRead;
            return this;
        }
        public Builder createdAt(OffsetDateTime createdAt) {
            this.createdAt = createdAt;
            return this;
        }
        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public Notification build() {
            return new Notification(notificationId, userEmail, title, body, channels, isRead, createdAt, deletedAt);
        }
    }
}