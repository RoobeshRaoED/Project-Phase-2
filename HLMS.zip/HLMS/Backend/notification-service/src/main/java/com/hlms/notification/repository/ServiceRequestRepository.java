package com.hlms.notification.repository;

import com.hlms.notification.entity.ServiceRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ServiceRequestRepository extends JpaRepository<ServiceRequest, String> {
    List<ServiceRequest> findByUserEmailAndDeletedAtIsNull(String userEmail);
    List<ServiceRequest> findByAppIdAndDeletedAtIsNull(String appId);
}
