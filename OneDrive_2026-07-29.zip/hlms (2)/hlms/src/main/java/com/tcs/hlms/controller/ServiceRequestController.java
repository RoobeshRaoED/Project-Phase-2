package com.tcs.hlms.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.tcs.hlms.entity.ServiceRequestEntity;
import com.tcs.hlms.service.ServiceRequestService;

@RestController
@RequestMapping("/api/service-requests")
public class ServiceRequestController {

    private final ServiceRequestService serviceRequestService;

    public ServiceRequestController(ServiceRequestService serviceRequestService) {
        this.serviceRequestService = serviceRequestService;
    }

    @PostMapping
    public ResponseEntity<ServiceRequestEntity> createRequest(
            @RequestBody ServiceRequestEntity request) {

        return ResponseEntity.ok(
                serviceRequestService.createRequest(request));
    }

    @PutMapping
    public ResponseEntity<ServiceRequestEntity> updateRequest(
            @RequestBody ServiceRequestEntity request) {

        return ResponseEntity.ok(
                serviceRequestService.updateRequest(request));
    }

    @GetMapping("/user/{email}")
    public ResponseEntity<List<ServiceRequestEntity>> getByUser(
            @PathVariable String email) {

        return ResponseEntity.ok(
                serviceRequestService.getRequestsByUser(email));
    }

    @GetMapping("/application/{appId}")
    public ResponseEntity<List<ServiceRequestEntity>> getByApplication(
            @PathVariable String appId) {

        return ResponseEntity.ok(
                serviceRequestService.getRequestsByApplication(appId));
    }

    @DeleteMapping("/{requestId}")
    public ResponseEntity<String> deleteRequest(
            @PathVariable String requestId) {

        serviceRequestService.softDeleteRequest(requestId);

        return ResponseEntity.ok(
                "Service request deleted successfully");
    }
}