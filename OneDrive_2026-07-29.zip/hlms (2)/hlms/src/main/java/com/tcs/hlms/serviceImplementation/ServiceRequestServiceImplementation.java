package com.tcs.hlms.serviceImplementation;

import java.time.OffsetDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.hlms.entity.ServiceRequestEntity;
import com.tcs.hlms.repository.ServiceRequestRepository;
import com.tcs.hlms.service.ServiceRequestService;

import com.tcs.hlms.Exceptions.DuplicateResourceException;
import com.tcs.hlms.Exceptions.InvalidRequestException;
import com.tcs.hlms.Exceptions.ResourceNotFoundException;

@Service
public class ServiceRequestServiceImplementation implements ServiceRequestService {

    @Autowired
    private ServiceRequestRepository serviceRequestRepository;

    @Override
    public ServiceRequestEntity createRequest(
            ServiceRequestEntity request) {

        if (request == null) {
            throw new InvalidRequestException(
                    "Service Request cannot be null");
        }

        if (serviceRequestRepository.existsById(
                request.getRequestId())) {

            throw new DuplicateResourceException(
                    "Service Request already exists");
        }

        return serviceRequestRepository.save(request);
    }

    @Override
    public ServiceRequestEntity updateRequest(
            ServiceRequestEntity request) {

        ServiceRequestEntity existing =
                serviceRequestRepository
                        .findById(request.getRequestId())
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Service Request not found"));

        existing.setStatus(request.getStatus());
        existing.setDescription(request.getDescription());

        return serviceRequestRepository.save(existing);
    }

    @Override
    public List<ServiceRequestEntity> getRequestsByUser(String email) {
        return serviceRequestRepository.findByUserEmailAndDeletedAtIsNull(email);
    }

    @Override
    public List<ServiceRequestEntity> getRequestsByApplication(String appId) {
        return serviceRequestRepository.findByAppIdAndDeletedAtIsNull(appId);
    }

    @Override
    public void softDeleteRequest(String requestId) {

        ServiceRequestEntity request =
                serviceRequestRepository
                        .findById(requestId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Service Request not found"));

        request.setDeletedAt(
                OffsetDateTime.now());

        serviceRequestRepository.save(request);
    }
}
