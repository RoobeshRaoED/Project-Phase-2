package com.tcs.hlms.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.tcs.hlms.entity.NotificationEntity;
import com.tcs.hlms.service.NotificationService;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    private final NotificationService notificationService;

    public NotificationController(
            NotificationService notificationService) {

        this.notificationService = notificationService;
    }

    @PostMapping
    public ResponseEntity<NotificationEntity> createNotification(
            @RequestBody NotificationEntity notification) {

        return ResponseEntity.ok(
                notificationService.createNotification(notification));
    }

    @GetMapping
    public ResponseEntity<List<NotificationEntity>>
            getAllNotifications() {

        return ResponseEntity.ok(
                notificationService.getAllNotifications());
    }

    @PutMapping("/{notificationId}/read")
    public ResponseEntity<String> markAsRead(
            @PathVariable String notificationId) {

        notificationService.markAsRead(notificationId);

        return ResponseEntity.ok(
                "Notification marked as read");
    }

    @DeleteMapping("/{notificationId}")
    public ResponseEntity<String> deleteNotification(
            @PathVariable String notificationId) {

        notificationService.softDeleteNotification(notificationId);

        return ResponseEntity.ok(
                "Notification deleted successfully");
    }
}