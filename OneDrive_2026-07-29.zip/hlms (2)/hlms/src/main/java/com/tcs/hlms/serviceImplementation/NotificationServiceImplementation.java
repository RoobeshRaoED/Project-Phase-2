package com.tcs.hlms.serviceImplementation;

import java.time.OffsetDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.tcs.hlms.entity.NotificationEntity;
import com.tcs.hlms.repository.NotificationRepository;
import com.tcs.hlms.service.NotificationService;


import com.tcs.hlms.Exceptions.DuplicateResourceException;
import com.tcs.hlms.Exceptions.InvalidRequestException;
import com.tcs.hlms.Exceptions.ResourceNotFoundException;
@Service
public class NotificationServiceImplementation
        implements NotificationService {

    private final NotificationRepository notificationRepository;

    public NotificationServiceImplementation(
            NotificationRepository notificationRepository) {

        this.notificationRepository = notificationRepository;
    }

    @Override
    public NotificationEntity createNotification(NotificationEntity notification) {

        if (notification == null) {
            throw new InvalidRequestException(
                    "Notification cannot be null");
        }

        if (notificationRepository.existsById(
                notification.getNotificationId())) {

            throw new DuplicateResourceException(
                    "Notification already exists");
        }

        return notificationRepository.save(notification);
    }

    @Override
    public List<NotificationEntity> getAllNotifications() {

        return notificationRepository.findByDeletedAtIsNull();
    }

    @Override
    public void markAsRead(String notificationId) {

        NotificationEntity notification =
                notificationRepository.findById(notificationId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Notification not found"));

        notification.setIsRead(true);

        notificationRepository.save(notification);
    }

    @Override
    public void softDeleteNotification(String notificationId) {

        NotificationEntity notification =
                notificationRepository.findById(notificationId)
                        .orElseThrow(() ->
                                new ResourceNotFoundException(
                                        "Notification not found"));

        notification.setDeletedAt(
                OffsetDateTime.now());

        notificationRepository.save(notification);
    }
}