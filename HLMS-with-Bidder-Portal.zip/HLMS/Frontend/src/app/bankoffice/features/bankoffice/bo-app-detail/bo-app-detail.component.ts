import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { LoanService } from '../../../core/services/loan.service';
import { LegalService } from '../../../core/services/legal.service';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';
import { NotificationService } from '../../../core/services/notification.service';
import { LoanApplication } from '../../../core/models/loan-application.model';
import { BankOfficeDecision, LegalVerification } from '../../../core/models/legal.model';
import { calculateEmi } from '../../../core/utils/loan-calc.util';

// Same standard rejection reasons the legacy Bank Office UI offered, so an
// officer can select one instead of free-typing every time.
export const BO_REJECTION_REASONS = [
  'Title discrepancy flagged by Legal Team',
  'Insufficient income / high debt-to-income ratio',
  'Incomplete or invalid documentation',
  'Property value below required threshold',
  'Poor credit history',
  'Applicant did not respond to a query in time',
  'Other (specify below)'
];

// Officer / department shown against each workflow stage. This is display-only
// context (no backend field carries it) mirroring the branch's real handoffs.
export const STAGE_OWNERS: { officer: string; dept: string }[] = [
  { officer: 'A. Mehta', dept: 'Customer Onboarding' },
  { officer: 'S. Iyer', dept: 'Document Verification Cell' },
  { officer: 'R. Sharma', dept: 'Credit Appraisal Dept' },
  { officer: 'N. Kulkarni', dept: 'Legal & Valuation Team' },
  { officer: 'P. Verma', dept: 'Loan Approval Committee' },
  { officer: 'K. Das', dept: 'Disbursement Desk' }
];

@Component({
  selector: 'app-bo-app-detail',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './bo-app-detail.component.html'
})
export class BoAppDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private loanService = inject(LoanService);
  private legalService = inject(LegalService);
  private auth = inject(AuthService);
  private toast = inject(ToastService);
  private notificationService = inject(NotificationService);

  // appId is a String business key everywhere on the backend (e.g. "APP1001"),
  // never a number - so it must NOT be passed through Number(...).
  appId = this.route.snapshot.paramMap.get('appId') ?? '';

  application = signal<LoanApplication | null>(null);
  decision = signal<BankOfficeDecision | null>(null);
  legalVerification = signal<LegalVerification | null>(null);
  loading = signal(true);

  // Names must match the entries in loan-service's WORKFLOW_STAGES list
  // exactly. Both stages belong to the Legal & Valuation Team - loan-service's
  // own StatusTrackingService.currentStakeholder() already treats every
  // stageIndex from "Document Verification" onward (until Bank Office
  // Decision) as "with the legal team for document/title verification" -
  // so Bank Office cannot forward an application past either stage itself.
  private readonly DOCUMENT_STAGE_NAME = 'Document Verification';
  private readonly LEGAL_STAGE_NAME = 'Legal Verification';
  // Legal team decisions that count as the stage being "done" from the Bank
  // Office's point of view - a Bank Officer can move past Legal Verification
  // once the Legal Team has recorded either of these. "Pending" (or no
  // record at all) means the Legal Team hasn't finished, so the officer must
  // wait even though the application already sits on this stage.
  private readonly LEGAL_CLEARED_DECISIONS = ['Cleared', 'Rejected'];

  // Populated from loan-service's own /workflow-stages endpoint so this always
  // matches the real stage names/order, instead of a hard-coded guess.
  workflowStages = signal<string[]>([]);
  productNames = signal<Record<string, string>>({});
  stageOwners = STAGE_OWNERS;

  rejectionReasons = BO_REJECTION_REASONS;
  rejectReason = '';
  remarks = '';
  showRejectForm = false;
  saving = false;

  ngOnInit(): void {
    this.loanService.getApplication(this.appId).subscribe({
      next: (app) => {
        // Drafts aren't real submissions yet - Bank Office has no business
        // with them even if someone lands here directly via URL/back-button.
        if (app?.status === 'Draft') {
          this.loading.set(false);
          this.toast.show('Not available', 'This application is still a draft and has not been submitted.', 'error');
          this.back();
          return;
        }
        this.application.set(app);
        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });
    this.loanService.getWorkflowStages().subscribe({
      next: (stages) => this.workflowStages.set(stages)
    });
    this.loanService.getProductNameMap().subscribe({
      next: (map) => this.productNames.set(map),
      error: () => this.productNames.set({})
    });
    this.refreshDecision();
    this.refreshLegalVerification();
  }

  refreshLegalVerification() {
    this.legalService.getVerificationForApp(this.appId).subscribe({
      next: (v) => this.legalVerification.set(v)
    });
  }

  // True while the application currently sits on the "Document Verification"
  // stage - the stage the Legal & Valuation Team now verifies documents on
  // and forwards on their own. Bank Officer cannot advance past this stage.
  isAtDocumentStage(): boolean {
    const app = this.application();
    if (!app) return false;
    const docIndex = this.workflowStages().indexOf(this.DOCUMENT_STAGE_NAME);
    return docIndex !== -1 && app.stageIndex === docIndex;
  }

  // True while the application currently sits on the "Legal Verification"
  // stage - i.e. the stage the Bank Officer is not allowed to advance past
  // on their own.
  isAtLegalStage(): boolean {
    const app = this.application();
    if (!app) return false;
    const legalIndex = this.workflowStages().indexOf(this.LEGAL_STAGE_NAME);
    return legalIndex !== -1 && app.stageIndex === legalIndex;
  }

  // Has the Legal Team recorded their decision for this application yet?
  legalVerificationDone(): boolean {
    const decision = this.legalVerification()?.decision;
    return !!decision && this.LEGAL_CLEARED_DECISIONS.includes(decision);
  }

  // The conditions that block the "Move to Next Stage" button:
  //  - sitting on Document Verification - only the Legal & Valuation Team can
  //    verify the submitted documents and forward the case from here, so the
  //    Bank Officer is always blocked at this stage.
  //  - sitting on Legal Verification without the Legal Team having recorded
  //    Cleared/Rejected yet.
  blockedOnLegalTeam(): boolean {
    return this.isAtDocumentStage() || (this.isAtLegalStage() && !this.legalVerificationDone());
  }

  productName(productId?: string): string {
    if (!productId) return '—';
    return this.productNames()[productId] ?? productId;
  }

  emi(app: LoanApplication): number {
    return calculateEmi(app.loanAmount, app.interestRate, app.tenureYears);
  }

  ownerFor(index: number): { officer: string; dept: string } | null {
    return this.stageOwners[index] ?? null;
  }

  // Advances the application exactly one stage past its current stageIndex -
  // the single "Move to Next Stage" action shown on the workflow card.
  nextStageIndex(): number {
    const app = this.application();
    return (app?.stageIndex ?? 0) + 1;
  }

  moveToNextStage() {
    if (this.blockedOnLegalTeam()) {
      const message = this.isAtDocumentStage()
        ? 'This application is with the Legal & Valuation Team for document verification. It can only move to the next stage once they verify the documents and forward the case.'
        : 'This application is still with the Legal & Valuation Team. It can only move to the next stage once they record their decision.';
      this.toast.show('Awaiting Legal Team', message, 'error');
      return;
    }
    const idx = this.nextStageIndex();
    if (idx >= this.workflowStages().length) return;
    this.advanceStage(idx);
  }

  refreshDecision() {
    this.legalService.getDecisionForApp(this.appId).subscribe({
      next: (d) => this.decision.set(d)
    });
  }

  statusBadge(status?: string): string {
    if (status === 'Disbursed') return 'badge-green';
    if (status === 'Rejected') return 'badge-red';
    if (status === 'In Progress' || status === 'Submitted') return 'badge-orange';
    return 'badge-gray';
  }

  stageStatus(index: number): 'completed' | 'current' | 'upcoming' {
    const app = this.application();
    if (!app || app.stageIndex == null) return 'upcoming';
    if (index < app.stageIndex) return 'completed';
    if (index === app.stageIndex) return 'current';
    return 'upcoming';
  }

  canAdvance(): boolean {
    const app = this.application();
    if (!app) return false;
    if (app.status === 'Disbursed' || app.status === 'Rejected') return false;
    return !this.blockedOnLegalTeam();
  }

  canReject(): boolean {
    const app = this.application();
    if (!app) return false;
    return app.status !== 'Disbursed' && app.status !== 'Rejected';
  }

  advanceStage(stageIndex: number) {
    const stageName = this.workflowStages()[stageIndex] ?? `Stage ${stageIndex}`;
    this.loanService.advanceStage(this.appId, stageIndex, stageName).subscribe({
      next: (updated) => {
        this.application.set(updated);
        this.toast.show('Stage updated', `Application moved to "${stageName}".`, 'success');
      }
    });
  }

  toggleRejectForm() {
    this.showRejectForm = !this.showRejectForm;
    this.rejectReason = '';
    this.remarks = '';
  }

  onReasonChange() {
    if (this.rejectReason && this.rejectReason !== 'Other (specify below)' && !this.remarks.trim()) {
      this.remarks = this.rejectReason + ' — ';
    }
  }

  reject() {
    if (!this.rejectReason) {
      this.toast.show('Reason required', 'Please select a rejection reason.', 'error');
      return;
    }
    if (!this.remarks.trim()) {
      this.toast.show('Remarks required', 'Please provide details for the applicant.', 'error');
      return;
    }
    const app = this.application();
    const officer = this.auth.currentUser()?.email;
    this.saving = true;
    this.legalService.recordDecision(this.appId, {
      status: 'Rejected',
      officerEmail: officer,
      reason: this.rejectReason,
      remarks: this.remarks.trim(),
      decisionDate: new Date().toISOString()
    }).subscribe({
      next: () => {
        this.saving = false;
        this.toast.show('Application Rejected', 'The applicant has been notified.', 'success');
        if (app?.userEmail) {
          this.notificationService.send(
            app.userEmail,
            'Application Rejected',
            `Your application ${app.trackingNo ?? ''} has been rejected by the Bank Office. Reason: ${this.remarks.trim()}`
          ).subscribe({ error: () => {} });
        }
        this.showRejectForm = false;
        this.rejectReason = '';
        this.remarks = '';
        this.refreshDecision();
        this.loanService.getApplication(this.appId).subscribe((updated) => this.application.set(updated));
      },
      error: () => { this.saving = false; this.toast.show('Error', 'Could not record rejection.', 'error'); }
    });
  }

  back() {
    this.router.navigate(['/officer/boapplications']);
  }
}
