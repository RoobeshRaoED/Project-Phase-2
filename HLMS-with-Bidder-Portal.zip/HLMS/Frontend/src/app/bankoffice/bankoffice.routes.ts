import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { roleGuard } from './core/guards/role.guard';

/**
 * Bank Office portal, mounted at /officer (was /app in hlms-bankoffice-ui).
 * The auth + role guards and every child route are the originals; only the
 * mount point changed, plus the module's own login/forgot-password pages moved
 * from /auth/... to /officer/... so they no longer collide with the shared
 * /login page owned by the auth module.
 */
export const BANKOFFICE_ROUTES: Routes = [
  { path: 'login', loadComponent: () => import('./features/auth/login/login.component').then(m => m.LoginComponent) },
  { path: 'forgot-password', loadComponent: () => import('./features/auth/forgot-password/forgot-password.component').then(m => m.ForgotPasswordComponent) },
  {
    path: '',
    canActivate: [authGuard],
    loadComponent: () => import('./layout/shell/shell.component').then(m => m.ShellComponent),
    children: [
      { path: 'bodash', canActivate: [roleGuard], data: { roles: ['bankoffice'] }, loadComponent: () => import('./features/bankoffice/bo-dashboard/bo-dashboard.component').then(m => m.BoDashboardComponent) },
      { path: 'boapplications', canActivate: [roleGuard], data: { roles: ['bankoffice'] }, loadComponent: () => import('./features/bankoffice/bo-applications/bo-applications.component').then(m => m.BoApplicationsComponent) },
      { path: 'boappdetail/:appId', canActivate: [roleGuard], data: { roles: ['bankoffice'] }, loadComponent: () => import('./features/bankoffice/bo-app-detail/bo-app-detail.component').then(m => m.BoAppDetailComponent) },
      { path: 'boportfolio', canActivate: [roleGuard], data: { roles: ['bankoffice'] }, loadComponent: () => import('./features/bankoffice/bo-portfolio/bo-portfolio.component').then(m => m.BoPortfolioComponent) },
      { path: 'bodisbursement', canActivate: [roleGuard], data: { roles: ['bankoffice'] }, loadComponent: () => import('./features/bankoffice/bo-disbursement/bo-disbursement.component').then(m => m.BoDisbursementComponent) },
      { path: 'bonpa', canActivate: [roleGuard], data: { roles: ['bankoffice'] }, loadComponent: () => import('./features/bankoffice/bo-npa/bo-npa.component').then(m => m.BoNpaComponent) },
      { path: 'bodocs', canActivate: [roleGuard], data: { roles: ['bankoffice'] }, loadComponent: () => import('./features/bankoffice/bo-docs/bo-docs.component').then(m => m.BoDocsComponent) },
      { path: 'boauction', canActivate: [roleGuard], data: { roles: ['bankoffice'] }, loadComponent: () => import('./features/bankoffice/bo-auction/bo-auction.component').then(m => m.BoAuctionComponent) },
      { path: 'boreports', canActivate: [roleGuard], data: { roles: ['bankoffice'] }, loadComponent: () => import('./features/bankoffice/bo-reports/bo-reports.component').then(m => m.BoReportsComponent) },
      { path: 'bosettings', canActivate: [roleGuard], data: { roles: ['bankoffice'] }, loadComponent: () => import('./features/bankoffice/bo-settings/bo-settings.component').then(m => m.BoSettingsComponent) },
      { path: '', pathMatch: 'full', redirectTo: 'bodash' }
    ]
  }
];
