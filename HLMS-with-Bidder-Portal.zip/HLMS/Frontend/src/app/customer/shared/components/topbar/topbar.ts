import { Component, OnInit, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { NotificationService } from '../../../core/services/notification.service';
import { Notification } from '../../../core/models/models';

@Component({
  selector: 'app-topbar',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="topbar">
      <button class="hamburger" (click)="sidebarOpen.set(!sidebarOpen())">☰</button>
      <a routerLink="/customer/dashboard" class="brand" style="text-decoration:none;">
        <div class="logo">
          <img src="assets/images/logo.png" width="34" style="border-radius:8px;" alt="HLMS" />
        </div>
        <div>
          <div class="title">HLMS</div>
          <div class="subtitle">Housing Loan Management System</div>
        </div>
      </a>
      <div class="topbar-search">
        <input placeholder="Search anything..." disabled title="Search coming soon" />
      </div>
      <div class="topbar-right">
        <button class="icon-btn" title="Notifications" (click)="openNotifPanel()">
          🔔<span class="icon-dot">{{ unreadCount() }}</span>
        </button>
        <a routerLink="/customer/profile" class="user-chip" style="text-decoration:none;">
          <div class="user-avatar">{{ initials() }}</div>
          <div class="user-name">{{ auth.currentUser()?.name || 'User' }}</div>
        </a>
        <button class="btn btn-outline btn-sm" (click)="logout()">Log Out</button>
      </div>
    </div>
  `
})
export class Topbar implements OnInit {
  auth = inject(AuthService);
  private notifSvc = inject(NotificationService);
  private router = inject(Router);

  sidebarOpen = signal(false);
  unreadCount = signal(0);

  ngOnInit(): void {
    const email = this.auth.currentUser()?.email;
    if (!email) return;
    this.notifSvc.unread(email).subscribe({
      next: (list: Notification[]) => this.unreadCount.set(list.length),
      error: () => this.unreadCount.set(0)
    });
  }

  initials(): string {
    const name = this.auth.currentUser()?.name || 'U';
    return name
      .split(' ')
      .map((p) => p[0])
      .join('')
      .slice(0, 2)
      .toUpperCase();
  }

  openNotifPanel(): void {
    this.router.navigate(['/customer/support']);
  }

  logout(): void {
    this.auth.logout();
  }
}
