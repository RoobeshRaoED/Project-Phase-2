import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterLinkActive, RouterOutlet, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs';

import { AuthService } from '../../../core/services/auth.service';

interface NavItem {
  route: string;
  icon: string;
  label: string;
  matchPrefixes: string[];
}

@Component({
  selector: 'app-admin-shell',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, RouterOutlet],
  templateUrl: './admin-shell.component.html',
  styleUrl: './admin-shell.component.css'
})
export class AdminShellComponent {
  auth = inject(AuthService);
  private router = inject(Router);

  sidebarOpen = signal(false);

  navItems: NavItem[] = [
    { route: '/admin/dashboard', icon: '▦', label: 'Dashboard', matchPrefixes: ['/admin/dashboard'] },
    {
      route: '/admin/bidder-management',
      icon: '🔨',
      label: 'Bidder Management',
      matchPrefixes: ['/admin/bidder-management', '/admin/admin-management']
    },
    {
      route: '/admin/employee-management',
      icon: '🧑‍💼',
      label: 'Employee Management',
      matchPrefixes: ['/admin/employee-management', '/admin/legal-management', '/admin/bankoffice-management']
    },
    { route: '/admin/profile', icon: '◍', label: 'Profile', matchPrefixes: ['/admin/profile'] }
  ];

  currentUrl = signal(this.router.url);

  constructor() {
    this.router.events.pipe(filter((e): e is NavigationEnd => e instanceof NavigationEnd)).subscribe((e) => {
      this.currentUrl.set(e.urlAfterRedirects);
      this.sidebarOpen.set(false);
    });
  }

  isActive(item: NavItem): boolean {
    return item.matchPrefixes.some((p) => this.currentUrl().startsWith(p));
  }

  toggleSidebar(): void {
    this.sidebarOpen.update((v) => !v);
  }

  initials(name: string | undefined): string {
    if (!name) return '?';
    const parts = name.trim().split(/\s+/);
    return ((parts[0]?.[0] ?? '') + (parts[1]?.[0] ?? '')).toUpperCase() || name[0]?.toUpperCase() || '?';
  }

  logout(): void {
    this.auth.logout();
    this.router.navigateByUrl('/login');
  }
}
