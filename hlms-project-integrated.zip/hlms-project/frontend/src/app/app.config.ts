import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import {
  provideRouter,
  withComponentInputBinding,
  withInMemoryScrolling
} from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideAnimations } from '@angular/platform-browser/animations';

import { routes } from './app.routes';

// Each portal's own interceptor(s) — aliased on import since several share
// the name `authInterceptor`. Every interceptor already guards itself with
// `req.url.startsWith(environment.apiBase...)` plus its own token-storage
// key, so an interceptor is a no-op for requests/sessions outside its own
// portal and it's safe to register all of them globally.
import { authInterceptor as customerAuthInterceptor } from './portals/customer/core/interceptors/auth.interceptor';
import { authInterceptor as adminAuthInterceptor } from './portals/admin/core/interceptors/auth.interceptor';
import { authInterceptor as bankofficeAuthInterceptor } from './portals/bankoffice/core/interceptors/auth.interceptor';
import { errorInterceptor as bankofficeErrorInterceptor } from './portals/bankoffice/core/interceptors/error.interceptor';
import { authInterceptor as legalAuthInterceptor } from './portals/legal/core/interceptors/auth.interceptor';
import { authInterceptor as bidderAuthInterceptor } from './portals/bidder/core/interceptors/auth.interceptor';
import { sessionExpiryInterceptor as bidderSessionExpiryInterceptor } from './portals/bidder/core/interceptors/session-expiry.interceptor';
import { authTokenInterceptor as welcomeAuthTokenInterceptor } from './portals/welcome/core/interceptors/auth-token.interceptor';

// Bidder portal's auth abstraction (see the "INTEGRATION POINT" note inside
// bidder-auth.port.ts) — left on its own StoredTokenAuthAdapter fallback,
// which reads the JWT that any portal's login flow stores.
import { BIDDER_AUTH } from './portals/bidder/core/auth/bidder-auth.port';
import { StoredTokenAuthAdapter } from './portals/bidder/core/auth/stored-token-auth.adapter';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(
      routes,
      withComponentInputBinding(),
      withInMemoryScrolling({ scrollPositionRestoration: 'top' })
    ),
    provideHttpClient(
      withInterceptors([
        customerAuthInterceptor,
        adminAuthInterceptor,
        bankofficeAuthInterceptor,
        bankofficeErrorInterceptor,
        legalAuthInterceptor,
        bidderAuthInterceptor,
        bidderSessionExpiryInterceptor,
        welcomeAuthTokenInterceptor
      ])
    ),
    provideAnimations(),
    { provide: BIDDER_AUTH, useExisting: StoredTokenAuthAdapter }
  ]
};
