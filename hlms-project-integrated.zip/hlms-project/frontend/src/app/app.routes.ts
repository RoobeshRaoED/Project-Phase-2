import { Routes } from '@angular/router';
import { bidderGuard } from './portals/bidder/core/guards/bidder.guard';

/**
 * HLMS Unified UI — top-level route table.
 *
 * Each portal keeps its own internal routing, guards, and services exactly
 * as authored; this file only assigns each one a URL namespace so they can
 * coexist in a single application shell:
 *
 *   /                → Customer portal (default / home)
 *   /admin/**        → Admin console
 *   /bankoffice/**   → Bank Office portal
 *   /legal/**        → Legal portal
 *   /bidder/**       → Bidder portal
 *   /welcome/**      → Public marketing / landing site
 */
export const routes: Routes = [
  // Customer portal — application default, mounted at the root.
  {
    path: '',
    loadChildren: () =>
      import('./portals/customer/customer.routes').then((m) => m.CUSTOMER_ROUTES)
  },

  // Admin console.
  {
    path: 'admin',
    loadChildren: () => import('./portals/admin/admin.routes').then((m) => m.ADMIN_ROUTES)
  },

  // Bank Office portal.
  {
    path: 'bankoffice',
    loadChildren: () =>
      import('./portals/bankoffice/bankoffice.routes').then((m) => m.BANKOFFICE_ROUTES)
  },

  // Legal portal.
  {
    path: 'legal',
    loadChildren: () => import('./portals/legal/legal.routes').then((m) => m.LEGAL_ROUTES)
  },

  // Bidder portal — unauthorized page sits outside the guard so a failed
  // bidderGuard check has somewhere safe to land (mirrors the original app).
  {
    path: 'bidder/unauthorized',
    title: 'Access denied · HLMS',
    loadComponent: () =>
      import('./portals/bidder/pages/unauthorized.component').then((m) => m.UnauthorizedComponent)
  },
  {
    path: 'bidder',
    canActivate: [bidderGuard],
    canActivateChild: [bidderGuard],
    loadChildren: () =>
      import('./portals/bidder/features/bidder/bidder.routes').then((m) => m.BIDDER_ROUTES)
  },

  // Public marketing / landing site.
  {
    path: 'welcome',
    loadChildren: () => import('./portals/welcome/welcome.routes').then((m) => m.WELCOME_ROUTES)
  },

  { path: '**', redirectTo: '' }
];
