export const environment = {
  production: false,
  // Dev: left empty so every service URL below is relative (e.g. "/user-service/api/...").
  // Those relative requests hit the Angular dev server (localhost:4200), which
  // proxy.conf.json forwards to the API Gateway on localhost:8080 - see "npm start".
  apiBaseUrl: ''
};
