import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { UserRole } from '../models/user.model';

/** Usage in routes: data: { roles: ['admin','employee'] } */
export const roleGuard: CanActivateFn = (route) => {
  const auth = inject(AuthService);
  const router = inject(Router);
  const allowed = route.data['roles'] as UserRole[] | undefined;
  const role = auth.role();

  if (!auth.isLoggedIn()) {
    router.navigate(['/bankoffice/auth/login']);
    return false;
  }
  if (allowed && role && !allowed.includes(role)) {
    router.navigate(['/bankoffice/app']);
    return false;
  }
  return true;
};
