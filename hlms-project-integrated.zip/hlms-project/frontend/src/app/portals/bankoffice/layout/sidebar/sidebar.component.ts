import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { BANK_OFFICE_NAV_ITEMS } from './sidebar.config';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
    <div class="sidebar" id="sidebar">
      @for (item of items; track item.view) {
        <a class="nav-item" [routerLink]="['/bankoffice/app', item.view]" routerLinkActive="active">
          <span class="ic">{{ item.icon }}</span>{{ item.label }}
        </a>
      }
      <button class="nav-item" style="margin-top:14px;border-top:1px solid var(--border);padding-top:16px;color:var(--red);" (click)="logout()">
        <span class="ic" style="color:var(--red);">⏻</span>Log Out
      </button>
    </div>
  `
})
export class SidebarComponent {
  private auth = inject(AuthService);
  items = BANK_OFFICE_NAV_ITEMS;

  logout() {
    this.auth.logout();
    window.location.href = '/auth/login';
  }
}
