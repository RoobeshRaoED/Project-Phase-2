import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { LoanService } from '../../../core/services/loan.service';
import { LoanApplication } from '../../../core/models/loan-application.model';

interface CustomerSummary {
  applicantEmail: string;
  applicantName: string;
  applicationCount: number;
  activeLoans: number;
  totalDisbursed: number;
  latestAppId?: string;
}

@Component({
  selector: 'app-bo-portfolio',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bo-portfolio.component.html'
})
export class BoPortfolioComponent implements OnInit {
  private loanService = inject(LoanService);
  private router = inject(Router);

  applications = signal<LoanApplication[]>([]);
  loading = signal(true);

  // Every registered customer (any application status) grouped by email,
  // matching the "Customer Portfolio" screen's per-customer summary.
  customers = computed<CustomerSummary[]>(() => {
    const byEmail = new Map<string, LoanApplication[]>();
    for (const app of this.applications()) {
      const key = app.userEmail;
      if (!byEmail.has(key)) byEmail.set(key, []);
      byEmail.get(key)!.push(app);
    }
    return Array.from(byEmail.entries()).map(([applicantEmail, apps]) => ({
      applicantEmail,
      applicantName: apps[0].applicantName || applicantEmail,
      applicationCount: apps.length,
      activeLoans: apps.filter((a) => a.status === 'Disbursed').length,
      totalDisbursed: apps.filter((a) => a.status === 'Disbursed').reduce((s, a) => s + (a.loanAmount || 0), 0),
      latestAppId: apps[0].appId
    }));
  });

  ngOnInit(): void {
    this.loanService.getAllApplications().subscribe({
      next: (apps) => {
        this.applications.set(apps);
        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });
  }

  open(appId?: string) {
    if (appId) this.router.navigate(['/bankoffice/app/boappdetail', appId]);
  }
}
