import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';

type Step = 'email' | 'otp' | 'reset';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './forgot-password.component.html'
})
export class ForgotPasswordComponent {
  private auth = inject(AuthService);
  private toast = inject(ToastService);
  private router = inject(Router);

  step = signal<Step>('email');
  loading = signal(false);

  email = '';
  otp = '';
  newPassword = '';
  confirmPassword = '';

  sendOtp() {
    if (!this.email) {
      this.toast.show('Email required', 'Please enter your registered email.', 'error');
      return;
    }
    this.loading.set(true);
    this.auth.forgotPassword(this.email).subscribe({
      next: () => {
        this.loading.set(false);
        this.step.set('otp');
        this.toast.show('OTP sent', 'Check your email for the verification code.', 'success');
      },
      error: () => this.loading.set(false)
    });
  }

  verifyOtp() {
    if (!this.otp || this.otp.length < 6) {
      this.toast.show('Invalid OTP', 'Please enter the 6-digit code.', 'error');
      return;
    }
    this.loading.set(true);
    this.auth.verifyOtp(this.email, this.otp).subscribe({
      next: () => {
        this.loading.set(false);
        this.step.set('reset');
      },
      error: () => this.loading.set(false)
    });
  }

  resetPassword() {
    if (!this.newPassword || this.newPassword.length < 8) {
      this.toast.show('Weak password', 'Password must be at least 8 characters.', 'error');
      return;
    }
    if (this.newPassword !== this.confirmPassword) {
      this.toast.show('Mismatch', 'Passwords do not match.', 'error');
      return;
    }
    this.loading.set(true);
    this.auth.resetPassword(this.email, this.otp, this.newPassword).subscribe({
      next: () => {
        this.loading.set(false);
        this.toast.show('Password reset', 'You can now log in with your new password.', 'success');
        this.router.navigate(['/bankoffice/auth/login']);
      },
      error: () => this.loading.set(false)
    });
  }
}
