import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

interface NavItem {
  path: string;
  icon: string;
  label: string;
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [RouterLink, RouterLinkActive],
  template: `
    <div class="sidebar" id="sidebar">
      @for (item of items; track item.path) {
        <a
          class="nav-item"
          [routerLink]="item.path"
          routerLinkActive="active-link"
          [routerLinkActiveOptions]="{ exact: false }"
        >
          <span class="ic">{{ item.icon }}</span>
          <span>{{ item.label }}</span>
        </a>
      }
    </div>
  `
})
export class Sidebar {
  items: NavItem[] = [
    { path: '/dashboard', icon: '⌂', label: 'Dashboard' },
    { path: '/guidance', icon: '☰', label: 'Loan Guidance' },
    { path: '/eligibility', icon: '☑', label: 'Eligibility Check' },
    { path: '/apply', icon: '📝', label: 'Apply for Loan' },
    { path: '/tracking', icon: '↗', label: 'Track Application' },
    { path: '/repayment', icon: 'Ⓡ', label: 'Repayment' },
    { path: '/postdisb', icon: '🏷', label: 'Post-Disbursement' },
    { path: '/documents', icon: '▯', label: 'Documents' },
    { path: '/auction', icon: '☆', label: 'Legal & Auction' },
    { path: '/profile', icon: '☺', label: 'My Profile' },
    { path: '/support', icon: '?', label: 'Support' }
  ];
}
