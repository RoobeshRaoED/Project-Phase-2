import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { LoanService } from '../../core/services/loan.service';
import { ToastService } from '../../core/services/toast.service';
import { EmiOption, LoanProduct, ProductRecommendation } from '../../core/models/models';

@Component({
  selector: 'app-guidance',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="page-head">
      <h1>Loan Guidance</h1>
      <p>Browse our loan products, get personalised recommendations, and plan your EMI.</p>
    </div>

    <div class="card">
      <h3>🏦 Loan Products</h3>
      @if (productsLoading()) {
        <div class="page-loading"><span class="spinner dark"></span> Loading products…</div>
      } @else if (productsError()) {
        <div class="inline-error">{{ productsError() }}</div>
      } @else {
        <div class="grid grid-3">
          @for (p of products(); track p.productId) {
            <div class="product-card">
              <h4>{{ p.name }}</h4>
              <div class="rate">{{ p.interestRate }}%<span style="font-size:12px;color:var(--text-gray);font-weight:600;"> p.a.</span></div>
              <span class="tag">Up to {{ p.maxTenureYears }} yrs · {{ p.maxLtv }} LTV</span>
              <p>{{ p.description }}</p>
            </div>
          }
        </div>
      }
    </div>

    <div class="grid grid-2">
      <div class="card">
        <h3>🎯 Product Recommendations</h3>
        <form [formGroup]="recForm" (ngSubmit)="getRecommendations()">
          <div class="field">
            <label>Purpose</label>
            <select formControlName="purpose">
              <option value="PURCHASE">Purchase</option>
              <option value="CONSTRUCTION">Construction</option>
              <option value="BALANCE_TRANSFER">Balance Transfer</option>
              <option value="TOPUP">Top-up</option>
            </select>
          </div>
          <div class="two-col">
            <div class="field"><label>Monthly Income (₹)</label><input type="number" formControlName="monthlyIncome" /></div>
            <div class="field"><label>Other EMIs (₹)</label><input type="number" formControlName="otherEmis" /></div>
          </div>
          <div class="two-col">
            <div class="field"><label>CIBIL Score</label><input type="number" formControlName="cibilScore" /></div>
            <div class="field"><label>Requested Amount (₹)</label><input type="number" formControlName="requestedAmount" /></div>
          </div>
          <div class="field"><label>Tenure (years)</label><input type="number" formControlName="tenureYears" /></div>
          <button class="btn btn-primary btn-block" type="submit" [disabled]="recLoading()">
            @if (recLoading()) { <span class="spinner"></span> } @else { Get Recommendations }
          </button>
        </form>

        @if (recError()) {
          <div class="inline-error">{{ recError() }}</div>
        }
        @if (recommendations().length > 0) {
          <div style="margin-top:14px;">
            @for (r of recommendations(); track r.productId) {
              <div class="case-card">
                <strong>{{ r.name }}</strong> · {{ r.interestRate }}% · Est. EMI ₹{{ r.estimatedEmi | number: '1.0-0' }}
                <div class="muted" style="margin-top:4px;">{{ r.matchReason }}</div>
              </div>
            }
          </div>
        }
      </div>

      <div class="card">
        <h3>🧮 EMI Assistant</h3>
        <form [formGroup]="emiForm" (ngSubmit)="runEmiAssistant()">
          <div class="field"><label>Loan Amount (₹)</label><input type="number" formControlName="loanAmount" /></div>
          <div class="two-col">
            <div class="field"><label>Interest Rate (%)</label><input type="number" formControlName="interestRate" step="0.01" /></div>
            <div class="field"><label>Max Affordable EMI (₹, optional)</label><input type="number" formControlName="maxAffordableEmi" /></div>
          </div>
          <button class="btn btn-teal btn-block" type="submit" [disabled]="emiLoading()">
            @if (emiLoading()) { <span class="spinner"></span> } @else { Compare Tenure Options }
          </button>
        </form>

        @if (emiError()) {
          <div class="inline-error">{{ emiError() }}</div>
        }
        @if (emiOptions().length > 0) {
          <table style="margin-top:12px;">
            <thead><tr><th>Tenure</th><th>EMI</th><th>Total Interest</th><th></th></tr></thead>
            <tbody>
              @for (o of emiOptions(); track o.tenureYears) {
                <tr>
                  <td>{{ o.tenureYears }} yrs</td>
                  <td>₹{{ o.emi | number: '1.0-0' }}</td>
                  <td>₹{{ o.totalInterest | number: '1.0-0' }}</td>
                  <td>@if (o.recommended) { <span class="badge badge-green">Best Fit</span> }</td>
                </tr>
              }
            </tbody>
          </table>
        }
      </div>
    </div>

    <div class="card" style="text-align:center;">
      <h3>Ready to move forward?</h3>
      <p class="muted">Check your exact eligibility or start your application now.</p>
      <div style="display:flex;gap:10px;justify-content:center;margin-top:10px;">
        <button class="btn btn-outline" routerLink="/eligibility">Check Eligibility</button>
        <button class="btn btn-primary" routerLink="/apply">Apply for a Loan</button>
      </div>
    </div>
  `
})
export class Guidance {
  private fb = inject(FormBuilder);
  private loanSvc = inject(LoanService);
  private toast = inject(ToastService);

  products = signal<LoanProduct[]>([]);
  productsLoading = signal(true);
  productsError = signal('');

  recommendations = signal<ProductRecommendation[]>([]);
  recLoading = signal(false);
  recError = signal('');

  emiOptions = signal<EmiOption[]>([]);
  emiLoading = signal(false);
  emiError = signal('');

  recForm = this.fb.nonNullable.group({
    purpose: ['PURCHASE'],
    monthlyIncome: [80000],
    otherEmis: [0],
    cibilScore: [750],
    requestedAmount: [3000000],
    tenureYears: [20]
  });

  emiForm = this.fb.nonNullable.group({
    loanAmount: [3000000],
    interestRate: [8.5],
    maxAffordableEmi: [null as number | null]
  });

  constructor() {
    this.loanSvc.listProducts().subscribe({
      next: (list) => {
        this.products.set(list);
        this.productsLoading.set(false);
      },
      error: () => {
        this.productsError.set('Could not load loan products from loan-service.');
        this.productsLoading.set(false);
      }
    });
  }

  getRecommendations(): void {
    this.recLoading.set(true);
    this.recError.set('');
    this.loanSvc.recommendProducts(this.recForm.getRawValue()).subscribe({
      next: (list) => {
        this.recommendations.set(list);
        this.recLoading.set(false);
        if (list.length === 0) this.toast.show('No matches found', 'Try adjusting your inputs.');
      },
      error: () => {
        this.recError.set('Could not fetch recommendations right now.');
        this.recLoading.set(false);
      }
    });
  }

  runEmiAssistant(): void {
    this.emiLoading.set(true);
    this.emiError.set('');
    const raw = this.emiForm.getRawValue();
    this.loanSvc
      .emiAssistant({
        loanAmount: raw.loanAmount,
        interestRate: raw.interestRate,
        maxAffordableEmi: raw.maxAffordableEmi ?? undefined
      })
      .subscribe({
        next: (list) => {
          this.emiOptions.set(list);
          this.emiLoading.set(false);
        },
        error: () => {
          this.emiError.set('Could not calculate EMI options right now.');
          this.emiLoading.set(false);
        }
      });
  }
}
