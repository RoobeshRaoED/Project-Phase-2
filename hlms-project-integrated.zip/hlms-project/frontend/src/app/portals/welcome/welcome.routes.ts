import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/auth/login/login.component';
import { RegisterComponent } from './pages/auth/register/register.component';

export const WELCOME_ROUTES: Routes = [
  { path: '', component: HomeComponent, title: 'HLMS | Home' },
  { path: 'login', component: LoginComponent, title: 'HLMS | Login' },
  { path: 'register', component: RegisterComponent, title: 'HLMS | Register' },
  { path: '**', redirectTo: '' }
];
