export const environment = {
  production: false,
  // Keep as empty string to use Angular proxy. Calls become /api/users/login.
  // This avoids browser CORS during local development.
  apiBaseUrl: ''
};
