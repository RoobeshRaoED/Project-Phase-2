import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { environment } from '../../environments/environment';
import { ApiUser, ForgotPasswordDTO, LoginRequestDTO, LoginResponseDTO, RegisterRequestDTO, ResetPasswordDTO } from '../models/auth.models';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly apiBase = `${environment.apiBaseUrl}/api`;
  private readonly tokenKey = 'hlms_auth_token';
  private readonly userKey = 'hlms_user';

  constructor(private http: HttpClient) {}

  register(payload: RegisterRequestDTO): Observable<ApiUser> {
    return this.http.post<ApiUser>(`${this.apiBase}/users/register`, payload);
  }

  login(payload: LoginRequestDTO): Observable<LoginResponseDTO> {
    return this.http.post<LoginResponseDTO>(`${this.apiBase}/users/login`, payload).pipe(
      tap((response) => this.saveLogin(response))
    );
  }

  getUser(email: string): Observable<ApiUser> {
    return this.http.get<ApiUser>(`${this.apiBase}/users/${encodeURIComponent(email)}`);
  }

  forgotPassword(payload: ForgotPasswordDTO): Observable<string> {
    return this.http.post(`${this.apiBase}/users/forgot-password`, payload, { responseType: 'text' });
  }

  resetPassword(payload: ResetPasswordDTO): Observable<string> {
    return this.http.post(`${this.apiBase}/users/reset-password`, payload, { responseType: 'text' });
  }



  logout(): void {
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem(this.userKey);
  }

  get token(): string | null {
    return localStorage.getItem(this.tokenKey);
  }

  private saveLogin(response: LoginResponseDTO): void {
    const token = response.token || response.jwtToken || response.accessToken;
    if (token) localStorage.setItem(this.tokenKey, token);
    localStorage.setItem(this.userKey, JSON.stringify(response));
  }
}
