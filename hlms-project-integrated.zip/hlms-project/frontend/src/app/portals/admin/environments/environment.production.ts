export const environment = {
  production: true,
  // Replace with your deployed API Gateway URL.
  apiBaseUrl: 'https://api.your-hlms-domain.com',
  services: {
    user: '/user-service',
    loan: '/loan-service',
    legal: '/legal-service',
    repayment: '/repayment-service',
    notification: '/notification-service',
    document: '/document-service'
  }
};
