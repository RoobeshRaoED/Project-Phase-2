/**
 * Points at the Spring Cloud API Gateway (api-gateway module), NOT at the
 * individual microservices directly. The gateway (default port 8080) routes
 * `/<service-name>/**` to the matching Eureka service and strips the
 * `/<service-name>` prefix — see api-gateway/src/main/resources/application.properties.
 *
 * Example: apiBaseUrl + '/user-service/api/users/login'
 *   -> http://localhost:8080/user-service/api/users/login
 *   -> gateway strips "/user-service" -> forwards to user-service's
 *      POST /api/users/login
 */
export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:8080',
  services: {
    user: '/user-service',
    loan: '/loan-service',
    legal: '/legal-service',
    repayment: '/repayment-service',
    notification: '/notification-service',
    document: '/document-service'
  }
};
