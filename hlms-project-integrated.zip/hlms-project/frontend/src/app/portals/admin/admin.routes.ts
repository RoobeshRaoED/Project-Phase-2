import { Routes } from '@angular/router';
import { authGuard, adminGuard } from './core/guards/auth.guard';

export const ADMIN_ROUTES: Routes = [
  {
    path: 'login',
    loadComponent: () =>
      import('./features/login/login.component').then((m) => m.LoginComponent)
  },
  {
    path: '',
    loadComponent: () =>
      import('./features/admin/admin-shell/admin-shell.component').then((m) => m.AdminShellComponent),
    canActivate: [authGuard, adminGuard],
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'dashboard'
      },
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./features/admin/dashboard/dashboard.component').then((m) => m.DashboardComponent)
      },

      {
        path: 'bidder-management',
        loadComponent: () =>
          import('./features/admin/staff-management/staff-management.component').then(
            (m) => m.StaffManagementComponent
          ),
        data: {
          pageTitle: 'Bidder Management',
          pageDesc: 'Manage bidder accounts from one place.',
          activeTab: 'BIDDER',
          tabs: [
            {
              key: 'BIDDER',
              label: 'Bidders',
              route: '/admin/bidder-management'
            }
          ]
        }
      },

      {
        path: 'admin-management',
        redirectTo: 'employee-management',
        pathMatch: 'full'
      },

      {
        path: 'employee-management',
        loadComponent: () =>
          import('./features/admin/staff-management/staff-management.component').then(
            (m) => m.StaffManagementComponent
          ),
        data: {
          pageTitle: 'Employee Management',
          pageDesc: 'Manage staff accounts and their access to HLMS across departments.',
          activeTab: 'ADMIN',
          tabs: [
            {
              key: 'ADMIN',
              label: 'Admins',
              route: '/admin/employee-management'
            },
            {
              key: 'LEGAL',
              label: 'Legal Team',
              route: '/admin/legal-management'
            },
            {
              key: 'BANK_OFFICER',
              label: 'Bank Office',
              route: '/admin/bankoffice-management'
            }
          ]
        }
      },

      {
        path: 'legal-management',
        loadComponent: () =>
          import('./features/admin/staff-management/staff-management.component').then(
            (m) => m.StaffManagementComponent
          ),
        data: {
          pageTitle: 'Employee Management',
          pageDesc: 'Manage staff accounts and their access to HLMS across departments.',
          activeTab: 'LEGAL',
          tabs: [
            {
              key: 'ADMIN',
              label: 'Admins',
              route: '/admin/employee-management'
            },
            {
              key: 'LEGAL',
              label: 'Legal Team',
              route: '/admin/legal-management'
            },
            {
              key: 'BANK_OFFICER',
              label: 'Bank Office',
              route: '/admin/bankoffice-management'
            }
          ]
        }
      },

      {
        path: 'bankoffice-management',
        loadComponent: () =>
          import('./features/admin/staff-management/staff-management.component').then(
            (m) => m.StaffManagementComponent
          ),
        data: {
          pageTitle: 'Employee Management',
          pageDesc: 'Manage staff accounts and their access to HLMS across departments.',
          activeTab: 'BANK_OFFICER',
          tabs: [
            {
              key: 'ADMIN',
              label: 'Admins',
              route: '/admin/employee-management'
            },
            {
              key: 'LEGAL',
              label: 'Legal Team',
              route: '/admin/legal-management'
            },
            {
              key: 'BANK_OFFICER',
              label: 'Bank Office',
              route: '/admin/bankoffice-management'
            }
          ]
        }
      },

      {
        path: 'profile',
        loadComponent: () =>
          import('./features/admin/profile/profile.component').then((m) => m.ProfileComponent)
      }
    ]
  },
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'login'
  },
  {
    path: '**',
    redirectTo: 'login'
  }
];