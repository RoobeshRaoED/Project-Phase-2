import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, tap, catchError, throwError, switchMap, of } from 'rxjs';
import { environment } from '../../environments/environment';
import { AppUser } from '../models/models';

interface LoginResponse { token: string; }
interface JwtPayload { sub: string; role: string; iat: number; exp: number; }

const TOKEN_KEY = 'hlms_legal_token';

@Injectable({ providedIn: 'root' })
export class AuthService {
  /** Current logged-in Legal Team user, or null. Populated after login / on app bootstrap. */
  currentUser = signal<AppUser | null>(null);
  authReady = signal(false);

  constructor(private http: HttpClient, private router: Router) {}

  private get base(): string {
    return `${environment.apiBase}/user-service/api/users`;
  }

  login(email: string, password: string): Observable<AppUser> {
    return this.http.post<LoginResponse>(`${this.base}/login`, { email, password }).pipe(
      switchMap((res) => {
        const payload = this.decodeToken(res.token);
        if (!payload) {
          return throwError(() => new Error('Received an invalid token from the server.'));
        }
        if ((payload.role || '').toUpperCase() !== 'LEGAL') {
          return throwError(() => new Error(
            'This portal is only for Legal & Valuation Team members. Your account role is "' + payload.role + '".'
          ));
        }
        localStorage.setItem(TOKEN_KEY, res.token);
        return this.http.get<AppUser>(`${this.base}/${encodeURIComponent(payload.sub)}`);
      }),
      tap((user) => this.currentUser.set(user)),
      catchError((err) => {
        localStorage.removeItem(TOKEN_KEY);
        return throwError(() => err);
      })
    );
  }

  /** Called once on app start to restore session from a stored token, if any. */
  restoreSession(): Observable<AppUser | null> {
    const token = this.getToken();
    if (!token) {
      this.authReady.set(true);
      return of(null);
    }
    const payload = this.decodeToken(token);
    if (!payload || this.isExpired(payload) || (payload.role || '').toUpperCase() !== 'LEGAL') {
      this.logout();
      this.authReady.set(true);
      return of(null);
    }
    return this.http.get<AppUser>(`${this.base}/${encodeURIComponent(payload.sub)}`).pipe(
      tap((user) => { this.currentUser.set(user); this.authReady.set(true); }),
      catchError(() => {
        this.logout();
        this.authReady.set(true);
        return of(null);
      })
    );
  }

  refreshCurrentUser(): void {
    const u = this.currentUser();
    if (!u) return;
    this.http.get<AppUser>(`${this.base}/${encodeURIComponent(u.email)}`).subscribe({
      next: (fresh) => this.currentUser.set(fresh)
    });
  }

  logout(): void {
    localStorage.removeItem(TOKEN_KEY);
    this.currentUser.set(null);
    this.router.navigate(['/legal/login']);
  }

  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  isLoggedIn(): boolean {
    const token = this.getToken();
    if (!token) return false;
    const payload = this.decodeToken(token);
    return !!payload && !this.isExpired(payload) && (payload.role || '').toUpperCase() === 'LEGAL';
  }

  private isExpired(payload: JwtPayload): boolean {
    return !payload.exp || Date.now() >= payload.exp * 1000;
  }

  private decodeToken(token: string): JwtPayload | null {
    try {
      const parts = token.split('.');
      if (parts.length !== 3) return null;
      const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
      const json = decodeURIComponent(
        atob(base64)
          .split('')
          .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
          .join('')
      );
      return JSON.parse(json);
    } catch {
      return null;
    }
  }
}
