import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { LegalNoticeDTO } from '../models/models';

@Injectable({ providedIn: 'root' })
export class LegalNoticeService {
  private base = `${environment.apiBase}/legal-service/api/legal-notices`;

  constructor(private http: HttpClient) {}

  listAll(): Observable<LegalNoticeDTO[]> {
    return this.http.get<LegalNoticeDTO[]>(this.base);
  }

  create(dto: LegalNoticeDTO): Observable<LegalNoticeDTO> {
    return this.http.post<LegalNoticeDTO>(this.base, dto);
  }
}
