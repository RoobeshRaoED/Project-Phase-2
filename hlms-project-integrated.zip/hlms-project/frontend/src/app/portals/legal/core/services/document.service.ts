import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, of } from 'rxjs';
import { environment } from '../../environments/environment';
import { ApplicationDocumentEntity, PostDisbursementDocumentEntity } from '../models/models';

@Injectable({ providedIn: 'root' })
export class DocumentService {
  private appDocsBase = `${environment.apiBase}/document-service/api/application-documents`;
  private pdDocsBase = `${environment.apiBase}/document-service/api/post-disbursement-documents`;

  constructor(private http: HttpClient) {}

  // These are fanned out per-application inside forkJoin (see legal-data.service.ts and the
  // list pages) - an application with zero documents uploaded yet is a normal state, not an
  // error, but a backend that 404s on an empty result must not be allowed to kill the whole
  // forkJoin and leave the page stuck on its loading spinner. Treat any failure as "no docs".
  // NOTE: this swallows the real error (401/403/500/CORS/service-down all look identical to
  // "zero documents" to the caller). That's fine for list/queue pages that only need a count,
  // but the case-detail page needs to tell a genuinely-empty case apart from a failed request -
  // see listApplicationDocumentsOrThrow() below, which it uses instead.
  listApplicationDocuments(appId: string): Observable<ApplicationDocumentEntity[]> {
    return this.http.get<ApplicationDocumentEntity[]>(`${this.appDocsBase}/app/${appId}`).pipe(
      catchError((err) => {
        console.error(`[DocumentService] listApplicationDocuments(${appId}) failed - treating as empty:`, err);
        return of([] as ApplicationDocumentEntity[]);
      })
    );
  }

  /** Same call as above but lets the error propagate, so the caller can distinguish
   *  "this application really has no documents" (empty array) from "the request failed"
   *  (observable errors) instead of both looking like an empty list. */
  listApplicationDocumentsOrThrow(appId: string): Observable<ApplicationDocumentEntity[]> {
    return this.http.get<ApplicationDocumentEntity[]>(`${this.appDocsBase}/app/${appId}`);
  }

  listAllApplicationDocuments(): Observable<ApplicationDocumentEntity[]> {
    return this.http.get<ApplicationDocumentEntity[]>(this.appDocsBase).pipe(
      catchError(() => of([] as ApplicationDocumentEntity[]))
    );
  }

  listAllPostDisbursementDocuments(): Observable<PostDisbursementDocumentEntity[]> {
    return this.http.get<PostDisbursementDocumentEntity[]>(this.pdDocsBase).pipe(
      catchError(() => of([] as PostDisbursementDocumentEntity[]))
    );
  }

  listPostDisbursementDocuments(appId: string): Observable<PostDisbursementDocumentEntity[]> {
    return this.http.get<PostDisbursementDocumentEntity[]>(`${this.pdDocsBase}/app/${appId}`).pipe(
      catchError(() => of([] as PostDisbursementDocumentEntity[]))
    );
  }

  /**
   * The backend has no dedicated "verify" / "reject" endpoint for either document
   * type — only generic CRUD (POST create / PUT-less update is actually missing too,
   * see README_API_GAPS.md). We work around it here with a full re-save via POST,
   * which the service treats as an upsert-by-id in the demo data model; if your
   * document-service instead requires a PUT for updates, adjust these two calls.
   */
  verifyPostDisbursementDocument(doc: PostDisbursementDocumentEntity, verifiedBy: string): Observable<PostDisbursementDocumentEntity> {
    const updated: PostDisbursementDocumentEntity = { ...doc, status: 'Verified', verifiedBy, verifiedAt: new Date().toISOString(), remarks: '' };
    return this.http.post<PostDisbursementDocumentEntity>(this.pdDocsBase, updated);
  }

  rejectPostDisbursementDocument(doc: PostDisbursementDocumentEntity, verifiedBy: string, remarks: string): Observable<PostDisbursementDocumentEntity> {
    const updated: PostDisbursementDocumentEntity = { ...doc, status: 'Rejected', verifiedBy, verifiedAt: new Date().toISOString(), remarks };
    return this.http.post<PostDisbursementDocumentEntity>(this.pdDocsBase, updated);
  }

  /**
   * document-service has no dedicated verify/reject endpoint for application
   * documents either (same gap as post-disbursement documents above - see
   * README_API_GAPS.md). Uses the same full re-save-via-POST workaround:
   * ApplicationDocumentServiceImpl.saveDocument() delegates straight to
   * repository.save(), which upserts by documentId since the id is already
   * set on the entity we send back.
   *
   * Document verification for application documents (the "Document
   * Verification" workflow stage) is done here by the Legal & Valuation
   * Team, not by Bank Office - see legal-case-detail.component.ts.
   */
  verifyApplicationDocument(doc: ApplicationDocumentEntity, verifiedBy: string): Observable<ApplicationDocumentEntity> {
    const updated: ApplicationDocumentEntity = { ...doc, verificationStatus: 'Verified', verifiedBy, verifiedAt: new Date().toISOString(), remarks: '' };
    return this.http.post<ApplicationDocumentEntity>(this.appDocsBase, updated);
  }

  rejectApplicationDocument(doc: ApplicationDocumentEntity, verifiedBy: string, remarks: string): Observable<ApplicationDocumentEntity> {
    const updated: ApplicationDocumentEntity = { ...doc, verificationStatus: 'Rejected', verifiedBy, verifiedAt: new Date().toISOString(), remarks };
    return this.http.post<ApplicationDocumentEntity>(this.appDocsBase, updated);
  }

  /**
   * Opens a base64-embedded document (fileData) in a new tab for viewing.
   *
   * Previous approach (still visible in git history) opened a blank window
   * and used document.write() to inject an <embed src="data:...;base64,...">
   * pointing straight at the raw base64 payload. Chrome tolerates that, but
   * Edge's built-in PDF reader attaches to the <embed> and tries to parse
   * the data: URI itself - for anything beyond a trivially small file this
   * reliably fails with Edge's own "We can't open this file / Something
   * went wrong" error page (0 of 0 pages), even though the underlying
   * fileData from document-service is perfectly valid.
   *
   * Fix: decode the base64 into an actual Blob and open a real
   * blob: object URL instead. That's a real, typed, same-origin resource
   * the browser's native PDF/image viewer opens exactly like a downloaded
   * file - works consistently in Edge, Chrome and Firefox. The object URL
   * is revoked after a delay long enough for the new tab to finish loading
   * it, so we don't leak memory on repeated "View" clicks.
   *
   * Returns false if there's nothing to show (no fileData, invalid base64,
   * or the popup was blocked), so callers can surface that to the user.
   */
  openInlineDocument(doc: { fileData?: string; fileName: string }): boolean {
    if (!doc.fileData) return false;
    try {
      const ext = (doc.fileName || '').split('.').pop()?.toLowerCase();
      const mime =
        ext === 'pdf' ? 'application/pdf' :
        ext === 'png' ? 'image/png' :
        ext === 'jpg' || ext === 'jpeg' ? 'image/jpeg' :
        ext === 'gif' ? 'image/gif' :
        ext === 'webp' ? 'image/webp' :
        'application/octet-stream';

      // atob() throws on malformed base64 - caught below, surfaced as "no file available".
      const binary = atob(doc.fileData);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      const blob = new Blob([bytes], { type: mime });
      const objectUrl = URL.createObjectURL(blob);

      const win = window.open(objectUrl, '_blank');
      if (!win) {
        URL.revokeObjectURL(objectUrl);
        return false; // popup blocked
      }
      // Give the new tab time to actually load the resource before revoking it.
      setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
      return true;
    } catch {
      // fileData wasn't valid base64 — nothing sensible to open.
      return false;
    }
  }
}
