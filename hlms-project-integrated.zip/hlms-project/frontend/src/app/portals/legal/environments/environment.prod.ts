export const environment = {
  production: true,
  // In production, point this at your deployed API Gateway origin,
  // e.g. 'https://api.yourbank.com'.
  apiBase: 'http://localhost:8080'
};
