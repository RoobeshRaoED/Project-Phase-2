import { Component, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { catchError, forkJoin, of, switchMap } from 'rxjs';

import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';
import { LoanApplicationService } from '../../core/services/loan-application.service';
import { LegalVerificationService } from '../../core/services/legal-verification.service';
import { LegalChecklistService } from '../../core/services/legal-checklist.service';
import { LegalDataService } from '../../core/services/legal-data.service';
import { DocumentService } from '../../core/services/document.service';
import { NotificationService } from '../../core/services/notification.service';
import {
  ApplicationDocumentEntity,
  LEGAL_CHECKLIST,
  LegalChecklistItemDTO,
  LegalVerificationDTO,
  LoanApplication
} from '../../core/models/models';

@Component({
  selector: 'app-legal-case-detail',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './legal-case-detail.component.html'
})
export class LegalCaseDetailComponent implements OnInit {
  loading = signal(true);
  notFound = signal(false);
  documentsLoadError = signal<string | null>(null);
  appId = '';
  legalStageIndex = 3;
  documentStageIndex = 2;

  app = signal<LoanApplication | null>(null);
  verification = signal<LegalVerificationDTO | null>(null);
  checklist = signal<LegalChecklistItemDTO[]>([]);
  documents = signal<ApplicationDocumentEntity[]>([]);
  productNames = signal<Record<string, string>>({});
  remarksDraft = signal('');
  savingRemarks = signal(false);
  decisionInProgress = signal(false);

  // Document Verification stage state - the Legal Team verifies documents
  // here (before Legal Verification proper) and forwards the case on once
  // done. Bank Office cannot advance past this stage on its own.
  savingDocId = signal<string | null>(null);
  rejectingDocId = signal<string | null>(null);
  docRejectRemarks = '';
  forwardingCase = signal(false);

  checklistDefs = LEGAL_CHECKLIST;

  allVerified = computed(() => this.checklistDefs.every((c) => this.statusFor(c.key) === 'Verified'));
  anyDiscrepancy = computed(() => this.checklistDefs.some((c) => this.statusFor(c.key) === 'Discrepancy'));

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    public auth: AuthService,
    private toast: ToastService,
    private loanSvc: LoanApplicationService,
    private verificationSvc: LegalVerificationService,
    private checklistSvc: LegalChecklistService,
    private legalData: LegalDataService,
    private docSvc: DocumentService,
    private notifSvc: NotificationService
  ) {}

  ngOnInit(): void {
    this.appId = this.route.snapshot.paramMap.get('appId') || '';
    this.legalData.getLegalStageIndex().subscribe((idx) => (this.legalStageIndex = idx));
    this.legalData.getDocumentStageIndex().subscribe((idx) => (this.documentStageIndex = idx));
    this.loanSvc.getProductNameMap().subscribe({
      next: (map) => this.productNames.set(map),
      error: () => this.productNames.set({})
    });
    this.loadAll();
  }

  private loadAll(): void {
    this.loading.set(true);
    this.documentsLoadError.set(null);
    forkJoin({
      app: this.loanSvc.get(this.appId),
      verification: this.verificationSvc.getByApplication(this.appId),
      checklist: this.checklistSvc.listByApplication(this.appId),
      // Uses the throwing variant here (unlike the queue/list pages) so a failed request
      // can be shown to the officer as "couldn't load documents", not confused with a case
      // that genuinely has zero documents uploaded.
      documents: this.docSvc.listApplicationDocumentsOrThrow(this.appId).pipe(
        catchError((err) => {
          const status = err?.status;
          this.documentsLoadError.set(
            status === 401 || status === 403
              ? `Not authorized to load documents (HTTP ${status}). Your session may need to be refreshed.`
              : status
                ? `Could not load documents (HTTP ${status}). The document service may be unreachable.`
                : 'Could not load documents. Check your connection and try again.'
          );
          console.error(`[CaseDetail] failed to load documents for ${this.appId}:`, err);
          return of([] as ApplicationDocumentEntity[]);
        })
      )
    }).subscribe({
      next: ({ app, verification, checklist, documents }) => {
        if (!app) {
          // loanSvc.get() resolves a missing/unreadable application to null (instead of
          // erroring the whole forkJoin) so other pages that fan this call out per-appId
          // aren't taken down by one bad id - handle that "not found" case explicitly here.
          this.notFound.set(true);
          this.loading.set(false);
          return;
        }
        this.app.set(app);
        this.verification.set(verification);
        this.remarksDraft.set(verification?.remarks || '');
        this.documents.set(documents);
        this.ensureChecklistRows(checklist);
        this.loading.set(false);
      },
      error: () => {
        this.notFound.set(true);
        this.loading.set(false);
      }
    });
  }

  /** Creates any of the 6 required checklist rows that don't exist yet for this application (defaults to Pending). */
  private ensureChecklistRows(existing: LegalChecklistItemDTO[]): void {
    const missingDefs = this.checklistDefs.filter((def) => !existing.some((e) => e.checklistKey === def.key));
    if (missingDefs.length === 0) {
      this.checklist.set(existing);
      return;
    }
    forkJoin(
      missingDefs.map((def) =>
        this.checklistSvc.create({ appId: this.appId, checklistKey: def.key, status: 'Pending' })
      )
    ).subscribe((created) => this.checklist.set([...existing, ...created]));
  }

  statusFor(key: string): string {
    return this.checklist().find((c) => c.checklistKey === key)?.status || 'Pending';
  }

  // True while the case currently sits at the Document Verification stage -
  // the Legal Team's job is to verify the submitted documents here and then
  // forward the case on to Legal Verification.
  isAtDocumentStage(): boolean {
    return this.app()?.stageIndex === this.documentStageIndex;
  }

  // True once the case has actually reached Legal Verification - the
  // checklist/decision UI below only applies once it's here, not while it's
  // still sitting at Document Verification.
  isAtLegalStage(): boolean {
    return this.app()?.stageIndex === this.legalStageIndex;
  }

  allDocsVerified(): boolean {
    return this.documents().length > 0 && this.documents().every((d) => d.verificationStatus === 'Verified');
  }

  verifyDoc(doc: ApplicationDocumentEntity): void {
    const officer = this.auth.currentUser();
    if (!officer || !doc.documentId) return;
    this.savingDocId.set(doc.documentId);
    this.docSvc.verifyApplicationDocument(doc, officer.email).subscribe({
      next: (saved) => {
        this.savingDocId.set(null);
        this.documents.set(this.documents().map((d) => (d.documentId === saved.documentId ? saved : d)));
        this.toast.success('Document Verified', doc.docType);
      },
      error: () => {
        this.savingDocId.set(null);
        this.toast.error('Could not verify document', 'Please try again.');
      }
    });
  }

  startRejectDoc(doc: ApplicationDocumentEntity): void {
    this.rejectingDocId.set(doc.documentId ?? null);
    this.docRejectRemarks = '';
  }

  cancelRejectDoc(): void {
    this.rejectingDocId.set(null);
    this.docRejectRemarks = '';
  }

  confirmRejectDoc(doc: ApplicationDocumentEntity): void {
    const officer = this.auth.currentUser();
    if (!officer || !doc.documentId) return;
    if (!this.docRejectRemarks.trim()) {
      this.toast.error('Reason required', 'Please provide a reason for rejection.');
      return;
    }
    this.savingDocId.set(doc.documentId);
    this.docSvc.rejectApplicationDocument(doc, officer.email, this.docRejectRemarks.trim()).subscribe({
      next: (saved) => {
        this.savingDocId.set(null);
        this.documents.set(this.documents().map((d) => (d.documentId === saved.documentId ? saved : d)));
        this.toast.success('Document Rejected', doc.docType);
        this.rejectingDocId.set(null);
        this.docRejectRemarks = '';
      },
      error: () => {
        this.savingDocId.set(null);
        this.toast.error('Could not reject document', 'Please try again.');
      }
    });
  }

  // The one action that moves a case past Document Verification - only the
  // Legal Team can do this, and only once every document is Verified. Bank
  // Office can then take over again once the case reaches its next stage.
  forwardToLegalVerification(): void {
    const app = this.app();
    const officer = this.auth.currentUser();
    if (!app || !officer) return;
    if (!this.allDocsVerified()) {
      this.toast.error('Documents Pending', 'Please verify all submitted documents before forwarding this case.');
      return;
    }
    this.forwardingCase.set(true);
    this.loanSvc.updateStage(this.appId, this.legalStageIndex, 'Under Review').subscribe({
      next: (updatedApp) => {
        this.app.set(updatedApp);
        this.forwardingCase.set(false);
        this.toast.success('Case Forwarded', app.trackingNo + ' moved to Legal Verification.');
        this.notifSvc.send(
          app.userEmail,
          'Documents Verified',
          `Your documents for application ${app.trackingNo} have been verified by the Legal & Valuation Team and the case has moved to Legal Verification.`
        ).subscribe({ error: () => {} });
      },
      error: () => {
        this.forwardingCase.set(false);
        this.toast.error('Could not forward case', 'Please try again.');
      }
    });
  }

  onChecklistChange(key: string, value: string): void {
    const item = this.checklist().find((c) => c.checklistKey === key);
    if (!item || !item.checklistItemId) return;
    const updated: LegalChecklistItemDTO = { ...item, status: value };
    this.checklistSvc.update(item.checklistItemId, updated).subscribe({
      next: (saved) => {
        this.checklist.set(this.checklist().map((c) => (c.checklistKey === key ? saved : c)));
      },
      error: () => this.toast.error('Could not update checklist item', 'Please try again.')
    });
  }

  saveRemarks(): void {
    this.savingRemarks.set(true);
    const current = this.verification();
    const dto: LegalVerificationDTO = {
      appId: this.appId,
      decision: current?.decision ?? null,
      decisionDate: current?.decisionDate ?? null,
      officerEmail: current?.officerEmail ?? null,
      remarks: this.remarksDraft()
    };
    const req = current?.verificationId
      ? this.verificationSvc.update(current.verificationId, dto)
      : this.verificationSvc.create(dto);
    req.subscribe({
      next: (saved) => {
        this.verification.set(saved);
        this.savingRemarks.set(false);
        this.toast.success('Remarks Saved', 'Legal remarks have been updated.');
      },
      error: () => {
        this.savingRemarks.set(false);
        this.toast.error('Could not save remarks', 'Please try again.');
      }
    });
  }

  decide(decision: 'Approved' | 'Query Raised' | 'Rejected'): void {
    const app = this.app();
    const officer = this.auth.currentUser();
    if (!app || !officer) return;

    if (decision === 'Approved' && !this.allVerified()) {
      this.toast.error('Cannot Approve', 'Please mark all checklist items as Verified first.');
      return;
    }

    this.decisionInProgress.set(true);
    const current = this.verification();
    const dto: LegalVerificationDTO = {
      appId: this.appId,
      decision,
      decisionDate: new Date().toISOString(),
      officerEmail: officer.email,
      remarks: this.remarksDraft()
    };
    const saveReq = current?.verificationId
      ? this.verificationSvc.update(current.verificationId, dto)
      : this.verificationSvc.create(dto);

    saveReq.pipe(
      switchMap((saved) => {
        this.verification.set(saved);
        if (decision === 'Approved') {
          return this.loanSvc.updateStage(this.appId, this.legalStageIndex + 1, 'Under Review');
        } else if (decision === 'Rejected') {
          return this.loanSvc.updateStage(this.appId, app.stageIndex, 'Rejected');
        }
        return of(app);
      })
    ).subscribe({
      next: (updatedApp) => {
        this.app.set(updatedApp);
        this.decisionInProgress.set(false);
        this.notifyBorrower(app, decision);
        if (decision === 'Approved') this.toast.success('Case Approved', app.trackingNo + ' forwarded to Final Approval.');
        else if (decision === 'Query Raised') this.toast.success('Query Raised', 'Applicant has been notified.');
        else this.toast.success('Case Rejected', app.trackingNo + ' has been rejected.');
      },
      error: () => {
        this.decisionInProgress.set(false);
        this.toast.error('Could not record decision', 'Please try again.');
      }
    });
  }

  private notifyBorrower(app: LoanApplication, decision: string): void {
    if (decision === 'Approved') {
      this.notifSvc.send(app.userEmail, 'Legal Verification Completed',
        `Your application ${app.trackingNo} has cleared legal & property verification and moved to Final Approval.`).subscribe();
    } else if (decision === 'Query Raised') {
      this.notifSvc.send(app.userEmail, 'Additional Information Required',
        `The Legal team has raised a query on your application ${app.trackingNo}. Please check remarks: ${this.remarksDraft() || 'See portal for details.'}`).subscribe();
    } else if (decision === 'Rejected') {
      this.notifSvc.send(app.userEmail, 'Application Rejected',
        `Your application ${app.trackingNo} could not be approved due to legal/title verification issues. Remarks: ${this.remarksDraft() || 'Contact support for details.'}`).subscribe();
    }
  }

  retryLoadDocuments(): void {
    this.loadAll();
  }

  viewDocument(doc: ApplicationDocumentEntity): void {
    const opened = this.docSvc.openInlineDocument(doc);
    if (!opened) {
      this.toast.error('No file available', 'This document has no stored file content, or your browser blocked the popup.');
    }
  }

  ltv(): string {
    const app = this.app();
    if (!app || !app.propertyValue) return '—';
    return Math.round(((app.loanAmount || 0) / app.propertyValue) * 100) + '%';
  }

  productName(productId?: string): string {
    if (!productId) return '—';
    return this.productNames()[productId] ?? productId;
  }
}
