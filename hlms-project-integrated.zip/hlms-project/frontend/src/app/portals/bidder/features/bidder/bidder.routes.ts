import { Routes } from '@angular/router';
import { BidderShellComponent } from '../../shared/components/bidder-shell.component';

/**
 * Everything under /bidder. Lazily loaded as a unit by app.routes.ts, and
 * each screen is lazily loaded again inside it, so a bidder who only opens
 * the dashboard never downloads the auction detail or settings code.
 *
 * The guard sits on the parent route in app.routes.ts - one gate, no way to
 * reach a child without passing it.
 */
export const BIDDER_ROUTES: Routes = [
  {
    path: '',
    component: BidderShellComponent,
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      {
        path: 'dashboard',
        title: 'Dashboard · HLMS Bidder Portal',
        loadComponent: () => import('./dashboard/dashboard.component').then((m) => m.BidderDashboardComponent),
      },
      {
        path: 'auctions',
        title: 'Auctions · HLMS Bidder Portal',
        loadComponent: () => import('./auctions/auction-list.component').then((m) => m.AuctionListComponent),
      },
      {
        path: 'auctions/:auctionId',
        title: 'Auction · HLMS Bidder Portal',
        loadComponent: () => import('./auctions/auction-detail.component').then((m) => m.AuctionDetailComponent),
      },
      {
        path: 'my-bids',
        title: 'My Bids · HLMS Bidder Portal',
        loadComponent: () => import('./my-bids/my-bids.component').then((m) => m.MyBidsComponent),
      },
      {
        path: 'won-auctions',
        title: 'Won Auctions · HLMS Bidder Portal',
        loadComponent: () => import('./won-auctions/won-auctions.component').then((m) => m.WonAuctionsComponent),
      },
      {
        path: 'upcoming-auctions',
        title: 'Upcoming Auctions · HLMS Bidder Portal',
        loadComponent: () =>
          import('./upcoming-auctions/upcoming-auctions.component').then((m) => m.UpcomingAuctionsComponent),
      },
      {
        path: 'notifications',
        title: 'Notifications · HLMS Bidder Portal',
        loadComponent: () => import('./notifications/notifications.component').then((m) => m.NotificationsComponent),
      },
      {
        path: 'profile',
        title: 'Profile · HLMS Bidder Portal',
        loadComponent: () => import('./profile/profile.component').then((m) => m.BidderProfileComponent),
      },
      {
        path: 'settings',
        title: 'Settings · HLMS Bidder Portal',
        loadComponent: () => import('./settings/settings.component').then((m) => m.BidderSettingsComponent),
      },
    ],
  },
];
