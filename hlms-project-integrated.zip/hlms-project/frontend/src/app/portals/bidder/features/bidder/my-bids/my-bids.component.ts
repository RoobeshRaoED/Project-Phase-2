import { ChangeDetectionStrategy, Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { BidStatus, MyBidRow, PortalError } from '../../../core/models/hlms.models';
import { BidderPortalService } from '../../../core/services/bidder-portal.service';
import { StateBlockComponent } from '../../../shared/components/state-block.component';
import { StatusBadgeComponent } from '../../../shared/components/status-badge.component';
import { HlmsDatePipe } from '../../../shared/pipes/hlms-date.pipe';
import { InrPipe } from '../../../shared/pipes/inr.pipe';

type SortKey = 'placed-desc' | 'placed-asc' | 'amount-desc' | 'amount-asc';

@Component({
  selector: 'hlms-my-bids',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule, RouterLink, StateBlockComponent, StatusBadgeComponent, InrPipe, HlmsDatePipe],
  template: `
    <div class="page-head">
      <h1>My Bids</h1>
      <p>Every bid you've placed, and where it stands against the current highest.</p>
    </div>

    <hlms-state-block
      [loading]="loading()"
      [error]="error()"
      [empty]="rows().length === 0"
      loadingText="Loading your bids..."
      emptyText="You haven't placed a bid yet."
      (retry)="load()"
    >
      <a emptyAction class="btn btn-outline btn-sm" routerLink="/bidder/auctions">Browse auctions</a>

      <div class="card">
        <div class="filter-bar">
          <div class="field">
            <label for="q">Search</label>
            <input id="q" type="search" placeholder="Property, bid ID or reference" [ngModel]="query()" (ngModelChange)="setQuery($event)" />
          </div>
          <div class="field">
            <label for="status">Status</label>
            <select id="status" [ngModel]="statusFilter()" (ngModelChange)="setStatus($event)">
              <option value="ALL">All statuses</option>
              <option value="WINNING">Winning</option>
              <option value="OUTBID">Outbid</option>
              <option value="WON_PROVISIONAL">Won (provisional)</option>
              <option value="LOST">Lost</option>
              <option value="CLOSED">Closed</option>
            </select>
          </div>
          <div class="field">
            <label for="sort">Sort by</label>
            <select id="sort" [ngModel]="sort()" (ngModelChange)="setSort($event)">
              <option value="placed-desc">Most recent first</option>
              <option value="placed-asc">Oldest first</option>
              <option value="amount-desc">Highest amount</option>
              <option value="amount-asc">Lowest amount</option>
            </select>
          </div>
        </div>

        @if (filtered().length === 0) {
          <div class="empty-state">
            <div class="ic">🔍</div>
            No bids match these filters.
            <div class="action">
              <button type="button" class="btn btn-outline btn-sm" (click)="reset()">Clear filters</button>
            </div>
          </div>
        } @else {
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Bid ID</th>
                  <th>Property</th>
                  <th>Your bid</th>
                  <th>Current highest</th>
                  <th>Placed</th>
                  <th>Auction</th>
                  <th>Status</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                @for (row of pageItems(); track row.bid.bidId) {
                  <tr class="clickable-row" (click)="open(row)">
                    <td class="mono">{{ row.bid.bidId }}</td>
                    <td>{{ row.listing?.property?.address ?? row.bid.appId }}</td>
                    <td class="num">{{ row.bid.bidAmount | inr }}</td>
                    <td class="num">{{ row.highestBid | inr }}</td>
                    <td>{{ row.bid.createdAt | hlmsDate: true }}</td>
                    <td>
                      @if (row.listing) {
                        <hlms-status-badge [phase]="row.listing.phase" />
                      } @else {
                        <span class="badge badge-gray">Unavailable</span>
                      }
                    </td>
                    <td><hlms-status-badge [bidStatus]="row.status" /></td>
                    <td class="right">
                      <button type="button" class="btn btn-outline btn-sm" (click)="open(row); $event.stopPropagation()">
                        View
                      </button>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>

          @if (totalPages() > 1) {
            <div class="pager">
              <button type="button" class="btn btn-outline btn-sm" [disabled]="page() === 1" (click)="prev()">Previous</button>
              <span class="small muted">Page {{ page() }} of {{ totalPages() }}</span>
              <button type="button" class="btn btn-outline btn-sm" [disabled]="page() === totalPages()" (click)="next()">Next</button>
            </div>
          }
        }
      </div>

      <div class="notice">
        Won and lost outcomes stay provisional until the bank confirms the auction result. Until then the status
        reflects the highest bid on record.
      </div>
    </hlms-state-block>
  `,
  styles: [
    `
      .pager { display: flex; align-items: center; justify-content: center; gap: 14px; padding: 14px 0 2px; }
      .mono { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 12.5px; }
    `,
  ],
})
export class MyBidsComponent implements OnInit {
  private readonly portal = inject(BidderPortalService);
  private readonly router = inject(Router);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly rows = signal<MyBidRow[]>([]);

  readonly query = signal('');
  readonly statusFilter = signal<BidStatus | 'ALL'>('ALL');
  readonly sort = signal<SortKey>('placed-desc');
  readonly page = signal(1);
  readonly pageSize = 10;

  readonly filtered = computed(() => {
    const q = this.query().trim().toLowerCase();
    const status = this.statusFilter();
    const rows = this.rows().filter((row) => {
      if (status !== 'ALL' && row.status !== status) {
        return false;
      }
      if (!q) {
        return true;
      }
      const haystack = [row.bid.bidId, row.bid.appId, row.listing?.property?.address, row.listing?.property?.reference]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
      return haystack.includes(q);
    });
    return this.applySort(rows);
  });

  readonly totalPages = computed(() => Math.max(1, Math.ceil(this.filtered().length / this.pageSize)));

  readonly pageItems = computed(() => {
    const start = (Math.min(this.page(), this.totalPages()) - 1) * this.pageSize;
    return this.filtered().slice(start, start + this.pageSize);
  });

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.error.set(null);
    this.portal.myBids().subscribe({
      next: (rows) => {
        this.rows.set(rows);
        this.loading.set(false);
      },
      error: (err: PortalError) => {
        this.error.set(err.message ?? 'Unable to load your bids.');
        this.loading.set(false);
      },
    });
  }

  open(row: MyBidRow): void {
    if (row.listing) {
      void this.router.navigate(['/bidder/auctions', row.listing.auction.auctionId]);
    }
  }

  setQuery(value: string): void {
    this.query.set(value);
    this.page.set(1);
  }

  setStatus(value: BidStatus | 'ALL'): void {
    this.statusFilter.set(value);
    this.page.set(1);
  }

  setSort(value: SortKey): void {
    this.sort.set(value);
    this.page.set(1);
  }

  reset(): void {
    this.query.set('');
    this.statusFilter.set('ALL');
    this.sort.set('placed-desc');
    this.page.set(1);
  }

  prev(): void {
    this.page.update((p) => Math.max(1, p - 1));
  }

  next(): void {
    this.page.update((p) => Math.min(this.totalPages(), p + 1));
  }

  private applySort(rows: MyBidRow[]): MyBidRow[] {
    const sorted = [...rows];
    switch (this.sort()) {
      case 'placed-asc':
        return sorted.sort((a, b) => (a.bid.createdAt ?? '').localeCompare(b.bid.createdAt ?? ''));
      case 'amount-desc':
        return sorted.sort((a, b) => b.bid.bidAmount - a.bid.bidAmount);
      case 'amount-asc':
        return sorted.sort((a, b) => a.bid.bidAmount - b.bid.bidAmount);
      default:
        return sorted.sort((a, b) => (b.bid.createdAt ?? '').localeCompare(a.bid.createdAt ?? ''));
    }
  }
}
