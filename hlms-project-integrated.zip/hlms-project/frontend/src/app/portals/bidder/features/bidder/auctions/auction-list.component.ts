import { ChangeDetectionStrategy, Component, OnInit, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuctionListing, AuctionPhase, PortalError } from '../../../core/models/hlms.models';
import { BidderPortalService } from '../../../core/services/bidder-portal.service';
import { StateBlockComponent } from '../../../shared/components/state-block.component';
import { StatusBadgeComponent } from '../../../shared/components/status-badge.component';
import { DaysLeftPipe } from '../../../shared/pipes/days-left.pipe';
import { HlmsDatePipe } from '../../../shared/pipes/hlms-date.pipe';
import { InrPipe } from '../../../shared/pipes/inr.pipe';

type SortKey = 'date-asc' | 'date-desc' | 'reserve-asc' | 'reserve-desc' | 'bids-desc';

/**
 * Auction listings.
 *
 * Search, filtering, sorting and paging all run over the array returned by
 * GET /api/auctions, because that endpoint accepts no query parameters
 * (BACKEND-GAPS.md #9). The filter state is deliberately kept in signals so
 * moving it server-side later is a change to one `load()` call, not a rewrite
 * of the screen.
 */
@Component({
  selector: 'hlms-auction-list',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule, StateBlockComponent, StatusBadgeComponent, InrPipe, HlmsDatePipe, DaysLeftPipe],
  template: `
    <div class="page-head">
      <h1>Auctions</h1>
      <p>Properties listed by the bank for e-auction after SARFAESI recovery proceedings.</p>
    </div>

    <hlms-state-block
      [loading]="loading()"
      [error]="error()"
      [empty]="listings().length === 0"
      loadingText="Loading auctions..."
      emptyText="No auctions have been listed yet. Check back once the bank publishes its next e-auction."
      (retry)="load()"
    >
      <div class="card filters">
        <div class="filter-bar">
          <div class="field">
            <label for="q">Search</label>
            <input id="q" type="search" placeholder="Address, city or reference" [ngModel]="query()" (ngModelChange)="setQuery($event)" />
          </div>
          <div class="field">
            <label for="phase">Status</label>
            <select id="phase" [ngModel]="phaseFilter()" (ngModelChange)="setPhase($event)">
              <option value="ALL">All statuses</option>
              <option value="OPEN">Open for bidding</option>
              <option value="CLOSING_TODAY">Closing today</option>
              <option value="UPCOMING">Not yet open</option>
              <option value="CLOSED">Bidding closed</option>
              <option value="CONCLUDED">Withdrawn / resolved</option>
            </select>
          </div>
          <div class="field">
            <label for="type">Property type</label>
            <select id="type" [ngModel]="typeFilter()" (ngModelChange)="setType($event)">
              <option value="ALL">All types</option>
              @for (type of propertyTypes(); track type) {
                <option [value]="type">{{ type }}</option>
              }
            </select>
          </div>
          <div class="field">
            <label for="min">Reserve from</label>
            <input id="min" type="number" min="0" step="100000" [ngModel]="minPrice()" (ngModelChange)="setMin($event)" />
          </div>
          <div class="field">
            <label for="max">Reserve to</label>
            <input id="max" type="number" min="0" step="100000" [ngModel]="maxPrice()" (ngModelChange)="setMax($event)" />
          </div>
          <div class="field">
            <label for="sort">Sort by</label>
            <select id="sort" [ngModel]="sort()" (ngModelChange)="setSort($event)">
              <option value="date-asc">Auction date, soonest</option>
              <option value="date-desc">Auction date, latest</option>
              <option value="reserve-asc">Reserve price, low to high</option>
              <option value="reserve-desc">Reserve price, high to low</option>
              <option value="bids-desc">Most bids</option>
            </select>
          </div>
        </div>
        <div class="row-between">
          <span class="small muted">
            Showing {{ pageItems().length }} of {{ filtered().length }} matching {{ listings().length }} listed auctions
          </span>
          <button type="button" class="btn btn-link small" (click)="resetFilters()">Reset filters</button>
        </div>
      </div>

      @if (filtered().length === 0) {
        <div class="card">
          <div class="empty-state">
            <div class="ic">🔍</div>
            No auctions match these filters.
            <div class="action">
              <button type="button" class="btn btn-outline btn-sm" (click)="resetFilters()">Clear filters</button>
            </div>
          </div>
        </div>
      } @else {
        <div class="grid grid-3">
          @for (listing of pageItems(); track listing.auction.auctionId) {
            <article class="product-card">
              <div class="row-between">
                <span class="tag">{{ listing.property?.type ?? 'Property' }}</span>
                <hlms-status-badge [phase]="listing.phase" />
              </div>
              <h4>{{ listing.property?.address ?? 'Property reference ' + listing.auction.appId }}</h4>
              <div class="rate">{{ listing.auction.reservePrice | inr }}</div>
              <p>Reserve price · Auction {{ listing.auction.auctionDate | hlmsDate }}</p>
              <p>
                Highest bid: {{ listing.highestBid | inr: 'No bids yet' }} · {{ listing.bidCount }}
                {{ listing.bidCount === 1 ? 'bid' : 'bids' }}
              </p>
              <p class="muted small">
                Reference {{ listing.property?.reference ?? listing.auction.appId }} ·
                {{ listing.daysLeft | daysLeft }}
              </p>
              @if (listing.myBid !== null) {
                <p class="small" [class.mine-top]="listing.iAmHighest">
                  Your bid: {{ listing.myBid | inr }}{{ listing.iAmHighest ? ' — currently highest' : '' }}
                </p>
              }
              <div class="spacer"></div>
              <button type="button" class="btn btn-teal btn-sm btn-block" (click)="open(listing)">
                {{ canBid(listing.phase) ? 'View & bid' : 'View details' }}
              </button>
            </article>
          }
        </div>

        @if (totalPages() > 1) {
          <div class="pager">
            <button type="button" class="btn btn-outline btn-sm" [disabled]="page() === 1" (click)="prev()">
              Previous
            </button>
            <span class="small muted">Page {{ page() }} of {{ totalPages() }}</span>
            <button type="button" class="btn btn-outline btn-sm" [disabled]="page() === totalPages()" (click)="next()">
              Next
            </button>
          </div>
        }
      }
    </hlms-state-block>
  `,
  styles: [
    `
      .filters { padding-bottom: 14px; }
      .pager { display: flex; align-items: center; justify-content: center; gap: 14px; padding: 6px 0 20px; }
      .mine-top { color: var(--green); font-weight: 600; }
    `,
  ],
})
export class AuctionListComponent implements OnInit {
  private readonly portal = inject(BidderPortalService);
  private readonly router = inject(Router);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly listings = signal<AuctionListing[]>([]);

  readonly query = signal('');
  readonly phaseFilter = signal<AuctionPhase | 'ALL'>('ALL');
  readonly typeFilter = signal<string>('ALL');
  readonly minPrice = signal<number | null>(null);
  readonly maxPrice = signal<number | null>(null);
  readonly sort = signal<SortKey>('date-asc');
  readonly page = signal(1);
  readonly pageSize = 9;

  readonly propertyTypes = computed(() =>
    [...new Set(this.listings().map((l) => l.property?.type).filter((t): t is string => !!t))].sort(),
  );

  readonly filtered = computed(() => {
    const q = this.query().trim().toLowerCase();
    const phase = this.phaseFilter();
    const type = this.typeFilter();
    const min = this.minPrice();
    const max = this.maxPrice();

    const rows = this.listings().filter((l) => {
      if (phase !== 'ALL' && l.phase !== phase) {
        return false;
      }
      if (type !== 'ALL' && l.property?.type !== type) {
        return false;
      }
      const reserve = l.auction.reservePrice ?? 0;
      if (min !== null && reserve < min) {
        return false;
      }
      if (max !== null && max > 0 && reserve > max) {
        return false;
      }
      if (!q) {
        return true;
      }
      const haystack = [
        l.property?.address,
        l.property?.city,
        l.property?.state,
        l.property?.reference,
        l.property?.type,
        l.auction.appId,
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
      return haystack.includes(q);
    });

    return this.applySort(rows);
  });

  readonly totalPages = computed(() => Math.max(1, Math.ceil(this.filtered().length / this.pageSize)));

  readonly pageItems = computed(() => {
    const start = (Math.min(this.page(), this.totalPages()) - 1) * this.pageSize;
    return this.filtered().slice(start, start + this.pageSize);
  });

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.error.set(null);
    this.portal.listings().subscribe({
      next: (listings) => {
        this.listings.set(listings);
        this.loading.set(false);
      },
      error: (err: PortalError) => {
        this.error.set(err.message ?? 'Unable to load auctions.');
        this.loading.set(false);
      },
    });
  }

  canBid(phase: AuctionPhase): boolean {
    return this.portal.canBid(phase);
  }

  open(listing: AuctionListing): void {
    void this.router.navigate(['/bidder/auctions', listing.auction.auctionId]);
  }

  setQuery(value: string): void {
    this.query.set(value);
    this.page.set(1);
  }

  setPhase(value: AuctionPhase | 'ALL'): void {
    this.phaseFilter.set(value);
    this.page.set(1);
  }

  setType(value: string): void {
    this.typeFilter.set(value);
    this.page.set(1);
  }

  setMin(value: number | null): void {
    this.minPrice.set(numberOrNull(value));
    this.page.set(1);
  }

  setMax(value: number | null): void {
    this.maxPrice.set(numberOrNull(value));
    this.page.set(1);
  }

  setSort(value: SortKey): void {
    this.sort.set(value);
    this.page.set(1);
  }

  resetFilters(): void {
    this.query.set('');
    this.phaseFilter.set('ALL');
    this.typeFilter.set('ALL');
    this.minPrice.set(null);
    this.maxPrice.set(null);
    this.sort.set('date-asc');
    this.page.set(1);
  }

  prev(): void {
    this.page.update((p) => Math.max(1, p - 1));
  }

  next(): void {
    this.page.update((p) => Math.min(this.totalPages(), p + 1));
  }

  private applySort(rows: AuctionListing[]): AuctionListing[] {
    const sorted = [...rows];
    switch (this.sort()) {
      case 'date-desc':
        return sorted.sort((a, b) => date(b).localeCompare(date(a)));
      case 'reserve-asc':
        return sorted.sort((a, b) => (a.auction.reservePrice ?? 0) - (b.auction.reservePrice ?? 0));
      case 'reserve-desc':
        return sorted.sort((a, b) => (b.auction.reservePrice ?? 0) - (a.auction.reservePrice ?? 0));
      case 'bids-desc':
        return sorted.sort((a, b) => b.bidCount - a.bidCount);
      default:
        return sorted.sort((a, b) => date(a).localeCompare(date(b)));
    }
  }
}

function date(listing: AuctionListing): string {
  return listing.auction.auctionDate ?? '9999-12-31';
}

function numberOrNull(value: number | null): number | null {
  return value === null || value === undefined || Number.isNaN(value) || value === 0 ? null : Number(value);
}
