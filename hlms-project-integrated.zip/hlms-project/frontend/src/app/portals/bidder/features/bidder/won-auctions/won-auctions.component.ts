import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuctionListing, PortalError } from '../../../core/models/hlms.models';
import { BidderPortalService } from '../../../core/services/bidder-portal.service';
import { StateBlockComponent } from '../../../shared/components/state-block.component';
import { HlmsDatePipe } from '../../../shared/pipes/hlms-date.pipe';
import { InrPipe } from '../../../shared/pipes/inr.pipe';

/**
 * Won auctions.
 *
 * There is no won-auctions endpoint and no winner column anywhere in the
 * schema, so this is derived: the bidding date has passed, the case was not
 * withdrawn by the bank, and the highest bid on record is this bidder's.
 *
 * Two things the backend genuinely cannot tell us yet, so the screen says so
 * rather than filling the gap with plausible-looking numbers:
 *   - whether the bank has confirmed the sale (BACKEND-GAPS.md #2)
 *   - payment status and deadlines (BACKEND-GAPS.md #10)
 */
@Component({
  selector: 'hlms-won-auctions',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, StateBlockComponent, InrPipe, HlmsDatePipe],
  template: `
    <div class="page-head">
      <h1>Won Auctions</h1>
      <p>Auctions where you hold the highest bid after bidding closed.</p>
    </div>

    <hlms-state-block
      [loading]="loading()"
      [error]="error()"
      [empty]="listings().length === 0"
      loadingText="Checking your results..."
      emptyText="You haven't won an auction yet. Results appear here once bidding closes on a property where you hold the highest bid."
      emptyIcon="🏆"
      (retry)="load()"
    >
      <a emptyAction class="btn btn-outline btn-sm" routerLink="/bidder/auctions">Browse auctions</a>

      <div class="notice warn">
        These results are provisional. The bank confirms every e-auction outcome separately and will contact you with
        payment instructions and the sale certificate process. Nothing here is a confirmation of sale.
      </div>

      <div class="grid grid-2">
        @for (listing of listings(); track listing.auction.auctionId) {
          <article class="card won">
            <div class="row-between">
              <h3>{{ listing.property?.address ?? 'Property ' + listing.auction.appId }}</h3>
              <span class="badge badge-teal">Provisional</span>
            </div>
            <table>
              <tbody>
                <tr><td>Property type</td><td class="right">{{ listing.property?.type ?? '—' }}</td></tr>
                <tr><td>Auction ID</td><td class="right">{{ listing.auction.auctionId }}</td></tr>
                <tr><td>Loan reference</td><td class="right">{{ listing.property?.reference ?? listing.auction.appId }}</td></tr>
                <tr><td>Reserve price</td><td class="right num">{{ listing.auction.reservePrice | inr }}</td></tr>
                <tr><td>Your winning bid</td><td class="right num"><strong>{{ listing.myBid | inr }}</strong></td></tr>
                <tr><td>Bidding closed</td><td class="right">{{ listing.auction.auctionDate | hlmsDate }}</td></tr>
                <tr><td>Total bids</td><td class="right">{{ listing.bidCount }}</td></tr>
                <tr>
                  <td>Payment status</td>
                  <td class="right muted small">Not tracked in HLMS yet</td>
                </tr>
              </tbody>
            </table>

            <div class="next-steps">
              <strong>What happens next</strong>
              <ol>
                <li>The bank's recovery team verifies the auction record and confirms the highest valid bid.</li>
                <li>You receive payment instructions and the deposit deadline directly from the bank.</li>
                <li>The sale certificate is issued after full payment clears.</li>
              </ol>
            </div>

            <button type="button" class="btn btn-outline btn-sm" (click)="open(listing)">View auction</button>
          </article>
        }
      </div>
    </hlms-state-block>
  `,
  styles: [
    `
      .won h3 { margin: 0; }
      .next-steps { margin-top: 14px; font-size: 13px; color: var(--text-mid); }
      .next-steps strong { display: block; color: var(--navy); margin-bottom: 6px; font-size: 13px; }
      .next-steps ol { margin: 0; padding-left: 18px; line-height: 1.6; }
      .card.won button { margin-top: 14px; }
    `,
  ],
})
export class WonAuctionsComponent implements OnInit {
  private readonly portal = inject(BidderPortalService);
  private readonly router = inject(Router);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly listings = signal<AuctionListing[]>([]);

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.error.set(null);
    this.portal.wonAuctions().subscribe({
      next: (listings) => {
        this.listings.set(listings);
        this.loading.set(false);
      },
      error: (err: PortalError) => {
        this.error.set(err.message ?? 'Unable to load your results.');
        this.loading.set(false);
      },
    });
  }

  open(listing: AuctionListing): void {
    void this.router.navigate(['/bidder/auctions', listing.auction.auctionId]);
  }
}
