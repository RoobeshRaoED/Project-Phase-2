import { ChangeDetectionStrategy, Component, OnDestroy, OnInit, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuctionListing, PortalError } from '../../../core/models/hlms.models';
import { BidderPortalService } from '../../../core/services/bidder-portal.service';
import { StateBlockComponent } from '../../../shared/components/state-block.component';
import { HlmsDatePipe } from '../../../shared/pipes/hlms-date.pipe';
import { InrPipe } from '../../../shared/pipes/inr.pipe';

/**
 * Auctions the bank has calendared but not yet opened for bidding.
 *
 * Derived from the same GET /api/auctions response: a case still at
 * 'Notice Issued' or 'Possession' stage that already carries a future
 * auction date. Once the bank moves it to 'Auction Scheduled' it leaves this
 * screen and appears under Auctions.
 *
 * The countdown ticks against midnight of the auction date, because
 * `auction_case.auction_date` is a DATE column with no time component - the
 * hours and minutes shown are time-until-that-day, not time-until-the-gavel.
 * A real start timestamp is BACKEND-GAPS.md #3.
 */
@Component({
  selector: 'hlms-upcoming-auctions',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, StateBlockComponent, InrPipe, HlmsDatePipe],
  template: `
    <div class="page-head">
      <h1>Upcoming Auctions</h1>
      <p>Properties scheduled for e-auction that are not open for bidding yet.</p>
    </div>

    <hlms-state-block
      [loading]="loading()"
      [error]="error()"
      [empty]="listings().length === 0"
      loadingText="Loading upcoming auctions..."
      emptyText="Nothing is scheduled beyond the auctions already open. New listings appear here as the bank calendars them."
      emptyIcon="⏰"
      (retry)="load()"
    >
      <a emptyAction class="btn btn-outline btn-sm" routerLink="/bidder/auctions">See open auctions</a>

      <div class="grid grid-3">
        @for (listing of listings(); track listing.auction.auctionId) {
          <article class="product-card">
            <div class="row-between">
              <span class="tag">{{ listing.property?.type ?? 'Property' }}</span>
              <span class="badge badge-teal">Not yet open</span>
            </div>
            <h4>{{ listing.property?.address ?? 'Property ' + listing.auction.appId }}</h4>
            <div class="rate">{{ listing.auction.reservePrice | inr }}</div>
            <p>Reserve price</p>
            <p>Auction date: {{ listing.auction.auctionDate | hlmsDate }}</p>
            <p class="countdown">{{ countdown(listing) }}</p>
            <p class="muted small">Reference {{ listing.property?.reference ?? listing.auction.appId }}</p>
            <div class="spacer"></div>
            <button type="button" class="btn btn-outline btn-sm btn-block" (click)="open(listing)">View details</button>
          </article>
        }
      </div>

      <div class="notice">
        Bidding opens once the bank's legal team publishes the property for e-auction. Times count down to the start of
        the scheduled auction day.
      </div>
    </hlms-state-block>
  `,
  styles: [
    `
      .countdown {
        font-variant-numeric: tabular-nums;
        font-weight: 700;
        color: var(--teal);
        font-size: 13.5px;
      }
    `,
  ],
})
export class UpcomingAuctionsComponent implements OnInit, OnDestroy {
  private readonly portal = inject(BidderPortalService);
  private readonly router = inject(Router);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly listings = signal<AuctionListing[]>([]);

  /** Drives the countdown re-render once a minute. */
  private readonly tick = signal(Date.now());
  private timer: ReturnType<typeof setInterval> | null = null;

  ngOnInit(): void {
    this.load();
    this.timer = setInterval(() => this.tick.set(Date.now()), 60_000);
  }

  ngOnDestroy(): void {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  load(): void {
    this.loading.set(true);
    this.error.set(null);
    this.portal.upcomingAuctions().subscribe({
      next: (listings) => {
        this.listings.set(listings);
        this.loading.set(false);
      },
      error: (err: PortalError) => {
        this.error.set(err.message ?? 'Unable to load upcoming auctions.');
        this.loading.set(false);
      },
    });
  }

  countdown(listing: AuctionListing): string {
    const now = this.tick();
    if (!listing.auction.auctionDate) {
      return 'Date to be announced';
    }
    const target = new Date(listing.auction.auctionDate).setHours(0, 0, 0, 0);
    const diff = target - now;
    if (diff <= 0) {
      return 'Opening today';
    }
    const days = Math.floor(diff / 86_400_000);
    const hours = Math.floor((diff % 86_400_000) / 3_600_000);
    const minutes = Math.floor((diff % 3_600_000) / 60_000);
    if (days > 0) {
      return `Opens in ${days}d ${hours}h`;
    }
    return `Opens in ${hours}h ${minutes}m`;
  }

  open(listing: AuctionListing): void {
    void this.router.navigate(['/bidder/auctions', listing.auction.auctionId]);
  }
}
