import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { signal } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { environment } from '../../../environments/environment';
import { BIDDER_AUTH, BidderAuthPort, BidderSession } from '../../../core/auth/bidder-auth.port';
import { AuctionDetailComponent } from './auction-detail.component';

class FakeAuth implements BidderAuthPort {
  readonly session = signal<BidderSession | null>({ email: 'arjun@example.com', role: 'BIDDER', name: 'Arjun Mehta' });
  token(): string | null {
    return 'token';
  }
  isAuthenticated(): boolean {
    return true;
  }
  isBidder(): boolean {
    return true;
  }
  signOut(): void {}
}

const gw = environment.apiBaseUrl;
const AUCTION_URL = `${gw}/repayment-service/api/auctions/1`;
const APP_URL = `${gw}/loan-service/api/loan-applications/APP-001`;
const BIDS_URL = `${gw}/repayment-service/api/auctions/APP-001/bids`;
const NOTES_URL = `${gw}/repayment-service/api/auctions/APP-001/notes`;

function futureDate(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

describe('AuctionDetailComponent', () => {
  let fixture: ComponentFixture<AuctionDetailComponent>;
  let component: AuctionDetailComponent;
  let backend: HttpTestingController;

  /** Answers the four calls the screen makes on load. */
  function settleLoad(options: { highest?: number; mine?: number; auctionDate?: string } = {}): void {
    const auctionDate = options.auctionDate ?? futureDate(5);
    backend.expectOne(AUCTION_URL).flush({
      auctionId: 1,
      appId: 'APP-001',
      stage: 'Auction Scheduled',
      noticeDate: '2026-01-01',
      noticeDueDate: '2026-03-01',
      demandAmount: 4_000_000,
      possessionDate: '2026-04-01',
      auctionDate,
      reservePrice: 2_500_000,
    });

    const bids = [];
    if (options.highest) {
      bids.push({ bidId: 'B-OTHER', appId: 'APP-001', bidderEmail: 'priya@example.com', bidAmount: options.highest, createdAt: '2026-08-01T10:00:00Z' });
    }
    if (options.mine) {
      bids.push({ bidId: 'B-MINE', appId: 'APP-001', bidderEmail: 'arjun@example.com', bidAmount: options.mine, createdAt: '2026-08-02T10:00:00Z' });
    }

    backend.expectOne(BIDS_URL).flush(bids);
    backend.expectOne(APP_URL).flush({
      appId: 'APP-001',
      trackingNo: 'HL-2026-0007',
      propertyAddress: '12 Rose Villa, Anna Nagar',
      propertyType: 'Independent House',
      propertyValue: 5_000_000,
      addrCity: 'Chennai',
      addrState: 'Tamil Nadu',
      addrPincode: '600040',
    });
    backend.expectOne(BIDS_URL).flush(bids); // history load
    backend.expectOne(NOTES_URL).flush([]);
    fixture.detectChanges();
  }

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [AuctionDetailComponent],
      providers: [
        provideRouter([]),
        provideHttpClient(),
        provideHttpClientTesting(),
        { provide: BIDDER_AUTH, useClass: FakeAuth },
      ],
    });
    fixture = TestBed.createComponent(AuctionDetailComponent);
    component = fixture.componentInstance;
    fixture.componentRef.setInput('auctionId', '1');
    backend = TestBed.inject(HttpTestingController);
    fixture.detectChanges();
  });

  afterEach(() => backend.verify({ ignoreCancelled: true }));

  it('loads the auction and pre-fills a suggested bid above the current highest', () => {
    settleLoad({ highest: 2_600_000 });
    expect(component.listing()?.highestBid).toBe(2_600_000);
    expect(component.form.controls.amount.value).toBe(2_600_000 + environment.bidIncrement);
  });

  it('starts at the reserve price when there are no bids yet', () => {
    settleLoad();
    expect(component.listing()?.minimumNextBid).toBe(2_500_000);
    expect(component.form.controls.amount.value).toBe(2_500_000);
  });

  it('refuses to open the confirmation for a bid below the minimum', () => {
    settleLoad({ highest: 2_600_000 });
    component.form.controls.amount.setValue(2_000_000);
    component.review();
    expect(component.confirming()).toBeFalse();
    expect(component.showAmountError()).toBeTrue();
    backend.expectNone(BIDS_URL);
  });

  it('asks for confirmation before sending a valid bid', () => {
    settleLoad({ highest: 2_600_000 });
    component.form.controls.amount.setValue(2_700_000);
    component.review();
    expect(component.confirming()).toBeTrue();
    backend.expectNone(BIDS_URL); // nothing sent until the user confirms
  });

  it('posts the bid and reloads from the backend on success', () => {
    settleLoad({ highest: 2_600_000 });
    component.form.controls.amount.setValue(2_700_000);
    component.review();
    component.submit();

    const post = backend.expectOne((r) => r.method === 'POST' && r.url === BIDS_URL);
    expect(post.request.body).toEqual({ appId: 'APP-001', bidderEmail: 'arjun@example.com', bidAmount: 2_700_000 });
    post.flush(
      { bidId: 'BID-NEW', appId: 'APP-001', bidderEmail: 'arjun@example.com', bidAmount: 2_700_000, createdAt: '2026-08-09T09:00:00Z' },
      { status: 201, statusText: 'Created' },
    );

    expect(component.submitting()).toBeFalse();
    expect(component.confirming()).toBeFalse();
    // the screen re-reads the auction rather than patching its own copy
    backend.expectOne(AUCTION_URL).flush({
      auctionId: 1, appId: 'APP-001', stage: 'Auction Scheduled', noticeDate: '2026-01-01', noticeDueDate: '2026-03-01',
      demandAmount: 4_000_000, possessionDate: '2026-04-01', auctionDate: futureDate(5), reservePrice: 2_500_000,
    });
    backend.expectOne(BIDS_URL).flush([]);
    backend.expectOne(APP_URL).flush({ appId: 'APP-001', trackingNo: 'x', propertyAddress: 'a', propertyType: 'Flat', propertyValue: 1, addrCity: 'c', addrState: 's', addrPincode: '1' });
    backend.expectOne(BIDS_URL).flush([]);
    backend.expectOne(NOTES_URL).flush([]);
  });

  it('ignores a second submit while one is in flight', () => {
    settleLoad({ highest: 2_600_000 });
    component.form.controls.amount.setValue(2_700_000);
    component.review();
    component.submit();
    component.submit(); // double tap
    backend.expectOne((r) => r.method === 'POST' && r.url === BIDS_URL).flush(
      { bidId: 'BID-NEW', appId: 'APP-001', bidderEmail: 'arjun@example.com', bidAmount: 2_700_000, createdAt: '' },
      { status: 201, statusText: 'Created' },
    );
    backend.expectOne(AUCTION_URL).flush({}, { status: 500, statusText: 'Server Error' });
  });

  it('shows the backend reason when a competing bid landed first', () => {
    settleLoad({ highest: 2_600_000 });
    component.form.controls.amount.setValue(2_700_000);
    component.review();
    component.submit();

    backend.expectOne((r) => r.method === 'POST' && r.url === BIDS_URL).flush(
      { status: 400, message: 'bidAmount must be higher than the current highest bid of 2800000.', timestamp: '' },
      { status: 400, statusText: 'Bad Request' },
    );

    expect(component.bidError()).toContain('higher than the current highest bid');
    expect(component.confirming()).toBeFalse();
    // a 400 means our view of the auction was stale, so it re-syncs
    backend.expectOne(AUCTION_URL).flush({}, { status: 500, statusText: 'Server Error' });
  });

  it('closes bidding once the auction date has passed', () => {
    settleLoad({ auctionDate: futureDate(-1) });
    expect(component.portal.canBid(component.listing()!.phase)).toBeFalse();
  });

  it('shows an error state when the auction cannot be loaded', () => {
    backend.expectOne(AUCTION_URL).flush({ status: 404, message: 'No auction case found with id 1.', timestamp: '' }, { status: 404, statusText: 'Not Found' });
    fixture.detectChanges();
    expect(component.error()).toContain('No auction case found');
  });

  it('never renders another bidder\'s email', () => {
    settleLoad({ highest: 2_600_000, mine: 2_500_000 });
    const others = component.bids().filter((b) => !component.isMine(b));
    others.forEach((b) => expect(component.maskBidder(b)).not.toContain('@'));
    expect(component.maskBidder(component.bids().find((b) => component.isMine(b))!)).toBe('You');
  });
});
