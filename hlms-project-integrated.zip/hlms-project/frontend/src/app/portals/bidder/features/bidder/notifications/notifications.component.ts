import { ChangeDetectionStrategy, Component, OnInit, computed, inject, signal } from '@angular/core';
import { BIDDER_AUTH } from '../../../core/auth/bidder-auth.port';
import { NotificationDto, PortalError } from '../../../core/models/hlms.models';
import { NotificationService, isRead } from '../../../core/services/notification.service';
import { ToastService } from '../../../core/services/toast.service';
import { StateBlockComponent } from '../../../shared/components/state-block.component';
import { HlmsDatePipe } from '../../../shared/pipes/hlms-date.pipe';

/**
 * Notifications from notification-service.
 *
 * Read-only plus mark-as-read: outbid alerts, auction results and payment
 * reminders are written by the services that own those events, never by this
 * portal. "Mark all as read" fans out one PATCH per unread item because there
 * is no bulk endpoint (BACKEND-GAPS.md #7).
 */
@Component({
  selector: 'hlms-notifications',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [StateBlockComponent, HlmsDatePipe],
  template: `
    <div class="page-head">
      <div class="row-between">
        <div>
          <h1>Notifications</h1>
          <p>Auction alerts and updates from the bank.</p>
        </div>
        @if (unreadIds().length > 0) {
          <button type="button" class="btn btn-outline btn-sm" [disabled]="marking()" (click)="markAll()">
            {{ marking() ? 'Marking...' : 'Mark all as read (' + unreadIds().length + ')' }}
          </button>
        }
      </div>
    </div>

    <hlms-state-block
      [loading]="loading()"
      [error]="error()"
      [empty]="items().length === 0"
      loadingText="Loading notifications..."
      emptyText="No notifications yet. You'll be alerted here when you're outbid, when an auction closes, and when results are announced."
      emptyIcon="🔔"
      (retry)="load()"
    >
      <div class="tabs">
        <button type="button" class="tab" [class.active]="filter() === 'all'" (click)="filter.set('all')">
          All ({{ items().length }})
        </button>
        <button type="button" class="tab" [class.active]="filter() === 'unread'" (click)="filter.set('unread')">
          Unread ({{ unreadIds().length }})
        </button>
      </div>

      @if (visible().length === 0) {
        <div class="card">
          <div class="empty-state"><div class="ic">✅</div>You're all caught up.</div>
        </div>
      } @else {
        <div class="card list">
          @for (item of visible(); track item.notificationId) {
            <article class="item" [class.unread]="!read(item)">
              <div class="dot" aria-hidden="true"></div>
              <div class="body">
                <div class="row-between">
                  <strong>{{ item.title }}</strong>
                  <span class="small muted">{{ item.createdAt | hlmsDate: true }}</span>
                </div>
                @if (item.body) {
                  <p>{{ item.body }}</p>
                }
                <div class="meta">
                  <span class="small muted">Sent via {{ item.channels.join(', ') }}</span>
                  @if (!read(item)) {
                    <button type="button" class="btn btn-link small" (click)="markOne(item)">Mark as read</button>
                  }
                </div>
              </div>
            </article>
          }
        </div>
      }
    </hlms-state-block>
  `,
  styles: [
    `
      .list { padding: 0; }
      .item { display: flex; gap: 12px; padding: 16px 20px; border-bottom: 1px solid var(--border); }
      .item:last-child { border-bottom: none; }
      .item .dot { width: 8px; height: 8px; border-radius: 50%; background: transparent; margin-top: 6px; flex: none; }
      .item.unread { background: #fbfdfd; }
      .item.unread .dot { background: var(--teal); }
      .item strong { font-size: 13.5px; color: var(--navy); }
      .item p { margin: 6px 0 0; font-size: 13px; color: var(--text-mid); line-height: 1.5; }
      .body { flex: 1; min-width: 0; }
      .meta { display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-top: 8px; }
    `,
  ],
})
export class NotificationsComponent implements OnInit {
  private readonly notifications = inject(NotificationService);
  private readonly auth = inject(BIDDER_AUTH);
  private readonly toasts = inject(ToastService);

  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly items = signal<NotificationDto[]>([]);
  readonly filter = signal<'all' | 'unread'>('all');
  readonly marking = signal(false);

  readonly unreadIds = computed(() => this.items().filter((n) => !isRead(n)).map((n) => n.notificationId));

  readonly visible = computed(() =>
    this.filter() === 'unread' ? this.items().filter((n) => !isRead(n)) : this.items(),
  );

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    const email = this.auth.session()?.email;
    if (!email) {
      this.error.set('No signed-in bidder.');
      this.loading.set(false);
      return;
    }
    this.loading.set(true);
    this.error.set(null);
    this.notifications.list(email).subscribe({
      next: (items) => {
        this.items.set(items);
        this.loading.set(false);
      },
      error: (err: PortalError) => {
        this.error.set(err.message ?? 'Unable to load notifications.');
        this.loading.set(false);
      },
    });
  }

  read(item: NotificationDto): boolean {
    return isRead(item);
  }

  markOne(item: NotificationDto): void {
    this.notifications.markRead(item.notificationId).subscribe({
      next: () => this.patchLocal([item.notificationId]),
      error: (err: PortalError) => this.toasts.error('Could not mark as read', err.message),
    });
  }

  markAll(): void {
    const ids = this.unreadIds();
    if (ids.length === 0) {
      return;
    }
    this.marking.set(true);
    this.notifications.markAllRead(ids).subscribe({
      next: () => {
        this.patchLocal(ids);
        this.marking.set(false);
      },
      error: (err: PortalError) => {
        this.marking.set(false);
        this.toasts.error('Could not mark everything as read', err.message);
        this.load(); // some may have succeeded - re-sync rather than guess
      },
    });
  }

  private patchLocal(ids: string[]): void {
    const set = new Set(ids);
    this.items.update((items) =>
      items.map((n) => (set.has(n.notificationId) ? { ...n, read: true, isRead: true } : n)),
    );
  }
}
