/**
 * Production / default environment.
 *
 * Every backend call in this module goes through the HLMS Spring Cloud
 * API gateway. The gateway routes by service-name prefix and strips that
 * prefix before forwarding (StripPrefix=1), which is why each service has
 * its own prefix constant below instead of one flat base URL.
 */
export const environment = {
  production: true,
  /** API gateway origin. Override per deployment. */
  apiBaseUrl: '/api-gateway',
  services: {
    user: '/user-service',
    loan: '/loan-service',
    repayment: '/repayment-service',
    notification: '/notification-service',
  },
  auth: {
    /**
     * Where the host HLMS shell stores the JWT issued by
     * user-service POST /api/users/login. This module only READS it.
     * If your shell exposes an AuthService instead, provide it against
     * the BIDDER_AUTH token in app.config.ts and this key is ignored.
     */
    tokenStorageKey: 'hlms.token',
    storage: 'session' as 'session' | 'local',
    /** Where to send the user when there is no valid session. */
    loginUrl: '/login',
  },
  /**
   * Minimum bid increment above the current highest bid, in rupees.
   * Front-end guidance only - the backend is the authority and rejects
   * anything not strictly above the current highest bid.
   */
  bidIncrement: 5000,
};
