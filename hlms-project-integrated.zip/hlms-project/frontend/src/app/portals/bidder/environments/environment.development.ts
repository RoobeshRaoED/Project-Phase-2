export const environment = {
  production: false,
  /** Local API gateway (api-gateway/src/main/resources/application.properties -> server.port=8080). */
  apiBaseUrl: 'http://localhost:8080',
  services: {
    user: '/user-service',
    loan: '/loan-service',
    repayment: '/repayment-service',
    notification: '/notification-service',
  },
  auth: {
    tokenStorageKey: 'hlms.token',
    storage: 'session' as 'session' | 'local',
    loginUrl: '/login',
  },
  bidIncrement: 5000,
};
