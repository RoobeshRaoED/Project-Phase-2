import { ChangeDetectionStrategy, Component, OnInit, computed, inject, signal } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { BIDDER_AUTH } from '../../core/auth/bidder-auth.port';
import { NotificationService } from '../../core/services/notification.service';

interface NavItem {
  path: string;
  icon: string;
  label: string;
  badge?: boolean;
}

/**
 * The frame every bidder screen sits in.
 *
 * Only bidder destinations appear here - no customer, admin, bank officer or
 * legal navigation exists in this application at all, so there is nothing to
 * hide at runtime. Below 900px the sidebar becomes an off-canvas drawer with
 * the same links rather than a cut-down menu.
 */
@Component({
  selector: 'hlms-bidder-shell',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <div class="shell" [class.drawer-open]="drawerOpen()">
      <aside class="sidebar" [attr.aria-hidden]="!drawerOpen() && isNarrow() ? 'true' : null">
        <div class="brand">
          <span class="mark">HLMS</span>
          <span class="sub">Bidder Portal</span>
        </div>
        <nav aria-label="Bidder navigation">
          @for (item of nav; track item.path) {
            <a
              class="nav-item"
              [routerLink]="item.path"
              routerLinkActive="active"
              [routerLinkActiveOptions]="{ exact: false }"
              (click)="closeDrawer()"
            >
              <span class="ic" aria-hidden="true">{{ item.icon }}</span>
              <span class="label">{{ item.label }}</span>
              @if (item.badge && unread() > 0) {
                <span class="count">{{ unread() }}</span>
              }
            </a>
          }
        </nav>
        <button type="button" class="nav-item signout" (click)="signOut()">
          <span class="ic" aria-hidden="true">🚪</span>
          <span class="label">Sign out</span>
        </button>
      </aside>

      @if (drawerOpen()) {
        <div class="scrim" (click)="closeDrawer()"></div>
      }

      <div class="main">
        <header class="topbar">
          <button type="button" class="burger" (click)="toggleDrawer()" aria-label="Toggle navigation">☰</button>
          <span class="topbar-title">HLMS Bidder Portal</span>
          <div class="spacer"></div>
          <a class="bell" routerLink="/bidder/notifications" [attr.aria-label]="bellLabel()">
            🔔
            @if (unread() > 0) {
              <span class="dot">{{ unread() }}</span>
            }
          </a>
          <a class="who" routerLink="/bidder/profile">
            <span class="avatar" aria-hidden="true">{{ initial() }}</span>
            <span class="who-text">{{ displayName() }}</span>
          </a>
        </header>

        <main class="content">
          <router-outlet />
        </main>
      </div>
    </div>
  `,
  styles: [
    `
      .shell { min-height: 100vh; }

      .sidebar {
        position: fixed;
        inset: 0 auto 0 0;
        width: var(--sidebar-w);
        background: var(--navy);
        color: #fff;
        display: flex;
        flex-direction: column;
        padding: 18px 12px;
        z-index: 40;
      }
      .brand { padding: 6px 12px 20px; }
      .brand .mark { display: block; font-size: 20px; font-weight: 800; letter-spacing: .06em; }
      .brand .sub { display: block; font-size: 11.5px; color: #9db4cc; margin-top: 2px; letter-spacing: .04em; }

      nav { display: flex; flex-direction: column; gap: 2px; flex: 1; }
      .nav-item {
        display: flex; align-items: center; gap: 11px;
        padding: 10px 12px; border-radius: 8px;
        color: #c8d6e5; font-size: 13.5px; font-weight: 600;
        background: none; border: none; text-align: left; width: 100%;
        text-decoration: none;
      }
      .nav-item:hover { background: var(--navy-light); color: #fff; text-decoration: none; }
      .nav-item.active { background: var(--teal); color: #fff; }
      .nav-item .ic { width: 18px; text-align: center; }
      .nav-item .count {
        margin-left: auto; background: var(--orange); color: #fff;
        font-size: 11px; font-weight: 700; padding: 1px 7px; border-radius: 999px;
      }
      .signout { margin-top: 8px; border-top: 1px solid rgba(255, 255, 255, .12); padding-top: 14px; border-radius: 0; }

      .main { margin-left: var(--sidebar-w); min-height: 100vh; display: flex; flex-direction: column; }

      .topbar {
        height: var(--topbar-h);
        background: #fff;
        border-bottom: 1px solid var(--border);
        display: flex; align-items: center; gap: 12px;
        padding: 0 20px;
        position: sticky; top: 0; z-index: 30;
      }
      .burger { display: none; background: none; border: none; font-size: 20px; color: var(--navy); }
      .topbar-title { font-weight: 700; color: var(--navy); font-size: 14.5px; }
      .spacer { flex: 1; }
      .bell { position: relative; font-size: 17px; text-decoration: none; }
      .bell .dot {
        position: absolute; top: -6px; right: -9px;
        background: var(--red); color: #fff; font-size: 10px; font-weight: 700;
        border-radius: 999px; padding: 1px 5px;
      }
      .who { display: flex; align-items: center; gap: 9px; text-decoration: none; }
      .avatar {
        width: 30px; height: 30px; border-radius: 50%;
        background: var(--teal-light); color: var(--teal);
        display: inline-flex; align-items: center; justify-content: center;
        font-weight: 700; font-size: 13px;
      }
      .who-text { font-size: 13px; font-weight: 600; color: var(--text-mid); }

      .content { padding: 22px; flex: 1; max-width: 1280px; width: 100%; }

      .scrim { position: fixed; inset: 0; background: rgba(19, 42, 68, .45); z-index: 35; }

      @media (max-width: 900px) {
        .sidebar { transform: translateX(-100%); transition: transform .2s ease; }
        .drawer-open .sidebar { transform: translateX(0); }
        .main { margin-left: 0; }
        .burger { display: block; }
        .who-text { display: none; }
        .content { padding: 16px; }
      }
    `,
  ],
})
export class BidderShellComponent implements OnInit {
  private readonly auth = inject(BIDDER_AUTH);
  private readonly notifications = inject(NotificationService);

  readonly nav: NavItem[] = [
    { path: '/bidder/dashboard', icon: '🏠', label: 'Dashboard' },
    { path: '/bidder/auctions', icon: '🔨', label: 'Auctions' },
    { path: '/bidder/my-bids', icon: '📋', label: 'My Bids' },
    { path: '/bidder/won-auctions', icon: '🏆', label: 'Won Auctions' },
    { path: '/bidder/upcoming-auctions', icon: '⏰', label: 'Upcoming Auctions' },
    { path: '/bidder/notifications', icon: '🔔', label: 'Notifications', badge: true },
    { path: '/bidder/profile', icon: '👤', label: 'Profile' },
    { path: '/bidder/settings', icon: '⚙️', label: 'Settings' },
  ];

  readonly drawerOpen = signal(false);
  readonly unread = this.notifications.unreadCount;

  readonly displayName = computed(() => {
    const session = this.auth.session();
    return session?.name?.split(' ')[0] ?? session?.email?.split('@')[0] ?? 'Bidder';
  });

  readonly initial = computed(() => this.displayName().charAt(0).toUpperCase());
  readonly bellLabel = computed(() =>
    this.unread() > 0 ? `Notifications, ${this.unread()} unread` : 'Notifications',
  );

  ngOnInit(): void {
    const email = this.auth.session()?.email;
    if (email) {
      this.notifications.refreshUnreadCount(email);
    }
  }

  isNarrow(): boolean {
    return typeof window !== 'undefined' && window.innerWidth <= 900;
  }

  toggleDrawer(): void {
    this.drawerOpen.update((open) => !open);
  }

  closeDrawer(): void {
    this.drawerOpen.set(false);
  }

  signOut(): void {
    this.auth.signOut('user');
  }
}
