import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { ToastService } from '../../core/services/toast.service';

/** Renders transient confirmations once, at app level. */
@Component({
  selector: 'hlms-toast-host',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="host" aria-live="polite">
      @for (toast of toasts.toasts(); track toast.id) {
        <div class="toast {{ toast.tone }}" (click)="toasts.dismiss(toast.id)">
          <strong>{{ toast.title }}</strong>
          @if (toast.body) {
            <span>{{ toast.body }}</span>
          }
        </div>
      }
    </div>
  `,
  styles: [
    `
      .host {
        position: fixed;
        right: 18px;
        bottom: 18px;
        display: flex;
        flex-direction: column;
        gap: 10px;
        z-index: 60;
        max-width: min(360px, calc(100vw - 36px));
      }
      .toast {
        background: #fff;
        border-left: 4px solid var(--teal);
        border-radius: 10px;
        box-shadow: 0 10px 30px rgba(19, 42, 68, 0.18);
        padding: 12px 14px;
        cursor: pointer;
        display: flex;
        flex-direction: column;
        gap: 3px;
      }
      .toast strong { font-size: 13.5px; color: var(--navy); }
      .toast span { font-size: 12.5px; color: var(--text-mid); }
      .toast.ok { border-left-color: var(--green); }
      .toast.err { border-left-color: var(--red); }
    `,
  ],
})
export class ToastHostComponent {
  readonly toasts = inject(ToastService);
}
