import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';

/**
 * Blocking confirmation for irreversible actions - currently just placing a
 * bid, which is a binding offer under the bank's e-auction terms.
 */
@Component({
  selector: 'hlms-confirm-dialog',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (open()) {
      <div class="backdrop" (click)="cancel.emit()">
        <div class="panel" role="dialog" aria-modal="true" [attr.aria-label]="title()" (click)="$event.stopPropagation()">
          <h3>{{ title() }}</h3>
          <p>{{ message() }}</p>
          <ng-content></ng-content>
          <div class="actions">
            <button type="button" class="btn btn-outline btn-sm" (click)="cancel.emit()" [disabled]="busy()">
              {{ cancelLabel() }}
            </button>
            <button type="button" class="btn btn-primary btn-sm" (click)="confirm.emit()" [disabled]="busy()">
              {{ busy() ? 'Working...' : confirmLabel() }}
            </button>
          </div>
        </div>
      </div>
    }
  `,
  styles: [
    `
      .backdrop {
        position: fixed;
        inset: 0;
        background: rgba(19, 42, 68, 0.45);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        z-index: 50;
      }
      .panel {
        background: #fff;
        border-radius: 12px;
        padding: 22px;
        width: min(440px, 100%);
        box-shadow: 0 18px 48px rgba(19, 42, 68, 0.25);
      }
      h3 { margin: 0 0 10px; font-size: 16px; color: var(--navy); }
      p { margin: 0 0 16px; font-size: 13.5px; color: var(--text-mid); line-height: 1.5; }
      .actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 18px; }
    `,
  ],
})
export class ConfirmDialogComponent {
  readonly open = input(false);
  readonly title = input('Are you sure?');
  readonly message = input('');
  readonly confirmLabel = input('Confirm');
  readonly cancelLabel = input('Cancel');
  readonly busy = input(false);
  readonly confirm = output<void>();
  readonly cancel = output<void>();
}
