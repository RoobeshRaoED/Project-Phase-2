import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';
import { AuctionPhase, BidStatus } from '../../core/models/hlms.models';

/** One badge vocabulary for auction phase and bid status, so colours never drift apart. */
@Component({
  selector: 'hlms-status-badge',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `<span class="badge {{ tone() }}">{{ label() }}</span>`,
})
export class StatusBadgeComponent {
  readonly phase = input<AuctionPhase | null>(null);
  readonly bidStatus = input<BidStatus | null>(null);

  readonly label = computed(() => {
    const phase = this.phase();
    if (phase) {
      return PHASE_LABEL[phase];
    }
    const status = this.bidStatus();
    return status ? BID_LABEL[status] : '';
  });

  readonly tone = computed(() => {
    const phase = this.phase();
    if (phase) {
      return PHASE_TONE[phase];
    }
    const status = this.bidStatus();
    return status ? BID_TONE[status] : 'badge-gray';
  });
}

const PHASE_LABEL: Record<AuctionPhase, string> = {
  OPEN: 'Open for bidding',
  CLOSING_TODAY: 'Closing today',
  UPCOMING: 'Not yet open',
  CLOSED: 'Bidding closed',
  CONCLUDED: 'Withdrawn / resolved',
  NOT_LISTED: 'Not listed',
};

const PHASE_TONE: Record<AuctionPhase, string> = {
  OPEN: 'badge-green',
  CLOSING_TODAY: 'badge-orange',
  UPCOMING: 'badge-teal',
  CLOSED: 'badge-gray',
  CONCLUDED: 'badge-purple',
  NOT_LISTED: 'badge-gray',
};

const BID_LABEL: Record<BidStatus, string> = {
  WINNING: 'Winning',
  OUTBID: 'Outbid',
  WON_PROVISIONAL: 'Won (provisional)',
  LOST: 'Lost',
  CLOSED: 'Closed',
};

const BID_TONE: Record<BidStatus, string> = {
  WINNING: 'badge-green',
  OUTBID: 'badge-orange',
  WON_PROVISIONAL: 'badge-teal',
  LOST: 'badge-red',
  CLOSED: 'badge-gray',
};
