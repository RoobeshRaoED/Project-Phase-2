import { Routes } from '@angular/router';
import { bidderGuard } from './core/guards/bidder.guard';

/**
 * A bidder signing in lands on /bidder/dashboard and never leaves the /bidder
 * tree. There are no customer, admin, bank officer or legal routes in this
 * application, so there is nothing for a bidder to be redirected into by
 * accident.
 */
export const BIDDER_ROUTES_ROOT: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'bidder/dashboard' },
  {
    path: 'bidder',
    canActivate: [bidderGuard],
    canActivateChild: [bidderGuard],
    loadChildren: () => import('./features/bidder/bidder.routes').then((m) => m.BIDDER_ROUTES),
  },
  {
    path: 'unauthorized',
    title: 'Access denied · HLMS',
    loadComponent: () => import('./pages/unauthorized.component').then((m) => m.UnauthorizedComponent),
  },
  { path: '**', redirectTo: 'bidder/dashboard' },
];
