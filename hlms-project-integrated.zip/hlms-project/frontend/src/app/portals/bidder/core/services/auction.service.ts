import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, catchError, map } from 'rxjs';
import { AuctionCaseDto, AuctionNoteDto } from '../models/hlms.models';
import { API } from './api-urls';
import { rethrowAsPortalError } from './error-mapper';

/**
 * repayment-service AuctionCaseController.
 *
 * The controller exposes no filtering, sorting or pagination - GET /api/auctions
 * returns every non-deleted auction case in one array (see AuctionCaseServiceImpl
 * .findAll). Search, filters and paging on the listing screens therefore run
 * client-side over that array. That is fine at the current data volume and is
 * flagged in BACKEND-GAPS.md #9 as the thing to move server-side first.
 */
@Injectable({ providedIn: 'root' })
export class AuctionService {
  private readonly http = inject(HttpClient);

  /** GET /repayment-service/api/auctions */
  list(): Observable<AuctionCaseDto[]> {
    return this.http.get<AuctionCaseDto[]>(API.auctions.list()).pipe(catchError(rethrowAsPortalError));
  }

  /** GET /repayment-service/api/auctions/{auctionId} - 404 becomes a PortalError. */
  byId(auctionId: number): Observable<AuctionCaseDto> {
    return this.http.get<AuctionCaseDto>(API.auctions.byId(auctionId)).pipe(catchError(rethrowAsPortalError));
  }

  /** GET /repayment-service/api/auctions/by-application/{appId} */
  byApplication(appId: string): Observable<AuctionCaseDto> {
    return this.http.get<AuctionCaseDto>(API.auctions.byApplication(appId)).pipe(catchError(rethrowAsPortalError));
  }

  /**
   * GET /repayment-service/api/auctions/{appId}/notes
   *
   * Public auction remarks recorded by the legal team. Read-only for bidders;
   * this module never POSTs a note.
   */
  notes(appId: string): Observable<AuctionNoteDto[]> {
    return this.http.get<AuctionNoteDto[]>(API.auctions.notes(appId)).pipe(
      map((notes) => [...notes].sort((a, b) => (b.noteDate ?? '').localeCompare(a.noteDate ?? ''))),
      catchError(rethrowAsPortalError),
    );
  }
}
