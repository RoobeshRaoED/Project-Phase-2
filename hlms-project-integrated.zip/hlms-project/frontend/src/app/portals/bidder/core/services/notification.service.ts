import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject, signal } from '@angular/core';
import { Observable, catchError, forkJoin, map, of, tap } from 'rxjs';
import { NotificationDto } from '../models/hlms.models';
import { API } from './api-urls';
import { rethrowAsPortalError } from './error-mapper';

/** Reads the flag whichever way Jackson spelled it (getter `isRead()` -> `read`). */
export function isRead(n: NotificationDto): boolean {
  return n.read ?? n.isRead ?? false;
}

/**
 * notification-service NotificationController.
 *
 * Notifications are written by other HLMS services (outbid alerts, auction
 * results, payment reminders). This portal only reads them and marks them
 * read - it never POSTs one, since a bidder generating their own notifications
 * would be meaningless.
 */
@Injectable({ providedIn: 'root' })
export class NotificationService {
  private readonly http = inject(HttpClient);

  /** Unread count for the sidebar badge. Kept here so every screen shares one value. */
  readonly unreadCount = signal(0);

  /** GET /notification-service/api/notifications?userEmail=... */
  list(userEmail: string): Observable<NotificationDto[]> {
    return this.http
      .get<NotificationDto[]>(API.notifications.forUser(), { params: new HttpParams().set('userEmail', userEmail) })
      .pipe(
        map((items) => [...items].sort((a, b) => (b.createdAt ?? '').localeCompare(a.createdAt ?? ''))),
        tap((items) => this.unreadCount.set(items.filter((n) => !isRead(n)).length)),
        catchError(rethrowAsPortalError),
      );
  }

  /** GET /notification-service/api/notifications/unread?userEmail=... */
  unread(userEmail: string): Observable<NotificationDto[]> {
    return this.http
      .get<NotificationDto[]>(API.notifications.unread(), { params: new HttpParams().set('userEmail', userEmail) })
      .pipe(
        tap((items) => this.unreadCount.set(items.length)),
        catchError(rethrowAsPortalError),
      );
  }

  /** Best-effort refresh of the badge; a failure here must not break a screen. */
  refreshUnreadCount(userEmail: string): void {
    this.unread(userEmail)
      .pipe(catchError(() => of([])))
      .subscribe();
  }

  /** PATCH /notification-service/api/notifications/{id}/read */
  markRead(notificationId: string): Observable<NotificationDto> {
    return this.http.patch<NotificationDto>(API.notifications.markRead(notificationId), {}).pipe(
      tap(() => this.unreadCount.update((n) => Math.max(0, n - 1))),
      catchError(rethrowAsPortalError),
    );
  }

  /**
   * "Mark all as read" - there is no bulk endpoint, so this fans out one PATCH
   * per unread notification (BACKEND-GAPS.md #7).
   */
  markAllRead(notificationIds: string[]): Observable<unknown> {
    if (notificationIds.length === 0) {
      return of([]);
    }
    return forkJoin(
      notificationIds.map((id) => this.http.patch<NotificationDto>(API.notifications.markRead(id), {})),
    ).pipe(
      tap(() => this.unreadCount.set(0)),
      catchError(rethrowAsPortalError),
    );
  }
}
