import { TestBed } from '@angular/core/testing';
import { Router, UrlTree } from '@angular/router';
import { signal } from '@angular/core';
import { provideRouter } from '@angular/router';
import { BIDDER_AUTH, BidderAuthPort, BidderSession } from '../auth/bidder-auth.port';
import { bidderGuard } from './bidder.guard';

/** Stand-in for whatever AuthService the host shell provides. */
class FakeAuth implements BidderAuthPort {
  readonly session = signal<BidderSession | null>(null);
  signedOut: 'expired' | 'user' | null = null;

  constructor(session: BidderSession | null) {
    this.session.set(session);
  }

  token(): string | null {
    return this.session() ? 'fake.jwt.token' : null;
  }

  isAuthenticated(): boolean {
    return this.session() !== null;
  }

  isBidder(): boolean {
    return this.session()?.role === 'BIDDER';
  }

  signOut(reason: 'expired' | 'user' = 'user'): void {
    this.signedOut = reason;
  }
}

function runGuard(auth: FakeAuth): boolean | UrlTree {
  TestBed.configureTestingModule({
    providers: [provideRouter([]), { provide: BIDDER_AUTH, useValue: auth }],
  });
  return TestBed.runInInjectionContext(
    () => bidderGuard(null as never, null as never) as boolean | UrlTree,
  );
}

describe('bidderGuard', () => {
  afterEach(() => TestBed.resetTestingModule());

  it('blocks an unauthenticated visitor and hands control back to the shell', () => {
    const auth = new FakeAuth(null);
    expect(runGuard(auth)).toBe(false);
    expect(auth.signedOut).toBe('expired');
  });

  it('sends a signed-in CUSTOMER to /unauthorized without ending their session', () => {
    const auth = new FakeAuth({ email: 'asha@example.com', role: 'CUSTOMER' });
    const result = runGuard(auth);
    expect(result instanceof UrlTree).toBeTrue();
    expect(TestBed.inject(Router).serializeUrl(result as UrlTree)).toBe('/unauthorized');
    expect(auth.signedOut).toBeNull();
  });

  it('sends a signed-in ADMIN to /unauthorized', () => {
    const auth = new FakeAuth({ email: 'admin@hlms.example.com', role: 'ADMIN' });
    expect(runGuard(auth) instanceof UrlTree).toBeTrue();
  });

  it('lets a BIDDER through', () => {
    const auth = new FakeAuth({ email: 'arjun@example.com', role: 'BIDDER' });
    expect(runGuard(auth)).toBeTrue();
  });

  it('treats an expired session as unauthenticated', () => {
    const auth = new FakeAuth({ email: 'arjun@example.com', role: 'BIDDER' });
    auth.session.set(null); // token expired between navigations
    expect(runGuard(auth)).toBe(false);
    expect(auth.signedOut).toBe('expired');
  });
});
