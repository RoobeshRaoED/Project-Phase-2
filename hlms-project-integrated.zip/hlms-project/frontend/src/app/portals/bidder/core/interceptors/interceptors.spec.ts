import { HttpClient, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { Router, provideRouter } from '@angular/router';
import { environment } from '../../environments/environment';
import { BIDDER_AUTH, BidderAuthPort, BidderSession } from '../auth/bidder-auth.port';
import { authInterceptor } from './auth.interceptor';
import { sessionExpiryInterceptor } from './session-expiry.interceptor';

class FakeAuth implements BidderAuthPort {
  readonly session = signal<BidderSession | null>({ email: 'arjun@example.com', role: 'BIDDER' });
  signedOut: 'expired' | 'user' | null = null;
  current: string | null = 'header.payload.signature';

  token(): string | null {
    return this.current;
  }
  isAuthenticated(): boolean {
    return this.current !== null;
  }
  isBidder(): boolean {
    return true;
  }
  signOut(reason: 'expired' | 'user' = 'user'): void {
    this.signedOut = reason;
  }
}

describe('HTTP interceptors', () => {
  let http: HttpClient;
  let backend: HttpTestingController;
  let auth: FakeAuth;
  const url = `${environment.apiBaseUrl}/repayment-service/api/auctions`;

  beforeEach(() => {
    auth = new FakeAuth();
    TestBed.configureTestingModule({
      providers: [
        provideRouter([]),
        provideHttpClient(withInterceptors([authInterceptor, sessionExpiryInterceptor])),
        provideHttpClientTesting(),
        { provide: BIDDER_AUTH, useValue: auth },
      ],
    });
    http = TestBed.inject(HttpClient);
    backend = TestBed.inject(HttpTestingController);
  });

  afterEach(() => backend.verify());

  it('attaches the bearer token to HLMS calls', () => {
    http.get(url).subscribe();
    const req = backend.expectOne(url);
    expect(req.request.headers.get('Authorization')).toBe('Bearer header.payload.signature');
    req.flush([]);
  });

  it('leaves third-party URLs untouched', () => {
    http.get('https://maps.example.com/tiles').subscribe();
    const req = backend.expectOne('https://maps.example.com/tiles');
    expect(req.request.headers.has('Authorization')).toBeFalse();
    req.flush({});
  });

  it('does not double up an Authorization header the shell already set', () => {
    http.get(url, { headers: { Authorization: 'Bearer shell-token' } }).subscribe();
    const req = backend.expectOne(url);
    expect(req.request.headers.get('Authorization')).toBe('Bearer shell-token');
    req.flush([]);
  });

  it('skips the header when there is no token', () => {
    auth.current = null;
    http.get(url).subscribe();
    const req = backend.expectOne(url);
    expect(req.request.headers.has('Authorization')).toBeFalse();
    req.flush([]);
  });

  it('signs out on 401 and still surfaces the error to the caller', () => {
    let failed = false;
    http.get(url).subscribe({ error: () => (failed = true) });
    backend.expectOne(url).flush({ status: 401, message: 'Unauthorized' }, { status: 401, statusText: 'Unauthorized' });
    expect(auth.signedOut).toBe('expired');
    expect(failed).toBeTrue();
  });

  it('routes to /unauthorized on 403 without ending the session', () => {
    const router = TestBed.inject(Router);
    const navigate = spyOn(router, 'navigate').and.resolveTo(true);
    http.get(url).subscribe({ error: () => undefined });
    backend.expectOne(url).flush({ status: 403, message: 'Forbidden' }, { status: 403, statusText: 'Forbidden' });
    expect(navigate).toHaveBeenCalledWith(['/unauthorized']);
    expect(auth.signedOut).toBeNull();
  });
});
