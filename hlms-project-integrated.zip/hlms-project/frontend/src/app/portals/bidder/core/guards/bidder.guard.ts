import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { BIDDER_AUTH } from '../auth/bidder-auth.port';

/**
 * Gate on every /bidder route.
 *
 * Three outcomes, in the order the requirements specify:
 *   no session          -> the host shell's login route
 *   session, wrong role -> /unauthorized
 *   session, BIDDER     -> through
 *
 * This is a routing decision, not a security boundary. The token is signed by
 * user-service and verified by every HLMS service on every call, so a user who
 * edits their local token past this guard still gets 401/403 from the backend
 * the moment a screen asks for data.
 */
export const bidderGuard: CanActivateFn = () => {
  const auth = inject(BIDDER_AUTH);
  const router = inject(Router);

  if (!auth.isAuthenticated()) {
    auth.signOut('expired');
    return false;
  }

  return auth.isBidder() ? true : router.createUrlTree(['/bidder/unauthorized']);
};
