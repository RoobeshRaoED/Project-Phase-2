import { Injectable, computed, signal } from '@angular/core';
import { environment } from '../../environments/environment';
import { BIDDER_ROLE, BidderAuthPort, BidderSession } from './bidder-auth.port';

interface JwtPayload {
  sub?: string;
  role?: string;
  name?: string;
  exp?: number;
}

/**
 * Fallback implementation of {@link BidderAuthPort} for when the host shell
 * only hands over a token (in storage) rather than a full AuthService.
 *
 * It reads the JWT that user-service issued at login and decodes the payload
 * to recover `sub` (email) and `role`. Decoding is NOT verification: the
 * signature is checked server-side by every HLMS service, using the shared
 * `hlms.jwt.secret`. What we read here only decides which screens to render;
 * a forged local token buys nothing, because every API call is re-validated
 * by Spring Security.
 *
 * This class never creates, signs, refreshes or renews a token.
 */
@Injectable({ providedIn: 'root' })
export class StoredTokenAuthAdapter implements BidderAuthPort {
  private readonly raw = signal<string | null>(this.read());

  readonly session = computed<BidderSession | null>(() => {
    const payload = this.payload(this.raw());
    if (!payload?.sub || !payload.role) {
      return null;
    }
    return { email: payload.sub, role: payload.role, name: payload.name };
  });

  token(): string | null {
    const value = this.raw();
    return value && !this.isExpired(value) ? value : null;
  }

  isAuthenticated(): boolean {
    return this.token() !== null && this.session() !== null;
  }

  isBidder(): boolean {
    return this.isAuthenticated() && this.session()?.role?.toUpperCase() === BIDDER_ROLE;
  }

  signOut(_reason: 'expired' | 'user' = 'user'): void {
    this.store()?.removeItem(environment.auth.tokenStorageKey);
    this.raw.set(null);
    // The host shell owns the login route; this module only leaves the building.
    window.location.assign(environment.auth.loginUrl);
  }

  /** Re-reads storage. Useful if the shell replaced the token in another tab. */
  refresh(): void {
    this.raw.set(this.read());
  }

  private store(): Storage | null {
    try {
      return environment.auth.storage === 'local' ? localStorage : sessionStorage;
    } catch {
      return null; // storage blocked (private mode, embedded frame)
    }
  }

  private read(): string | null {
    return this.store()?.getItem(environment.auth.tokenStorageKey) ?? null;
  }

  private payload(token: string | null): JwtPayload | null {
    if (!token) {
      return null;
    }
    const segments = token.split('.');
    if (segments.length !== 3) {
      return null;
    }
    try {
      const base64 = segments[1].replace(/-/g, '+').replace(/_/g, '/');
      const padded = base64.padEnd(base64.length + ((4 - (base64.length % 4)) % 4), '=');
      const json = decodeURIComponent(
        atob(padded)
          .split('')
          .map((c) => '%' + c.charCodeAt(0).toString(16).padStart(2, '0'))
          .join(''),
      );
      return JSON.parse(json) as JwtPayload;
    } catch {
      return null;
    }
  }

  private isExpired(token: string): boolean {
    const exp = this.payload(token)?.exp;
    return typeof exp === 'number' ? exp * 1000 <= Date.now() : false;
  }
}
