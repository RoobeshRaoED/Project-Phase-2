import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, catchError } from 'rxjs';
import { AppUser, ProfileUpdateRequest } from '../models/hlms.models';
import { API } from './api-urls';
import { rethrowAsPortalError } from './error-mapper';

/**
 * user-service appUserController.
 *
 * PUT /api/users/{email} takes the whole appUserEntity, but
 * appUserServiceImplementation.updateUser only copies name, mobile,
 * prefEmail, prefSms and prefInapp onto the existing row. Role, email,
 * idType/idNumber, active and the password hash are untouchable no matter
 * what the client sends - so this service sends exactly those five fields
 * and nothing else.
 *
 * Note the prefs are copied straight across, nulls included: omitting one
 * would blank it. ProfileUpdateRequest keeps all five mandatory for that
 * reason.
 */
@Injectable({ providedIn: 'root' })
export class ProfileService {
  private readonly http = inject(HttpClient);

  /** GET /user-service/api/users/{email} */
  get(email: string): Observable<AppUser> {
    return this.http.get<AppUser>(API.users.byEmail(email)).pipe(catchError(rethrowAsPortalError));
  }

  /** PUT /user-service/api/users/{email} */
  update(email: string, changes: ProfileUpdateRequest): Observable<AppUser> {
    return this.http.put<AppUser>(API.users.byEmail(email), changes).pipe(catchError(rethrowAsPortalError));
  }
}
