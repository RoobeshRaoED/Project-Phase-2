import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { environment } from '../../environments/environment';
import { BidDto, PortalError } from '../models/hlms.models';
import { BidService } from './bid.service';

const BIDS_URL = `${environment.apiBaseUrl}/repayment-service/api/bids`;
const AUCTION_BIDS_URL = `${environment.apiBaseUrl}/repayment-service/api/auctions/APP-001/bids`;

function bid(overrides: Partial<BidDto> = {}): BidDto {
  return {
    bidId: 'BID-00000001',
    appId: 'APP-001',
    bidderEmail: 'arjun@example.com',
    bidAmount: 2_600_000,
    createdAt: '2026-08-01T10:00:00Z',
    ...overrides,
  };
}

describe('BidService', () => {
  let service: BidService;
  let backend: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting(), BidService],
    });
    service = TestBed.inject(BidService);
    backend = TestBed.inject(HttpTestingController);
  });

  afterEach(() => backend.verify());

  it('posts only appId, bidderEmail and bidAmount - the server owns bidId and createdAt', () => {
    service.place({ appId: 'APP-001', bidderEmail: 'arjun@example.com', bidAmount: 2_600_000 }).subscribe();
    const req = backend.expectOne(AUCTION_BIDS_URL);
    expect(req.request.method).toBe('POST');
    expect(Object.keys(req.request.body).sort()).toEqual(['appId', 'bidAmount', 'bidderEmail']);
    req.flush(bid(), { status: 201, statusText: 'Created' });
  });

  it('surfaces the backend reason when a bid is below the reserve price', (done) => {
    service.place({ appId: 'APP-001', bidderEmail: 'arjun@example.com', bidAmount: 100 }).subscribe({
      error: (err: PortalError) => {
        expect(err.status).toBe(400);
        expect(err.message).toContain('reserve price');
        done();
      },
    });
    backend.expectOne(AUCTION_BIDS_URL).flush(
      { status: 400, message: 'bidAmount must be at least the reserve price of 2500000.', timestamp: '2026-08-09T00:00:00Z' },
      { status: 400, statusText: 'Bad Request' },
    );
  });

  it('surfaces the backend reason when a bid does not beat the current highest', (done) => {
    service.place({ appId: 'APP-001', bidderEmail: 'arjun@example.com', bidAmount: 2_500_000 }).subscribe({
      error: (err: PortalError) => {
        expect(err.message).toContain('higher than the current highest bid');
        done();
      },
    });
    backend.expectOne(AUCTION_BIDS_URL).flush(
      { status: 400, message: 'bidAmount must be higher than the current highest bid of 2600000.', timestamp: '' },
      { status: 400, statusText: 'Bad Request' },
    );
  });

  it('reports a network failure in plain language rather than an HTTP code', (done) => {
    service.place({ appId: 'APP-001', bidderEmail: 'arjun@example.com', bidAmount: 3_000_000 }).subscribe({
      error: (err: PortalError) => {
        expect(err.status).toBe(0);
        expect(err.message).toContain('Cannot reach the HLMS server');
        done();
      },
    });
    backend.expectOne(AUCTION_BIDS_URL).error(new ProgressEvent('network error'));
  });

  it('never leaks a stack trace from a 500', (done) => {
    service.place({ appId: 'APP-001', bidderEmail: 'arjun@example.com', bidAmount: 3_000_000 }).subscribe({
      error: (err: PortalError) => {
        expect(err.message).not.toContain('java.lang');
        expect(err.message).toContain('could not complete');
        done();
      },
    });
    backend.expectOne(AUCTION_BIDS_URL).flush(
      { status: 500, message: 'java.lang.NullPointerException at com.hlms2.repayment.BidServiceImpl.create(BidServiceImpl.java:71)', timestamp: '' },
      { status: 500, statusText: 'Server Error' },
    );
  });

  it('returns only the signed-in bidder\'s rows from the shared bids endpoint', (done) => {
    service.mine('arjun@example.com').subscribe((bids) => {
      expect(bids.length).toBe(2);
      expect(bids.every((b) => b.bidderEmail.toLowerCase() === 'arjun@example.com')).toBeTrue();
      // newest first
      expect(bids[0].bidId).toBe('BID-2');
      done();
    });
    backend.expectOne(BIDS_URL).flush([
      bid({ bidId: 'BID-1', createdAt: '2026-08-01T10:00:00Z' }),
      bid({ bidId: 'BID-OTHER', bidderEmail: 'priya@example.com' }),
      bid({ bidId: 'BID-2', createdAt: '2026-08-05T10:00:00Z' }),
    ]);
  });

  it('matches the bidder email case-insensitively', (done) => {
    service.mine('Arjun@Example.com').subscribe((bids) => {
      expect(bids.length).toBe(1);
      done();
    });
    backend.expectOne(BIDS_URL).flush([bid()]);
  });

  it('sorts an auction\'s bid history by amount, highest first', (done) => {
    service.forAuction('APP-001').subscribe((bids) => {
      expect(bids.map((b) => b.bidAmount)).toEqual([3_000_000, 2_600_000, 2_500_000]);
      done();
    });
    backend.expectOne(AUCTION_BIDS_URL).flush([
      bid({ bidId: 'B1', bidAmount: 2_600_000 }),
      bid({ bidId: 'B2', bidAmount: 3_000_000 }),
      bid({ bidId: 'B3', bidAmount: 2_500_000 }),
    ]);
  });

  it('handles an auction with no bids', (done) => {
    service.forAuction('APP-001').subscribe((bids) => {
      expect(bids).toEqual([]);
      done();
    });
    backend.expectOne(AUCTION_BIDS_URL).flush([]);
  });
});
