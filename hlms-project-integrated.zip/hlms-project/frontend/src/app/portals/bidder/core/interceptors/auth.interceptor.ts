import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { BIDDER_AUTH } from '../auth/bidder-auth.port';
import { environment } from '../../environments/environment';

/**
 * Attaches the host shell's bearer token to HLMS calls.
 *
 * Two guards against leaking it: only requests aimed at the configured API
 * gateway are touched, and an Authorization header already set by the shell is
 * left alone rather than doubled up.
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(BIDDER_AUTH);

  const isHlmsCall = req.url.startsWith(environment.apiBaseUrl);
  const alreadySigned = req.headers.has('Authorization');
  const token = auth.token();

  if (!isHlmsCall || alreadySigned || !token) {
    return next(req);
  }

  return next(req.clone({ setHeaders: { Authorization: `Bearer ${token}` } }));
};
