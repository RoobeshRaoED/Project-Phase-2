import { HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { ApiError, PortalError } from '../models/hlms.models';

/**
 * Turns any HTTP failure into a message a bidder can act on.
 *
 * The HLMS services return `ApiError { status, message, timestamp }`, and the
 * validation messages in BidServiceImpl are already written for humans
 * ("bidAmount must be at least the reserve price of 2500000."), so those are
 * surfaced as-is. Anything unrecognised falls back to a generic line - raw
 * stack traces (which the catch-all Exception handler will happily return in
 * `message` on a 500) never reach the screen.
 */
export function toPortalError(error: unknown): PortalError {
  if (!(error instanceof HttpErrorResponse)) {
    return { status: 0, message: 'Something went wrong. Please try again.', authFailure: false };
  }

  const body = error.error as Partial<ApiError> | string | null;
  const backendMessage = typeof body === 'object' && body?.message ? body.message : null;

  switch (error.status) {
    case 0:
      return {
        status: 0,
        message: 'Cannot reach the HLMS server. Check your connection and try again.',
        authFailure: false,
      };
    case 400:
    case 422:
      return {
        status: error.status,
        message: safe(backendMessage) ?? 'That request was rejected. Check the values and try again.',
        authFailure: false,
      };
    case 401:
      return { status: 401, message: 'Your session has expired. Sign in again to continue.', authFailure: true };
    case 403:
      return { status: 403, message: 'Your account is not allowed to perform this action.', authFailure: true };
    case 404:
      return { status: 404, message: safe(backendMessage) ?? 'That record no longer exists.', authFailure: false };
    case 409:
      return {
        status: 409,
        message: safe(backendMessage) ?? 'That action conflicts with the current state of this auction.',
        authFailure: false,
      };
    default:
      return {
        status: error.status,
        message: 'The HLMS server could not complete that request. Please try again shortly.',
        authFailure: false,
      };
  }
}

/** Drops anything that smells like a stack trace or a raw exception dump. */
function safe(message: string | null): string | null {
  if (!message) {
    return null;
  }
  const looksInternal = /(\bat\s+[\w.$]+\()|Exception:|\borg\.springframework\b|\bjava\.lang\b/.test(message);
  return looksInternal || message.length > 240 ? null : message;
}

export function rethrowAsPortalError(error: unknown): Observable<never> {
  return throwError(() => toPortalError(error));
}
