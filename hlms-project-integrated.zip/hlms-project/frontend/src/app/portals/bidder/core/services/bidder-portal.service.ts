import { Injectable, inject } from '@angular/core';
import { Observable, forkJoin, map, of, switchMap } from 'rxjs';
import { environment } from '../../environments/environment';
import { BIDDER_AUTH } from '../auth/bidder-auth.port';
import {
  AuctionCaseDto,
  AuctionListing,
  AuctionPhase,
  BidDto,
  BidStatus,
  DashboardSummary,
  MyBidRow,
  PropertySummary,
} from '../models/hlms.models';
import { AuctionService } from './auction.service';
import { BidService, equalsIgnoreCase } from './bid.service';
import { NotificationService } from './notification.service';
import { PropertyService } from './property.service';

/**
 * The join layer between three microservices and the bidder's screens.
 *
 * Nothing here invents data. Everything is composed from:
 *   repayment-service  GET /api/auctions        (auction cases)
 *   repayment-service  GET /api/bids            (all bids)
 *   loan-service       GET /api/loan-applications/{appId}  (the property)
 *
 * The derivations below exist because the backend has no auction status,
 * no auction start/end timestamp, no winner and no dashboard endpoint.
 * Each one is spelled out so the rules stay auditable when those endpoints
 * eventually land - see BACKEND-GAPS.md.
 */
@Injectable({ providedIn: 'root' })
export class BidderPortalService {
  private readonly auctions = inject(AuctionService);
  private readonly bids = inject(BidService);
  private readonly properties = inject(PropertyService);
  private readonly notifications = inject(NotificationService);
  private readonly auth = inject(BIDDER_AUTH);

  /**
   * Every auction a bidder is allowed to see, with property, bid totals and
   * phase resolved.
   *
   * Cases in stage 'None' are excluded outright: an early-stage recovery file
   * is the bank's internal business, and surfacing it would tell a bidder that
   * a named property is heading for default before the bank has listed it.
   */
  listings(): Observable<AuctionListing[]> {
    return forkJoin({ auctions: this.auctions.list(), bids: this.bids.all() }).pipe(
      switchMap(({ auctions, bids }) => {
        const visible = auctions.filter((a) => this.isBidderVisible(a));
        if (visible.length === 0) {
          return of([] as AuctionListing[]);
        }
        return forkJoin(
          visible.map((auction) =>
            this.properties
              .forApplication(auction.appId)
              .pipe(map((property) => this.compose(auction, bids, property))),
          ),
        );
      }),
      map((listings) => listings.sort(byAuctionDateAsc)),
    );
  }

  /** One auction, resolved the same way as in the list. */
  listing(auctionId: number): Observable<AuctionListing> {
    return this.auctions.byId(auctionId).pipe(
      switchMap((auction) =>
        forkJoin({
          bids: this.bids.forAuction(auction.appId),
          property: this.properties.forApplication(auction.appId),
        }).pipe(map(({ bids, property }) => this.compose(auction, bids, property))),
      ),
    );
  }

  /** Full bid history for one auction, most recent price first. */
  bidHistory(appId: string): Observable<BidDto[]> {
    return this.bids.forAuction(appId);
  }

  /** The signed-in bidder's bids, each joined to its auction. */
  myBids(): Observable<MyBidRow[]> {
    const email = this.email();
    return forkJoin({ listings: this.listings(), bids: this.bids.mine(email) }).pipe(
      map(({ listings, bids }) => {
        const byApp = new Map(listings.map((l) => [l.auction.appId, l]));
        return bids.map((bid) => {
          const listing = byApp.get(bid.appId) ?? null;
          return { bid, listing, status: this.bidStatus(bid, listing), highestBid: listing?.highestBid ?? null };
        });
      }),
    );
  }

  /**
   * Auctions the bidder has provisionally won.
   *
   * Derived, because the backend never declares a winner: the bidding date has
   * passed, the case was not withdrawn, and the highest bid on record is this
   * bidder's. It stays provisional until the bank confirms - the screen says so,
   * and BACKEND-GAPS.md #2 has the endpoint that would make it authoritative.
   */
  wonAuctions(): Observable<AuctionListing[]> {
    return this.listings().pipe(
      map((listings) => listings.filter((l) => l.phase === 'CLOSED' && l.iAmHighest)),
    );
  }

  /**
   * Auctions calendared but not yet open for bidding: the bank has set an
   * auction date while the case is still at notice or possession stage.
   * Once it moves to 'Auction Scheduled' the auction appears under Auctions.
   */
  upcomingAuctions(): Observable<AuctionListing[]> {
    return this.listings().pipe(map((listings) => listings.filter((l) => l.phase === 'UPCOMING')));
  }

  /** Dashboard counters. No /api/bidder/dashboard exists - this is the composition. */
  dashboard(): Observable<{ summary: DashboardSummary; endingSoon: AuctionListing[]; recentBids: MyBidRow[] }> {
    const email = this.email();
    return forkJoin({
      listings: this.listings(),
      myBids: this.bids.mine(email),
      unread: this.notifications.unread(email),
    }).pipe(
      map(({ listings, myBids, unread }) => {
        const byApp = new Map(listings.map((l) => [l.auction.appId, l]));
        const rows: MyBidRow[] = myBids.map((bid) => {
          const listing = byApp.get(bid.appId) ?? null;
          return { bid, listing, status: this.bidStatus(bid, listing), highestBid: listing?.highestBid ?? null };
        });
        const open = listings.filter((l) => l.phase === 'OPEN' || l.phase === 'CLOSING_TODAY');
        const summary: DashboardSummary = {
          openAuctions: open.length,
          totalBids: rows.length,
          winningBids: rows.filter((r) => r.status === 'WINNING').length,
          outbidBids: rows.filter((r) => r.status === 'OUTBID').length,
          wonProvisional: listings.filter((l) => l.phase === 'CLOSED' && l.iAmHighest).length,
          upcomingAuctions: listings.filter((l) => l.phase === 'UPCOMING').length,
          unreadNotifications: unread.length,
        };
        return {
          summary,
          endingSoon: open.slice(0, 5),
          recentBids: rows.slice(0, 5),
        };
      }),
    );
  }

  /* ---------------- derivation rules ---------------- */

  /**
   * Bidding phase from `stage` + `auctionDate`, the only two signals the
   * backend gives us. `auctionDate` is a LocalDate, so everything is
   * day-resolution - "ends in 2h 30m" is not derivable today
   * (BACKEND-GAPS.md #3).
   */
  phase(auction: AuctionCaseDto, now = new Date()): AuctionPhase {
    const today = startOfDay(now);
    const date = auction.auctionDate ? startOfDay(new Date(auction.auctionDate)) : null;

    if (auction.stage === 'Resolved') {
      return 'CONCLUDED';
    }
    if (auction.stage === 'Auction Scheduled') {
      if (!date) {
        return 'OPEN'; // listed for e-auction, sale date not yet published
      }
      if (date.getTime() > today.getTime()) {
        return 'OPEN';
      }
      return date.getTime() === today.getTime() ? 'CLOSING_TODAY' : 'CLOSED';
    }
    if (auction.stage === 'Notice Issued' || auction.stage === 'Possession') {
      return date && date.getTime() >= today.getTime() ? 'UPCOMING' : 'NOT_LISTED';
    }
    return 'NOT_LISTED';
  }

  /** True while the portal will let a bid through to the backend. */
  canBid(phase: AuctionPhase): boolean {
    return phase === 'OPEN' || phase === 'CLOSING_TODAY';
  }

  /**
   * The lowest amount the backend will accept: strictly above the current
   * highest bid, and never below the reserve price (BidServiceImpl.validate).
   * Rupee amounts are whole numbers throughout HLMS, so +1 is the real step.
   */
  minimumAllowedBid(reservePrice: number | null, highestBid: number | null): number {
    const reserve = reservePrice ?? 0;
    return highestBid === null ? reserve : Math.max(reserve, highestBid + 1);
  }

  /** What we pre-fill the bid box with - a round increment, not the bare floor. */
  suggestedBid(reservePrice: number | null, highestBid: number | null): number {
    if (highestBid === null) {
      return reservePrice ?? 0;
    }
    return Math.max(reservePrice ?? 0, highestBid + environment.bidIncrement);
  }

  private bidStatus(bid: BidDto, listing: AuctionListing | null): BidStatus {
    if (!listing) {
      return 'CLOSED';
    }
    const isTop = listing.highestBid !== null && bid.bidAmount >= listing.highestBid && listing.iAmHighest;
    switch (listing.phase) {
      case 'OPEN':
      case 'CLOSING_TODAY':
        return isTop ? 'WINNING' : 'OUTBID';
      case 'CLOSED':
        return isTop ? 'WON_PROVISIONAL' : 'LOST';
      case 'CONCLUDED':
        return 'CLOSED';
      default:
        return 'CLOSED';
    }
  }

  private isBidderVisible(auction: AuctionCaseDto): boolean {
    const phase = this.phase(auction);
    return phase !== 'NOT_LISTED';
  }

  private compose(auction: AuctionCaseDto, allBids: BidDto[], property: PropertySummary | null): AuctionListing {
    const email = this.email();
    const forAuction = allBids.filter((b) => b.appId === auction.appId);
    const highest = forAuction.reduce<BidDto | null>(
      (top, b) => (top === null || b.bidAmount > top.bidAmount ? b : top),
      null,
    );
    const mine = forAuction
      .filter((b) => equalsIgnoreCase(b.bidderEmail, email))
      .reduce<number | null>((max, b) => (max === null || b.bidAmount > max ? b.bidAmount : max), null);
    const phase = this.phase(auction);

    return {
      auction,
      property,
      phase,
      bidCount: forAuction.length,
      highestBid: highest?.bidAmount ?? null,
      iAmHighest: !!highest && equalsIgnoreCase(highest.bidderEmail, email),
      myBid: mine,
      minimumNextBid: this.minimumAllowedBid(auction.reservePrice, highest?.bidAmount ?? null),
      daysLeft: auction.auctionDate ? daysBetween(new Date(), new Date(auction.auctionDate)) : null,
    };
  }

  private email(): string {
    return this.auth.session()?.email ?? '';
  }
}

function startOfDay(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function daysBetween(from: Date, to: Date): number {
  return Math.ceil((startOfDay(to).getTime() - startOfDay(from).getTime()) / 86_400_000);
}

function byAuctionDateAsc(a: AuctionListing, b: AuctionListing): number {
  const left = a.auction.auctionDate ?? '9999-12-31';
  const right = b.auction.auctionDate ?? '9999-12-31';
  return left.localeCompare(right);
}
