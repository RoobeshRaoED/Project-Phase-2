import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { BIDDER_AUTH } from '../auth/bidder-auth.port';

/**
 * Reacts to the two answers that mean "stop asking".
 *
 * 401 - the token is gone or expired, so hand control back to the shell's
 *       sign-out flow.
 * 403 - authenticated but not permitted; the session is fine, the route is not,
 *       so route to /unauthorized and leave the token alone.
 *
 * The error still propagates: screens keep their own error state, this only
 * adds the navigation that belongs at app level.
 */
export const sessionExpiryInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(BIDDER_AUTH);
  const router = inject(Router);

  return next(req).pipe(
    catchError((error: unknown) => {
      if (error instanceof HttpErrorResponse) {
        if (error.status === 401) {
          auth.signOut('expired');
        } else if (error.status === 403) {
          void router.navigate(['/bidder/unauthorized']);
        }
      }
      return throwError(() => error);
    }),
  );
};
