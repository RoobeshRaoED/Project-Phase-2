/* ============================================================
   Models mirroring the real HLMS backend contracts.
   Field names below are taken verbatim from the Java DTOs /
   entities - nothing here is invented.
   ============================================================ */

/**
 * repayment-service `exception/ApiError`.
 * Emitted by GlobalExceptionHandler for 400 / 404 / 409 / 500.
 */
export interface ApiError {
  status: number;
  message: string;
  timestamp: string;
}

/** A backend failure translated into something a bidder can act on. */
export interface PortalError {
  status: number;
  message: string;
  /** True for 401/403 - the shell may want to re-authenticate. */
  authFailure: boolean;
}

/* ---------- Auctions ---------- */

/**
 * repayment-service `dto/AuctionCaseDTO`, straight off
 * GET /repayment-service/api/auctions.
 *
 * Note what is NOT here: no property title, no images, no auction start
 * or end timestamp, no live status, no winner. `auctionDate` is a
 * java.time.LocalDate, so it serialises as 'yyyy-MM-dd' with no time.
 */
export interface AuctionCaseDto {
  auctionId: number;
  appId: string;
  /** One of the schema CHECK values, see AuctionStage. */
  stage: AuctionStage;
  noticeDate: string | null;
  noticeDueDate: string | null;
  demandAmount: number | null;
  possessionDate: string | null;
  auctionDate: string | null;
  reservePrice: number | null;
}

/** Exact vocabulary enforced by AuctionCaseServiceImpl.VALID_STAGES. */
export type AuctionStage = 'None' | 'Notice Issued' | 'Possession' | 'Auction Scheduled' | 'Resolved';

/**
 * Bidding phase, derived on the client from `stage` + `auctionDate`.
 * The backend has no live auction status field - see BACKEND-GAPS.md #3.
 */
export type AuctionPhase = 'OPEN' | 'CLOSING_TODAY' | 'UPCOMING' | 'CLOSED' | 'CONCLUDED' | 'NOT_LISTED';

/** repayment-service `dto/AuctionNoteDTO`. */
export interface AuctionNoteDto {
  noteId: string;
  appId: string;
  noteDate: string;
  noteText: string;
}

/* ---------- Bids ---------- */

/**
 * repayment-service `dto/BidDTO`.
 * `createdAt` is an OffsetDateTime; `bidderEmail` is an FK into app_user.
 * There is no status column on `bid` - status is derived, see BidStatus.
 */
export interface BidDto {
  bidId: string;
  appId: string;
  bidderEmail: string;
  bidAmount: number;
  createdAt: string;
}

/** Payload for POST /repayment-service/api/auctions/{appId}/bids. */
export interface PlaceBidRequest {
  appId: string;
  bidderEmail: string;
  bidAmount: number;
}

/**
 * Derived bid status. The backend stores none of these - they are computed
 * from (my bid amount) vs (highest bid) vs (auction phase).
 * WON / LOST are provisional until the bank declares a winner; the backend
 * has no winner field at all (BACKEND-GAPS.md #2).
 */
export type BidStatus = 'WINNING' | 'OUTBID' | 'WON_PROVISIONAL' | 'LOST' | 'CLOSED';

/* ---------- Property ---------- */

/**
 * loan-service `entity/LoanApplication` as returned by
 * GET /loan-service/api/loan-applications/{appId}.
 *
 * Only the property-safe subset is typed here. The endpoint also returns
 * borrower PII (applicantName, applicantPan, monthlyIncome, employer...)
 * which this portal must never render to a bidder - see BACKEND-GAPS.md #4.
 */
export interface LoanApplicationPropertyView {
  appId: string;
  trackingNo: string | null;
  propertyAddress: string | null;
  propertyType: string | null;
  propertyValue: number | null;
  addrCity: string | null;
  addrState: string | null;
  addrPincode: string | null;
}

/** The bidder-facing property card. */
export interface PropertySummary {
  appId: string;
  reference: string;
  address: string;
  type: string;
  declaredValue: number | null;
  city: string | null;
  state: string | null;
}

/* ---------- Composed view models ---------- */

/** An auction plus everything the listing screens need to render it. */
export interface AuctionListing {
  auction: AuctionCaseDto;
  property: PropertySummary | null;
  phase: AuctionPhase;
  bidCount: number;
  highestBid: number | null;
  /** True when the signed-in bidder currently holds the highest bid. */
  iAmHighest: boolean;
  /** My highest bid on this auction, if any. */
  myBid: number | null;
  /** Suggested next bid. Guidance only - the backend decides. */
  minimumNextBid: number;
  /** Whole days until auctionDate; negative once past. */
  daysLeft: number | null;
}

/** A row on the My Bids screen. */
export interface MyBidRow {
  bid: BidDto;
  listing: AuctionListing | null;
  status: BidStatus;
  highestBid: number | null;
}

/** Dashboard counters, all derived client-side (no dashboard endpoint exists). */
export interface DashboardSummary {
  openAuctions: number;
  totalBids: number;
  winningBids: number;
  outbidBids: number;
  wonProvisional: number;
  upcomingAuctions: number;
  unreadNotifications: number;
}

/* ---------- Notifications ---------- */

/**
 * notification-service `entity/Notification`.
 * Careful: the entity's getter is `isRead()` over a Boolean field, so
 * Jackson serialises the flag as `read` while the setter accepts `isRead`.
 * Both spellings are tolerated here.
 */
export interface NotificationDto {
  notificationId: string;
  userEmail: string;
  title: string;
  body: string | null;
  channels: string[];
  read?: boolean;
  isRead?: boolean;
  createdAt: string;
}

/* ---------- User / profile ---------- */

/**
 * user-service `Entity/appUserEntity` from GET /user-service/api/users/{email}.
 * PUT on the same path only applies name, mobile, prefEmail, prefSms and
 * prefInapp (see appUserServiceImplementation.updateUser) - everything else
 * is read-only no matter what the client sends.
 */
export interface AppUser {
  email: string;
  name: string;
  mobile: string;
  role: string;
  active: boolean;
  idType: string | null;
  idNumber: string | null;
  prefSms: boolean;
  prefEmail: boolean;
  prefInapp: boolean;
  createdAt: string | null;
}

/** The only fields the backend will actually persist on update. */
export interface ProfileUpdateRequest {
  name: string;
  mobile: string;
  prefSms: boolean;
  prefEmail: boolean;
  prefInapp: boolean;
}
