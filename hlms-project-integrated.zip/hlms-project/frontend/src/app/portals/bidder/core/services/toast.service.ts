import { Injectable, signal } from '@angular/core';

export interface Toast {
  id: number;
  title: string;
  body?: string;
  tone: 'ok' | 'err' | 'info';
}

/** Transient confirmations and failures, rendered once by the app shell. */
@Injectable({ providedIn: 'root' })
export class ToastService {
  private counter = 0;
  readonly toasts = signal<Toast[]>([]);

  show(title: string, body?: string, tone: Toast['tone'] = 'info'): void {
    const toast: Toast = { id: ++this.counter, title, body, tone };
    this.toasts.update((list) => [...list, toast]);
    setTimeout(() => this.dismiss(toast.id), 5000);
  }

  success(title: string, body?: string): void {
    this.show(title, body, 'ok');
  }

  error(title: string, body?: string): void {
    this.show(title, body, 'err');
  }

  dismiss(id: number): void {
    this.toasts.update((list) => list.filter((t) => t.id !== id));
  }
}
