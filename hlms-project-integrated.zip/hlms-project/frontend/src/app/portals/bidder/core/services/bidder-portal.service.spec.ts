import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { signal } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { environment } from '../../environments/environment';
import { BIDDER_AUTH, BidderAuthPort, BidderSession } from '../auth/bidder-auth.port';
import { AuctionCaseDto, AuctionStage } from '../models/hlms.models';
import { BidderPortalService } from './bidder-portal.service';

class FakeAuth implements BidderAuthPort {
  readonly session = signal<BidderSession | null>({ email: 'arjun@example.com', role: 'BIDDER' });
  token(): string | null {
    return 'token';
  }
  isAuthenticated(): boolean {
    return true;
  }
  isBidder(): boolean {
    return true;
  }
  signOut(): void {}
}

function auction(stage: AuctionStage, auctionDate: string | null, overrides: Partial<AuctionCaseDto> = {}): AuctionCaseDto {
  return {
    auctionId: 1,
    appId: 'APP-001',
    stage,
    noticeDate: '2026-01-01',
    noticeDueDate: '2026-03-01',
    demandAmount: 4_000_000,
    possessionDate: '2026-04-01',
    auctionDate,
    reservePrice: 2_500_000,
    ...overrides,
  };
}

function isoDaysFromNow(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

describe('BidderPortalService derivations', () => {
  let service: BidderPortalService;
  let backend: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        BidderPortalService,
        { provide: BIDDER_AUTH, useClass: FakeAuth },
      ],
    });
    service = TestBed.inject(BidderPortalService);
    backend = TestBed.inject(HttpTestingController);
  });

  afterEach(() => backend.verify());

  describe('phase()', () => {
    it('is OPEN while a scheduled auction is still ahead', () => {
      expect(service.phase(auction('Auction Scheduled', isoDaysFromNow(5)))).toBe('OPEN');
    });

    it('is CLOSING_TODAY on the auction date itself', () => {
      expect(service.phase(auction('Auction Scheduled', isoDaysFromNow(0)))).toBe('CLOSING_TODAY');
    });

    it('is CLOSED once the auction date has passed', () => {
      expect(service.phase(auction('Auction Scheduled', isoDaysFromNow(-1)))).toBe('CLOSED');
    });

    it('is OPEN when listed for e-auction with no date published yet', () => {
      expect(service.phase(auction('Auction Scheduled', null))).toBe('OPEN');
    });

    it('is UPCOMING for a case calendared but not yet listed', () => {
      expect(service.phase(auction('Possession', isoDaysFromNow(10)))).toBe('UPCOMING');
      expect(service.phase(auction('Notice Issued', isoDaysFromNow(30)))).toBe('UPCOMING');
    });

    it('is CONCLUDED once the bank resolves or withdraws the case', () => {
      expect(service.phase(auction('Resolved', isoDaysFromNow(-5)))).toBe('CONCLUDED');
    });

    it('hides early-stage recovery files from bidders entirely', () => {
      expect(service.phase(auction('None', null))).toBe('NOT_LISTED');
      expect(service.phase(auction('Notice Issued', null))).toBe('NOT_LISTED');
    });
  });

  describe('canBid()', () => {
    it('allows bidding only while an auction is open', () => {
      expect(service.canBid('OPEN')).toBeTrue();
      expect(service.canBid('CLOSING_TODAY')).toBeTrue();
      expect(service.canBid('CLOSED')).toBeFalse();
      expect(service.canBid('UPCOMING')).toBeFalse();
      expect(service.canBid('CONCLUDED')).toBeFalse();
    });
  });

  describe('minimumAllowedBid()', () => {
    it('is the reserve price when nobody has bid', () => {
      expect(service.minimumAllowedBid(2_500_000, null)).toBe(2_500_000);
    });

    it('must strictly beat the current highest bid', () => {
      expect(service.minimumAllowedBid(2_500_000, 2_600_000)).toBe(2_600_001);
    });

    it('never drops below the reserve even if the highest bid somehow did', () => {
      expect(service.minimumAllowedBid(2_500_000, 2_000_000)).toBe(2_500_000);
    });

    it('suggests a round increment rather than the bare floor', () => {
      expect(service.suggestedBid(2_500_000, 2_600_000)).toBe(2_600_000 + environment.bidIncrement);
    });
  });

  describe('listings()', () => {
    const auctionsUrl = `${environment.apiBaseUrl}/repayment-service/api/auctions`;
    const bidsUrl = `${environment.apiBaseUrl}/repayment-service/api/bids`;
    const appUrl = (appId: string) => `${environment.apiBaseUrl}/loan-service/api/loan-applications/${appId}`;

    it('composes highest bid, my bid and bid count from the shared bids feed', (done) => {
      service.listings().subscribe((listings) => {
        expect(listings.length).toBe(1);
        const l = listings[0];
        expect(l.bidCount).toBe(2);
        expect(l.highestBid).toBe(3_000_000);
        expect(l.iAmHighest).toBeFalse();
        expect(l.myBid).toBe(2_600_000);
        expect(l.property?.address).toBe('12 Rose Villa, Anna Nagar');
        done();
      });

      backend.expectOne(auctionsUrl).flush([auction('Auction Scheduled', isoDaysFromNow(4))]);
      backend.expectOne(bidsUrl).flush([
        { bidId: 'B1', appId: 'APP-001', bidderEmail: 'arjun@example.com', bidAmount: 2_600_000, createdAt: '' },
        { bidId: 'B2', appId: 'APP-001', bidderEmail: 'priya@example.com', bidAmount: 3_000_000, createdAt: '' },
      ]);
      backend.expectOne(appUrl('APP-001')).flush({
        appId: 'APP-001',
        trackingNo: 'HL-2026-0007',
        propertyAddress: '12 Rose Villa, Anna Nagar',
        propertyType: 'Independent House',
        propertyValue: 5_000_000,
        addrCity: 'Chennai',
        addrState: 'Tamil Nadu',
        addrPincode: '600040',
        // The endpoint also returns borrower PII - none of it should reach a listing.
        applicantName: 'Ravi Kumar',
        applicantPan: 'ABCDE1234F',
        monthlyIncome: 120000,
      });
    });

    it('excludes cases a bidder should never see', (done) => {
      service.listings().subscribe((listings) => {
        expect(listings).toEqual([]);
        done();
      });
      backend.expectOne(auctionsUrl).flush([auction('None', null), auction('Notice Issued', null, { auctionId: 2 })]);
      backend.expectOne(bidsUrl).flush([]);
    });

    it('survives a missing property record rather than dropping the auction', (done) => {
      service.listings().subscribe((listings) => {
        expect(listings.length).toBe(1);
        expect(listings[0].property).toBeNull();
        done();
      });
      backend.expectOne(auctionsUrl).flush([auction('Auction Scheduled', isoDaysFromNow(2))]);
      backend.expectOne(bidsUrl).flush([]);
      backend.expectOne(appUrl('APP-001')).flush({ status: 404, message: 'not found' }, { status: 404, statusText: 'Not Found' });
    });

    it('reports an empty auction list as empty, not as an error', (done) => {
      service.listings().subscribe((listings) => {
        expect(listings).toEqual([]);
        done();
      });
      backend.expectOne(auctionsUrl).flush([]);
      backend.expectOne(bidsUrl).flush([]);
    });

    it('propagates an auction API failure to the caller', (done) => {
      service.listings().subscribe({
        error: (err) => {
          expect(err.status).toBe(500);
          done();
        },
      });
      backend.expectOne(auctionsUrl).flush({}, { status: 500, statusText: 'Server Error' });
      backend.expectOne(bidsUrl).flush([]);
    });
  });

  describe('wonAuctions()', () => {
    const auctionsUrl = `${environment.apiBaseUrl}/repayment-service/api/auctions`;
    const bidsUrl = `${environment.apiBaseUrl}/repayment-service/api/bids`;

    it('claims a provisional win only when bidding has closed and my bid is highest', (done) => {
      service.wonAuctions().subscribe((won) => {
        expect(won.length).toBe(1);
        expect(won[0].auction.auctionId).toBe(1);
        done();
      });

      backend.expectOne(auctionsUrl).flush([
        auction('Auction Scheduled', isoDaysFromNow(-2), { auctionId: 1, appId: 'APP-001' }),
        auction('Auction Scheduled', isoDaysFromNow(-2), { auctionId: 2, appId: 'APP-002' }),
        // withdrawn by the bank - not a win no matter who bid highest
        auction('Resolved', isoDaysFromNow(-3), { auctionId: 3, appId: 'APP-003' }),
      ]);
      backend.expectOne(bidsUrl).flush([
        { bidId: 'B1', appId: 'APP-001', bidderEmail: 'arjun@example.com', bidAmount: 3_000_000, createdAt: '' },
        { bidId: 'B2', appId: 'APP-002', bidderEmail: 'priya@example.com', bidAmount: 4_000_000, createdAt: '' },
        { bidId: 'B3', appId: 'APP-002', bidderEmail: 'arjun@example.com', bidAmount: 3_500_000, createdAt: '' },
        { bidId: 'B4', appId: 'APP-003', bidderEmail: 'arjun@example.com', bidAmount: 9_000_000, createdAt: '' },
      ]);

      ['APP-001', 'APP-002', 'APP-003'].forEach((appId) =>
        backend
          .expectOne(`${environment.apiBaseUrl}/loan-service/api/loan-applications/${appId}`)
          .flush({ appId, trackingNo: appId, propertyAddress: 'x', propertyType: 'Flat', propertyValue: 1, addrCity: 'c', addrState: 's', addrPincode: '1' }),
      );
    });
  });
});
