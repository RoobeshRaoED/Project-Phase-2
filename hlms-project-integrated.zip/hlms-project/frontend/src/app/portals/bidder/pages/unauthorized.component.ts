import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { BIDDER_AUTH } from '../core/auth/bidder-auth.port';

/**
 * Where a signed-in non-bidder ends up. Deliberately a dead end: this
 * application has no other role's screens to offer, so the only ways out are
 * back to the host shell or a different sign-in.
 */
@Component({
  selector: 'hlms-unauthorized',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="wrap">
      <div class="card panel">
        <div class="mark">HLMS</div>
        <h1>This portal is for bidders</h1>
        <p>
          You're signed in as <strong>{{ role() }}</strong>. The bidder portal is limited to accounts registered for
          property e-auctions.
        </p>
        <p class="small muted">
          If you should have bidder access, ask HLMS support to update the role on your account.
        </p>
        <button type="button" class="btn btn-primary" (click)="signOut()">Sign in with another account</button>
      </div>
    </div>
  `,
  styles: [
    `
      .wrap { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 24px; }
      .panel { max-width: 430px; text-align: center; padding: 32px 28px; margin: 0; }
      .mark { font-weight: 800; letter-spacing: .08em; color: var(--navy); margin-bottom: 18px; }
      h1 { font-size: 19px; color: var(--navy); margin: 0 0 12px; }
      p { font-size: 13.5px; color: var(--text-mid); line-height: 1.6; margin: 0 0 12px; }
      button { margin-top: 10px; }
    `,
  ],
})
export class UnauthorizedComponent {
  private readonly auth = inject(BIDDER_AUTH);

  readonly role = computed(() => this.auth.session()?.role ?? 'an unknown role');

  signOut(): void {
    this.auth.signOut('user');
  }
}
