# HLMS Customer Portal — Angular 19

This is the **customer-facing** UI for the HLMS Housing Loan Management System, rebuilt in
Angular 19 (standalone components, signals, new `@if`/`@for` control flow) and wired directly
to your existing Spring Boot / Spring Cloud microservices backend (`user-service`,
`loan-service`, `document-service`, `repayment-service`, `legal-service`,
`notification-service`, `api-gateway`, `eureka-server`).

The visual theme (colors, typography, cards, buttons, badges, layout) is ported 1:1 from your
`Updated_UI/integration-2.css`, so the look matches your existing design exactly — only the
implementation changed, from a single static HTML/JS file to a proper Angular app with real
backend calls, routing, guards, and reactive forms.

**See `API_GAPS.md` for a full list of backend endpoints that are missing, inconsistent, or
insecure and should be addressed** — the UI works around several of these, but they should be
fixed for a production launch.

## 1. Prerequisites

- Node.js 18+ and npm
- Your backend running locally:
  1. `eureka-server` (port 8761)
  2. `user-service`, `loan-service`, `document-service`, `repayment-service`,
     `legal-service`, `notification-service` (each registers itself with Eureka)
  3. `api-gateway` (port 8080) — **the Angular app only ever talks to this**, never to the
     individual services directly.

## 2. Install & run

```bash
npm install
npm start          # ng serve, http://localhost:4200
```

The app calls the gateway at `http://localhost:8080` (see `src/environments/environment.ts`).
Change `apiBase` there (and in `environment.development.ts`) if your gateway runs elsewhere.

CORS is already configured on the gateway side for `http://localhost:4200` — nothing to change
on the backend for local development.

## 3. Building for production

```bash
npm run build
```

Output goes to `dist/hlms-customer-ui`. Update `environment.ts`'s `apiBase` to your deployed
gateway URL before building for production.

## 4. How authentication works

- **Login** calls `POST /user-service/api/users/login` with `{ email, password }`, gets back a
  JWT, decodes it client-side to read the `role` claim, and rejects login in the UI if the role
  isn't `CUSTOMER` (this portal is customer-only — staff/admin/bidder/legal roles should use
  their own portals).
- The JWT is attached as `Authorization: Bearer <token>` to every backend call via an HTTP
  interceptor (`core/interceptors/auth.interceptor.ts`).
- A `401` response from any service logs the user out and redirects to `/login`.
- **There is no refresh-token endpoint** on the backend, so sessions simply expire when the JWT
  expires (60 minutes by default — see `API_GAPS.md`).

## 5. App structure

```
src/app/
  core/
    models/models.ts          — TypeScript interfaces mirroring every backend DTO/entity
    services/                 — one service per backend concern (auth, user, loan, document,
                                 repayment, legal, notification, toast)
    interceptors/              — attaches JWT, handles 401
    guards/                    — authGuard (customer-only routes), guestGuard (login/register)
  shared/components/
    shell/                     — app frame (topbar + sidebar + router-outlet)
    topbar/, sidebar/, toast/
  features/
    home/                      — public marketing landing page
    auth/login, register, forgot-password
    dashboard/                 — customer home page after login
    guidance/                  — loan products, recommendations, EMI assistant
    eligibility/               — eligibility check + history
    apply/                     — multi-step loan application wizard (draft-save + submit)
    tracking/                  — application list + stage timeline + stakeholder + SLA
    repayment/                 — EMI schedule, disbursement, insurance
    postdisb/                  — post-disbursement documents + service requests
    documents/                 — pre-disbursement document upload/list/delete
    auction/                   — legal notices / SARFAESI / auction transparency (read-only)
    profile/                   — personal + employment profile
    support/                   — notifications inbox + general support requests
```

## 6. Routing

- `/` — public landing page
- `/login`, `/register`, `/forgot-password` — public, redirect to `/dashboard` if already
  logged in as a customer
- Everything else (`/dashboard`, `/guidance`, `/eligibility`, `/apply`, `/tracking`,
  `/repayment`, `/postdisb`, `/documents`, `/auction`, `/profile`, `/support`) is behind
  `authGuard` and requires the `CUSTOMER` role.
- **After login, the customer is taken to `/dashboard`** — this is the customer "home page"
  requested, showing application stats, a quick list of applications, notifications, and quick
  links to every other feature.
