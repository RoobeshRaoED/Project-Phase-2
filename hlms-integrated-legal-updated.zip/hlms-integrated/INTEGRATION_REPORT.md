# HLMS — Integration Report

Single Angular 19 application built from the four uploaded archives.

---

## 1. What was integrated

The four zips contained **five** Angular applications (the customer/admin archive held two projects, and a Legal & Valuation portal was present that wasn't listed in the brief):

| Source archive | Project | Role in the integrated app | Files |
|---|---|---|---|
| `hlms-angular19-hlms-auth.zip` | `hlms-angular19-hlms-auth` | Home, Login, Register | 12 |
| `Final_customer_and_admin_UI.zip` | `angular-customer-ui` | Customer portal | 31 |
| `Final_customer_and_admin_UI.zip` | `hlms-admin-ui` | Admin console | 26 |
| `hlms-bankoffice-ui-updated__5_.zip` | `hlms-bankoffice-ui` | Bank Office portal | 50 |
| `hlms-legal-portal-angular19.zip` | `hlms-legal-portal` | Legal & Valuation portal | 36 |

All 155 source files were carried across. No component, service, model, guard, template or stylesheet was rewritten or replaced with sample code.

**Toolchain — no conflict.** All five projects were already on Angular `^19.0.0`, TypeScript `~5.6`, RxJS `~7.8`, zone.js `~0.15`, with identical dependency sets. Nothing needed upgrading or downgrading.

---

## 2. Final folder structure

```
hlms-integrated/
├── angular.json  package.json  proxy.conf.json  tsconfig.json  tsconfig.app.json
├── public/favicon.png
└── src/
    ├── index.html  main.ts  styles.css  favicon.ico
    ├── assets/                     hero + logo under every filename the five apps referenced
    ├── environments/               environment.ts | .prod.ts | .development.ts | .production.ts
    └── app/
        ├── app.component.ts        application root (router-outlet only)
        ├── app.config.ts           merged providers
        ├── app.routes.ts           top-level router
        │
        ├── core/                   ── NEW: the integration layer, 3 files ──
        │   ├── session/session-keys.ts       localStorage key registry + clearHlmsSession()
        │   ├── session/session.service.ts    single sign-on + role dispatch
        │   └── interceptors/hlms-auth.interceptor.ts
        │
        ├── auth/                   Home / Login / Register
        │   ├── core/{guards,interceptors,models,services,validators}
        │   ├── pages/{home, auth/login, auth/register}
        │   └── auth.routes.ts
        │
        ├── customer/               Customer portal
        │   ├── core/{guards,interceptors,models,services}
        │   ├── features/           dashboard, guidance, eligibility, apply, tracking,
        │   │                       repayment, postdisb, documents, auction, profile, support
        │   ├── shared/components/  shell, sidebar, topbar, toast
        │   ├── customer-root.ts    module wrapper (was this project's app.ts)
        │   └── customer.routes.ts
        │
        ├── admin/                  Admin console
        │   ├── core/  features/admin/{admin-shell,dashboard,staff-management,profile}
        │   ├── features/login  shared/{toast,api-banner}
        │   ├── admin-root.ts  admin.routes.ts
        │
        ├── bankoffice/             Bank Office portal
        │   ├── core/{guards,interceptors,models,services,utils}
        │   ├── features/bankoffice/  bo-dashboard … bo-settings (10 screens)
        │   ├── features/auth/  layout/{shell,sidebar,topbar}  shared/components/toast
        │   ├── bankoffice-root.component.ts  bankoffice.routes.ts
        │
        └── legal/                  Legal & Valuation portal
            ├── core/{guards,interceptors,models,services}   (12 services)
            ├── layout/{shell,toast}  pages/{dashboard,queue,case-detail,documents,auction,notices,profile,login}
            ├── legal-root.component.ts  legal.routes.ts
```

Each module keeps its **own** `core/` — its own `AuthService`, models and services — exactly as its developer wrote them. Duplicate class names across modules are harmless because they live in separate files and are resolved per-module.

---

## 3. Routes

```
/                        Home                     (auth)
/login                   Login  ← single sign-on for all roles
/register                Register

/customer/dashboard      guidance · eligibility · apply(/:appId) · tracking(/:appId)
                         repayment(/:appId) · postdisb(/:appId) · documents(/:appId)
                         auction(/:appId) · profile · support
                         + /customer/login · /register · /forgot-password

/admin/dashboard         bidder-management · employee-management · legal-management
                         bankoffice-management · admin-management(→employee) · profile
                         + /admin/login

/officer/bodash          boapplications · boappdetail/:appId · boportfolio · bodisbursement
                         bonpa · bodocs · boauction · boreports · bosettings
                         + /officer/login · /officer/forgot-password

/legal/dashboard         queue · case/:appId · documents · auction · notices · profile
                         + /legal/login

/**                      → /
```

**How the paths were remapped.** Four apps each claimed `/login`; three claimed `/dashboard` and `/profile`. Each portal was moved under its own prefix and 32 files had their internal navigation rewritten programmatically:

| Module | Original mount | New mount | Navigation edits |
|---|---|---|---|
| auth | `/`, `/login`, `/register` | unchanged | none |
| customer | `/` | `/customer` | 13 files |
| admin | `/admin` | `/admin` | **0** — already namespaced |
| bank office | `/app`, `/auth/*` | `/officer` | 14 files |
| legal | `/` | `/legal` | 5 files |

Each module's own login page was preserved and is still routed (at `/customer/login`, `/admin/login`, `/officer/login`, `/legal/login`) rather than deleted — the shared `/login` is simply the primary entry point.

---

## 4. Authentication integration

Each project invented its own localStorage keys for the same JWT:

| Module | Token key | User key |
|---|---|---|
| auth | `hlms_auth_token` | `hlms_user` |
| customer | `hlms_token` | `hlms_user` |
| admin | `hlms_admin_token` | — |
| bank office | `hlms_token` | `hlms_session_v1` |
| legal | `hlms_legal_token` | — |

Rather than rewrite five working `AuthService`s, `core/session/session.service.ts` **fans the single JWT out to every key** and writes the user record in each shape those modules expect (including the bank office's lower-case role mapping). Every module then restores its session through its own original, untouched code path.

Flow: `/login` → `AuthService.login()` (unchanged) → demo OTP step (unchanged) → `SessionService.establish()` → decode JWT → fan out token → `GET /user-service/api/users/{email}` → fan out user → redirect by role.

| JWT role | Lands on |
|---|---|
| `CUSTOMER` | `/customer/dashboard` |
| `ADMIN` | `/admin/dashboard` |
| `BANK_OFFICER` | `/officer/bodash` |
| `LEGAL` | `/legal/dashboard` |
| `BIDDER` | stays on `/login` with an explanatory message |

`BIDDER` has no destination because **none of the uploaded projects contains a bidder portal** — the admin module only manages bidder *accounts*. Rather than invent a placeholder page, the login refuses with a clear message.

**Role-based access** is enforced entirely by each module's original guards: customer's `authGuard`+`isCustomer()`, admin's `authGuard`+`adminGuard`, bank office's `authGuard`+`roleGuard`, legal's LEGAL-only `authGuard`.

---

## 5. Services and API integration

**Environment naming conflict.** Three projects read `environment.apiBaseUrl`; two read `environment.apiBase`. The unified environment exposes **both names with the same value**, plus admin's `services` map — so **no service file needed its API code changed**:

```ts
export const environment = {
  production: false,
  apiBaseUrl: '',   // auth, admin, bank office
  apiBase: '',      // customer, legal
  services: { user:'/user-service', loan:'/loan-service', legal:'/legal-service',
              repayment:'/repayment-service', notification:'/notification-service',
              document:'/document-service' }
};
```

Both are `''` so every service URL stays relative and is forwarded by `proxy.conf.json` to the API Gateway on `localhost:8080`.

**Interceptors.** All five modules registered their own HTTP interceptor. Interceptors registered in `app.config` run for *every* request regardless of which module issued it, so five stacked would each set the same header. They were consolidated into one (`hlms-auth.interceptor.ts`) keeping the union of behaviour: read whichever token key is populated, honour the customer module's public-endpoint allowlist, and treat a 401 as a session-wide sign-out. The bank office's *second* interceptor (error toasts) is kept and scoped to `/officer`.

---

## 6. Styles

All five stylesheets were forks of the same navy/teal design system. Measured overlap: of **314 distinct selectors, only 28** were defined more than once with differing bodies, and nearly all of those differences were whitespace or a single value (`font-weight:600` vs `700`, `max-width:920px` vs `960px`).

`src/styles.css` layers them (later wins), carrying `@media` and `@keyframes` blocks over whole:

1. Auth/Home/Login/Register sheet — 140 blocks
2. Shared portal base (customer) — 174 blocks
3. Legal (13), Bank Office (11), Admin (18) additions
4. `.auth-page` — reclaims the values the auth pages need back
5. `.admin-scope` — the five places the admin console genuinely differs

Layers 4–5 required adding one class to five template root elements. Nothing was dropped.

---

## 7. Conflicts encountered

| # | Conflict | Resolution |
|---|---|---|
| 1 | Four apps claimed `/login`; three claimed `/dashboard`, `/profile` | Namespaced each portal; 32 files re-pathed |
| 2 | Five different localStorage token keys | `SessionService` fans one JWT to all keys |
| 3 | `apiBase` vs `apiBaseUrl` | Unified environment exposes both |
| 4 | Auth module called port **8081** directly; other four used gateway **8080** | Auth pointed at the gateway (change #1 below) |
| 5 | Five `AuthService` / four `authGuard` / four `authInterceptor` class names | Kept separate per module; only interceptors consolidated |
| 6 | Five root components all with selector `app-root` | Each became its module's wrapper with a unique selector |
| 7 | Legal root gated the *whole app* on `authReady()` | Scoped to `/legal` via its wrapper component |
| 8 | Per-module toast hosts lived on the app root | Each module's wrapper carries its own toast host |
| 9 | Import depth changed (`app/x` → `app/<mod>/x`) | 31 cross-boundary imports rewritten programmatically |
| 10 | Same-named assets across projects | All were the same two images (md5-verified); emitted under every referenced name |
| 11 | Logging out of one portal left other portals reachable | `clearHlmsSession()` added to all five `logout()` methods |
| 12 | Bank office `roleGuard` redirect loop | Redirect changed to `/` (change #4 below) |

---

## 8. Every change made to existing code

Thirteen files carry an `INTEGRATION CHANGE` or `INTEGRATION FIX` comment. In full:

**1. `auth/core/services/auth.service.ts` — API base path**
`${environment.apiBaseUrl}/api` → `${environment.apiBaseUrl}${environment.services.user}/api`.
*Why:* the auth app proxied `/api` straight to user-service on port 8081; the other four go through the API Gateway on 8080 using the `/user-service` prefix. One base path, same endpoints and payloads. Unavoidable — two different backends can't both be the single app's backend.

**2. `auth/pages/auth/login/login.component.ts` — role dispatch**
After OTP verification, `router.navigateByUrl('/')` → `SessionService.establish()` then redirect by role.
*Why:* the standalone auth app returned to `/` because it had no dashboards. Login logic, validation, OTP handling and forgot-password flow are all untouched.

**3. Five `logout()` methods (auth, customer, admin, bankoffice, legal) — one added line**
`clearHlmsSession();`
*Why:* each module cleared only its own key. Signing out of the customer portal would leave `hlms_admin_token` etc. intact and the other portals still reachable — a real security hole created by the shared session.

**4. `bankoffice/core/guards/role.guard.ts` — redirect target**
`router.navigate(['/app'])` → `router.navigate(['/'])`.
*Why:* `/app` became `/officer`, which redirects to `bodash`, which re-enters this guard — an infinite redirect loop for any non-bank-office role. Verified fixed by test.

**5. `bankoffice/core/interceptors/error.interceptor.ts` — scoping**
Added an early return when the active URL isn't under `/officer`.
*Why:* it is now registered app-wide but its toast host only renders inside the Bank Office wrapper.

**6. Four root components — selector rename only**
`app-root` → `app-customer-root` / `app-admin-root` / `app-bankoffice-root` / `app-legal-root`; files renamed to `*-root*.ts`.
*Why:* `index.html` can only have one `<app-root>`. Templates and logic are byte-identical otherwise.

**7. `bankoffice/features/bankoffice/bo-docs/bo-docs.component.ts` — missing imports**
Added `import { NotificationService }` and `import { AuthService }`.
*Why:* **pre-existing defect in the upload** — both were `inject()`ed but never imported, so this file could not compile as shipped (both injections are also unused). Imports added rather than deleting the author's lines.

**8. `tsconfig.json` — `"useDefineForClassFields": false`**
*Why:* **pre-existing requirement** — the auth project's own `tsconfig.json` had this flag; the other four omitted it. Its login/register components initialise reactive forms from a constructor parameter property (`form = this.fb.nonNullable.group(...)`), which raises `TS2729` without it.

**9. Five template root elements — one CSS class added**
`class="auth-page"` on the auth home/login/register roots, `class="admin-scope"` on the admin shell and login roots. No logic touched.

**10. 32 files — navigation path prefixes**, and **31 files — import depth**. Mechanical; both applied by script and verified.

That is the complete list. No form validation, no API call, no business logic, no error handling and no component behaviour was altered anywhere.

---

## 9. Build and test status

**Build — passing.**

```
ng build --configuration development   ✓  2.03 MB
ng build --configuration production    ✓  490.15 kB initial (129.76 kB transfer), 71 lazy chunks
```

Zero TypeScript errors, zero Angular errors, zero missing dependencies, zero broken references.

**Runtime — verified.** The production bundle was booted headlessly against a mock API gateway.

*Login and role dispatch (drove the real form: credentials → demo OTP read from the page → verify):*

```
CUSTOMER      PASS  -> /customer/dashboard    session keys: all 6 written
ADMIN         PASS  -> /admin/dashboard       session keys: all 6 written
BANK_OFFICER  PASS  -> /officer/bodash        session keys: all 6 written
LEGAL         PASS  -> /legal/dashboard       session keys: all 6 written
BIDDER        PASS  stayed on /login — "Your account role does not have a portal…"
```

*Access control — a CUSTOMER session attempting staff portals:*

```
/customer/dashboard  -> /customer/dashboard   (own portal, renders)
/admin/dashboard     -> /login                (refused)
/officer/bodash      -> /                     (refused, no loop)
/legal/dashboard     -> /login                (refused)
```

*Logout:* all 6 session keys cleared from every module, redirected to `/`.

*Route sweep — all 32 portal screens rendered with content:* **32 passed, 0 failed.**

*Unauthenticated access* to all four dashboards correctly redirects to `/login`.

**Remaining build warnings** (all pre-existing in the uploads, none blocking, left untouched):
- `TS-998113` unused `RouterLinkActive` import in `AdminShellComponent`
- `NG8107` ×2 unnecessary `?.` in `customer/features/eligibility`

---

## 10. Requires manual configuration

1. **Backend must be running.** `proxy.conf.json` forwards all six `/<service>-service` prefixes to the API Gateway at `http://localhost:8080`. Change the targets if your gateway differs.
2. **The auth module now calls the gateway, not port 8081.** If you intend to keep user-service reachable directly, add a `/api → 8081` proxy entry and revert change #1.
3. **The OTP step is demo-only.** The auth module generates and displays the OTP client-side (`generateOtpStatic()`); it is not a backend OTP. The bank office `AuthService` has real `generateOtp`/`verifyOtp` calls to `/otp/generate` and `/otp/verify` that are not currently wired into the shared login — worth connecting when the backend OTP endpoints are ready.
4. **No BIDDER portal exists** in any uploaded project. Bidder logins are refused at `/login`. If you have a bidder UI, mount it and add its route to `ROLE_HOME` in `session.service.ts`.
5. **`admin` module's `EMPLOYEE` role** has no matching value in the backend `roleEnum` — flagged in the original project's own README and still true.
6. The pre-existing API gaps documented in `API_GAPS.md` (customer) and `README_API_GAPS.md` (legal) are unchanged by this integration.

---

## 11. Running it

```bash
npm install
npm start          # ng serve with proxy.conf.json, opens http://localhost:4200
npm run build      # production build -> dist/hlms-integrated
```
