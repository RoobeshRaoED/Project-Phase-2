import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, forkJoin, of, catchError } from 'rxjs';

import { environment } from '../../../../environments/environment';
import { AppUser, BackendRole, RegisterRequest } from '../models/user.model';

@Injectable({ providedIn: 'root' })
export class UserService {
  private readonly base = `${environment.apiBaseUrl}${environment.services.user}/api/users`;

  constructor(private http: HttpClient) {}

  /** GET /user-service/api/users/{email} — EXISTS in backend. */
  getByEmail(email: string): Observable<AppUser> {
    return this.http.get<AppUser>(`${this.base}/${encodeURIComponent(email)}`);
  }

  /**
   * GET /user-service/api/users?role={role} — DOES NOT EXIST YET.
   * appUserController currently has no "list users" endpoint at all, so
   * there is no way to populate the Dashboard counts or the
   * Bidder/Employee/Legal/Bank Office management tables from real data.
   * See README.md → "Missing / Broken Endpoints" #1 for the exact
   * controller/service/repository code needed to add this.
   *
   * Implemented here against the endpoint we *expect* the backend to
   * gain, so the screen will start working the moment it's added —
   * no frontend changes required. Until then it fails gracefully and
   * the UI shows an inline banner instead of silently looking empty.
   */
  listByRole(role: BackendRole | 'EMPLOYEE'): Observable<AppUser[]> {
    return this.http.get<AppUser[]>(`${this.base}`, { params: { role } }).pipe(
      catchError(() => of([] as AppUser[]))
    );
  }

  /** Fetches several roles in parallel (used by the Dashboard for counts). */
  listByRoles(roles: (BackendRole | 'EMPLOYEE')[]): Observable<Record<string, AppUser[]>> {
    const calls = roles.reduce((acc, role) => {
      acc[role] = this.listByRole(role);
      return acc;
    }, {} as Record<string, Observable<AppUser[]>>);
    return forkJoin(calls);
  }

  /** POST /user-service/api/users/register — EXISTS in backend (used for "Add Staff"). */
  register(payload: RegisterRequest): Observable<AppUser> {
    return this.http.post<AppUser>(`${this.base}/register`, payload);
  }

  /**
   * PUT /user-service/api/users/{email} — EXISTS, but the service
   * implementation only persists name/mobile/prefEmail/prefSms/prefInapp.
   * `role` and `active` sent in the body are silently ignored server-side.
   * See README → "Missing / Broken Endpoints" #2.
   */
  updateProfile(email: string, patch: Partial<AppUser>): Observable<AppUser> {
    return this.http.put<AppUser>(`${this.base}/${encodeURIComponent(email)}`, patch);
  }

  /**
   * PATCH /user-service/api/users/{email}/status — DOES NOT EXIST.
   * Needed to activate/deactivate a staff account (Deactivate / Activate
   * buttons in the management tables). Calling the existing PUT endpoint
   * would not work because `active` is ignored by updateUser() today.
   * See README → "Missing / Broken Endpoints" #2.
   */
  setActive(email: string, active: boolean): Observable<AppUser> {
    return this.http.patch<AppUser>(`${this.base}/${encodeURIComponent(email)}/status`, { active });
  }

  /** DELETE /user-service/api/users/{email} — EXISTS (soft delete via deletedAt). */
  deleteUser(email: string): Observable<string> {
    return this.http.delete(`${this.base}/${encodeURIComponent(email)}`, { responseType: 'text' });
  }

  /**
   * POST /user-service/api/users/forgot-password — EXISTS, but has a bug:
   * the generated OTP is returned directly in the response body and is
   * never persisted anywhere (not saved against the user / otp table).
   * See README → "Missing / Broken Endpoints" #3.
   */
  requestPasswordOtp(email: string): Observable<string> {
    return this.http.post(`${this.base}/forgot-password`, { email }, { responseType: 'text' });
  }

  /**
   * POST /user-service/api/users/reset-password — EXISTS, but
   * resetPassword() never checks `otpCode` against anything (see the
   * bug noted on requestPasswordOtp above), so today ANY otpCode value
   * is accepted. There is also no authenticated "current password +
   * new password" endpoint for a logged-in user's own Profile screen —
   * this OTP flow is the only working substitute until one is added.
   */
  resetPassword(email: string, otpCode: string, newPassword: string): Observable<string> {
    return this.http.post(
      `${this.base}/reset-password`,
      { email, otpCode, newPassword },
      { responseType: 'text' }
    );
  }
}
