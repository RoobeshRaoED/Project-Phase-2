import { HttpInterceptorFn } from '@angular/common/http';
import { environment } from '../../../../environments/environment';

const TOKEN_KEY = 'hlms_admin_token';

/**
 * Attaches "Authorization: Bearer <jwt>" to every request that targets our
 * own API Gateway. Every user-service endpoint except register/login/
 * forgot-password/reset-password requires this header (see SecurityConfig).
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const token = localStorage.getItem(TOKEN_KEY);
  const isApiCall = req.url.startsWith(environment.apiBaseUrl);
  if (token && isApiCall) {
    req = req.clone({ setHeaders: { Authorization: `Bearer ${token}` } });
  }
  return next(req);
};
