import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../shared/toast/toast.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private toast = inject(ToastService);

  showPassword = false;
  submitting = false;
  errorMsg = '';

  form = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required]]
  });

  constructor() {
    const reason = this.route.snapshot.queryParamMap.get('reason');
    if (reason === 'not-admin') {
      this.errorMsg = 'That account is not an HLMS Admin account. This console is for administrators only.';
    }
  }

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.submitting = true;
    this.errorMsg = '';
    this.auth.login(this.form.getRawValue()).subscribe({
      next: (user) => {
        this.submitting = false;
        if (user.role !== 'ADMIN') {
          this.auth.logout();
          this.errorMsg = 'That account is not an HLMS Admin account. This console is for administrators only.';
          return;
        }
        this.toast.success('Welcome back', `Signed in as ${user.name}.`);
        this.router.navigateByUrl('/admin/dashboard');
      },
      error: (err) => {
        this.submitting = false;
        this.errorMsg =
          err?.status === 0
            ? 'Could not reach the HLMS API Gateway. Is it running on ' + 'the configured apiBaseUrl?'
            : err?.error?.message || 'Invalid email or password.';
      }
    });
  }
}
