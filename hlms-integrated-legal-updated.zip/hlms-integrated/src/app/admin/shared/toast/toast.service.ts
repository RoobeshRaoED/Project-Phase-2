import { Injectable, signal } from '@angular/core';

export type ToastType = 'info' | 'success' | 'error';
export interface ToastMsg { id: number; title: string; body?: string; type: ToastType; }

@Injectable({ providedIn: 'root' })
export class ToastService {
  private nextId = 1;
  readonly toasts = signal<ToastMsg[]>([]);

  show(title: string, body?: string, type: ToastType = 'info'): void {
    const id = this.nextId++;
    this.toasts.update((list) => [...list, { id, title, body, type }]);
    setTimeout(() => this.dismiss(id), 4200);
  }

  success(title: string, body?: string): void { this.show(title, body, 'success'); }
  error(title: string, body?: string): void { this.show(title, body, 'error'); }

  dismiss(id: number): void {
    this.toasts.update((list) => list.filter((t) => t.id !== id));
  }
}
