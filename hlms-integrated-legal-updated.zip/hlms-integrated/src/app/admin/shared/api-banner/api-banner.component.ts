import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-api-banner',
  standalone: true,
  template: `
    <div class="api-banner">
      <span>⚠️</span>
      <span>
        <b>{{ title }}</b><br>
        {{ message }}
        @if (endpoint) { <br><code>{{ endpoint }}</code> }
        <br>See <b>README.md → Missing / Broken Endpoints</b> for details.
      </span>
    </div>
  `
})
export class ApiBannerComponent {
  @Input() title = 'Backend endpoint not available yet';
  @Input() message = 'This screen is fully wired up, but the backend does not yet expose the data it needs.';
  @Input() endpoint = '';
}
