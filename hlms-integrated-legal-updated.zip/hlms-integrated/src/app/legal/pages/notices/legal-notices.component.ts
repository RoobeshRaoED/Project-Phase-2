import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { forkJoin } from 'rxjs';
import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';
import { LegalNoticeService } from '../../core/services/legal-notice.service';
import { LoanApplicationService } from '../../core/services/loan-application.service';
import { NotificationService } from '../../core/services/notification.service';
import { LegalNoticeDTO, LoanApplication } from '../../core/models/models';

interface NoticeRow extends LegalNoticeDTO { trackingNo: string; applicantName: string; userEmail: string; }

const NOTICE_TYPES = ['Demand Notice', 'SARFAESI Notice', 'Possession Notice', 'General Legal Notice'];

@Component({
  selector: 'app-legal-notices',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './legal-notices.component.html'
})
export class LegalNoticesComponent implements OnInit {
  loading = signal(true);
  notices = signal<NoticeRow[]>([]);
  apps = signal<LoanApplication[]>([]);
  noticeTypes = NOTICE_TYPES;

  draftModalOpen = signal(false);
  draft = { appId: '', noticeType: NOTICE_TYPES[0], dueInDays: 30, content: '' };
  draftError = signal<string | null>(null);
  saving = signal(false);

  constructor(
    public auth: AuthService,
    private toast: ToastService,
    private noticeSvc: LegalNoticeService,
    private loanSvc: LoanApplicationService,
    private notifSvc: NotificationService
  ) {}

  ngOnInit(): void {
    this.loadAll();
  }

  private loadAll(): void {
    this.loading.set(true);
    forkJoin({ notices: this.noticeSvc.listAll(), apps: this.loanSvc.listAll() }).subscribe({
      next: ({ notices, apps }) => {
        this.apps.set(apps);
        const byId = new Map<string, LoanApplication>(apps.map((a) => [a.appId, a]));
        this.notices.set(
          notices
            .map((n) => ({
              ...n,
              trackingNo: n.appId ? (byId.get(n.appId)?.trackingNo || n.appId) : '—',
              applicantName: n.appId ? (byId.get(n.appId)?.applicantName || '—') : '—',
              userEmail: n.appId ? (byId.get(n.appId)?.userEmail || '') : ''
            }))
            .sort((a, b) => new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime())
        );
        this.loading.set(false);
      },
      error: () => {
        this.loading.set(false);
        this.toast.error('Could not load notices', 'Please refresh the page to try again.');
      }
    });
  }

  statusBadge(status: string): string {
    return status === 'Active' ? 'badge-orange' : 'badge-gray';
  }

  openDraft(): void {
    this.draft = { appId: '', noticeType: NOTICE_TYPES[0], dueInDays: 30, content: '' };
    this.draftError.set(null);
    this.draftModalOpen.set(true);
  }

  closeDraft(): void {
    this.draftModalOpen.set(false);
  }

  submitDraft(): void {
    const officer = this.auth.currentUser();
    if (!officer) return;
    if (!this.draft.appId || !this.draft.content.trim()) {
      this.draftError.set('Please select an application and enter the notice content.');
      return;
    }
    const app = this.apps().find((a) => a.appId === this.draft.appId);
    const now = new Date();
    const due = new Date(now.getTime() + this.draft.dueInDays * 24 * 60 * 60 * 1000);
    const dto: LegalNoticeDTO = {
      noticeNo: 'LN-' + Date.now(),
      appId: this.draft.appId,
      noticeType: this.draft.noticeType,
      issueDate: now.toISOString(),
      dueDate: due.toISOString(),
      status: 'Active',
      officerEmail: officer.email,
      content: this.draft.content.trim()
    };
    this.saving.set(true);
    this.noticeSvc.create(dto).subscribe({
      next: () => {
        this.saving.set(false);
        this.toast.success('Notice Issued', dto.noticeNo);
        if (app) {
          this.notifSvc.send(app.userEmail, dto.noticeType, dto.content).subscribe();
        }
        this.closeDraft();
        this.loadAll();
      },
      error: () => {
        this.saving.set(false);
        this.draftError.set('Could not issue notice. Please try again.');
      }
    });
  }
}
