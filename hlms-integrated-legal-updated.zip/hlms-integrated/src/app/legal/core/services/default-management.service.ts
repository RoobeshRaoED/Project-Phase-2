import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, of } from 'rxjs';
import { environment } from '../../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class DefaultManagementService {
  private base = `${environment.apiBase}/repayment-service/api/default-management`;

  constructor(private http: HttpClient) {}

  /** Set of appIds that currently have at least one overdue EMI installment. */
  detectOverdueLoans(): Observable<string[]> {
    return this.http.get<string[]>(`${this.base}/overdue`).pipe(
      catchError(() => of([] as string[]))
    );
  }
}
