import { Injectable } from '@angular/core';
import { catchError, forkJoin, map, Observable, of, switchMap } from 'rxjs';
import { LoanApplicationService } from './loan-application.service';
import { LegalVerificationService } from './legal-verification.service';
import { DocumentService } from './document.service';
import { AuctionService } from './auction.service';
import { DefaultManagementService } from './default-management.service';
import { EmiInstallmentService } from './emi-installment.service';
import { LegalQueueRow, LoanApplication, OverdueAccount } from '../models/models';

/**
 * Composes data from loan-service, legal-service, document-service and
 * repayment-service into the shapes the Legal Team UI needs. The backend
 * has no single "legal review queue" or "auction snapshot" endpoint, so
 * this service does the joining client-side (see README_API_GAPS.md).
 */
@Injectable({ providedIn: 'root' })
export class LegalDataService {
  private legalStageIndex$?: Observable<number>;
  private documentStageIndex$?: Observable<number>;

  constructor(
    private loanSvc: LoanApplicationService,
    private verificationSvc: LegalVerificationService,
    private docSvc: DocumentService,
    private auctionSvc: AuctionService,
    private defaultMgmtSvc: DefaultManagementService,
    private emiSvc: EmiInstallmentService
  ) {}

  getLegalStageIndex(): Observable<number> {
    if (!this.legalStageIndex$) {
      this.legalStageIndex$ = this.loanSvc.workflowStages().pipe(
        map((stages) => {
          const idx = stages.findIndex((s) => s.toLowerCase().includes('legal'));
          return idx >= 0 ? idx : 3;
        })
      );
    }
    return this.legalStageIndex$;
  }

  // Index of the "Document Verification" stage - the stage right before
  // "Legal Verification". StatusTrackingService on loan-service already
  // treats stageIndex >= "Document Verification" as belonging to the legal
  // team ("With the legal team for document/title verification."), so the
  // Legal Team - not Bank Office - verifies documents here and forwards
  // the case on to Legal Verification themselves.
  getDocumentStageIndex(): Observable<number> {
    if (!this.documentStageIndex$) {
      this.documentStageIndex$ = this.loanSvc.workflowStages().pipe(
        map((stages) => {
          const idx = stages.findIndex((s) => s.toLowerCase().includes('document'));
          return idx >= 0 ? idx : 2;
        })
      );
    }
    return this.documentStageIndex$;
  }

  /**
   * Applications currently sitting at the Document Verification stage,
   * waiting on the Legal Team to verify the submitted documents and
   * forward the case on to Legal Verification. Bank Office can only
   * forward the case past this stage once the Legal Team has done so.
   */
  getDocumentQueue(): Observable<LegalQueueRow[]> {
    return this.getDocumentStageIndex().pipe(
      switchMap((documentStageIndex) =>
        this.loanSvc.listAll().pipe(
          map((apps) => apps.filter((a) => a.stageIndex === documentStageIndex && a.status !== 'Rejected' && a.status !== 'Disbursed')),
          switchMap((pendingApps) => {
            if (pendingApps.length === 0) return of([] as LegalQueueRow[]);
            return forkJoin(
              pendingApps.map((app) =>
                this.docSvc.listApplicationDocuments(app.appId).pipe(
                  map((docs): LegalQueueRow => ({
                    app,
                    verification: null,
                    locked: false,
                    docsVerified: docs.length > 0 && docs.every((d) => d.verificationStatus === 'Verified')
                  }))
                )
              )
            );
          })
        )
      ),
      catchError(() => of([] as LegalQueueRow[]))
    );
  }

  /** True once every document uploaded for this application has been verified by Bank Office. */
  isReadyForLegalReview(appId: string): Observable<boolean> {
    return this.docSvc.listApplicationDocuments(appId).pipe(
      map((docs) => docs.length === 0 || docs.every((d) => d.verificationStatus === 'Verified'))
    );
  }

  /** All applications currently sitting at the Legal Verification stage, split into ready / locked. */
  getQueue(): Observable<{ ready: LegalQueueRow[]; locked: LegalQueueRow[] }> {
    return this.getLegalStageIndex().pipe(
      switchMap((legalStageIndex) =>
        this.loanSvc.listAll().pipe(
          map((apps) => apps.filter((a) => a.stageIndex === legalStageIndex && a.status === 'Under Review')),
          switchMap((pendingApps) => {
            if (pendingApps.length === 0) return of([] as LegalQueueRow[]);
            return forkJoin(
              pendingApps.map((app) =>
                forkJoin({
                  verification: this.verificationSvc.getByApplication(app.appId),
                  locked: this.isReadyForLegalReview(app.appId).pipe(map((ready) => !ready))
                }).pipe(map(({ verification, locked }): LegalQueueRow => ({ app, verification, locked })))
              )
            );
          })
        )
      ),
      map((rows) => ({
        ready: rows.filter((r) => !r.locked),
        locked: rows.filter((r) => r.locked)
      })),
      catchError(() => of({ ready: [] as LegalQueueRow[], locked: [] as LegalQueueRow[] }))
    );
  }

  /** Applications that have already moved past (or been rejected out of) the Legal stage, with their decision. */
  getRecentlyActioned(): Observable<LegalQueueRow[]> {
    return this.getLegalStageIndex().pipe(
      switchMap((legalStageIndex) =>
        this.loanSvc.listAll().pipe(
          map((apps) => apps.filter((a) => !(a.stageIndex === legalStageIndex && a.status === 'Under Review') && a.stageIndex >= legalStageIndex)),
          switchMap((apps) => {
            if (apps.length === 0) return of([] as LegalQueueRow[]);
            return forkJoin(
              apps.map((app) =>
                this.verificationSvc.getByApplication(app.appId).pipe(
                  map((verification): LegalQueueRow => ({ app, verification, locked: false }))
                )
              )
            );
          })
        )
      ),
      catchError(() => of([] as LegalQueueRow[]))
    );
  }

  /** Accounts with at least one overdue EMI, joined with loan + auction info, for the recovery/SARFAESI views. */
  getOverdueAccounts(): Observable<OverdueAccount[]> {
    return this.defaultMgmtSvc.detectOverdueLoans().pipe(
      switchMap((appIds) => {
        if (!appIds || appIds.length === 0) return of([] as OverdueAccount[]);
        return forkJoin(
          appIds.map((appId) =>
            forkJoin({
              app: this.loanSvc.get(appId),
              auction: this.auctionSvc.getByApplication(appId),
              schedule: this.emiSvc.getSchedule(appId)
            }).pipe(
              map(({ app, auction, schedule }): OverdueAccount | null => {
                if (!app) return null; // stale appId (e.g. app since deleted) - drop this row
                // Backend's EmiInstallment.status is uppercase: PENDING | PAID | OVERDUE
                // (see EmiInstallmentServiceImpl.VALID_STATUSES) - matching on title-case
                // strings here would silently never flag anything as overdue.
                const overdueCount = schedule.filter((s) => s.status === 'OVERDUE' || (s.status !== 'PAID' && new Date(s.dueDate) < new Date())).length;
                const lastInstallment = schedule.length ? schedule[schedule.length - 1] : null;
                const outstandingBalance = lastInstallment?.closingBalance ?? 0;
                return {
                  app,
                  auction: auction ?? { appId, stage: 'None' },
                  outstandingBalance,
                  overdueCount
                };
              })
            )
          )
        );
      }),
      map((rows) => rows.filter((r): r is OverdueAccount => !!r && r.overdueCount > 0)),
      // Last line of defence: if anything upstream still throws, don't take the whole
      // dashboard/auction page down with it - just show zero overdue accounts.
      catchError(() => of([] as OverdueAccount[]))
    );
  }
}
