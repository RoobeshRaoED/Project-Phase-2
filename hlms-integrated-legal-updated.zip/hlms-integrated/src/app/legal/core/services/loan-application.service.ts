import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, map, of, shareReplay } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { LoanApplication } from '../models/models';

interface LoanProductLite { productId: string; name: string; }

@Injectable({ providedIn: 'root' })
export class LoanApplicationService {
  private base = `${environment.apiBase}/loan-service/api/loan-applications`;
  private productsUrl = `${environment.apiBase}/loan-service/api/loan-products`;

  constructor(private http: HttpClient) {}

  // Called directly (no legal-data.service wrapper) from the Document Center, Notices and
  // Auction & SARFAESI pages' own forkJoins - a bare failure here used to take down the whole
  // page's forkJoin and land it on the "Could not load" error state even though every sibling
  // method (get(), listAllApplicationDocuments(), etc.) already degrades gracefully. Matches
  // that same pattern now: an empty list here is a "0 applications" state, not a fatal error.
  listAll(): Observable<LoanApplication[]> {
    return this.http.get<LoanApplication[]>(`${this.base}/all`).pipe(
      catchError((err) => {
        console.error('[LoanApplicationService] listAll() failed - treating as empty:', err);
        return of([] as LoanApplication[]);
      })
    );
  }

  // Fanned out per-appId inside LegalDataService.getOverdueAccounts()'s forkJoin. appIds there
  // come straight from the backend's own /overdue list, so a 404 here means stale/inconsistent
  // data rather than a real client error - drop that one row instead of failing the whole page.
  get(appId: string): Observable<LoanApplication | null> {
    return this.http.get<LoanApplication>(`${this.base}/${appId}`).pipe(
      catchError(() => of(null))
    );
  }

  workflowStages(): Observable<string[]> {
    return this.http.get<string[]>(`${this.base}/workflow-stages`);
  }

  /** Moves an application to a new workflow stage / status (used when Legal approves a case). */
  updateStage(appId: string, stageIndex: number, status: string): Observable<LoanApplication> {
    return this.http.patch<LoanApplication>(`${this.base}/${appId}/stage`, { stageIndex, status });
  }

  // productId -> display name (e.g. "HPL01" -> "Home Purchase Loan"). LoanApplication
  // only stores the productId FK, so "Loan Type" on any screen needs this lookup -
  // fetched once per session and shared across every page that needs it.
  private productNameMap$?: Observable<Record<string, string>>;
  getProductNameMap(): Observable<Record<string, string>> {
    if (!this.productNameMap$) {
      this.productNameMap$ = this.http.get<LoanProductLite[]>(this.productsUrl).pipe(
        map((list) => Object.fromEntries((list || []).map((p) => [p.productId, p.name]))),
        shareReplay(1)
      );
    }
    return this.productNameMap$;
  }
}
