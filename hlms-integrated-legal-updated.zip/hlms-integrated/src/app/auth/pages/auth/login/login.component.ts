import { CommonModule } from '@angular/common';
import { Component, ElementRef, QueryList, ViewChildren } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { AuthService } from '../../../core/services/auth.service';
import { readableApiError } from '../../../core/services/api-error.util';
import { HlmsValidators } from '../../../core/validators/hlms-validators';
import { SessionService } from '../../../../core/session/session.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './login.component.html'
})
export class LoginComponent {
  @ViewChildren('loginOtpBox') loginOtpInputs!: QueryList<ElementRef<HTMLInputElement>>;
  @ViewChildren('forgotOtpBox') forgotOtpInputs!: QueryList<ElementRef<HTMLInputElement>>;

  showPassword = false;
  showResetPassword = false;
  showConfirmResetPassword = false;

  loading = false;
  apiError = '';
  successMessage = '';

  otpStep = false;
  currentOtp = '';
  loginOtpGeneratedAt = 0;
  otpDigits = ['', '', '', '', '', ''];
  readonly otpExpiryMs = 5 * 60 * 1000;

  showForgotPassword = false;
  forgotLoading = false;
  forgotVerifying = false;
  resetLoading = false;
  forgotMessage = '';
  forgotError = '';
  forgotOtpStep = false;
  forgotOtpVerified = false;
  forgotGeneratedOtp = '';
  forgotOtpGeneratedAt = 0;
  forgotOtpDigits = ['', '', '', '', '', ''];

  form = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.email, Validators.maxLength(100)]],
    password: ['', [Validators.required, HlmsValidators.password()]]
  });

  forgotForm = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.email, Validators.maxLength(100)]]
  });

  resetForm = this.fb.nonNullable.group({
    newPassword: ['', [Validators.required, HlmsValidators.password()]],
    confirmPassword: ['', [Validators.required]]
  }, {
    validators: [HlmsValidators.matchPassword('newPassword', 'confirmPassword')]
  });

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private session: SessionService
  ) {}

  trackByIndex(index: number): number {
    return index;
  }

  continueToOtp(): void {
    this.apiError = '';
    this.successMessage = '';
    this.form.markAllAsTouched();

    if (this.form.invalid) return;

    const value = this.form.getRawValue();

    this.loading = true;

    this.authService.login({
      email: value.email.trim(),
      password: value.password
    }).pipe(
      finalize(() => this.loading = false)
    ).subscribe({
      next: () => {
        this.currentOtp = this.generateOtpStatic();
        this.loginOtpGeneratedAt = Date.now();
        this.otpStep = true;

        this.resetOtpBoxes(this.otpDigits, this.loginOtpInputs);

        this.successMessage = 'Credentials verified. Enter the OTP to continue.';

        setTimeout(() => {
          this.focusOtp(this.loginOtpInputs, 0);
        }, 100);
      },
      error: (error) => {
        this.apiError = readableApiError(
          error,
          'Invalid email or password.'
        );
      }
    });
  }

  submit(): void {
    if (!this.otpStep) {
      this.continueToOtp();
      return;
    }

    this.verifyOtpAndLogin();
  }

  onLoginOtpInput(event: Event, index: number): void {
    this.handleOtpInput(event, index, this.otpDigits, this.loginOtpInputs);
  }

  onLoginOtpKeydown(event: KeyboardEvent, index: number): void {
    this.handleOtpKeydown(event, index, this.otpDigits, this.loginOtpInputs);
  }

  onLoginOtpPaste(event: ClipboardEvent, index: number): void {
    this.handleOtpPaste(event, index, this.otpDigits, this.loginOtpInputs);
  }

  verifyOtpAndLogin(): void {
    this.apiError = '';
    this.successMessage = '';

    const enteredOtp = this.otpDigits.join('');

    const validationMessage = this.validateOtp(
      this.currentOtp,
      enteredOtp,
      this.loginOtpGeneratedAt
    );

    if (validationMessage) {
      this.apiError = validationMessage;
      return;
    }

    this.successMessage = 'OTP verified successfully. Login successful.';

    // INTEGRATION CHANGE: the standalone auth app always returned to '/' because
    // it had no dashboards to go to. Now that all four portals live in the same
    // app, the session is published to every module and the user is sent to the
    // dashboard matching the role in their JWT.
    this.loading = true;
    this.session.establish()
      .pipe(finalize(() => this.loading = false))
      .subscribe({
        next: (target) => {
          if (!target) {
            this.session.clear();
            this.otpStep = false;
            this.successMessage = '';
            this.apiError = 'Your account role does not have a portal in this application yet.';
            return;
          }
          setTimeout(() => this.router.navigateByUrl(target), 400);
        },
        error: () => {
          this.session.clear();
          this.apiError = 'Signed in, but the user profile could not be loaded. Please try again.';
        }
      });
  }

  resendOtp(): void {
    this.currentOtp = this.generateOtpStatic();
    this.loginOtpGeneratedAt = Date.now();

    this.resetOtpBoxes(this.otpDigits, this.loginOtpInputs);

    this.apiError = '';
    this.successMessage = 'A new demo OTP has been generated.';

    setTimeout(() => {
      this.focusOtp(this.loginOtpInputs, 0);
    }, 100);
  }

  backToCredentials(): void {
    this.otpStep = false;
    this.apiError = '';
    this.successMessage = '';
    this.currentOtp = '';
    this.loginOtpGeneratedAt = 0;

    this.resetOtpBoxes(this.otpDigits, this.loginOtpInputs);
  }

  openForgotPassword(): void {
    this.showForgotPassword = true;
    this.forgotError = '';
    this.forgotMessage = '';
    this.forgotOtpStep = false;
    this.forgotOtpVerified = false;
    this.forgotGeneratedOtp = '';
    this.forgotOtpGeneratedAt = 0;

    this.resetForm.reset();
    this.resetOtpBoxes(this.forgotOtpDigits, this.forgotOtpInputs);

    const email = this.form.controls.email.value.trim();

    if (email) {
      this.forgotForm.controls.email.setValue(email);
    }

    setTimeout(() => {
      document.getElementById('forgotEmail')?.focus();
    }, 100);
  }

  closeForgotPassword(): void {
    this.showForgotPassword = false;
    this.forgotError = '';
    this.forgotMessage = '';
    this.forgotOtpStep = false;
    this.forgotOtpVerified = false;
    this.forgotGeneratedOtp = '';
    this.forgotOtpGeneratedAt = 0;

    this.resetOtpBoxes(this.forgotOtpDigits, this.forgotOtpInputs);
  }

  sendForgotOtp(): void {
    this.forgotError = '';
    this.forgotMessage = '';
    this.forgotForm.markAllAsTouched();

    if (this.forgotForm.invalid) return;

    const email = this.forgotForm.controls.email.value.trim();

    this.forgotLoading = true;

    this.authService.forgotPassword({ email })
      .pipe(finalize(() => this.forgotLoading = false))
      .subscribe({
        next: (message) => {
          this.forgotGeneratedOtp = this.generateOtpStatic();
          this.forgotOtpGeneratedAt = Date.now();
          this.forgotOtpStep = true;
          this.forgotOtpVerified = false;
          this.forgotMessage = message || 'Forgot password request accepted. Use the demo OTP displayed above.';

          this.resetOtpBoxes(this.forgotOtpDigits, this.forgotOtpInputs);

          setTimeout(() => {
            this.focusOtp(this.forgotOtpInputs, 0);
          }, 100);
        },
        error: (error) => {
          this.forgotError = readableApiError(
            error,
            'Forgot password request failed. Please check the email and backend API.'
          );
        }
      });
  }

  resendForgotOtp(): void {
    this.forgotError = '';
    this.forgotMessage = 'A new demo OTP has been generated.';
    this.forgotGeneratedOtp = this.generateOtpStatic();
    this.forgotOtpGeneratedAt = Date.now();
    this.forgotOtpVerified = false;

    this.resetForm.reset();
    this.resetOtpBoxes(this.forgotOtpDigits, this.forgotOtpInputs);

    setTimeout(() => {
      this.focusOtp(this.forgotOtpInputs, 0);
    }, 100);
  }

  onForgotOtpInput(event: Event, index: number): void {
    this.handleOtpInput(event, index, this.forgotOtpDigits, this.forgotOtpInputs);
  }

  onForgotOtpKeydown(event: KeyboardEvent, index: number): void {
    this.handleOtpKeydown(event, index, this.forgotOtpDigits, this.forgotOtpInputs);
  }

  onForgotOtpPaste(event: ClipboardEvent, index: number): void {
    this.handleOtpPaste(event, index, this.forgotOtpDigits, this.forgotOtpInputs);
  }

  verifyForgotOtp(): void {
    this.forgotError = '';
    this.forgotMessage = '';

    const enteredOtp = this.forgotOtpDigits.join('');

    const validationMessage = this.validateOtp(
      this.forgotGeneratedOtp,
      enteredOtp,
      this.forgotOtpGeneratedAt
    );

    if (validationMessage) {
      this.forgotError = validationMessage;
      return;
    }

    this.forgotVerifying = true;

    setTimeout(() => {
      this.forgotVerifying = false;
      this.forgotOtpVerified = true;
      this.forgotMessage = 'OTP verified successfully. Enter your new password.';

      setTimeout(() => {
        document.getElementById('newPassword')?.focus();
      }, 100);
    }, 250);
  }

  resetPassword(): void {
    this.forgotError = '';
    this.forgotMessage = '';

    if (!this.forgotOtpVerified) {
      this.forgotError = 'OTP verification required before password reset.';
      return;
    }

    this.resetForm.markAllAsTouched();

    if (this.resetForm.invalid) return;

    const email = this.forgotForm.controls.email.value.trim();
    const value = this.resetForm.getRawValue();

    this.resetLoading = true;

    this.authService.resetPassword({
      email,
      otpCode: this.forgotGeneratedOtp,
      newPassword: value.newPassword
    }).pipe(
      finalize(() => this.resetLoading = false)
    ).subscribe({
      next: (message) => {
        this.forgotMessage = message || 'Password reset successful. You can log in with the new password.';

        setTimeout(() => {
          this.closeForgotPassword();
        }, 1200);
      },
      error: (error) => {
        this.forgotError = readableApiError(
          error,
          'Password reset failed. Please verify backend reset-password implementation and database update.'
        );
      }
    });
  }

  hasError(field: 'email' | 'password', error: string): boolean {
    const control = this.form.controls[field];
    return control.touched && control.hasError(error);
  }

  hasForgotEmailError(error: string): boolean {
    const control = this.forgotForm.controls.email;
    return control.touched && control.hasError(error);
  }

  hasResetError(field: 'newPassword' | 'confirmPassword', error: string): boolean {
    const control = this.resetForm.controls[field];
    return control.touched && control.hasError(error);
  }

  get resetPasswordMismatch(): boolean {
    return this.resetForm.touched && this.resetForm.hasError('passwordMismatch');
  }

  generateOtpStatic(): string {
    return Math.floor(100000 + Math.random() * 900000).toString();
  }

  verifyOtpStatic(generatedOtp: string, enteredOtp: string): boolean {
    return generatedOtp === enteredOtp;
  }

  private validateOtp(
    generatedOtp: string,
    enteredOtp: string,
    generatedAt: number
  ): string {
    if (enteredOtp.length !== 6) {
      return 'Enter the complete 6 digit OTP.';
    }

    if (!generatedOtp || !generatedAt) {
      return 'OTP not generated. Please resend OTP.';
    }

    if (Date.now() - generatedAt > this.otpExpiryMs) {
      return 'OTP expired. Please resend OTP.';
    }

    if (!this.verifyOtpStatic(generatedOtp, enteredOtp)) {
      return 'Invalid OTP';
    }

    return '';
  }

  private handleOtpInput(
    event: Event,
    index: number,
    digits: string[],
    inputs: QueryList<ElementRef<HTMLInputElement>>
  ): void {
    const input = event.target as HTMLInputElement;
    const value = input.value.replace(/\D/g, '');

    if (!value) {
      digits[index] = '';
      input.value = '';
      return;
    }

    if (value.length > 1) {
      this.fillOtpFromText(value, index, digits, inputs);
      return;
    }

    digits[index] = value;
    input.value = value;

    if (index < digits.length - 1) {
      this.focusOtp(inputs, index + 1);
    }
  }

  private handleOtpKeydown(
    event: KeyboardEvent,
    index: number,
    digits: string[],
    inputs: QueryList<ElementRef<HTMLInputElement>>
  ): void {
    const inputArray = inputs?.toArray() || [];

    if (event.key === 'Backspace') {
      event.preventDefault();

      if (digits[index]) {
        digits[index] = '';

        if (inputArray[index]) {
          inputArray[index].nativeElement.value = '';
        }

        return;
      }

      if (index > 0) {
        digits[index - 1] = '';

        if (inputArray[index - 1]) {
          inputArray[index - 1].nativeElement.value = '';
        }

        this.focusOtp(inputs, index - 1);
      }

      return;
    }

    if (event.key === 'Delete') {
      event.preventDefault();
      return;
    }

    if (event.key === 'ArrowLeft' && index > 0) {
      event.preventDefault();
      this.focusOtp(inputs, index - 1);
      return;
    }

    if (event.key === 'ArrowRight' && index < digits.length - 1) {
      event.preventDefault();
      this.focusOtp(inputs, index + 1);
      return;
    }

    if (
      event.key === 'Tab' ||
      event.key === 'Home' ||
      event.key === 'End'
    ) {
      return;
    }

    if (event.ctrlKey || event.metaKey) {
      return;
    }

    if (!/^\d$/.test(event.key)) {
      event.preventDefault();
    }
  }

  private handleOtpPaste(
    event: ClipboardEvent,
    index: number,
    digits: string[],
    inputs: QueryList<ElementRef<HTMLInputElement>>
  ): void {
    event.preventDefault();

    const pastedText = event.clipboardData?.getData('text') || '';
    this.fillOtpFromText(pastedText, index, digits, inputs);
  }

  private fillOtpFromText(
    text: string,
    startIndex: number,
    digits: string[],
    inputs: QueryList<ElementRef<HTMLInputElement>>
  ): void {
    const inputArray = inputs?.toArray() || [];

    const pastedDigits = text
      .replace(/\D/g, '')
      .slice(0, digits.length - startIndex)
      .split('');

    if (!pastedDigits.length) return;

    pastedDigits.forEach((digit, offset) => {
      const targetIndex = startIndex + offset;

      digits[targetIndex] = digit;

      if (inputArray[targetIndex]) {
        inputArray[targetIndex].nativeElement.value = digit;
      }
    });

    const nextIndex = Math.min(
      startIndex + pastedDigits.length,
      digits.length - 1
    );

    this.focusOtp(inputs, nextIndex);
  }

  private focusOtp(
    inputs: QueryList<ElementRef<HTMLInputElement>>,
    index: number
  ): void {
    setTimeout(() => {
      const input = inputs?.toArray()[index]?.nativeElement;

      if (!input) return;

      input.focus();
      input.select();
    }, 0);
  }

  private resetOtpBoxes(
    digits: string[],
    inputs: QueryList<ElementRef<HTMLInputElement>>
  ): void {
    digits.splice(0, digits.length, '', '', '', '', '', '');

    setTimeout(() => {
      inputs?.forEach((input) => {
        input.nativeElement.value = '';
      });
    }, 0);
  }
}

// import { CommonModule } from '@angular/common';
// import { Component, ElementRef, QueryList, ViewChildren } from '@angular/core';
// import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
// import { Router, RouterLink } from '@angular/router';
// import { finalize } from 'rxjs';
// import { AuthService } from '../../../core/services/auth.service';
// import { readableApiError } from '../../../core/services/api-error.util';
// import { HlmsValidators } from '../../../core/validators/hlms-validators';

// @Component({
//   selector: 'app-login',
//   standalone: true,
//   imports: [CommonModule, ReactiveFormsModule, RouterLink],
//   templateUrl: './login.component.html'
// })
// export class LoginComponent {
//   @ViewChildren('loginOtpBox') loginOtpInputs!: QueryList<ElementRef<HTMLInputElement>>;
//   @ViewChildren('forgotOtpBox') forgotOtpInputs!: QueryList<ElementRef<HTMLInputElement>>;

//   showPassword = false;
//   showResetPassword = false;
//   showConfirmResetPassword = false;

//   loading = false;
//   apiError = '';
//   successMessage = '';

//   otpStep = false;
//   currentOtp = '';
//   loginOtpGeneratedAt = 0;
//   otpDigits = ['', '', '', '', '', ''];
//   readonly otpExpiryMs = 5 * 60 * 1000;

//   showForgotPassword = false;
//   forgotLoading = false;
//   forgotVerifying = false;
//   resetLoading = false;
//   forgotMessage = '';
//   forgotError = '';
//   forgotOtpStep = false;
//   forgotOtpVerified = false;
//   forgotGeneratedOtp = '';
//   forgotOtpGeneratedAt = 0;
//   forgotOtpDigits = ['', '', '', '', '', ''];

//   form = this.fb.nonNullable.group({
//     email: ['', [Validators.required, Validators.email, Validators.maxLength(100)]],
//     password: ['', [Validators.required, HlmsValidators.password()]]
//   });

//   forgotForm = this.fb.nonNullable.group({
//     email: ['', [Validators.required, Validators.email, Validators.maxLength(100)]]
//   });

//   resetForm = this.fb.nonNullable.group({
//     newPassword: ['', [Validators.required, HlmsValidators.password()]],
//     confirmPassword: ['', [Validators.required]]
//   }, {
//     validators: [HlmsValidators.matchPassword('newPassword', 'confirmPassword')]
//   });

//   constructor(
//     private fb: FormBuilder,
//     private authService: AuthService,
//     private router: Router
//   ) {}

//   trackByIndex(index: number): number {
//     return index;
//   }

//   continueToOtp(): void {
//     this.apiError = '';
//     this.successMessage = '';
//     this.form.markAllAsTouched();

//     if (this.form.invalid) return;

//     this.currentOtp = this.generateOtpStatic();
//     this.loginOtpGeneratedAt = Date.now();
//     this.otpStep = true;

//     this.resetOtpBoxes(this.otpDigits, this.loginOtpInputs);

//     setTimeout(() => {
//       this.focusOtp(this.loginOtpInputs, 0);
//     }, 100);
//   }

//   submit(): void {
//     if (!this.otpStep) {
//       this.continueToOtp();
//       return;
//     }

//     this.verifyOtpAndLogin();
//   }

//   onLoginOtpInput(event: Event, index: number): void {
//     this.handleOtpInput(event, index, this.otpDigits, this.loginOtpInputs);
//   }

//   onLoginOtpKeydown(event: KeyboardEvent, index: number): void {
//     this.handleOtpKeydown(event, index, this.otpDigits, this.loginOtpInputs);
//   }

//   onLoginOtpPaste(event: ClipboardEvent, index: number): void {
//     this.handleOtpPaste(event, index, this.otpDigits, this.loginOtpInputs);
//   }

//   verifyOtpAndLogin(): void {
//     this.apiError = '';
//     this.successMessage = '';

//     const enteredOtp = this.otpDigits.join('');

//     const validationMessage = this.validateOtp(
//       this.currentOtp,
//       enteredOtp,
//       this.loginOtpGeneratedAt
//     );

//     if (validationMessage) {
//       this.apiError = validationMessage;
//       return;
//     }

//     const value = this.form.getRawValue();

//     this.loading = true;

//     this.authService.login({
//       email: value.email.trim(),
//       password: value.password
//     }).pipe(
//       finalize(() => this.loading = false)
//     ).subscribe({
//       next: () => {
//         this.successMessage = 'OTP verified successfully. Login successful.';

//         setTimeout(() => {
//           this.router.navigateByUrl('/');
//         }, 700);
//       },
//       error: (error) => {
//         this.apiError = readableApiError(
//           error,
//           'Login failed. Please check email, password, backend port, and Spring Security settings.'
//         );
//       }
//     });
//   }

//   resendOtp(): void {
//     this.currentOtp = this.generateOtpStatic();
//     this.loginOtpGeneratedAt = Date.now();

//     this.resetOtpBoxes(this.otpDigits, this.loginOtpInputs);

//     this.apiError = '';
//     this.successMessage = 'A new demo OTP has been generated.';

//     setTimeout(() => {
//       this.focusOtp(this.loginOtpInputs, 0);
//     }, 100);
//   }

//   backToCredentials(): void {
//     this.otpStep = false;
//     this.apiError = '';
//     this.successMessage = '';
//     this.currentOtp = '';
//     this.loginOtpGeneratedAt = 0;

//     this.resetOtpBoxes(this.otpDigits, this.loginOtpInputs);
//   }

//   openForgotPassword(): void {
//     this.showForgotPassword = true;
//     this.forgotError = '';
//     this.forgotMessage = '';
//     this.forgotOtpStep = false;
//     this.forgotOtpVerified = false;
//     this.forgotGeneratedOtp = '';
//     this.forgotOtpGeneratedAt = 0;

//     this.resetForm.reset();
//     this.resetOtpBoxes(this.forgotOtpDigits, this.forgotOtpInputs);

//     const email = this.form.controls.email.value.trim();

//     if (email) {
//       this.forgotForm.controls.email.setValue(email);
//     }

//     setTimeout(() => {
//       document.getElementById('forgotEmail')?.focus();
//     }, 100);
//   }

//   closeForgotPassword(): void {
//     this.showForgotPassword = false;
//     this.forgotError = '';
//     this.forgotMessage = '';
//     this.forgotOtpStep = false;
//     this.forgotOtpVerified = false;
//     this.forgotGeneratedOtp = '';
//     this.forgotOtpGeneratedAt = 0;

//     this.resetOtpBoxes(this.forgotOtpDigits, this.forgotOtpInputs);
//   }

//   sendForgotOtp(): void {
//     this.forgotError = '';
//     this.forgotMessage = '';
//     this.forgotForm.markAllAsTouched();

//     if (this.forgotForm.invalid) return;

//     const email = this.forgotForm.controls.email.value.trim();

//     this.forgotLoading = true;

//     this.authService.forgotPassword({ email })
//       .pipe(finalize(() => this.forgotLoading = false))
//       .subscribe({
//         next: (message) => {
//           this.forgotGeneratedOtp = this.generateOtpStatic();
//           this.forgotOtpGeneratedAt = Date.now();
//           this.forgotOtpStep = true;
//           this.forgotOtpVerified = false;
//           this.forgotMessage = message || 'Forgot password request accepted. Use the demo OTP displayed above.';

//           this.resetOtpBoxes(this.forgotOtpDigits, this.forgotOtpInputs);

//           setTimeout(() => {
//             this.focusOtp(this.forgotOtpInputs, 0);
//           }, 100);
//         },
//         error: (error) => {
//           this.forgotError = readableApiError(
//             error,
//             'Forgot password request failed. Please check the email and backend API.'
//           );
//         }
//       });
//   }

//   resendForgotOtp(): void {
//     this.forgotError = '';
//     this.forgotMessage = 'A new demo OTP has been generated.';
//     this.forgotGeneratedOtp = this.generateOtpStatic();
//     this.forgotOtpGeneratedAt = Date.now();
//     this.forgotOtpVerified = false;

//     this.resetForm.reset();
//     this.resetOtpBoxes(this.forgotOtpDigits, this.forgotOtpInputs);

//     setTimeout(() => {
//       this.focusOtp(this.forgotOtpInputs, 0);
//     }, 100);
//   }

//   onForgotOtpInput(event: Event, index: number): void {
//     this.handleOtpInput(event, index, this.forgotOtpDigits, this.forgotOtpInputs);
//   }

//   onForgotOtpKeydown(event: KeyboardEvent, index: number): void {
//     this.handleOtpKeydown(event, index, this.forgotOtpDigits, this.forgotOtpInputs);
//   }

//   onForgotOtpPaste(event: ClipboardEvent, index: number): void {
//     this.handleOtpPaste(event, index, this.forgotOtpDigits, this.forgotOtpInputs);
//   }

//   verifyForgotOtp(): void {
//     this.forgotError = '';
//     this.forgotMessage = '';

//     const enteredOtp = this.forgotOtpDigits.join('');

//     const validationMessage = this.validateOtp(
//       this.forgotGeneratedOtp,
//       enteredOtp,
//       this.forgotOtpGeneratedAt
//     );

//     if (validationMessage) {
//       this.forgotError = validationMessage;
//       return;
//     }

//     this.forgotVerifying = true;

//     setTimeout(() => {
//       this.forgotVerifying = false;
//       this.forgotOtpVerified = true;
//       this.forgotMessage = 'OTP verified successfully. Enter your new password.';

//       setTimeout(() => {
//         document.getElementById('newPassword')?.focus();
//       }, 100);
//     }, 250);
//   }

//   resetPassword(): void {
//     this.forgotError = '';
//     this.forgotMessage = '';

//     if (!this.forgotOtpVerified) {
//       this.forgotError = 'OTP verification required before password reset.';
//       return;
//     }

//     this.resetForm.markAllAsTouched();

//     if (this.resetForm.invalid) return;

//     const email = this.forgotForm.controls.email.value.trim();
//     const value = this.resetForm.getRawValue();

//     this.resetLoading = true;

//     this.authService.resetPassword({
//       email,
//       otpCode: this.forgotGeneratedOtp,
//       newPassword: value.newPassword
//     }).pipe(
//       finalize(() => this.resetLoading = false)
//     ).subscribe({
//       next: (message) => {
//         this.forgotMessage = message || 'Password reset successful. You can log in with the new password.';

//         setTimeout(() => {
//           this.closeForgotPassword();
//         }, 1200);
//       },
//       error: (error) => {
//         this.forgotError = readableApiError(
//           error,
//           'Password reset failed. Please verify backend reset-password implementation and database update.'
//         );
//       }
//     });
//   }

//   hasError(field: 'email' | 'password', error: string): boolean {
//     const control = this.form.controls[field];
//     return control.touched && control.hasError(error);
//   }

//   hasForgotEmailError(error: string): boolean {
//     const control = this.forgotForm.controls.email;
//     return control.touched && control.hasError(error);
//   }

//   hasResetError(field: 'newPassword' | 'confirmPassword', error: string): boolean {
//     const control = this.resetForm.controls[field];
//     return control.touched && control.hasError(error);
//   }

//   get resetPasswordMismatch(): boolean {
//     return this.resetForm.touched && this.resetForm.hasError('passwordMismatch');
//   }

//   generateOtpStatic(): string {
//     return Math.floor(100000 + Math.random() * 900000).toString();
//   }

//   verifyOtpStatic(generatedOtp: string, enteredOtp: string): boolean {
//     return generatedOtp === enteredOtp;
//   }

//   private validateOtp(
//     generatedOtp: string,
//     enteredOtp: string,
//     generatedAt: number
//   ): string {
//     if (enteredOtp.length !== 6) {
//       return 'Enter the complete 6 digit OTP.';
//     }

//     if (!generatedOtp || !generatedAt) {
//       return 'OTP not generated. Please resend OTP.';
//     }

//     if (Date.now() - generatedAt > this.otpExpiryMs) {
//       return 'OTP expired. Please resend OTP.';
//     }

//     if (!this.verifyOtpStatic(generatedOtp, enteredOtp)) {
//       return 'Invalid OTP';
//     }

//     return '';
//   }

//   private handleOtpInput(
//     event: Event,
//     index: number,
//     digits: string[],
//     inputs: QueryList<ElementRef<HTMLInputElement>>
//   ): void {
//     const input = event.target as HTMLInputElement;
//     const value = input.value.replace(/\D/g, '');

//     if (!value) {
//       digits[index] = '';
//       input.value = '';
//       return;
//     }

//     if (value.length > 1) {
//       this.fillOtpFromText(value, index, digits, inputs);
//       return;
//     }

//     digits[index] = value;
//     input.value = value;

//     if (index < digits.length - 1) {
//       this.focusOtp(inputs, index + 1);
//     }
//   }

//   private handleOtpKeydown(
//     event: KeyboardEvent,
//     index: number,
//     digits: string[],
//     inputs: QueryList<ElementRef<HTMLInputElement>>
//   ): void {
//     const inputArray = inputs?.toArray() || [];

//     if (event.key === 'Backspace') {
//       event.preventDefault();

//       if (digits[index]) {
//         digits[index] = '';

//         if (inputArray[index]) {
//           inputArray[index].nativeElement.value = '';
//         }

//         return;
//       }

//       if (index > 0) {
//         digits[index - 1] = '';

//         if (inputArray[index - 1]) {
//           inputArray[index - 1].nativeElement.value = '';
//         }

//         this.focusOtp(inputs, index - 1);
//       }

//       return;
//     }

//     if (event.key === 'Delete') {
//       event.preventDefault();
//       return;
//     }

//     if (event.key === 'ArrowLeft' && index > 0) {
//       event.preventDefault();
//       this.focusOtp(inputs, index - 1);
//       return;
//     }

//     if (event.key === 'ArrowRight' && index < digits.length - 1) {
//       event.preventDefault();
//       this.focusOtp(inputs, index + 1);
//       return;
//     }

//     if (
//       event.key === 'Tab' ||
//       event.key === 'Home' ||
//       event.key === 'End'
//     ) {
//       return;
//     }

//     if (event.ctrlKey || event.metaKey) {
//       return;
//     }

//     if (!/^\d$/.test(event.key)) {
//       event.preventDefault();
//     }
//   }

//   private handleOtpPaste(
//     event: ClipboardEvent,
//     index: number,
//     digits: string[],
//     inputs: QueryList<ElementRef<HTMLInputElement>>
//   ): void {
//     event.preventDefault();

//     const pastedText = event.clipboardData?.getData('text') || '';
//     this.fillOtpFromText(pastedText, index, digits, inputs);
//   }

//   private fillOtpFromText(
//     text: string,
//     startIndex: number,
//     digits: string[],
//     inputs: QueryList<ElementRef<HTMLInputElement>>
//   ): void {
//     const inputArray = inputs?.toArray() || [];

//     const pastedDigits = text
//       .replace(/\D/g, '')
//       .slice(0, digits.length - startIndex)
//       .split('');

//     if (!pastedDigits.length) return;

//     pastedDigits.forEach((digit, offset) => {
//       const targetIndex = startIndex + offset;

//       digits[targetIndex] = digit;

//       if (inputArray[targetIndex]) {
//         inputArray[targetIndex].nativeElement.value = digit;
//       }
//     });

//     const nextIndex = Math.min(
//       startIndex + pastedDigits.length,
//       digits.length - 1
//     );

//     this.focusOtp(inputs, nextIndex);
//   }

//   private focusOtp(
//     inputs: QueryList<ElementRef<HTMLInputElement>>,
//     index: number
//   ): void {
//     setTimeout(() => {
//       const input = inputs?.toArray()[index]?.nativeElement;

//       if (!input) return;

//       input.focus();
//       input.select();
//     }, 0);
//   }

//   private resetOtpBoxes(
//     digits: string[],
//     inputs: QueryList<ElementRef<HTMLInputElement>>
//   ): void {
//     digits.splice(0, digits.length, '', '', '', '', '', '');

//     setTimeout(() => {
//       inputs?.forEach((input) => {
//         input.nativeElement.value = '';
//       });
//     }, 0);
//   }
// }
