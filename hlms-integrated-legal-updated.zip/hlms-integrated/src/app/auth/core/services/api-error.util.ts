export function readableApiError(error: unknown, fallback: string): string {
  const err = error as { error?: unknown; message?: string; status?: number };
  if (typeof err?.error === 'string' && err.error.trim()) return err.error;
  if (typeof err?.error === 'object' && err.error !== null) {
    const obj = err.error as { message?: string; error?: string };
    if (obj.message) return obj.message;
    if (obj.error) return obj.error;
  }
  if (err?.status === 0) return 'Backend not reachable. Start Spring Boot on port 8081 and run Angular with npm start so the proxy can forward /api requests.';
  if (err?.message) return err.message;
  return fallback;
}
