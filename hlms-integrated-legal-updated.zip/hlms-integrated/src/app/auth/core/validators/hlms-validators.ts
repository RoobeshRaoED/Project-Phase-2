import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export class HlmsValidators {
  static fullName(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = String(control.value || '').trim();
      if (!value) return null;
      if (!/^[A-Za-z ]+$/.test(value)) return { invalidName: true };
      if (value.length < 2) return { invalidName: true };
      if (value.length > 50) return { invalidName: true };
      return null;
    };
  }

  static mobile(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = String(control.value || '').trim();
      if (!value) return null;
      return /^[6-9][0-9]{9}$/.test(value) ? null : { invalidMobile: true };
    };
  }

  static password(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = String(control.value || '');
      if (!value) return null;
      const rules: ValidationErrors = {};
      if (value.length < 8) rules['min8'] = true;
      if (!/[A-Z]/.test(value)) rules['uppercase'] = true;
      if (!/[a-z]/.test(value)) rules['lowercase'] = true;
      if (!/[0-9]/.test(value)) rules['number'] = true;
      if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?`~]/.test(value)) rules['special'] = true;
      return Object.keys(rules).length ? { weakPassword: rules } : null;
    };
  }

  static matchPassword(passwordField = 'password', confirmField = 'confirmPassword'): ValidatorFn {
    return (group: AbstractControl): ValidationErrors | null => {
      const password = group.get(passwordField)?.value;
      const confirmPassword = group.get(confirmField)?.value;
      if (!password || !confirmPassword) return null;
      return password === confirmPassword ? null : { passwordMismatch: true };
    };
  }
}
