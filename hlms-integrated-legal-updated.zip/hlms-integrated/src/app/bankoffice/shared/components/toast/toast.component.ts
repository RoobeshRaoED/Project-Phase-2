import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToastService } from '../../../core/services/toast.service';

@Component({
  selector: 'app-toast',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="toast-wrap">
      @for (t of toastService.toasts(); track t.id) {
        <div class="toast" [class.toast-error]="t.type === 'error'" [class.toast-success]="t.type === 'success'">
          <strong>{{ t.title }}</strong>
          <div>{{ t.message }}</div>
        </div>
      }
    </div>
  `,
  styles: [`
    .toast-wrap { position: fixed; right: 20px; bottom: 20px; z-index: 9999; display:flex; flex-direction:column; gap:10px; }
    .toast { background:#1f2937; color:#fff; padding:12px 16px; border-radius:10px; min-width:240px; box-shadow:0 8px 24px rgba(0,0,0,.2); }
    .toast-error { background:#b91c1c; }
    .toast-success { background:#15803d; }
  `]
})
export class ToastComponent {
  toastService = inject(ToastService);
}
