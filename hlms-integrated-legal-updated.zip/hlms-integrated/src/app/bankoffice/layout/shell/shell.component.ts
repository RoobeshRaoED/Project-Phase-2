import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { SidebarComponent } from '../sidebar/sidebar.component';
import { TopbarComponent } from '../topbar/topbar.component';

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [RouterOutlet, SidebarComponent, TopbarComponent],
  template: `
    <div id="app">
      <app-topbar (toggleSidebar)="sidebarOpen = !sidebarOpen"></app-topbar>
      <app-sidebar [class.open]="sidebarOpen"></app-sidebar>
      <div class="main">
        <router-outlet></router-outlet>
      </div>
      <footer class="app-footer">HLMS Bank Office Portal — connected to HLMS microservices backend.</footer>
    </div>
  `
})
export class ShellComponent {
  sidebarOpen = false;
}
