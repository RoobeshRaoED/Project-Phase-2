import { Component, EventEmitter, Output, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { NotificationService } from '../../core/services/notification.service';

@Component({
  selector: 'app-topbar',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="topbar">
      <button class="hamburger" (click)="toggleSidebar.emit()">☰</button>
      <div class="brand">
        <div class="logo"><img src="assets/images/favicon.png" width="40px" style="border-radius:2px;" /></div>
        <div>
          <div class="title">HLMS</div>
          <div class="subtitle">Housing Loan Management System</div>
        </div>
      </div>
      <div class="topbar-search">
        <input placeholder="Search anything..." autocomplete="off" [(ngModel)]="searchTerm" />
      </div>
      <div class="topbar-right">
        <button class="icon-btn" title="Notifications" (click)="openNotifications()">
          🔔<span class="icon-dot">{{ notifService.unreadCount() }}</span>
        </button>
        <div class="user-chip" (click)="goProfile()">
          <div class="user-avatar">{{ initials() }}</div>
          <div class="user-name">{{ auth.currentUser()?.fullName || 'User' }}</div>
        </div>
      </div>
    </div>
  `
})
export class TopbarComponent implements OnInit {
  @Output() toggleSidebar = new EventEmitter<void>();
  auth = inject(AuthService);
  notifService = inject(NotificationService);
  private router = inject(Router);
  searchTerm = '';

  ngOnInit() {
    const email = this.auth.currentUser()?.email;
    if (email) this.notifService.loadForUser(email).subscribe({ error: () => {} });
  }

  initials(): string {
    const name = this.auth.currentUser()?.fullName || 'User';
    return name.split(' ').map(p => p[0]).join('').slice(0, 2).toUpperCase();
  }

  goProfile() {
    this.router.navigate(['/officer', 'bosettings']);
  }

  openNotifications() {
    // Placeholder: could open a dropdown/panel with notifService.notifications()
  }
}
