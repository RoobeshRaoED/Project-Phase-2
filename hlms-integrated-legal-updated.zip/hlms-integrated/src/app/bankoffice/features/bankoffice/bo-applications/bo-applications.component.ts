import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { LoanService } from '../../../core/services/loan.service';
import { LoanApplication } from '../../../core/models/loan-application.model';

@Component({
  selector: 'app-bo-applications',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bo-applications.component.html'
})
export class BoApplicationsComponent implements OnInit {
  private loanService = inject(LoanService);
  private router = inject(Router);

  applications = signal<LoanApplication[]>([]);
  productNames = signal<Record<string, string>>({});
  loading = signal(true);

  sorted = computed(() =>
    this.applications()
      .slice()
      .sort((a, b) => new Date(b.createdAt ?? 0).getTime() - new Date(a.createdAt ?? 0).getTime())
  );

  ngOnInit(): void {
    this.loanService.getAllApplications().subscribe({
      next: (apps) => { this.applications.set(apps); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
    this.loanService.getProductNameMap().subscribe({
      next: (map) => this.productNames.set(map),
      error: () => this.productNames.set({})
    });
  }

  productName(productId?: string): string {
    if (!productId) return '—';
    return this.productNames()[productId] ?? productId;
  }

  statusBadge(status?: string): string {
    if (status === 'Disbursed') return 'badge-green';
    if (status === 'Rejected') return 'badge-red';
    if (status === 'In Progress' || status === 'Submitted') return 'badge-orange';
    return 'badge-gray';
  }

  open(appId?: string) {
    if (appId) this.router.navigate(['/officer/boappdetail', appId]);
  }
}
