export interface EligibilityRequest {
  monthlyIncome: number;
  otherEMIs: number;
  loanAmount: number;
  tenureYears: number;
}

export interface EligibilityResult {
  eligible: boolean;
  maxEligibleAmount: number;
  estimatedEmi: number;
  interestRate: number;
  remarks?: string;
}
