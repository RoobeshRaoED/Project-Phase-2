// Kept in exact sync with repayment-service's AuctionCaseDTO / BidDTO.

export interface AuctionCase {
  auctionId?: number;
  appId: string;
  stage: 'None' | 'Notice Issued' | 'Possession' | 'Auction Scheduled' | 'Resolved';
  noticeDate?: string;
  noticeDueDate?: string;
  demandAmount?: number;
  possessionDate?: string;
  auctionDate?: string;
  reservePrice?: number;
  // Convenience fields joined in from the linked application on the UI
  // side (not part of AuctionCaseDTO) - populated after fetching.
  propertyAddress?: string;
  trackingNo?: string;
  applicantName?: string;
}

export interface Bid {
  bidId?: string;
  appId: string;
  bidderEmail: string;
  bidAmount: number;
  createdAt?: string;
}
