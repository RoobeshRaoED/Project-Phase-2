import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { UserRole } from '../models/user.model';

/** Usage in routes: data: { roles: ['admin','employee'] } */
export const roleGuard: CanActivateFn = (route) => {
  const auth = inject(AuthService);
  const router = inject(Router);
  const allowed = route.data['roles'] as UserRole[] | undefined;
  const role = auth.role();

  if (!auth.isLoggedIn()) {
    router.navigate(['/login']);
    return false;
  }
  if (allowed && role && !allowed.includes(role)) {
    // INTEGRATION CHANGE: originally navigated to '/app' (now '/officer'), but
    // that route redirects to 'bodash' which re-enters this guard -> redirect
    // loop. A user without the bank-office role is sent to the public home page.
    router.navigate(['/']);
    return false;
  }
  return true;
};
