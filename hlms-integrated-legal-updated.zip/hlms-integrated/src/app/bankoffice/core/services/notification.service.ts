import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { Notification, ServiceRequest } from '../models/notification.model';

@Injectable({ providedIn: 'root' })
export class NotificationService {
  private readonly notifUrl = `${environment.apiBaseUrl}/notification-service/api/notifications`;
  private readonly requestUrl = `${environment.apiBaseUrl}/notification-service/api/service-requests`;

  readonly notifications = signal<Notification[]>([]);
  readonly unreadCount = signal(0);

  constructor(private http: HttpClient) {}

  // NotificationController.send: POST /api/notifications with
  // { userEmail, title, body, channels }.
  send(userEmail: string, title: string, body: string, channels: string[] = ['IN_APP']): Observable<Notification> {
    return this.http.post<Notification>(this.notifUrl, { userEmail, title, body, channels });
  }

  loadForUser(email: string): Observable<Notification[]> {
    return this.http.get<Notification[]>(this.notifUrl, { params: { userEmail: email } }).pipe(
      tap((list) => {
        this.notifications.set(list);
        this.unreadCount.set(list.filter(n => !n.read).length);
      })
    );
  }

  markRead(notificationId: number): Observable<Notification> {
    // NotificationController exposes this as PATCH, not PUT.
    return this.http.patch<Notification>(`${this.notifUrl}/${notificationId}/read`, {});
  }

  // NOTE: NotificationController has no DELETE endpoint - this will 404.
  // Not currently invoked by any component.
  delete(notificationId: number): Observable<void> {
    return this.http.delete<void>(`${this.notifUrl}/${notificationId}`);
  }

  // ---- Support / service requests ----
  // NOTE: service-requests has no "/context" aggregate endpoint - this call
  // will 404. Not currently invoked by any component.
  getRequestContext(appId: number): Observable<unknown> {
    return this.http.get(`${this.requestUrl}/application/${appId}/context`);
  }

  createRequest(payload: Partial<ServiceRequest>): Observable<ServiceRequest> {
    return this.http.post<ServiceRequest>(this.requestUrl, payload);
  }

  // ServiceRequestController only supports changing status, via PATCH /{requestId}/status.
  updateRequestStatus(requestId: number, status: string): Observable<ServiceRequest> {
    return this.http.patch<ServiceRequest>(`${this.requestUrl}/${requestId}/status`, { status });
  }

  // ServiceRequestController's root GET takes "userEmail" as a query param, not a path segment.
  getRequestsForUser(email: string): Observable<ServiceRequest[]> {
    return this.http.get<ServiceRequest[]>(this.requestUrl, { params: { userEmail: email } });
  }

  getRequestsForApp(appId: number): Observable<ServiceRequest[]> {
    return this.http.get<ServiceRequest[]>(`${this.requestUrl}/by-app/${appId}`);
  }
}
