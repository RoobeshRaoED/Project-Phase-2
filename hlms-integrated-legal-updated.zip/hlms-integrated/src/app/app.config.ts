import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter, withComponentInputBinding } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideAnimations } from '@angular/platform-browser/animations';

import { routes } from './app.routes';
import { hlmsAuthInterceptor } from './core/interceptors/hlms-auth.interceptor';
import { errorInterceptor } from './bankoffice/core/interceptors/error.interceptor';

/**
 * Merged from the five source app.config.ts files:
 *   - provideZoneChangeDetection({ eventCoalescing: true })  (customer, bank office, legal)
 *   - withComponentInputBinding()                            (customer, admin, bank office)
 *   - provideAnimations()                                    (bank office)
 *   - provideHttpClient(withInterceptors([...]))             (all five)
 *
 * The five modules each registered their own HTTP interceptor, but an
 * interceptor registered here would run for every module. They are replaced by
 * a single interceptor that reuses the same behaviour -- see
 * core/interceptors/hlms-auth.interceptor.ts for exactly what was consolidated.
 */
export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes, withComponentInputBinding()),
    provideHttpClient(withInterceptors([hlmsAuthInterceptor, errorInterceptor])),
    provideAnimations()
  ]
};
