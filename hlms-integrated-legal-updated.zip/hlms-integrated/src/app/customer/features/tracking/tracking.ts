import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { LoanService } from '../../core/services/loan.service';
import { ToastService } from '../../core/services/toast.service';
import {
  ExpectedCompletion,
  LoanApplication,
  StakeholderInfo,
  WorkflowTimelineResponse
} from '../../core/models/models';

@Component({
  selector: 'app-tracking',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page-head">
      <h1>Track Application</h1>
      <p>Follow your loan application through every stage of the workflow.</p>
    </div>

    @if (!selectedId()) {
      @if (listLoading()) {
        <div class="page-loading"><span class="spinner dark"></span> Loading your applications…</div>
      } @else if (apps().length === 0) {
        <div class="card">
          <div class="empty-state"><div class="ic">↗</div><p>You have no applications to track yet.</p>
            <button class="btn btn-primary btn-sm" routerLink="/customer/apply">Apply for a Loan</button>
          </div>
        </div>
      } @else {
        <div class="card">
          <table>
            <thead><tr><th>App ID</th><th>Product</th><th>Amount</th><th>Status</th><th></th></tr></thead>
            <tbody>
              @for (a of apps(); track a.appId) {
                <tr class="clickable-row" (click)="select(a.appId)">
                  <td>{{ a.trackingNo || a.appId }}</td>
                  <td>{{ a.productId || '—' }}</td>
                  <td>{{ a.loanAmount ? ('₹' + a.loanAmount) : '—' }}</td>
                  <td><span class="badge" [class]="badgeClass(a.status)">{{ a.status }}</span></td>
                  <td><span class="btn-link">View →</span></td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      }
    } @else {
      <button class="back-link" (click)="deselect()">← All Applications</button>

      @if (detailLoading()) {
        <div class="page-loading"><span class="spinner dark"></span> Loading tracking details…</div>
      } @else {
        @if (detailError()) {
          <div class="inline-error">{{ detailError() }}</div>
        }

        @if (application(); as app) {
          <div class="card">
            <div class="two-col">
              <div class="stat"><span class="lbl">Application</span><span class="val">{{ app.trackingNo || app.appId }}</span></div>
              <div class="stat"><span class="lbl">Status</span><span class="badge" [class]="badgeClass(app.status)">{{ app.status }}</span></div>
            </div>
            <div class="two-col" style="margin-top:10px;">
              <div class="stat"><span class="lbl">Loan Amount</span><span class="val">₹{{ app.loanAmount || 0 | number: '1.0-0' }}</span></div>
              <div class="stat"><span class="lbl">Product</span><span class="val">{{ app.productId || '—' }}</span></div>
            </div>

            @if (app.status === 'Draft') {
              <button class="btn btn-primary" style="margin-top:14px;" [routerLink]="['/customer/apply', app.appId]">
                Continue Application →
              </button>
            }
            @if (['Draft', 'Submitted'].includes(app.status)) {
              <button class="btn btn-danger" style="margin-top:14px;margin-left:10px;" (click)="withdraw(app.appId)">
                Withdraw Application
              </button>
            }
          </div>
        }

        @if (stakeholder(); as sh) {
          <div class="card">
            <h3>👤 Currently With</h3>
            <p><strong>{{ sh.stakeholderRole }}</strong> — {{ sh.currentStageName }}</p>
            <p class="muted">{{ sh.note }}</p>
          </div>
        }

        @if (expected(); as ex) {
          <div class="card">
            <h3>⏱ Expected Completion</h3>
            <div class="two-col">
              <div class="stat"><span class="lbl">Current Stage</span><span class="val">{{ ex.currentStageName }}</span></div>
              <div class="stat"><span class="lbl">Expected By</span><span class="val teal">{{ ex.expectedCompletionDate | date }}</span></div>
            </div>
            <p class="muted" style="margin-top:8px;">{{ ex.slaDaysRemainingForStage }} day(s) remaining in SLA for this stage.</p>
          </div>
        }

        @if (timeline(); as tl) {
          <div class="card">
            <h3>📍 Workflow Timeline</h3>
            <div class="stepper">
              @for (t of tl.timeline; track t.stageIndex) {
                <div class="step" [class.done]="t.status === 'completed'" [class.current]="t.status === 'current'">
                  <div class="dot">{{ t.stageIndex + 1 }}</div>
                  <div class="lbl">{{ t.stageName }}</div>
                  @if (t.occurredAt) {
                    <div class="muted" style="font-size:11px;">{{ t.occurredAt | date: 'short' }}</div>
                  }
                </div>
              }
            </div>
          </div>
        }

        @if (application(); as app2) {
          <div class="card">
            <h3>Quick Actions</h3>
            <div style="display:flex;gap:10px;flex-wrap:wrap;">
              <button class="btn btn-outline btn-sm" [routerLink]="['/customer/documents', app2.appId]">View Documents</button>
              <button class="btn btn-outline btn-sm" [routerLink]="['/customer/repayment', app2.appId]">Repayment Schedule</button>
              <button class="btn btn-outline btn-sm" [routerLink]="['/customer/auction', app2.appId]">Legal &amp; Auction Status</button>
            </div>
          </div>
        }
      }
    }
  `
})
export class Tracking {
  private auth = inject(AuthService);
  private loanSvc = inject(LoanService);
  private toast = inject(ToastService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  apps = signal<LoanApplication[]>([]);
  listLoading = signal(true);

  selectedId = signal<string | null>(null);
  detailLoading = signal(false);
  detailError = signal('');
  application = signal<LoanApplication | null>(null);
  stakeholder = signal<StakeholderInfo | null>(null);
  timeline = signal<WorkflowTimelineResponse | null>(null);
  expected = signal<ExpectedCompletion | null>(null);

  constructor() {
    const email = this.auth.currentUser()?.email;
    if (email) {
      this.loanSvc.listForUser(email).subscribe({
        next: (list) => {
          this.apps.set(list);
          this.listLoading.set(false);
          const routeAppId = this.route.snapshot.paramMap.get('appId');
          if (routeAppId) this.select(routeAppId);
        },
        error: () => this.listLoading.set(false)
      });
    } else {
      this.listLoading.set(false);
    }
  }

  select(appId: string): void {
    this.selectedId.set(appId);
    this.detailLoading.set(true);
    this.detailError.set('');
    this.application.set(null);
    this.stakeholder.set(null);
    this.timeline.set(null);
    this.expected.set(null);

    this.loanSvc.getApplication(appId).subscribe({
      next: (app) => this.application.set(app),
      error: () => this.detailError.set('Could not load this application.')
    });
    this.loanSvc.stakeholder(appId).subscribe({ next: (s) => this.stakeholder.set(s), error: () => {} });
    this.loanSvc.timeline(appId).subscribe({
      next: (t) => {
        this.timeline.set(t);
        this.detailLoading.set(false);
      },
      error: () => this.detailLoading.set(false)
    });
    this.loanSvc.expectedCompletion(appId).subscribe({ next: (e) => this.expected.set(e), error: () => {} });
  }

  deselect(): void {
    this.selectedId.set(null);
    this.router.navigate(['/customer/tracking']);
  }

  withdraw(appId: string): void {
    if (!confirm('Are you sure you want to withdraw this application? This cannot be undone.')) return;
    this.loanSvc.withdraw(appId).subscribe({
      next: () => {
        this.toast.success('Application withdrawn');
        this.apps.update((list) => list.filter((a) => a.appId !== appId));
        this.deselect();
      },
      error: () => this.toast.error('Could not withdraw', 'Please try again.')
    });
  }

  badgeClass(status: string): string {
    if (status === 'Disbursed') return 'badge-green';
    if (status === 'Rejected') return 'badge-red';
    if (status === 'Draft') return 'badge-gray';
    return 'badge-orange';
  }
}
