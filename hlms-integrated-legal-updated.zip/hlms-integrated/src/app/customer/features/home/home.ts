import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div id="homeScreen">
      <nav class="home-nav">
        <div class="home-nav-brand">
          <img src="assets/images/logo.png" width="38" style="border-radius:8px;" alt="HLMS" />
          <div>
            <div class="home-nav-title">HLMS</div>
            <div class="home-nav-subtitle">Housing Loan Management System</div>
          </div>
        </div>
        <div class="home-nav-links">
          <a href="#features">Features</a>
          <a href="#products">Loan Products</a>
          <a href="#howitworks">How It Works</a>
          <button class="btn btn-outline btn-sm" routerLink="/login">Log In</button>
          <button class="btn btn-primary btn-sm" routerLink="/register">Register</button>
        </div>
      </nav>

      <header class="hero">
        <div class="hero-text">
          <span class="hero-badge">🏠 Trusted Housing Finance Partner</span>
          <h1>Your Dream Home,<br /><span>Financed Simply.</span></h1>
          <p>
            HLMS brings the entire home loan journey — application, verification, disbursement and
            repayment — onto one secure, transparent digital platform.
          </p>
          <div class="hero-cta">
            <button class="btn btn-primary" routerLink="/register">Apply for a Loan →</button>
            <button class="btn btn-outline" routerLink="/login">Track Existing Application</button>
          </div>
          <div class="hero-stats">
            <div><strong>8.4%</strong><span>Starting Rate</span></div>
            <div><strong>30 Yrs</strong><span>Max Tenure</span></div>
            <div><strong>90%</strong><span>Max Financing</span></div>
            <div><strong>24/7</strong><span>Digital Tracking</span></div>
          </div>
        </div>
        <div class="hero-image">
          <img src="assets/images/hero.png" alt="HLMS" />
        </div>
      </header>

      <section class="home-section" id="features">
        <div class="section-head">
          <h2>Everything you need, in one place</h2>
          <p>Purpose-built tools for every stage of your housing loan lifecycle.</p>
        </div>
        <div class="grid grid-4 home-features">
          @for (f of features; track f.title) {
            <div class="card feature-card">
              <div class="feature-ic">{{ f.icon }}</div>
              <h3>{{ f.title }}</h3>
              <p>{{ f.desc }}</p>
            </div>
          }
        </div>
      </section>

      <section class="home-section alt" id="products">
        <div class="section-head">
          <h2>Loan Products Built Around You</h2>
          <p>Competitive rates across every housing finance need.</p>
        </div>
        <div class="grid grid-3">
          <div class="product-card">
            <h4>Home Purchase Loan</h4>
            <div class="rate">8.5%<span style="font-size:12px;color:var(--text-gray);font-weight:600;"> p.a. onwards</span></div>
            <span class="tag">Up to 30 yrs · 90% LTV</span>
            <p>Finance the purchase of a new or resale residential property.</p>
          </div>
          <div class="product-card">
            <h4>Home Construction Loan</h4>
            <div class="rate">8.75%<span style="font-size:12px;color:var(--text-gray);font-weight:600;"> p.a. onwards</span></div>
            <span class="tag">Up to 25 yrs · 85% LTV</span>
            <p>Staged disbursement to construct your house on owned land.</p>
          </div>
          <div class="product-card">
            <h4>Balance Transfer + Top-up</h4>
            <div class="rec">Best Rate</div>
            <div class="rate">8.4%<span style="font-size:12px;color:var(--text-gray);font-weight:600;"> p.a. onwards</span></div>
            <span class="tag">Up to 30 yrs · 90% LTV</span>
            <p>Transfer your existing home loan and get an additional top-up amount.</p>
          </div>
        </div>
        <div style="text-align:center;margin-top:22px;">
          <button class="btn btn-teal" routerLink="/register">Explore All Loan Products →</button>
        </div>
      </section>

      <section class="home-section" id="howitworks">
        <div class="section-head">
          <h2>How It Works</h2>
          <p>From application to disbursement, tracked at every stage.</p>
        </div>
        <div class="stepper home-stepper">
          <div class="step done"><div class="dot">1</div><div class="lbl">Application Submitted</div></div>
          <div class="step done"><div class="dot">2</div><div class="lbl">Document Verification</div></div>
          <div class="step current"><div class="dot">3</div><div class="lbl">Eligibility &amp; Credit Check</div></div>
          <div class="step"><div class="dot">4</div><div class="lbl">Property Verification</div></div>
          <div class="step"><div class="dot">5</div><div class="lbl">Final Approval</div></div>
          <div class="step"><div class="dot">6</div><div class="lbl">Disbursement</div></div>
        </div>
      </section>

      <section class="home-cta-band">
        <h2>Ready to take the next step towards your new home?</h2>
        <p>Create your free HLMS account and get a real-time view of your entire loan journey.</p>
        <button class="btn btn-primary" routerLink="/register">Create Free Account</button>
      </section>

      <footer class="home-footer">
        <div>© {{ year }} HLMS — Housing Loan Management System.</div>
        <div class="home-footer-links">
          <a routerLink="/login">Log In</a>
          <a routerLink="/register">Register</a>
        </div>
      </footer>
    </div>
  `
})
export class Home {
  year = new Date().getFullYear();

  features = [
    { icon: '📝', title: 'Simple Application', desc: 'Apply online in minutes with guided, step-by-step forms.' },
    { icon: '↗', title: 'Real-Time Tracking', desc: 'Follow your application through every stage — from submission to disbursement.' },
    { icon: '▯', title: 'Secure Document Vault', desc: 'Upload and manage KYC, income and property documents safely.' },
    { icon: 'Ⓡ', title: 'Smart Repayment', desc: 'View EMI schedules, outstanding balance and repayment history anytime.' },
    { icon: '☑', title: 'Instant Eligibility Check', desc: 'Know your loan eligibility and estimated EMI before you apply.' },
    { icon: '🔔', title: 'Timely Notifications', desc: 'Stay informed with in-app alerts at every milestone.' },
    { icon: '☆', title: 'Auction Transparency', desc: 'Track SARFAESI notices and auction listings with complete clarity.' },
    { icon: '?', title: 'Dedicated Support', desc: 'Reach our support team directly from your dashboard whenever you need help.' }
  ];
}
