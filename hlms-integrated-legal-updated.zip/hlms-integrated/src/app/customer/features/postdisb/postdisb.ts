import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { LoanService } from '../../core/services/loan.service';
import { DocumentService, fileToBase64 } from '../../core/services/document.service';
import { NotificationService } from '../../core/services/notification.service';
import { ToastService } from '../../core/services/toast.service';
import { LoanApplication, PostDisbursementDocument, ServiceRequest } from '../../core/models/models';

const PD_DOC_TYPES = ['NOC Request', 'Property Title Copy', 'Insurance Renewal', 'Other'];
const REQUEST_TYPES = ['Duplicate Statement', 'Loan Closure Letter', 'NOC / No-Dues Certificate', 'Interest Certificate', 'Other'];

@Component({
  selector: 'app-postdisb',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="page-head">
      <h1>Post-Disbursement Services</h1>
      <p>Manage documents and service requests for your disbursed loan.</p>
    </div>

    @if (!appId()) {
      <div class="card">
        @if (listLoading()) {
          <div class="page-loading"><span class="spinner dark"></span> Loading your applications…</div>
        } @else if (eligibleApps().length === 0) {
          <div class="empty-state"><p>These services become available once your loan is disbursed.</p></div>
        } @else {
          <table>
            <thead><tr><th>App ID</th><th>Product</th><th>Status</th><th></th></tr></thead>
            <tbody>
              @for (a of eligibleApps(); track a.appId) {
                <tr class="clickable-row" [routerLink]="['/customer/postdisb', a.appId]">
                  <td>{{ a.trackingNo || a.appId }}</td><td>{{ a.productId }}</td>
                  <td><span class="badge badge-green">{{ a.status }}</span></td>
                  <td><span class="btn-link">Manage →</span></td>
                </tr>
              }
            </tbody>
          </table>
        }
      </div>
    } @else {
      <button class="back-link" routerLink="/customer/postdisb">← All Applications</button>

      <div class="card">
        <h3>🛠 Raise a Service Request</h3>
        @if (reqError()) {
          <div class="inline-error">{{ reqError() }}</div>
        }
        <div class="two-col">
          <div class="field">
            <label>Request Type</label>
            <select [(ngModel)]="requestType" [ngModelOptions]="{ standalone: true }">
              @for (t of requestTypes; track t) { <option [value]="t">{{ t }}</option> }
            </select>
          </div>
          <div class="field">
            <label>Description (optional)</label>
            <input [(ngModel)]="requestDesc" [ngModelOptions]="{ standalone: true }" placeholder="Any additional detail" />
          </div>
        </div>
        <button class="btn btn-primary btn-sm" (click)="raiseRequest()" [disabled]="raisingReq()">
          @if (raisingReq()) { <span class="spinner"></span> } @else { Submit Request }
        </button>
      </div>

      <div class="card">
        <h3>📋 My Service Requests</h3>
        @if (reqsLoading()) {
          <div class="page-loading"><span class="spinner dark"></span> Loading…</div>
        } @else if (requests().length === 0) {
          <div class="empty-state"><p>No service requests raised for this loan yet.</p></div>
        } @else {
          <table>
            <thead><tr><th>Type</th><th>Description</th><th>Status</th><th>Raised</th></tr></thead>
            <tbody>
              @for (r of requests(); track r.requestId) {
                <tr>
                  <td>{{ r.requestType }}</td><td>{{ r.description || '—' }}</td>
                  <td><span class="badge badge-orange">{{ r.status || 'Requested' }}</span></td>
                  <td>{{ r.createdAt | date: 'medium' }}</td>
                </tr>
              }
            </tbody>
          </table>
        }
      </div>

      <div class="card">
        <h3>⬆ Upload a Post-Disbursement Document</h3>
        @if (uploadError()) {
          <div class="inline-error">{{ uploadError() }}</div>
        }
        <div class="two-col">
          <div class="field">
            <label>Document Type</label>
            <select [(ngModel)]="docType" [ngModelOptions]="{ standalone: true }">
              @for (t of pdDocTypes; track t) { <option [value]="t">{{ t }}</option> }
            </select>
          </div>
          <div class="field">
            <label>File</label>
            <input type="file" (change)="onFile($event)" />
          </div>
        </div>
        <button class="btn btn-primary btn-sm" (click)="upload()" [disabled]="!selectedFile() || uploading()">
          @if (uploading()) { <span class="spinner"></span> } @else { Upload Document }
        </button>
      </div>

      <div class="card">
        <h3>📁 Uploaded Documents</h3>
        @if (docsLoading()) {
          <div class="page-loading"><span class="spinner dark"></span> Loading…</div>
        } @else if (docs().length === 0) {
          <div class="empty-state"><p>No post-disbursement documents uploaded yet.</p></div>
        } @else {
          <table>
            <thead><tr><th>Type</th><th>File</th><th>Status</th><th></th></tr></thead>
            <tbody>
              @for (d of docs(); track d.pdDocId) {
                <tr>
                  <td>{{ d.docType }}</td><td>{{ d.fileName }}</td>
                  <td><span class="badge" [class]="d.status === 'Verified' ? 'badge-green' : 'badge-orange'">{{ d.status || 'Pending' }}</span></td>
                  <td><button class="btn btn-outline btn-sm" (click)="remove(d)">Delete</button></td>
                </tr>
              }
            </tbody>
          </table>
        }
      </div>
    }
  `
})
export class Postdisb {
  private auth = inject(AuthService);
  private loanSvc = inject(LoanService);
  private docSvc = inject(DocumentService);
  private notifSvc = inject(NotificationService);
  private toast = inject(ToastService);
  private route = inject(ActivatedRoute);

  pdDocTypes = PD_DOC_TYPES;
  requestTypes = REQUEST_TYPES;
  docType = PD_DOC_TYPES[0];
  requestType = REQUEST_TYPES[0];
  requestDesc = '';

  appId = signal<string | null>(null);
  listLoading = signal(true);
  eligibleApps = signal<LoanApplication[]>([]);

  docsLoading = signal(true);
  docs = signal<PostDisbursementDocument[]>([]);
  selectedFile = signal<File | null>(null);
  uploading = signal(false);
  uploadError = signal('');

  reqsLoading = signal(true);
  requests = signal<ServiceRequest[]>([]);
  raisingReq = signal(false);
  reqError = signal('');

  constructor() {
    const routeAppId = this.route.snapshot.paramMap.get('appId');
    if (routeAppId) {
      this.appId.set(routeAppId);
      this.listLoading.set(false);
      this.loadDocs(routeAppId);
      this.loadRequests(routeAppId);
    } else {
      const email = this.auth.currentUser()?.email;
      if (email) {
        this.loanSvc.listForUser(email).subscribe({
          next: (list) => {
this.eligibleApps.set(
  list.filter((a) => a.status === 'Disbursed' || a.status === 'Active')
);
            this.listLoading.set(false);
          },
          error: () => this.listLoading.set(false)
        });
      } else {
        this.listLoading.set(false);
      }
    }
  }

  private loadDocs(appId: string): void {
    this.docsLoading.set(true);
    this.docSvc.listPostDisbByApp(appId).subscribe({
      next: (list) => {
        this.docs.set(list);
        this.docsLoading.set(false);
      },
      error: () => this.docsLoading.set(false)
    });
  }

  private loadRequests(appId: string): void {
    this.reqsLoading.set(true);
    this.notifSvc.listServiceRequestsForApp(appId).subscribe({
      next: (list) => {
        this.requests.set(list);
        this.reqsLoading.set(false);
      },
      error: () => this.reqsLoading.set(false)
    });
  }

  raiseRequest(): void {
    const email = this.auth.currentUser()?.email;
    const appId = this.appId();
    if (!email || !appId) return;
    this.raisingReq.set(true);
    this.reqError.set('');
    this.notifSvc
      .createServiceRequest({ userEmail: email, appId, requestType: this.requestType, description: this.requestDesc })
      .subscribe({
        next: () => {
          this.raisingReq.set(false);
          this.requestDesc = '';
          this.toast.success('Request submitted');
          this.loadRequests(appId);
        },
        error: () => {
          this.raisingReq.set(false);
          this.reqError.set('Could not submit request. Please try again.');
        }
      });
  }

  onFile(evt: Event): void {
    const input = evt.target as HTMLInputElement;
    this.selectedFile.set(input.files?.[0] ?? null);
  }

  async upload(): Promise<void> {
    const appId = this.appId();
    const file = this.selectedFile();
    if (!appId || !file) return;
    this.uploading.set(true);
    this.uploadError.set('');
    try {
      const fileData = await fileToBase64(file);
      this.docSvc
        .uploadPostDisb({ appId, docType: this.docType, fileName: file.name, fileData, fileSize: file.size })
        .subscribe({
          next: () => {
            this.uploading.set(false);
            this.selectedFile.set(null);
            this.toast.success('Document uploaded');
            this.loadDocs(appId);
          },
          error: () => {
            this.uploading.set(false);
            this.uploadError.set('Upload failed. Please try again.');
          }
        });
    } catch {
      this.uploading.set(false);
      this.uploadError.set('Could not read the selected file.');
    }
  }

  remove(doc: PostDisbursementDocument): void {
    if (!doc.pdDocId || !confirm(`Delete "${doc.fileName}"?`)) return;
    this.docSvc.removePostDisb(doc.pdDocId).subscribe({
      next: () => {
        this.docs.update((list) => list.filter((d) => d.pdDocId !== doc.pdDocId));
        this.toast.success('Document deleted');
      },
      error: () => this.toast.error('Could not delete document')
    });
  }
}
