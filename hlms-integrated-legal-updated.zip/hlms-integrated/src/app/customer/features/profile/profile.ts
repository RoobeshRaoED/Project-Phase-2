import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { UserService } from '../../core/services/user.service';
import { ToastService } from '../../core/services/toast.service';
import { CustomerEmploymentProfile } from '../../core/models/models';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="page-head">
      <h1>My Profile</h1>
      <p>Manage your personal details and employment / income information.</p>
    </div>

    <div class="grid grid-2">
      <div class="card">
        <h3>👤 Personal Details</h3>
        @if (userError()) {
          <div class="inline-error">{{ userError() }}</div>
        }
        <form [formGroup]="userForm" (ngSubmit)="saveUser()">
          <div class="field"><label>Full Name</label><input formControlName="name" /></div>
          <div class="two-col">
            <div class="field"><label>Email</label><input formControlName="email" [readonly]="true" /></div>
            <div class="field"><label>Mobile</label><input formControlName="mobile" /></div>
          </div>
          <button class="btn btn-primary btn-sm" type="submit" [disabled]="userForm.invalid || savingUser()">
            @if (savingUser()) { <span class="spinner"></span> } @else { Save Changes }
          </button>
        </form>
        <div style="margin-top:14px;">
          <span class="btn-link" routerLink="/forgot-password">Change my password →</span>
        </div>
      </div>

      <div class="card">
        <h3>💼 Employment &amp; Income Profile</h3>
        @if (empError()) {
          <div class="inline-error">{{ empError() }}</div>
        }
        @if (empLoading()) {
          <div class="page-loading"><span class="spinner dark"></span> Loading…</div>
        } @else {
          <form [formGroup]="empForm" (ngSubmit)="saveEmployment()">
            <div class="field">
              <label>Employment Type</label>
              <select formControlName="employmentType">
                <option value="SALARIED">Salaried</option>
                <option value="SELF_EMPLOYED">Self-Employed</option>
                <option value="BUSINESS_OWNER">Business Owner</option>
              </select>
            </div>
            <div class="field"><label>Employer</label><input formControlName="employer" /></div>
            <div class="two-col">
              <div class="field"><label>Monthly Income (₹)</label><input type="number" formControlName="monthlyIncome" /></div>
              <div class="field"><label>Other EMIs (₹)</label><input type="number" formControlName="otherEmis" /></div>
            </div>
            <div class="two-col">
              <div class="field"><label>Desired Loan Amount (₹)</label><input type="number" formControlName="desiredAmount" /></div>
              <div class="field"><label>PAN</label><input formControlName="pan" /></div>
            </div>
            <button class="btn btn-primary btn-sm" type="submit" [disabled]="savingEmp()">
              @if (savingEmp()) { <span class="spinner"></span> } @else { Save Employment Profile }
            </button>
          </form>
        }
      </div>
    </div>
  `
})
export class Profile {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private userSvc = inject(UserService);
  private toast = inject(ToastService);

  savingUser = signal(false);
  userError = signal('');

  empLoading = signal(true);
  savingEmp = signal(false);
  empError = signal('');
  private empExists = false;

  userForm = this.fb.nonNullable.group({
    name: [this.auth.currentUser()?.name || ''],
    email: [this.auth.currentUser()?.email || ''],
    mobile: [this.auth.currentUser()?.mobile || '']
  });

  empForm = this.fb.nonNullable.group({
    employmentType: ['SALARIED'],
    employer: [''],
    monthlyIncome: [0],
    otherEmis: [0],
    desiredAmount: [0],
    pan: ['']
  });

  constructor() {
    const email = this.auth.currentUser()?.email;
    if (!email) {
      this.empLoading.set(false);
      return;
    }
    this.userSvc.getEmploymentProfile(email).subscribe({
      next: (p) => {
        this.empForm.patchValue(p as any);
        this.empExists = true;
        this.empLoading.set(false);
      },
      error: () => {
        // No profile yet — that's fine, the form starts blank and we POST on first save.
        this.empExists = false;
        this.empLoading.set(false);
      }
    });
  }

  saveUser(): void {
    const email = this.auth.currentUser()?.email;
    if (!email) return;
    this.savingUser.set(true);
    this.userError.set('');
    const { name, mobile } = this.userForm.getRawValue();
    this.userSvc.updateUser(email, { name, mobile }).subscribe({
      next: (user) => {
        this.savingUser.set(false);
        this.toast.success('Profile updated');
        localStorage.setItem('hlms_user', JSON.stringify(user));
      },
      error: () => {
        this.savingUser.set(false);
        this.userError.set('Could not update your profile. Please try again.');
      }
    });
  }

  saveEmployment(): void {
    const email = this.auth.currentUser()?.email;
    if (!email) return;
    this.savingEmp.set(true);
    this.empError.set('');
    const profile: CustomerEmploymentProfile = { userEmail: email, ...this.empForm.getRawValue() };
    const req = this.empExists
      ? this.userSvc.updateEmploymentProfile(email, profile)
      : this.userSvc.createEmploymentProfile(profile);
    req.subscribe({
      next: () => {
        this.savingEmp.set(false);
        this.empExists = true;
        this.toast.success('Employment profile saved');
      },
      error: () => {
        this.savingEmp.set(false);
        this.empError.set('Could not save your employment profile. Please try again.');
      }
    });
  }
}
