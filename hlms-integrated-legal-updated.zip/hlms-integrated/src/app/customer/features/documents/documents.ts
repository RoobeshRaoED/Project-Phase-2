import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';

import { AuthService } from '../../core/services/auth.service';
import { LoanService } from '../../core/services/loan.service';
import {
  DocumentService,
  downloadBase64File,
  fileToBase64
} from '../../core/services/document.service';
import { ToastService } from '../../core/services/toast.service';

import { ApplicationDocument, LoanApplication } from '../../core/models/models';

interface RequiredDoc {
  type: string;
  title: string;
  description: string;
}

const REQUIRED_DOCS: RequiredDoc[] = [
  {
    type: 'PAN Card',
    title: 'PAN Card',
    description: 'Required for applicant identity and tax verification.'
  },
  {
    type: 'Identity Proof',
    title: 'Identity Proof',
    description: 'Upload passport, voter ID, driving license, or other accepted identity proof.'
  },
  {
    type: 'Address Proof',
    title: 'Address Proof',
    description: 'Upload electricity bill, rental agreement, passport, or other address proof.'
  },
  {
    type: 'Income Proof',
    title: 'Income Proof',
    description: 'Upload salary slips, Form 16, ITR, or business income proof.'
  },
  {
    type: 'Bank Statement',
    title: 'Bank Statement',
    description: 'Upload recent salary or operating account bank statement.'
  },
  {
    type: 'Property Papers',
    title: 'Property Papers',
    description: 'Upload sale agreement, allotment letter, title document, or property related proof.'
  },
  {
    type: 'Photograph',
    title: 'Photograph',
    description: 'Upload recent passport-size photograph.'
  }
];

const ALLOWED_EXTENSIONS = ['pdf', 'jpg', 'jpeg', 'png'];
const MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024;

@Component({
  selector: 'app-documents',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="page-head">
      <h1>Documents</h1>
      <p>Upload and manage documents required for your housing loan application.</p>
    </div>

    @if (!appId()) {
      <div class="card">
        @if (listLoading()) {
          <div class="page-loading">
            <span class="spinner dark"></span> Loading your applications...
          </div>
        } @else if (apps().length === 0) {
          <div class="empty-state">
            <p>Start an application first to upload documents.</p>
            <button class="btn btn-primary btn-sm" routerLink="/customer/apply">
              Apply for a Loan
            </button>
          </div>
        } @else {
          <p class="muted">Select an application to manage its documents.</p>

          <table>
            <thead>
              <tr>
                <th>Application</th>
                <th>Product</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>

            <tbody>
              @for (a of apps(); track a.appId) {
                <tr class="clickable-row" [routerLink]="['/customer/documents', a.appId]">
                  <td>{{ a.trackingNo || a.appId }}</td>
                  <td>{{ a.productId || 'Not selected' }}</td>
                  <td>
                    <span class="badge badge-orange">
                      {{ a.status || 'Draft' }}
                    </span>
                  </td>
                  <td>
                    <span class="btn-link">Manage Documents</span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        }
      </div>
    } @else {
      <button class="back-link" routerLink="/customer/documents">
        ← All Applications
      </button>

      <div class="card">
        <h3>Required Documents</h3>
        <p class="muted">
          Upload all required documents before final loan submission.
        </p>

        <div style="margin: 12px 0;">
          <span class="badge" [class.badge-green]="allRequiredUploaded()" [class.badge-orange]="!allRequiredUploaded()">
            {{ uploadedRequiredCount() }} / {{ requiredDocs.length }} Documents Uploaded
          </span>
        </div>

        <table>
          <thead>
            <tr>
              <th>Document</th>
              <th>Description</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>

          <tbody>
            @for (r of requiredDocs; track r.type) {
              <tr>
                <td>
                  <strong>{{ r.title }}</strong>
                </td>
                <td>{{ r.description }}</td>
                <td>
                  @if (hasDoc(r.type)) {
                    <span class="badge badge-green">Uploaded</span>
                  } @else {
                    <span class="badge badge-red">Required</span>
                  }
                </td>
                <td>
                  <button type="button" class="btn btn-outline btn-sm" (click)="selectDocType(r.type)">
                    {{ hasDoc(r.type) ? 'Re-upload' : 'Upload' }}
                  </button>
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>

      <div class="card">
        <h3>Upload Document</h3>

        @if (uploadError()) {
          <div class="inline-error">{{ uploadError() }}</div>
        }

        <div class="two-col">
          <div class="field">
            <label>Document Type</label>
            <select [(ngModel)]="docType" [ngModelOptions]="{ standalone: true }">
              @for (d of requiredDocs; track d.type) {
                <option [value]="d.type">{{ d.title }}</option>
              }
            </select>
          </div>

          <div class="field">
            <label>File</label>
            <input type="file" accept=".pdf,.jpg,.jpeg,.png" (change)="onFile($event)" />
            <div class="muted" style="font-size:12px;margin-top:4px;">
              Allowed formats: PDF, JPG, JPEG, PNG. Max size: 10 MB.
            </div>
          </div>
        </div>

        @if (selectedFile()) {
          <div class="muted" style="margin-bottom:10px;">
            Selected: {{ selectedFile()?.name }} ({{ selectedFileSizeText() }})
          </div>
        }

        <button class="btn btn-primary btn-sm" (click)="upload()" [disabled]="!selectedFile() || uploading()">
          @if (uploading()) {
            <span class="spinner"></span>
          } @else {
            Upload Document
          }
        </button>
      </div>

      <div class="card">
        <h3>Uploaded Documents</h3>

        @if (docsLoading()) {
          <div class="page-loading">
            <span class="spinner dark"></span> Loading documents...
          </div>
        } @else if (docs().length === 0) {
          <div class="empty-state">
            <p>No documents uploaded yet.</p>
          </div>
        } @else {
          <table>
            <thead>
              <tr>
                <th>Type</th>
                <th>File Name</th>
                <th>Uploaded</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>

            <tbody>
              @for (d of docs(); track d.documentId || d.fileName) {
                <tr>
                  <td>{{ d.docType }}</td>
                  <td>{{ d.fileName }}</td>
                  <td>{{ d.uploadedAt | date: 'medium' }}</td>
                  <td>
                    <span
                      class="badge"
                      [class.badge-green]="d.verificationStatus === 'Verified'"
                      [class.badge-red]="d.verificationStatus === 'Rejected'"
                      [class.badge-orange]="!d.verificationStatus || d.verificationStatus === 'Pending'">
                      {{ d.verificationStatus || 'Pending' }}
                    </span>
                  </td>
                  <td style="white-space: nowrap;">
                    <button class="btn btn-outline btn-sm" (click)="download(d)">
                      Download
                    </button>
                    <button class="btn btn-danger btn-sm" (click)="remove(d)">
                      Delete
                    </button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        }
      </div>
    }
  `
})
export class Documents {
  private auth = inject(AuthService);
  private loanSvc = inject(LoanService);
  private docSvc = inject(DocumentService);
  private toast = inject(ToastService);
  private route = inject(ActivatedRoute);

  requiredDocs = REQUIRED_DOCS;
  docType = REQUIRED_DOCS[0].type;

  appId = signal<string | null>(null);

  listLoading = signal(true);
  apps = signal<LoanApplication[]>([]);

  docsLoading = signal(false);
  docs = signal<ApplicationDocument[]>([]);

  selectedFile = signal<File | null>(null);
  uploading = signal(false);
  uploadError = signal('');

  constructor() {
    const routeAppId = this.route.snapshot.paramMap.get('appId');

    if (routeAppId) {
      this.appId.set(routeAppId);
      this.listLoading.set(false);
      this.loadDocs(routeAppId);
      return;
    }

    const email = this.auth.currentUser()?.email;

    if (!email) {
      this.listLoading.set(false);
      return;
    }

    this.loanSvc.listForUser(email).subscribe({
      next: (list) => {
        this.apps.set(list);
        this.listLoading.set(false);
      },
      error: () => {
        this.listLoading.set(false);
      }
    });
  }

  private loadDocs(appId: string): void {
    this.docsLoading.set(true);

    this.docSvc.listByApp(appId).subscribe({
      next: (list) => {
        this.docs.set(list || []);
        this.docsLoading.set(false);
      },
      error: () => {
        this.docs.set([]);
        this.docsLoading.set(false);
      }
    });
  }

  hasDoc(type: string): boolean {
    return this.docs().some((d) => d.docType === type);
  }

  uploadedRequiredCount(): number {
    return this.requiredDocs.filter((d) => this.hasDoc(d.type)).length;
  }

  allRequiredUploaded(): boolean {
    return this.uploadedRequiredCount() === this.requiredDocs.length;
  }

  selectDocType(type: string): void {
    this.docType = type;
    this.uploadError.set('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  onFile(evt: Event): void {
    const input = evt.target as HTMLInputElement;
    const file = input.files?.[0] ?? null;

    this.uploadError.set('');

    if (!file) {
      this.selectedFile.set(null);
      return;
    }

    const extension = file.name.split('.').pop()?.toLowerCase() || '';

    if (!ALLOWED_EXTENSIONS.includes(extension)) {
      this.selectedFile.set(null);
      this.uploadError.set('Invalid file type. Please upload PDF, JPG, JPEG, or PNG.');
      input.value = '';
      return;
    }

    if (file.size > MAX_FILE_SIZE_BYTES) {
      this.selectedFile.set(null);
      this.uploadError.set('File size must not exceed 10 MB.');
      input.value = '';
      return;
    }

    this.selectedFile.set(file);
  }

  selectedFileSizeText(): string {
    const file = this.selectedFile();

    if (!file) {
      return '';
    }

    const sizeMb = file.size / (1024 * 1024);
    return `${sizeMb.toFixed(2)} MB`;
  }

  async upload(): Promise<void> {
    const appId = this.appId();
    const file = this.selectedFile();

    if (!appId) {
      this.uploadError.set('Application ID not found.');
      return;
    }

    if (!file) {
      this.uploadError.set('Please select a file.');
      return;
    }

    if (this.hasDoc(this.docType)) {
      const confirmReplace = confirm(
        `${this.docType} is already uploaded. Delete the existing document before uploading a replacement.`
      );

      if (!confirmReplace) {
        return;
      }

      this.uploadError.set('Please delete the existing document first, then upload the new file.');
      return;
    }

    this.uploading.set(true);
    this.uploadError.set('');

    try {
      const fileData = await fileToBase64(file);

      this.docSvc.upload({
        appId,
        docType: this.docType,
        fileName: file.name,
        fileData,
        fileSize: file.size,
        verificationStatus: 'Pending'
      }).subscribe({
        next: () => {
          this.uploading.set(false);
          this.selectedFile.set(null);
          this.toast.success('Document uploaded');
          this.loadDocs(appId);
        },
        error: (err) => {
          this.uploading.set(false);

          this.uploadError.set(
            err?.error?.message ||
              err?.error?.error ||
              'Upload failed. Please try again.'
          );
        }
      });
    } catch {
      this.uploading.set(false);
      this.uploadError.set('Could not read the selected file.');
    }
  }

  download(doc: ApplicationDocument): void {
    if (!doc.fileData) {
      this.toast.error('Download unavailable', 'File data is missing.');
      return;
    }

    const mimeType = this.mimeTypeForFile(doc.fileName || '');

    downloadBase64File(
      doc.fileData,
      doc.fileName || `${doc.docType || 'document'}.pdf`,
      mimeType
    );
  }

  remove(doc: ApplicationDocument): void {
    if (!doc.documentId) {
      return;
    }

    if (!confirm(`Delete "${doc.fileName}"?`)) {
      return;
    }

    this.docSvc.remove(doc.documentId).subscribe({
      next: () => {
        this.docs.update((list) =>
          list.filter((d) => d.documentId !== doc.documentId)
        );

        this.toast.success('Document deleted');
      },
      error: () => {
        this.toast.error('Could not delete document');
      }
    });
  }

  private mimeTypeForFile(fileName: string): string {
    const extension = fileName.split('.').pop()?.toLowerCase();

    if (extension === 'pdf') {
      return 'application/pdf';
    }

    if (extension === 'jpg' || extension === 'jpeg') {
      return 'image/jpeg';
    }

    if (extension === 'png') {
      return 'image/png';
    }

    return 'application/octet-stream';
  }
}