import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  template: `
    <div id="authScreen">
      <div class="auth-wrap">
        <div class="auth-side">
          <img class="auth-image" src="assets/images/hero.png" alt="HLMS" />
        </div>
        <div class="auth-form">
          <span class="back-link" routerLink="/">← Back to Home</span>
          <h2>Create your account</h2>
          <div class="sub">Register as a home loan customer to apply and track your loan online.</div>

          @if (errorMsg()) {
            <div class="inline-error">{{ errorMsg() }}</div>
          }

          <form [formGroup]="form" (ngSubmit)="submit()">
            <div class="field">
              <label>Full Name</label>
              <input formControlName="name" placeholder="Jane Doe" />
            </div>
            <div class="field">
              <label>Email</label>
              <input type="email" formControlName="email" placeholder="you@example.com" />
            </div>
            <div class="field">
              <label>Mobile</label>
              <input formControlName="mobile" placeholder="9876543210" />
            </div>
            <div class="two-col">
              <div class="field">
                <label>ID Type</label>
                <select formControlName="idType">
                  <option value="PAN">PAN</option>
                  <option value="AADHAAR">Aadhaar</option>
                  <option value="PASSPORT">Passport</option>
                  <option value="VOTER_ID">Voter ID</option>
                </select>
              </div>
              <div class="field">
                <label>ID Number</label>
                <input formControlName="idNumber" placeholder="ABCDE1234F" />
              </div>
            </div>
            <div class="field">
              <label>Password</label>
              <div class="password-wrap">
                <input [type]="showPw() ? 'text' : 'password'" formControlName="password" placeholder="Min. 8 characters" />
                <span class="password-toggle" (click)="showPw.set(!showPw())">{{ showPw() ? '🙈' : '👁' }}</span>
              </div>
            </div>
            <button class="btn btn-primary btn-block" type="submit" [disabled]="form.invalid || loading()">
              @if (loading()) {
                <span class="spinner"></span>
              } @else {
                Create Account
              }
            </button>
          </form>

          <div class="auth-switch">Already have an account? <a routerLink="/login">Log In</a></div>
        </div>
      </div>
    </div>
  `
})
export class Register {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private router = inject(Router);
  private toast = inject(ToastService);

  loading = signal(false);
  showPw = signal(false);
  errorMsg = signal('');

  form = this.fb.nonNullable.group({
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    mobile: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
    idType: ['PAN', Validators.required],
    idNumber: ['', Validators.required],
    password: ['', [Validators.required, Validators.minLength(8)]]
  });

  submit(): void {
    if (this.form.invalid) return;
    this.loading.set(true);
    this.errorMsg.set('');
    const { name, email, mobile, idType, idNumber, password } = this.form.getRawValue();
    this.auth
      .register({ name, email, mobile, idType, idNumber, password, role: 'CUSTOMER' })
      .subscribe({
        next: () => {
          this.loading.set(false);
          this.toast.success('Account created', 'You can now log in with your new account.');
          this.router.navigate(['/login']);
        },
        error: (err) => {
          this.loading.set(false);
          this.errorMsg.set(
            err?.status === 409
              ? 'An account with this email already exists.'
              : err?.error?.message || 'Registration failed. Please check the backend is running and try again.'
          );
        }
      });
  }
}
