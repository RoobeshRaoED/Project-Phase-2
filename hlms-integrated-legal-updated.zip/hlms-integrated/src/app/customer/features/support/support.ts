import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../core/services/auth.service';
import { NotificationService } from '../../core/services/notification.service';
import { ToastService } from '../../core/services/toast.service';
import { Notification, ServiceRequest } from '../../core/models/models';

const REQUEST_TYPES = ['General Query', 'Complaint', 'Document Assistance', 'Payment Issue', 'Other'];

@Component({
  selector: 'app-support',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-head">
      <h1>Support</h1>
      <p>Your notifications, service requests and ways to reach our team.</p>
    </div>

    <div class="grid grid-2">
      <div class="card">
        <h3>🔔 Notifications</h3>
        @if (notifLoading()) {
          <div class="page-loading"><span class="spinner dark"></span> Loading…</div>
        } @else if (notifications().length === 0) {
          <div class="empty-state"><p>No notifications yet.</p></div>
        } @else {
          @for (n of notifications(); track n.notificationId) {
            <div class="note-item" [style.opacity]="n.isRead ? 0.6 : 1">
              <div class="dt">{{ n.createdAt | date: 'medium' }}</div>
              <strong>{{ n.title }}</strong> — {{ n.body }}
              @if (!n.isRead) {
                <div><button class="btn-link" (click)="markRead(n)">Mark as read</button></div>
              }
            </div>
          }
        }
      </div>

      <div class="card">
        <h3>🛠 Raise a General Support Request</h3>
        @if (reqError()) {
          <div class="inline-error">{{ reqError() }}</div>
        }
        <div class="field">
          <label>Request Type</label>
          <select [(ngModel)]="requestType" [ngModelOptions]="{ standalone: true }">
            @for (t of requestTypes; track t) { <option [value]="t">{{ t }}</option> }
          </select>
        </div>
        <div class="field">
          <label>Description</label>
          <textarea rows="4" [(ngModel)]="requestDesc" [ngModelOptions]="{ standalone: true }" placeholder="Describe your issue or question"></textarea>
        </div>
        <button class="btn btn-primary btn-sm" (click)="raiseRequest()" [disabled]="raising()">
          @if (raising()) { <span class="spinner"></span> } @else { Submit Request }
        </button>

        <h4 style="margin-top:18px;">My Requests</h4>
        @if (reqsLoading()) {
          <div class="page-loading"><span class="spinner dark"></span> Loading…</div>
        } @else if (requests().length === 0) {
          <div class="empty-state"><p>No support requests raised yet.</p></div>
        } @else {
          <table>
            <thead><tr><th>Type</th><th>Status</th><th>Raised</th></tr></thead>
            <tbody>
              @for (r of requests(); track r.requestId) {
                <tr><td>{{ r.requestType }}</td><td><span class="badge badge-orange">{{ r.status || 'Requested' }}</span></td><td>{{ r.createdAt | date: 'short' }}</td></tr>
              }
            </tbody>
          </table>
        }
      </div>
    </div>

    <div class="card">
      <h3>📞 Contact Us</h3>
      <div class="grid grid-3">
        <div class="stat"><span class="lbl">Customer Care</span><span class="val">1800-123-4567</span></div>
        <div class="stat"><span class="lbl">Email</span><span class="val">support&#64;hlms.example</span></div>
        <div class="stat"><span class="lbl">Hours</span><span class="val">Mon–Sat, 9 AM – 7 PM</span></div>
      </div>
    </div>
  `
})
export class Support {
  private auth = inject(AuthService);
  private notifSvc = inject(NotificationService);
  private toast = inject(ToastService);

  requestTypes = REQUEST_TYPES;
  requestType = REQUEST_TYPES[0];
  requestDesc = '';

  notifLoading = signal(true);
  notifications = signal<Notification[]>([]);

  reqsLoading = signal(true);
  requests = signal<ServiceRequest[]>([]);
  raising = signal(false);
  reqError = signal('');

  constructor() {
    const email = this.auth.currentUser()?.email;
    if (!email) {
      this.notifLoading.set(false);
      this.reqsLoading.set(false);
      return;
    }
    this.notifSvc.listForUser(email).subscribe({
      next: (list) => {
        this.notifications.set(list);
        this.notifLoading.set(false);
      },
      error: () => this.notifLoading.set(false)
    });
    this.loadRequests(email);
  }

  private loadRequests(email: string): void {
    this.reqsLoading.set(true);
    this.notifSvc.listServiceRequests(email).subscribe({
      next: (list) => {
        this.requests.set(list);
        this.reqsLoading.set(false);
      },
      error: () => this.reqsLoading.set(false)
    });
  }

  markRead(n: Notification): void {
    if (!n.notificationId) return;
    this.notifSvc.markRead(n.notificationId).subscribe({
      next: (updated) => {
        this.notifications.update((list) =>
          list.map((x) => (x.notificationId === updated.notificationId ? updated : x))
        );
      },
      error: () => this.toast.error('Could not mark as read')
    });
  }

  raiseRequest(): void {
    const email = this.auth.currentUser()?.email;
    if (!email) return;
    this.raising.set(true);
    this.reqError.set('');
    this.notifSvc.createServiceRequest({ userEmail: email, requestType: this.requestType, description: this.requestDesc }).subscribe({
      next: () => {
        this.raising.set(false);
        this.requestDesc = '';
        this.toast.success('Request submitted', 'Our team will get back to you shortly.');
        this.loadRequests(email);
      },
      error: () => {
        this.raising.set(false);
        this.reqError.set('Could not submit your request. Please try again.');
      }
    });
  }
}
