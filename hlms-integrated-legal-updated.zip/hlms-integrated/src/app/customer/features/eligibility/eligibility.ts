import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { LoanService } from '../../core/services/loan.service';
import { EligibilityAssessment, EligibilityResponse } from '../../core/models/models';

@Component({
  selector: 'app-eligibility',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="page-head">
      <h1>Eligibility Check</h1>
      <p>See your estimated loan eligibility and EMI before you apply.</p>
    </div>

    <div class="grid grid-2">
      <div class="card">
        <h3>Your Details</h3>
        @if (formError()) {
          <div class="inline-error">{{ formError() }}</div>
        }
        <form [formGroup]="form" (ngSubmit)="assess()">
          <div class="two-col">
            <div class="field"><label>Monthly Income (₹)</label><input type="number" formControlName="monthlyIncome" /></div>
            <div class="field"><label>Other EMIs (₹)</label><input type="number" formControlName="otherEmis" /></div>
          </div>
          <div class="two-col">
            <div class="field"><label>CIBIL Score</label><input type="number" formControlName="cibilScore" /></div>
            <div class="field"><label>Requested Amount (₹)</label><input type="number" formControlName="requestedAmount" /></div>
          </div>
          <div class="two-col">
            <div class="field"><label>Tenure (years)</label><input type="number" formControlName="tenureYears" /></div>
            <div class="field"><label>Interest Rate (%)</label><input type="number" formControlName="interestRate" step="0.01" /></div>
          </div>
          <button class="btn btn-primary btn-block" type="submit" [disabled]="form.invalid || loading()">
            @if (loading()) { <span class="spinner"></span> } @else { Check My Eligibility }
          </button>
        </form>
      </div>

      <div class="card">
        <h3>Result</h3>
        @if (!result() && !loading()) {
          <div class="empty-state"><div class="ic">☑</div><p>Fill in your details and check your eligibility.</p></div>
        }
        @if (loading()) {
          <div class="page-loading"><span class="spinner dark"></span> Assessing…</div>
        }
        @if (result(); as r) {
          <div class="stat" style="margin-bottom:12px;">
            <span class="lbl">Status</span>
            <span class="badge" [class]="r.status === 'Eligible' ? 'badge-green' : 'badge-red'">{{ r.status }}</span>
          </div>
          <div class="two-col">
            <div class="stat"><span class="lbl">Max Eligible Amount</span><span class="val teal">₹{{ r.maxEligibleLoanAmount | number: '1.0-0' }}</span></div>
            <div class="stat"><span class="lbl">Estimated EMI</span><span class="val">₹{{ r.estimatedEmi | number: '1.0-0' }}</span></div>
          </div>
          <div class="stat" style="margin:10px 0;"><span class="lbl">Debt-to-Income Ratio</span><span class="val">{{ (r.debtToIncomeRatio * 100) | number: '1.0-1' }}%</span></div>
          @if (r.reasons?.length) {
            <div><strong>Notes</strong>
              <ul>@for (x of r.reasons; track x) { <li>{{ x }}</li> }</ul>
            </div>
          }
          @if (r.recommendations?.length) {
            <div><strong>Recommendations</strong>
              <ul>@for (x of r.recommendations; track x) { <li>{{ x }}</li> }</ul>
            </div>
          }
          @if (r.status === 'Eligible') {
            <button class="btn btn-primary btn-block" style="margin-top:12px;" routerLink="/customer/apply">Proceed to Apply →</button>
          }
        }
      </div>
    </div>

    <div class="card">
      <h3>📜 Past Eligibility Checks</h3>
      @if (historyLoading()) {
        <div class="page-loading"><span class="spinner dark"></span> Loading history…</div>
      } @else if (history().length === 0) {
        <div class="empty-state"><p>No previous eligibility checks yet.</p></div>
      } @else {
        <table>
          <thead><tr><th>Date</th><th>Requested</th><th>Status</th><th>Max Eligible</th><th>Est. EMI</th></tr></thead>
          <tbody>
            @for (h of history(); track h.assessmentId) {
              <tr>
                <td>{{ h.createdAt | date: 'medium' }}</td>
                <td>₹{{ h.requestedAmount | number: '1.0-0' }}</td>
                <td><span class="badge" [class]="h.status === 'Eligible' ? 'badge-green' : 'badge-red'">{{ h.status }}</span></td>
                <td>₹{{ h.maxEligibleLoanAmount | number: '1.0-0' }}</td>
                <td>₹{{ h.estimatedEmi | number: '1.0-0' }}</td>
              </tr>
            }
          </tbody>
        </table>
      }
    </div>
  `
})
export class Eligibility {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private loanSvc = inject(LoanService);

  loading = signal(false);
  formError = signal('');
  result = signal<EligibilityResponse | null>(null);

  history = signal<EligibilityAssessment[]>([]);
  historyLoading = signal(true);

  form = this.fb.nonNullable.group({
    monthlyIncome: [80000],
    otherEmis: [0],
    cibilScore: [750],
    requestedAmount: [3000000],
    tenureYears: [20],
    interestRate: [8.5]
  });

  constructor() {
    this.loadHistory();
  }

  private loadHistory(): void {
    const email = this.auth.currentUser()?.email;
    if (!email) {
      this.historyLoading.set(false);
      return;
    }
    this.loanSvc.eligibilityHistory(email).subscribe({
      next: (list) => {
        this.history.set(list);
        this.historyLoading.set(false);
      },
      error: () => this.historyLoading.set(false)
    });
  }

  assess(): void {
    const email = this.auth.currentUser()?.email;
    if (!email || this.form.invalid) return;
    this.loading.set(true);
    this.formError.set('');
    this.loanSvc.assessEligibility(email, this.form.getRawValue()).subscribe({
      next: (res) => {
        this.result.set(res);
        this.loading.set(false);
        this.loadHistory();
      },
      error: () => {
        this.formError.set('Could not assess eligibility right now. Please try again.');
        this.loading.set(false);
      }
    });
  }
}
