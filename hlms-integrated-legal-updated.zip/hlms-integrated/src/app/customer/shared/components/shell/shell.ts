import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Topbar } from '../topbar/topbar';
import { Sidebar } from '../sidebar/sidebar';

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [RouterOutlet, Topbar, Sidebar],
  template: `
    <div id="app">
      <app-topbar></app-topbar>
      <app-sidebar></app-sidebar>
      <div class="main">
        <router-outlet></router-outlet>
      </div>
      <footer class="app-footer">HLMS Customer Portal — connected to the live HLMS microservices backend.</footer>
    </div>
  `
})
export class Shell {}
