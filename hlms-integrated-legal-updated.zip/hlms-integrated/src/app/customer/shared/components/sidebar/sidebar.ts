import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

interface NavItem {
  path: string;
  icon: string;
  label: string;
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [RouterLink, RouterLinkActive],
  template: `
    <div class="sidebar" id="sidebar">
      @for (item of items; track item.path) {
        <a
          class="nav-item"
          [routerLink]="item.path"
          routerLinkActive="active-link"
          [routerLinkActiveOptions]="{ exact: false }"
        >
          <span class="ic">{{ item.icon }}</span>
          <span>{{ item.label }}</span>
        </a>
      }
    </div>
  `
})
export class Sidebar {
  items: NavItem[] = [
    { path: '/customer/dashboard', icon: '⌂', label: 'Dashboard' },
    { path: '/customer/guidance', icon: '☰', label: 'Loan Guidance' },
    { path: '/customer/eligibility', icon: '☑', label: 'Eligibility Check' },
    { path: '/customer/apply', icon: '📝', label: 'Apply for Loan' },
    { path: '/customer/tracking', icon: '↗', label: 'Track Application' },
    { path: '/customer/repayment', icon: 'Ⓡ', label: 'Repayment' },
    { path: '/customer/postdisb', icon: '🏷', label: 'Post-Disbursement' },
    { path: '/customer/documents', icon: '▯', label: 'Documents' },
    { path: '/customer/auction', icon: '☆', label: 'Legal & Auction' },
    { path: '/customer/profile', icon: '☺', label: 'My Profile' },
    { path: '/customer/support', icon: '?', label: 'Support' }
  ];
}
