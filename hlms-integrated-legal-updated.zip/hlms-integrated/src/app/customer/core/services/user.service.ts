import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { AppUser, CustomerEmploymentProfile } from '../models/models';

@Injectable({ providedIn: 'root' })
export class UserService {
  private base = `${environment.apiBase}/user-service/api`;

  constructor(private http: HttpClient) {}

  getUser(email: string): Observable<AppUser> {
    return this.http.get<AppUser>(`${this.base}/users/${encodeURIComponent(email)}`);
  }

  updateUser(email: string, user: Partial<AppUser>): Observable<AppUser> {
    return this.http.put<AppUser>(`${this.base}/users/${encodeURIComponent(email)}`, user);
  }

  // ---- Employment / eligibility profile (US customer-profile) ----

  getEmploymentProfile(email: string): Observable<CustomerEmploymentProfile> {
    return this.http.get<CustomerEmploymentProfile>(
      `${this.base}/customer-profile/${encodeURIComponent(email)}`
    );
  }

  createEmploymentProfile(profile: CustomerEmploymentProfile): Observable<CustomerEmploymentProfile> {
    return this.http.post<CustomerEmploymentProfile>(`${this.base}/customer-profile`, profile);
  }

  updateEmploymentProfile(
    email: string,
    profile: CustomerEmploymentProfile
  ): Observable<CustomerEmploymentProfile> {
    return this.http.put<CustomerEmploymentProfile>(
      `${this.base}/customer-profile/${encodeURIComponent(email)}`,
      profile
    );
  }
}
