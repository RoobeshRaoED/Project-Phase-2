import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';
import { environment } from '../../../../environments/environment';

import {
  Disbursement,
  EligibilityAssessment,
  EligibilityRequest,
  EligibilityResponse,
  EmiOption,
  ExpectedCompletion,
  GuidanceAssistantRequest,
  LoanApplication,
  LoanProduct,
  LoanRecommendationRequest,
  MortgageCalculationRequest,
  MortgageCalculationResponse,
  ProductRecommendation,
  StakeholderInfo,
  SubmitApplicationRequest,
  WorkflowTimelineResponse
} from '../models/models';

@Injectable({ providedIn: 'root' })
export class LoanService {
  private base = `${environment.apiBase}/loan-service/api`;

  constructor(private http: HttpClient) {}

  // ---- Loan products ----

  listProducts(): Observable<LoanProduct[]> {
    const url = `${this.base}/loan-products`;

    console.log('Loan products API URL:', url);

    return this.http.get<LoanProduct[]>(url).pipe(
      catchError((error) => {
        console.error('Loan products API failed:', error);
        return throwError(() => error);
      })
    );
  }

  getProduct(productId: string): Observable<LoanProduct> {
    const url = `${this.base}/loan-products/${encodeURIComponent(productId)}`;

    return this.http.get<LoanProduct>(url).pipe(
      catchError((error) => {
        console.error('Get loan product API failed:', error);
        return throwError(() => error);
      })
    );
  }

  // ---- Eligibility ----

  assessEligibility(userEmail: string, req: EligibilityRequest): Observable<EligibilityResponse> {
    const params = new HttpParams().set('userEmail', userEmail);
    const url = `${this.base}/eligibility/assess`;

    return this.http.post<EligibilityResponse>(url, req, { params }).pipe(
      catchError((error) => {
        console.error('Assess eligibility API failed:', error);
        return throwError(() => error);
      })
    );
  }

  simulateEligibility(req: EligibilityRequest): Observable<EligibilityResponse> {
    const url = `${this.base}/eligibility/simulate`;

    return this.http.post<EligibilityResponse>(url, req).pipe(
      catchError((error) => {
        console.error('Simulate eligibility API failed:', error);
        return throwError(() => error);
      })
    );
  }

  eligibilityHistory(userEmail: string): Observable<EligibilityAssessment[]> {
    const params = new HttpParams().set('userEmail', userEmail);
    const url = `${this.base}/eligibility/history`;

    return this.http.get<EligibilityAssessment[]>(url, { params }).pipe(
      catchError((error) => {
        console.error('Eligibility history API failed:', error);
        return throwError(() => error);
      })
    );
  }

  // ---- Mortgage / collateral ----

  calculateMortgage(req: MortgageCalculationRequest): Observable<MortgageCalculationResponse> {
    const url = `${this.base}/mortgage/calculate`;

    return this.http.post<MortgageCalculationResponse>(url, req).pipe(
      catchError((error) => {
        console.error('Calculate mortgage API failed:', error);
        return throwError(() => error);
      })
    );
  }

  calculateMortgageForApplication(
    appId: string,
    req: MortgageCalculationRequest
  ): Observable<MortgageCalculationResponse> {
    const url = `${this.base}/mortgage/${encodeURIComponent(appId)}/calculate`;

    return this.http.post<MortgageCalculationResponse>(url, req).pipe(
      catchError((error) => {
        console.error('Calculate mortgage for application API failed:', error);
        return throwError(() => error);
      })
    );
  }

  getMortgageRecord(appId: string): Observable<Record<string, unknown>> {
    const url = `${this.base}/mortgage/${encodeURIComponent(appId)}`;

    return this.http.get<Record<string, unknown>>(url).pipe(
      catchError((error) => {
        console.error('Get mortgage record API failed:', error);
        return throwError(() => error);
      })
    );
  }

  // ---- Guidance ----

  recommendProducts(req: LoanRecommendationRequest): Observable<ProductRecommendation[]> {
    const url = `${this.base}/loan-guidance/recommendations`;

    console.log('Recommendations API URL:', url);

    return this.http.post<ProductRecommendation[]>(url, req).pipe(
      catchError((error) => {
        console.error('Recommendations API failed:', error);
        return throwError(() => error);
      })
    );
  }

  emiAssistant(req: GuidanceAssistantRequest): Observable<EmiOption[]> {
    const url = `${this.base}/loan-guidance/emi-assistant`;

    console.log('EMI Assistant API URL:', url);

    return this.http.post<EmiOption[]>(url, req).pipe(
      catchError((error) => {
        console.error('EMI Assistant API failed:', error);
        return throwError(() => error);
      })
    );
  }

  // ---- Applications ----

  listForUser(userEmail: string): Observable<LoanApplication[]> {
    const params = new HttpParams().set('userEmail', userEmail);
    const url = `${this.base}/loan-applications`;

    return this.http.get<LoanApplication[]>(url, { params }).pipe(
      catchError((error) => {
        console.error('List applications API failed:', error);
        return throwError(() => error);
      })
    );
  }

  getApplication(appId: string): Observable<LoanApplication> {
    const url = `${this.base}/loan-applications/${encodeURIComponent(appId)}`;

    return this.http.get<LoanApplication>(url).pipe(
      catchError((error) => {
        console.error('Get application API failed:', error);
        return throwError(() => error);
      })
    );
  }

  trackByTrackingNo(trackingNo: string): Observable<LoanApplication> {
    const url = `${this.base}/loan-applications/track/${encodeURIComponent(trackingNo)}`;

    return this.http.get<LoanApplication>(url).pipe(
      catchError((error) => {
        console.error('Track application API failed:', error);
        return throwError(() => error);
      })
    );
  }

  workflowStages(): Observable<string[]> {
    const url = `${this.base}/loan-applications/workflow-stages`;

    return this.http.get<string[]>(url).pipe(
      catchError((error) => {
        console.error('Workflow stages API failed:', error);
        return throwError(() => error);
      })
    );
  }

  saveDraft(
    userEmail: string,
    currentStep: number,
    req: SubmitApplicationRequest,
    appId?: string
  ): Observable<LoanApplication> {
    let params = new HttpParams()
      .set('userEmail', userEmail)
      .set('currentStep', currentStep);

    if (appId) {
      params = params.set('appId', appId);
    }

    const url = `${this.base}/loan-applications/draft`;

    return this.http.post<LoanApplication>(url, req, { params }).pipe(
      catchError((error) => {
        console.error('Save draft API failed:', error);
        return throwError(() => error);
      })
    );
  }

  submitApplication(appId: string): Observable<LoanApplication> {
    const url = `${this.base}/loan-applications/${encodeURIComponent(appId)}/submit`;

    return this.http.post<LoanApplication>(url, {}).pipe(
      catchError((error) => {
        console.error('Submit application API failed:', error);
        return throwError(() => error);
      })
    );
  }

  withdraw(appId: string): Observable<void> {
    const url = `${this.base}/loan-applications/${encodeURIComponent(appId)}`;

    return this.http.delete<void>(url).pipe(
      catchError((error) => {
        console.error('Withdraw application API failed:', error);
        return throwError(() => error);
      })
    );
  }

  // ---- Status tracking ----

  stakeholder(appId: string): Observable<StakeholderInfo> {
    const url = `${this.base}/loan-applications/${encodeURIComponent(appId)}/stakeholder`;

    return this.http.get<StakeholderInfo>(url).pipe(
      catchError((error) => {
        console.error('Stakeholder API failed:', error);
        return throwError(() => error);
      })
    );
  }

  timeline(appId: string): Observable<WorkflowTimelineResponse> {
    const url = `${this.base}/loan-applications/${encodeURIComponent(appId)}/timeline`;

    return this.http.get<WorkflowTimelineResponse>(url).pipe(
      catchError((error) => {
        console.error('Timeline API failed:', error);
        return throwError(() => error);
      })
    );
  }

  expectedCompletion(appId: string): Observable<ExpectedCompletion> {
    const url = `${this.base}/loan-applications/${encodeURIComponent(appId)}/expected-completion`;

    return this.http.get<ExpectedCompletion>(url).pipe(
      catchError((error) => {
        console.error('Expected completion API failed:', error);
        return throwError(() => error);
      })
    );
  }

    // ---- Disbursement ----

  createOrUpdateDisbursement(req: Partial<Disbursement>): Observable<Disbursement> {
    const url = `${this.base}/disbursements`;

    return this.http.post<Disbursement>(url, req).pipe(
      catchError((error) => {
        console.error('Create disbursement API failed:', error);
        return throwError(() => error);
      })
    );
  }

  getDisbursementByApp(appId: string): Observable<Disbursement> {
    const url = `${this.base}/disbursements/app/${encodeURIComponent(appId)}`;

    return this.http.get<Disbursement>(url).pipe(
      catchError((error) => {
        console.error('Get disbursement API failed:', error);
        return throwError(() => error);
      })
    );
  }
}