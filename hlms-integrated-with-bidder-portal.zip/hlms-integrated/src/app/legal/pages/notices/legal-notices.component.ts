import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { forkJoin } from 'rxjs';
import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';
import { LegalNoticeService } from '../../core/services/legal-notice.service';
import { LoanApplicationService } from '../../core/services/loan-application.service';
import { NotificationService } from '../../core/services/notification.service';
import { LegalNoticeDTO, LoanApplication } from '../../core/models/models';

interface NoticeRow extends LegalNoticeDTO { trackingNo: string; applicantName: string; userEmail: string; }

@Component({
  selector: 'app-legal-notices',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './legal-notices.component.html'
})
export class LegalNoticesComponent implements OnInit {
  loading = signal(true);
  notices = signal<NoticeRow[]>([]);
  apps = signal<LoanApplication[]>([]);

  draftModalOpen = signal(false);
  draft = { appId: '', noticeType: '', content: '' };
  draftError = signal<string | null>(null);
  saving = signal(false);

  constructor(
    public auth: AuthService,
    private toast: ToastService,
    private noticeSvc: LegalNoticeService,
    private loanSvc: LoanApplicationService,
    private notifSvc: NotificationService
  ) {}

  ngOnInit(): void {
    this.loadAll();
  }

  private loadAll(): void {
    this.loading.set(true);
    forkJoin({ notices: this.noticeSvc.listAll(), apps: this.loanSvc.listAll() }).subscribe(({ notices, apps }) => {
      this.apps.set(apps);
      const byId = new Map<string, LoanApplication>(apps.map((a) => [a.appId, a]));
      this.notices.set(
        notices
          .map((n) => ({
            ...n,
            trackingNo: n.appId ? (byId.get(n.appId)?.trackingNo || n.appId) : '—',
            applicantName: n.appId ? (byId.get(n.appId)?.applicantName || '—') : '—',
            userEmail: n.appId ? (byId.get(n.appId)?.userEmail || '') : ''
          }))
          .sort((a, b) => new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime())
      );
      this.loading.set(false);
    });
  }

  statusBadge(status: string): string {
    return status === 'Active' ? 'badge-orange' : 'badge-gray';
  }

  openDraft(): void {
    this.draft = { appId: '', noticeType: '', content: '' };
    this.draftError.set(null);
    this.draftModalOpen.set(true);
  }

  closeDraft(): void {
    this.draftModalOpen.set(false);
  }

  submitDraft(): void {
    const officer = this.auth.currentUser();
    if (!officer) return;
    if (!this.draft.noticeType.trim() || !this.draft.content.trim()) {
      this.draftError.set('Please provide a notice type and content.');
      return;
    }
    const app = this.draft.appId ? this.apps().find((a) => a.appId === this.draft.appId) : undefined;
    const now = new Date();
    const dto: LegalNoticeDTO = {
      noticeNo: 'LEGAL/' + now.getFullYear() + '/' + Date.now(),
      appId: this.draft.appId || null,
      noticeType: this.draft.noticeType.trim(),
      issueDate: now.toISOString(),
      dueDate: null,
      status: 'Active',
      officerEmail: officer.email,
      content: this.draft.content.trim()
    };
    this.saving.set(true);
    this.noticeSvc.create(dto).subscribe({
      next: () => {
        this.saving.set(false);
        this.toast.success('Notice Logged', dto.noticeNo);
        if (app) {
          this.notifSvc.send(app.userEmail, dto.noticeType,
            `A new legal communication has been issued regarding your loan account ${app.trackingNo}.`).subscribe();
        }
        this.closeDraft();
        this.loadAll();
      },
      error: () => {
        this.saving.set(false);
        this.draftError.set('Could not issue notice. Please try again.');
      }
    });
  }

  downloadNotice(n: NoticeRow): void {
    const blob = new Blob([n.content || ''], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${(n.noticeNo || 'notice').replace(/\//g, '_')}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
