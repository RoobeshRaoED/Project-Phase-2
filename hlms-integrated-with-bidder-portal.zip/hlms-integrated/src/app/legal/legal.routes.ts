import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';

/**
 * Legal & Valuation Team portal, mounted at /legal.
 * Child paths and the LEGAL-role guard are the originals from
 * hlms-legal-portal's app.routes.ts.
 */
export const LEGAL_ROUTES: Routes = [
  {
    path: 'login',
    loadComponent: () => import('./pages/login/login.component').then((m) => m.LoginComponent)
  },
  {
    path: '',
    loadComponent: () => import('./layout/shell/shell.component').then((m) => m.ShellComponent),
    canActivate: [authGuard],
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      { path: 'dashboard', loadComponent: () => import('./pages/dashboard/legal-dashboard.component').then((m) => m.LegalDashboardComponent) },
      { path: 'queue', loadComponent: () => import('./pages/queue/legal-queue.component').then((m) => m.LegalQueueComponent) },
      { path: 'case/:appId', loadComponent: () => import('./pages/case-detail/legal-case-detail.component').then((m) => m.LegalCaseDetailComponent) },
      { path: 'documents', loadComponent: () => import('./pages/documents/legal-documents.component').then((m) => m.LegalDocumentsComponent) },
      { path: 'auction', loadComponent: () => import('./pages/auction/legal-auction.component').then((m) => m.LegalAuctionComponent) },
      { path: 'notices', loadComponent: () => import('./pages/notices/legal-notices.component').then((m) => m.LegalNoticesComponent) },
      { path: 'profile', loadComponent: () => import('./pages/profile/legal-profile.component').then((m) => m.LegalProfileComponent) }
    ]
  }
];
