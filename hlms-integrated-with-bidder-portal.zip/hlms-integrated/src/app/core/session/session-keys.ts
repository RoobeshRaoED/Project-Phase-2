/**
 * INTEGRATION LAYER - localStorage key registry.
 *
 * The five source projects were developed independently and each invented its
 * own localStorage keys for the very same JWT / user record:
 *
 *   hlms-auth (home/login/register) : 'hlms_auth_token' + 'hlms_user'
 *   customer  (angular-customer-ui) : 'hlms_token'      + 'hlms_user'
 *   admin     (hlms-admin-ui)       : 'hlms_admin_token'
 *   bank office (hlms-bankoffice-ui): 'hlms_token'      + 'hlms_session_v1'
 *   legal     (hlms-legal-portal)   : 'hlms_legal_token'
 *   bidder    (Bidder Portal)       : 'hlms_bidder_token'
 *
 * Rather than rewrite five working AuthServices, the integration keeps every
 * key and writes the SAME token to all of them at login time (see
 * SessionService). Each module then restores its session through its own
 * original, unmodified code path.
 *
 * This file is the single place that knows the full key list, so that a logout
 * from ANY module can clear the whole session instead of leaving another
 * module's portal still reachable.
 */

export const TOKEN_KEYS = [
  'hlms_auth_token',   // auth module
  'hlms_token',        // customer + bank office
  'hlms_admin_token',  // admin module
  'hlms_legal_token',  // legal module
  'hlms_bidder_token'  // bidder portal (added with the Bidder Portal integration)
] as const;

export const USER_KEYS = [
  'hlms_user',       // auth + customer
  'hlms_session_v1'  // bank office
] as const;

/**
 * Wipes every module's session material.
 *
 * Called from each module's own logout() so that signing out of, say, the
 * customer portal really does end the session everywhere -- without this, the
 * other modules' keys would survive and their guards would still pass.
 */
export function clearHlmsSession(): void {
  for (const k of TOKEN_KEYS) localStorage.removeItem(k);
  for (const k of USER_KEYS) localStorage.removeItem(k);
}
