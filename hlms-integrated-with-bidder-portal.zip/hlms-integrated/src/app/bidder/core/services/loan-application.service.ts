import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { LoanApplication } from '../models/models';

/**
 * loan-service read access for the Bidder Portal.
 *
 * IMPORTANT -- why /all and not /{appId}:
 * LoanApplicationController.get(appId) is annotated @RequireAppOwner, and
 * AppOwnerSecurityAspect only treats ADMIN / BANK_OFFICER / LEGAL as
 * privileged. A BIDDER therefore gets 403 on the by-id endpoint for any
 * application it does not own. GET /api/loan-applications/all carries no such
 * annotation (SecurityConfig requires authentication only), so the portal
 * fetches the list once and joins client-side.
 *
 * This is the same approach the Bank Office auction screen already uses
 * (bo-auction.component.ts), so it follows an established convention rather
 * than introducing a new one.
 */
@Injectable({ providedIn: 'root' })
export class LoanApplicationService {
  private base = `${environment.apiBase}/loan-service/api/loan-applications`;

  constructor(private http: HttpClient) {}

  listAll(): Observable<LoanApplication[]> {
    return this.http.get<LoanApplication[]>(`${this.base}/all`);
  }
}
