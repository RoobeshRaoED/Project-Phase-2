import { Injectable } from '@angular/core';
import { Observable, forkJoin, map, of, catchError } from 'rxjs';

import { AuctionService } from './auction.service';
import { LoanApplicationService } from './loan-application.service';
import {
  AUCTION_LIVE_STAGE,
  AuctionCaseDTO,
  AuctionListing,
  BidDTO,
  LoanApplication
} from '../models/models';

/**
 * Builds the Bidder Portal's view model from the three real backend sources.
 *
 * No single endpoint returns "auction listings", so this composes:
 *
 *   GET /repayment-service/api/auctions              -> the auction cases
 *   GET /loan-service/api/loan-applications/all      -> property details
 *   GET /repayment-service/api/bids                  -> every bid
 *
 * and derives, per listing, the bid history, the highest bid, whether bidding
 * is still open and the minimum next bid. Fetching all bids once (rather than
 * one /auctions/{appId}/bids call per listing) keeps the dashboard and the
 * listings grid to three HTTP calls total; the detail screen still re-reads
 * its own listing's bids from /auctions/{appId}/bids so a freshly placed bid
 * shows up immediately.
 *
 * Nothing here is mocked -- if a call fails the error propagates so the
 * component can show a real error state instead of a silently empty page.
 */
@Injectable({ providedIn: 'root' })
export class BidderDataService {
  constructor(
    private auctionSvc: AuctionService,
    private loanSvc: LoanApplicationService
  ) {}

  /**
   * Every property currently listed for e-auction, newest auction date first,
   * enriched with its property and bid data.
   *
   * Only cases at stage "Auction Scheduled" are public: that is the stage the
   * Legal & Valuation portal sets when it posts a property for e-auction
   * (legal-auction.component.ts), and the reference UI applies exactly the
   * same filter.
   */
  listings(): Observable<AuctionListing[]> {
    return forkJoin({
      auctions: this.auctionSvc.listAll(),
      apps: this.loanSvc.listAll().pipe(catchError(() => of([] as LoanApplication[]))),
      bids: this.auctionSvc.listAllBids().pipe(catchError(() => of([] as BidDTO[])))
    }).pipe(
      map(({ auctions, apps, bids }) => {
        const live = auctions.filter((a) => a.stage === AUCTION_LIVE_STAGE);
        return live
          .map((auction) =>
            this.toListing(
              auction,
              apps.find((app) => String(app.appId) === String(auction.appId)) ?? null,
              bids.filter((b) => String(b.appId) === String(auction.appId))
            )
          )
          .sort((x, y) => this.time(x.auction.auctionDate) - this.time(y.auction.auctionDate));
      })
    );
  }

  /**
   * One listing, with its bid history read fresh from
   * GET /api/auctions/{appId}/bids.
   */
  listing(appId: string): Observable<AuctionListing | null> {
    return forkJoin({
      auction: this.auctionSvc.getByApplication(appId).pipe(catchError(() => of(null))),
      apps: this.loanSvc.listAll().pipe(catchError(() => of([] as LoanApplication[]))),
      bids: this.auctionSvc.getBidsForApp(appId).pipe(catchError(() => of([] as BidDTO[])))
    }).pipe(
      map(({ auction, apps, bids }) => {
        if (!auction || auction.stage !== AUCTION_LIVE_STAGE) return null;
        const app = apps.find((a) => String(a.appId) === String(appId)) ?? null;
        return this.toListing(auction, app, bids);
      })
    );
  }

  /** Every bid placed by this bidder, newest first, with its listing attached. */
  myBids(bidderEmail: string): Observable<{ bid: BidDTO; listing: AuctionListing | null }[]> {
    return forkJoin({
      all: this.auctionSvc.listAllBids(),
      listings: this.listings().pipe(catchError(() => of([] as AuctionListing[])))
    }).pipe(
      map(({ all, listings }) =>
        all
          .filter((b) => this.sameEmail(b.bidderEmail, bidderEmail))
          .sort((a, b) => this.time(b.createdAt) - this.time(a.createdAt))
          .map((bid) => ({
            bid,
            listing: listings.find((l) => String(l.appId) === String(bid.appId)) ?? null
          }))
      )
    );
  }

  // ---- derivation helpers (ported from the reference UI's bidder section) ----

  private toListing(
    auction: AuctionCaseDTO,
    app: LoanApplication | null,
    rawBids: BidDTO[]
  ): AuctionListing {
    // Highest first; on equal amounts the earlier bid ranks first, matching
    // the reference UI's bidsForApp() ordering.
    const bids = rawBids
      .slice()
      .sort((a, b) => (b.bidAmount - a.bidAmount) || (this.time(a.createdAt) - this.time(b.createdAt)));
    const highestBid = bids.length ? bids[0] : null;
    const open = this.isOpen(auction);

    return {
      appId: auction.appId,
      auction,
      app,
      bids,
      highestBid,
      bidCount: bids.length,
      open,
      daysLeft: this.daysLeft(auction),
      minNextBid: this.minNextBid(auction, highestBid)
    };
  }

  /** Bidding stays open until the auction date passes. */
  isOpen(auction: AuctionCaseDTO): boolean {
    return !!auction.auctionDate && new Date(auction.auctionDate).getTime() > Date.now();
  }

  daysLeft(auction: AuctionCaseDTO): number {
    if (!auction.auctionDate) return 0;
    return Math.ceil((new Date(auction.auctionDate).getTime() - Date.now()) / 86400000);
  }

  /**
   * Minimum acceptable next bid.
   *
   * Reserve price when there are no bids yet; otherwise the current highest
   * plus an increment of max(5000, 1% of the reserve rounded to the nearest
   * 1000) -- the rule from the reference UI, kept as-is.
   *
   * Note this is STRICTER than the server rule (BidServiceImpl requires only
   * ">= reserve price" and "> current highest"), which is the safe direction:
   * every amount the form accepts is also acceptable to the backend, so the
   * user never gets a surprise 400 from the increment rule.
   */
  minNextBid(auction: AuctionCaseDTO, highestBid: BidDTO | null): number {
    const reserve = Number(auction.reservePrice ?? 0);
    if (!highestBid) return reserve;
    const step = Math.max(5000, Math.round((reserve * 0.01) / 1000) * 1000);
    return Number(highestBid.bidAmount) + step;
  }

  sameEmail(a?: string | null, b?: string | null): boolean {
    return !!a && !!b && a.trim().toLowerCase() === b.trim().toLowerCase();
  }

  /**
   * Other bidders' identities are masked in public bid history, as in the
   * reference UI ("A*** M.").
   */
  displayBidder(bid: BidDTO, myEmail: string | null): string {
    if (this.sameEmail(bid.bidderEmail, myEmail)) return 'You';
    const local = (bid.bidderEmail || 'bidder').split('@')[0].replace(/[._-]+/g, ' ').trim();
    const parts = local.split(' ').filter(Boolean);
    if (!parts.length) return 'Bidder';
    const first = parts[0][0].toUpperCase();
    const last = parts.length > 1 ? parts[parts.length - 1][0].toUpperCase() + '.' : '';
    return `${first}*** ${last}`.trim();
  }

  private time(value?: string | null): number {
    return value ? new Date(value).getTime() : 0;
  }
}
