import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, tap, catchError, throwError, switchMap, of } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { AppUser } from '../models/models';
import { clearHlmsSession } from '../../../core/session/session-keys';

interface LoginResponse { token: string; }
interface JwtPayload { sub: string; role: string; iat: number; exp: number; }

const TOKEN_KEY = 'hlms_bidder_token';
const ROLE = 'BIDDER';

/**
 * Bidder Portal AuthService.
 *
 * Deliberately mirrors legal/core/services/auth.service.ts one-for-one: same
 * endpoints (user-service), same JWT decode, same restoreSession()/authReady()
 * bootstrap contract, same role check -- only TOKEN_KEY and the required role
 * differ. Following the established per-module pattern means the shared
 * SessionService fan-out and the shared hlms-auth.interceptor pick this module
 * up with no changes on their side.
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  currentUser = signal<AppUser | null>(null);
  authReady = signal(false);

  constructor(private http: HttpClient, private router: Router) {}

  private get base(): string {
    return `${environment.apiBase}/user-service/api/users`;
  }

  login(email: string, password: string): Observable<AppUser> {
    return this.http.post<LoginResponse>(`${this.base}/login`, { email, password }).pipe(
      switchMap((res) => {
        const payload = this.decodeToken(res.token);
        if (!payload) {
          return throwError(() => new Error('Received an invalid token from the server.'));
        }
        if ((payload.role || '').toUpperCase() !== ROLE) {
          return throwError(() => new Error(
            'This portal is only for registered bidders. Your account role is "' + payload.role + '".'
          ));
        }
        localStorage.setItem(TOKEN_KEY, res.token);
        return this.http.get<AppUser>(`${this.base}/${encodeURIComponent(payload.sub)}`);
      }),
      tap((user) => this.currentUser.set(user)),
      catchError((err) => {
        localStorage.removeItem(TOKEN_KEY);
        return throwError(() => err);
      })
    );
  }

  /** Called once when the /bidder wrapper mounts, to restore a stored session. */
  restoreSession(): Observable<AppUser | null> {
    const token = this.getToken();
    if (!token) {
      this.authReady.set(true);
      return of(null);
    }
    const payload = this.decodeToken(token);
    if (!payload || this.isExpired(payload) || (payload.role || '').toUpperCase() !== ROLE) {
      this.authReady.set(true);
      return of(null);
    }
    return this.http.get<AppUser>(`${this.base}/${encodeURIComponent(payload.sub)}`).pipe(
      tap((user) => { this.currentUser.set(user); this.authReady.set(true); }),
      catchError(() => {
        this.authReady.set(true);
        return of(null);
      })
    );
  }

  refreshCurrentUser(): void {
    const u = this.currentUser();
    if (!u) return;
    this.http.get<AppUser>(`${this.base}/${encodeURIComponent(u.email)}`).subscribe({
      next: (fresh) => this.currentUser.set(fresh)
    });
  }

  logout(): void {
    // Clear every module's session material, exactly as the other four
    // portals' logout() methods do -- otherwise the other portals stay
    // reachable after signing out here.
    clearHlmsSession();
    localStorage.removeItem(TOKEN_KEY);
    this.currentUser.set(null);
    this.router.navigate(['/login']);
  }

  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  /** The e-mail the backend keys bids on (bid.bidder_email -> app_user.email). */
  get email(): string | null {
    return this.currentUser()?.email ?? this.decodeToken(this.getToken() || '')?.sub ?? null;
  }

  isLoggedIn(): boolean {
    const token = this.getToken();
    if (!token) return false;
    const payload = this.decodeToken(token);
    return !!payload && !this.isExpired(payload) && (payload.role || '').toUpperCase() === ROLE;
  }

  private isExpired(payload: JwtPayload): boolean {
    return !payload.exp || Date.now() >= payload.exp * 1000;
  }

  private decodeToken(token: string): JwtPayload | null {
    try {
      const parts = token.split('.');
      if (parts.length !== 3) return null;
      const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
      const json = decodeURIComponent(
        atob(base64)
          .split('')
          .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
          .join('')
      );
      return JSON.parse(json);
    } catch {
      return null;
    }
  }
}
