import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { NotificationDTO } from '../models/models';

/**
 * notification-service reads for the bidder's bell menu.
 *
 * Bidder notifications ("New Property Listed for e-Auction") are written by
 * the Legal / Bank Office portals when an auction is posted; this module only
 * reads them and marks them read.
 */
@Injectable({ providedIn: 'root' })
export class NotificationService {
  private base = `${environment.apiBase}/notification-service/api/notifications`;

  constructor(private http: HttpClient) {}

  listForUser(userEmail: string): Observable<NotificationDTO[]> {
    const params = new HttpParams().set('userEmail', userEmail);
    return this.http.get<NotificationDTO[]>(this.base, { params });
  }

  unread(userEmail: string): Observable<NotificationDTO[]> {
    const params = new HttpParams().set('userEmail', userEmail);
    return this.http.get<NotificationDTO[]>(`${this.base}/unread`, { params });
  }

  markRead(notificationId: string): Observable<NotificationDTO> {
    return this.http.patch<NotificationDTO>(`${this.base}/${notificationId}/read`, {});
  }
}
