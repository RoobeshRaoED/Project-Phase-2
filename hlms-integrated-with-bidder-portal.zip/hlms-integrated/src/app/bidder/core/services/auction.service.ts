import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { AuctionCaseDTO, BidDTO } from '../models/models';

/**
 * repayment-service auction + bid API.
 *
 * Endpoints are the real ones from Final_Backend
 * (com.hlms2.repayment.controller.AuctionCaseController / BidController);
 * request and response bodies are the backend DTOs unchanged.
 *
 * Errors are NOT swallowed here -- the components need to distinguish an empty
 * result from a failed call, and POST /bids returns a 400 with the validation
 * message that the bid form has to show the user.
 */
@Injectable({ providedIn: 'root' })
export class AuctionService {
  private auctions = `${environment.apiBase}/repayment-service/api/auctions`;
  private bids = `${environment.apiBase}/repayment-service/api/bids`;

  constructor(private http: HttpClient) {}

  /** GET /api/auctions -- every non-deleted auction case. */
  listAll(): Observable<AuctionCaseDTO[]> {
    return this.http.get<AuctionCaseDTO[]>(this.auctions);
  }

  /** GET /api/auctions/by-application/{appId} */
  getByApplication(appId: string): Observable<AuctionCaseDTO> {
    return this.http.get<AuctionCaseDTO>(`${this.auctions}/by-application/${encodeURIComponent(appId)}`);
  }

  /** GET /api/auctions/{appId}/bids -- bid history for one listing. */
  getBidsForApp(appId: string): Observable<BidDTO[]> {
    return this.http.get<BidDTO[]>(`${this.auctions}/${encodeURIComponent(appId)}/bids`);
  }

  /**
   * POST /api/auctions/{appId}/bids
   *
   * The controller overwrites dto.appId from the path, and BidServiceImpl
   * generates bidId and createdAt, so only bidderEmail + bidAmount are really
   * carried by the body. Server-side validation (>= reserve price, strictly
   * above the current highest, bidder must be an active app_user) comes back
   * as a 400 ValidationException.
   */
  placeBid(appId: string, bid: BidDTO): Observable<BidDTO> {
    return this.http.post<BidDTO>(`${this.auctions}/${encodeURIComponent(appId)}/bids`, bid);
  }

  /** GET /api/bids -- all bids; used to build "My Bids" (see BidderDataService). */
  listAllBids(): Observable<BidDTO[]> {
    return this.http.get<BidDTO[]>(this.bids);
  }
}
