import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { AppUser } from '../models/models';

/**
 * user-service profile writes for the Bidder Portal.
 *
 * PUT /api/users/{email} is the real update endpoint used by every other
 * portal's profile screen.
 *
 * Password change: there is still no authenticated
 * "current password + new password" endpoint in user-service (the gap the
 * Admin console's user.service.ts already documents). The OTP-based
 * forgot/reset pair is the only working substitute, so this module uses the
 * same two-step flow the Admin profile screen uses rather than inventing an
 * endpoint.
 */
@Injectable({ providedIn: 'root' })
export class UserService {
  private base = `${environment.apiBase}/user-service/api/users`;

  constructor(private http: HttpClient) {}

  update(email: string, user: AppUser): Observable<AppUser> {
    return this.http.put<AppUser>(`${this.base}/${encodeURIComponent(email)}`, user);
  }

  requestPasswordOtp(email: string): Observable<string> {
    return this.http.post(`${this.base}/forgot-password`, { email }, { responseType: 'text' });
  }

  resetPassword(email: string, otpCode: string, newPassword: string): Observable<string> {
    return this.http.post(
      `${this.base}/reset-password`,
      { email, otpCode, newPassword },
      { responseType: 'text' }
    );
  }
}
