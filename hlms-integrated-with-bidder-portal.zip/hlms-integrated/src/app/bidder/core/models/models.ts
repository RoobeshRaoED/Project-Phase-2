/**
 * Bidder Portal models.
 *
 * Field names mirror the backend DTOs exactly so no request/response mapping
 * is needed:
 *   AuctionCaseDTO / BidDTO  -> repayment-service  (com.hlms2.repayment.dto)
 *   LoanApplication          -> loan-service       (GET /api/loan-applications/all)
 *   AppUser                  -> user-service       (appUserEntity)
 */

/** user-service appUserEntity. Same shape the other four portals use. */
export interface AppUser {
  email: string;
  name: string;
  mobile: string;
  role: string; // CUSTOMER | LEGAL | BANK_OFFICER | BIDDER | ADMIN
  active: boolean;
  idType?: string;
  idNumber?: string;
  prefSms?: boolean;
  prefEmail?: boolean;
  prefInapp?: boolean;
  createdAt?: string;
}

/**
 * loan-service loan application. Only the fields the public auction listing is
 * allowed to surface are used by this module -- borrower identity fields
 * (applicantName, userEmail, applicantPan, income) are deliberately never
 * rendered, matching the reference UI's "borrower identity is withheld" rule.
 */
export interface LoanApplication {
  appId: string;
  trackingNo: string;
  propertyAddress?: string;
  propertyType?: string;
  propertyValue?: number;
  status?: string;
  stageIndex?: number;
}

/** repayment-service AuctionCaseDTO. */
export interface AuctionCaseDTO {
  auctionId?: number | null;
  appId: string;
  stage: string; // None | Notice Issued | Possession | Auction Scheduled | Resolved
  noticeDate?: string | null;
  noticeDueDate?: string | null;
  demandAmount?: number | null;
  possessionDate?: string | null;
  auctionDate?: string | null;
  reservePrice?: number | null;
}

/** repayment-service BidDTO. */
export interface BidDTO {
  bidId?: string | null;
  appId: string;
  bidderEmail: string;
  bidAmount: number;
  createdAt?: string | null;
}

/** notification-service Notification. */
export interface NotificationDTO {
  notificationId?: string;
  userEmail: string;
  title: string;
  body: string;
  channels?: string[];
  isRead?: boolean;
  createdAt?: string;
}

/**
 * View model for one auction listing: the auction case joined with its loan
 * application (for the property details) and its bids.
 *
 * The join is done in the Angular layer because no single backend endpoint
 * returns the combination -- the same approach the Bank Office auction screen
 * already uses (bo-auction.component.ts).
 */
export interface AuctionListing {
  appId: string;
  auction: AuctionCaseDTO;
  app: LoanApplication | null;
  bids: BidDTO[]; // sorted highest amount first, earliest first on a tie
  highestBid: BidDTO | null;
  bidCount: number;
  open: boolean; // auctionDate is still in the future
  daysLeft: number;
  minNextBid: number;
}

/** The auction stage at which a property becomes publicly biddable. */
export const AUCTION_LIVE_STAGE = 'Auction Scheduled';
