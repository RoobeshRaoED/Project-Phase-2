import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

/**
 * Bidder Portal route guard.
 *
 * Same contract as the Legal portal's authGuard: a valid, unexpired JWT whose
 * role claim is BIDDER. Any other role (or none) is bounced to the shared
 * login page rather than into another portal, so an ADMIN/CUSTOMER session
 * cannot reach /bidder/* by typing the URL.
 */
export const authGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);
  if (auth.isLoggedIn()) return true;
  router.navigate(['/login']);
  return false;
};
