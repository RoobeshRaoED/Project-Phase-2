import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';

/**
 * Bidder Portal, mounted at /bidder.
 *
 * Screen set and order are taken from the Updated_UI(1) reference
 * (VIEWS_BIDDER = bidderdash, bidderlistings, bidderlistingdetail,
 * bidderbids, biddersettings). Every child sits behind the BIDDER-role
 * authGuard on the shell route, matching how the Legal portal is protected.
 *
 * There is no /bidder/login: bidders sign in through the shared /login page
 * like every other role, and the guard sends unauthenticated users there.
 */
export const BIDDER_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () => import('./layout/shell/shell.component').then((m) => m.ShellComponent),
    canActivate: [authGuard],
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./pages/dashboard/bidder-dashboard.component').then((m) => m.BidderDashboardComponent)
      },
      {
        path: 'listings',
        loadComponent: () =>
          import('./pages/listings/bidder-listings.component').then((m) => m.BidderListingsComponent)
      },
      {
        path: 'listings/:appId',
        loadComponent: () =>
          import('./pages/listing-detail/bidder-listing-detail.component').then(
            (m) => m.BidderListingDetailComponent
          )
      },
      {
        path: 'my-bids',
        loadComponent: () =>
          import('./pages/my-bids/bidder-my-bids.component').then((m) => m.BidderMyBidsComponent)
      },
      {
        path: 'settings',
        loadComponent: () =>
          import('./pages/settings/bidder-settings.component').then((m) => m.BidderSettingsComponent)
      },
      { path: '**', redirectTo: 'dashboard' }
    ]
  }
];
