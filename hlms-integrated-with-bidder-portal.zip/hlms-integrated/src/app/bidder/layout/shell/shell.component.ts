import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterOutlet, RouterLink, NavigationEnd } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { NotificationService } from '../../core/services/notification.service';
import { NotificationDTO } from '../../core/models/models';

interface NavItem { path: string; ic: string; label: string; }

/**
 * Bidder Portal shell -- topbar, role sidebar and router outlet.
 *
 * Structure and markup follow the Updated_UI(1) app shell (topbar with brand,
 * notification bell and user chip; left sidebar of role-specific nav items;
 * .main content area; app footer), and the sidebar entries are the reference
 * UI's bidder set verbatim, icons included.
 */
@Component({
  selector: 'app-bidder-shell',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink],
  templateUrl: './shell.component.html'
})
export class ShellComponent {
  sidebarOpen = signal(false);
  activePath = signal('dashboard');

  notifications = signal<NotificationDTO[]>([]);
  unreadCount = signal(0);
  notifOpen = signal(false);

  navItems: NavItem[] = [
    { path: 'dashboard', ic: '▦', label: 'Dashboard' },
    { path: 'listings', ic: '☆', label: 'Auction Listings' },
    { path: 'my-bids', ic: '💰', label: 'My Bids' },
    { path: 'settings', ic: '⚙', label: 'Settings' }
  ];

  constructor(
    public auth: AuthService,
    private router: Router,
    private notifSvc: NotificationService
  ) {
    this.syncActivePath();
    this.router.events.subscribe((e) => {
      if (e instanceof NavigationEnd) {
        this.syncActivePath();
        this.sidebarOpen.set(false);
        this.notifOpen.set(false);
      }
    });
    this.loadNotifications();
  }

  private syncActivePath(): void {
    // '/bidder/listings/APP-1' -> 'listings'
    const seg = this.router.url.split('?')[0].split('/').filter(Boolean);
    this.activePath.set(seg[1] || 'dashboard');
  }

  private loadNotifications(): void {
    const email = this.auth.email;
    if (!email) return;
    this.notifSvc.listForUser(email).subscribe({
      next: (list) => {
        const sorted = list
          .slice()
          .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
        this.notifications.set(sorted);
        this.unreadCount.set(sorted.filter((n) => !n.isRead).length);
      },
      // A notification outage must not take the whole portal down.
      error: () => { this.notifications.set([]); this.unreadCount.set(0); }
    });
  }

  toggleNotifs(): void {
    this.notifOpen.update((v) => !v);
    if (this.notifOpen()) this.loadNotifications();
  }

  markRead(n: NotificationDTO): void {
    if (n.isRead || !n.notificationId) return;
    this.notifSvc.markRead(n.notificationId).subscribe({
      next: () => {
        this.notifications.update((list) =>
          list.map((x) => (x.notificationId === n.notificationId ? { ...x, isRead: true } : x))
        );
        this.unreadCount.update((c) => Math.max(0, c - 1));
      },
      error: () => {}
    });
  }

  initials(): string {
    const name = this.auth.currentUser()?.name || '';
    return name.split(' ').filter(Boolean).map((p) => p[0]).slice(0, 2).join('').toUpperCase() || 'BD';
  }

  toggleSidebar(): void { this.sidebarOpen.update((v) => !v); }

  logout(): void { this.auth.logout(); }
}
