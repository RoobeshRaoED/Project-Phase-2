import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AuthService } from './core/services/auth.service';
import { ToastComponent } from './layout/toast/toast.component';

/**
 * Wrapper component for the /bidder routes.
 *
 * Mirrors legal-root.component.ts: it restores the session before the child
 * routes render (so components can read auth.currentUser() synchronously) and
 * hosts this module's toast outlet. Scoped to /bidder, so it does not gate the
 * rest of the application.
 */
@Component({
  selector: 'app-bidder-root',
  standalone: true,
  imports: [RouterOutlet, ToastComponent],
  template: `
    @if (auth.authReady()) {
      <router-outlet></router-outlet>
    } @else {
      <div class="app-loading">Loading HLMS Bidder Portal…</div>
    }
    <app-bidder-toast></app-bidder-toast>
  `
})
export class AppComponent implements OnInit {
  constructor(public auth: AuthService) {}

  ngOnInit(): void {
    this.auth.restoreSession().subscribe();
  }
}
