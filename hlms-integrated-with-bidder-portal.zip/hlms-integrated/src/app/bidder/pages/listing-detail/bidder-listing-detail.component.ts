import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { finalize } from 'rxjs';

import { AuthService } from '../../core/services/auth.service';
import { AuctionService } from '../../core/services/auction.service';
import { BidderDataService } from '../../core/services/bidder-data.service';
import { ToastService } from '../../core/services/toast.service';
import { AuctionListing, BidDTO } from '../../core/models/models';

/**
 * Listing detail + bid submission -- reference UI's viewBidderListingDetail()
 * and placeBid().
 *
 * Layout is the reference's two-column grid (Property Details | Place Your
 * Bid) above a full-width Bid History card.
 *
 * The bid POST goes to the real endpoint
 * POST /repayment-service/api/auctions/{appId}/bids. Client-side validation
 * mirrors the reference's minimum-increment rule; the server's own rules
 * (>= reserve price, strictly above the current highest, active app_user) are
 * authoritative and their 400 message is surfaced verbatim to the user.
 */
@Component({
  selector: 'app-bidder-listing-detail',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './bidder-listing-detail.component.html'
})
export class BidderListingDetailComponent implements OnInit {
  loading = signal(true);
  submitting = signal(false);
  loadError = signal<string | null>(null);
  listing = signal<AuctionListing | null>(null);

  bidAmount: number | null = null;
  bidError = signal<string | null>(null);

  private appId = '';

  constructor(
    public auth: AuthService,
    public data: BidderDataService,
    private auctionSvc: AuctionService,
    private toast: ToastService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.appId = this.route.snapshot.paramMap.get('appId') || '';
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.loadError.set(null);
    this.data.listing(this.appId).subscribe({
      next: (l) => { this.listing.set(l); this.loading.set(false); },
      error: () => {
        this.loadError.set('Could not load this listing. Please try again.');
        this.loading.set(false);
      }
    });
  }

  back(): void { this.router.navigate(['/bidder/listings']); }

  myEmail(): string | null { return this.auth.email; }

  iAmHighest(): boolean {
    const l = this.listing();
    return !!l?.highestBid && this.data.sameEmail(l.highestBid.bidderEmail, this.myEmail());
  }

  isMine(bid: BidDTO): boolean {
    return this.data.sameEmail(bid.bidderEmail, this.myEmail());
  }

  bidderLabel(bid: BidDTO): string {
    return this.data.displayBidder(bid, this.myEmail());
  }

  placeBid(): void {
    const l = this.listing();
    if (!l) return;

    if (!l.open) {
      this.toast.error('Auction Closed', 'This auction is no longer accepting bids.');
      return;
    }

    const email = this.myEmail();
    if (!email) {
      this.bidError.set('Your session has expired. Please sign in again.');
      return;
    }

    const amount = Number(this.bidAmount || 0);
    if (!amount || amount < l.minNextBid) {
      this.bidError.set(
        `Bid must be at least ₹${l.minNextBid.toLocaleString('en-IN')}.`
      );
      return;
    }
    this.bidError.set(null);

    // appId is set from the path by AuctionCaseController; sent anyway so the
    // body is a complete, valid BidDTO.
    const payload: BidDTO = { appId: l.appId, bidderEmail: email, bidAmount: amount };

    this.submitting.set(true);
    this.auctionSvc.placeBid(l.appId, payload)
      .pipe(finalize(() => this.submitting.set(false)))
      .subscribe({
        next: (saved) => {
          this.toast.success(
            'Bid Placed',
            `Your bid of ₹${Number(saved.bidAmount).toLocaleString('en-IN')} has been recorded.`
          );
          this.bidAmount = null;
          this.load(); // re-read history so the new bid and ranking are live
        },
        error: (err: HttpErrorResponse) => {
          const message = this.messageFor(err);
          this.bidError.set(message);
          this.toast.error('Bid Rejected', message);
        }
      });
  }

  /** Surfaces the backend's own ApiError.message where there is one. */
  private messageFor(err: HttpErrorResponse): string {
    const backendMessage = err?.error?.message;
    if (typeof backendMessage === 'string' && backendMessage.trim()) return backendMessage;
    if (err.status === 0) return 'Cannot reach the server. Check your connection and try again.';
    if (err.status === 401) return 'Your session has expired. Please sign in again.';
    if (err.status === 403) return 'Your account is not permitted to bid on this listing.';
    if (err.status === 404) return 'This auction listing no longer exists.';
    return 'Your bid could not be placed. Please try again.';
  }
}
