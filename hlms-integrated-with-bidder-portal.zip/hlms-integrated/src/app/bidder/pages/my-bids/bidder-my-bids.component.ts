import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { BidderDataService } from '../../core/services/bidder-data.service';
import { AuctionListing, BidDTO } from '../../core/models/models';

interface MyBidRow { bid: BidDTO; listing: AuctionListing | null; }

/**
 * My Bids -- reference UI's viewBidderMyBids().
 *
 * Every bid this bidder has placed, newest first, showing the current highest
 * bid on that listing and whether the bidder is still leading or has been
 * outbid.
 */
@Component({
  selector: 'app-bidder-my-bids',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bidder-my-bids.component.html'
})
export class BidderMyBidsComponent implements OnInit {
  loading = signal(true);
  error = signal<string | null>(null);
  rows = signal<MyBidRow[]>([]);

  constructor(
    private auth: AuthService,
    private data: BidderDataService,
    private router: Router
  ) {}

  ngOnInit(): void { this.load(); }

  load(): void {
    const email = this.auth.email;
    if (!email) {
      this.error.set('Your session has expired. Please sign in again.');
      this.loading.set(false);
      return;
    }
    this.loading.set(true);
    this.error.set(null);
    this.data.myBids(email).subscribe({
      next: (rows) => { this.rows.set(rows); this.loading.set(false); },
      error: () => {
        this.error.set('Could not load your bids. Please try again.');
        this.loading.set(false);
      }
    });
  }

  /** True when this bidder currently holds the highest bid on that listing. */
  winning(row: MyBidRow): boolean {
    const hb = row.listing?.highestBid;
    return !!hb && this.data.sameEmail(hb.bidderEmail, this.auth.email);
  }

  goToListings(): void { this.router.navigate(['/bidder/listings']); }

  open(row: MyBidRow): void {
    this.router.navigate(['/bidder/listings', row.bid.appId]);
  }
}
