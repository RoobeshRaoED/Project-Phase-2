import { Component, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { BidderDataService } from '../../core/services/bidder-data.service';
import { AuctionListing } from '../../core/models/models';

/**
 * Auction Listings -- reference UI's viewBidderListings().
 *
 * Open / Closed tabs over a three-column grid of product cards, with the tab
 * counts in the labels exactly as the reference does.
 */
@Component({
  selector: 'app-bidder-listings',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bidder-listings.component.html'
})
export class BidderListingsComponent implements OnInit {
  loading = signal(true);
  error = signal<string | null>(null);
  all = signal<AuctionListing[]>([]);
  tab = signal<'open' | 'closed'>('open');

  openListings = computed(() => this.all().filter((l) => l.open));
  closedListings = computed(() => this.all().filter((l) => !l.open));
  visible = computed(() => (this.tab() === 'open' ? this.openListings() : this.closedListings()));

  constructor(private data: BidderDataService, private router: Router) {}

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading.set(true);
    this.error.set(null);
    this.data.listings().subscribe({
      next: (list) => { this.all.set(list); this.loading.set(false); },
      error: () => {
        this.error.set('Could not load auction listings. Please try again.');
        this.loading.set(false);
      }
    });
  }

  setTab(t: 'open' | 'closed'): void { this.tab.set(t); }

  open(listing: AuctionListing): void {
    this.router.navigate(['/bidder/listings', listing.appId]);
  }
}
