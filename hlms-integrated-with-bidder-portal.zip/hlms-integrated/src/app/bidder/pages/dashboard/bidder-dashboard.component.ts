import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { BidderDataService } from '../../core/services/bidder-data.service';
import { AuctionListing } from '../../core/models/models';

/**
 * Bidder dashboard -- reference UI's viewBidderDashboard().
 *
 * Three stat cards (My Total Bids / Currently Highest On / Listed All-Time),
 * a "Closing Soon" table of the five nearest open auctions, and the standing
 * SARFAESI advisory note.
 */
@Component({
  selector: 'app-bidder-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bidder-dashboard.component.html'
})
export class BidderDashboardComponent implements OnInit {
  loading = signal(true);
  error = signal<string | null>(null);

  listings = signal<AuctionListing[]>([]);
  myBidCount = signal(0);
  winningCount = signal(0);

  constructor(
    public auth: AuthService,
    private data: BidderDataService,
    private router: Router
  ) {}

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading.set(true);
    this.error.set(null);
    const email = this.auth.email;

    this.data.listings().subscribe({
      next: (all) => {
        this.listings.set(all);
        const open = all.filter((l) => l.open);
        this.myBidCount.set(
          all.reduce((n, l) => n + l.bids.filter((b) => this.data.sameEmail(b.bidderEmail, email)).length, 0)
        );
        this.winningCount.set(
          open.filter((l) => l.highestBid && this.data.sameEmail(l.highestBid.bidderEmail, email)).length
        );
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Could not load auction listings. Please check your connection and try again.');
        this.loading.set(false);
      }
    });
  }

  /** The five soonest-closing open auctions. */
  closingSoon(): AuctionListing[] {
    return this.listings().filter((l) => l.open).slice(0, 5);
  }

  firstName(): string {
    return (this.auth.currentUser()?.name || 'Bidder').split(' ')[0];
  }

  open(listing: AuctionListing): void {
    this.router.navigate(['/bidder/listings', listing.appId]);
  }
}
