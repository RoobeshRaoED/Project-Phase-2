import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { finalize } from 'rxjs';

import { AuthService } from '../../core/services/auth.service';
import { UserService } from '../../core/services/user.service';
import { ToastService } from '../../core/services/toast.service';
import { AppUser } from '../../core/models/models';

const ROLE_LABELS: Record<string, string> = {
  ADMIN: 'Admin',
  LEGAL: 'Legal Team',
  BANK_OFFICER: 'Bank Office',
  CUSTOMER: 'Customer',
  BIDDER: 'Bidder'
};

/**
 * Bidder settings -- reference UI's viewBidderSettings().
 *
 * Two cards: Account Details (name / mobile, with e-mail and role read-only)
 * and Change Password.
 */
@Component({
  selector: 'app-bidder-settings',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './bidder-settings.component.html'
})
export class BidderSettingsComponent {
  savingPersonal = signal(false);
  savingPassword = signal(false);

  nameDraft = '';
  mobileDraft = '';
  nameError = signal<string | null>(null);
  mobileError = signal<string | null>(null);

  currentPassword = '';
  newPassword = '';
  confirmPassword = '';
  passwordError = signal<string | null>(null);

  constructor(
    public auth: AuthService,
    private users: UserService,
    private toast: ToastService
  ) {
    const u = this.auth.currentUser();
    this.nameDraft = u?.name || '';
    this.mobileDraft = u?.mobile || '';
  }

  roleLabel(): string {
    const role = this.auth.currentUser()?.role || 'BIDDER';
    return ROLE_LABELS[role] || role;
  }

  savePersonal(): void {
    const user = this.auth.currentUser();
    if (!user) return;

    this.nameError.set(null);
    this.mobileError.set(null);

    let ok = true;
    if (!this.nameDraft.trim()) { this.nameError.set('Full name is required.'); ok = false; }
    if (!/^\d{10}$/.test((this.mobileDraft || '').trim())) {
      this.mobileError.set('Enter a valid 10-digit mobile number.');
      ok = false;
    }
    if (!ok) return;

    const updated: AppUser = { ...user, name: this.nameDraft.trim(), mobile: this.mobileDraft.trim() };

    this.savingPersonal.set(true);
    this.users.update(user.email, updated)
      .pipe(finalize(() => this.savingPersonal.set(false)))
      .subscribe({
        next: () => {
          this.auth.refreshCurrentUser();
          this.toast.success('Profile Updated', 'Your account details have been saved.');
        },
        error: (err) =>
          this.toast.error('Could not save changes', err?.error?.message || 'Please try again.')
      });
  }

  changePassword(): void {
    const email = this.auth.currentUser()?.email;
    if (!email) return;

    this.passwordError.set(null);
    if (!this.currentPassword) { this.passwordError.set('Current password is required.'); return; }
    if (!this.newPassword || this.newPassword.length < 8) {
      this.passwordError.set('New password must be at least 8 characters.');
      return;
    }
    if (this.newPassword !== this.confirmPassword) {
      this.passwordError.set('The two passwords do not match.');
      return;
    }

    this.savingPassword.set(true);
    // Same substitute flow the Admin profile screen uses: user-service has no
    // authenticated change-password endpoint, only the OTP forgot/reset pair.
    this.users.requestPasswordOtp(email).subscribe({
      next: (otp) => {
        this.users.resetPassword(email, otp, this.newPassword)
          .pipe(finalize(() => this.savingPassword.set(false)))
          .subscribe({
            next: () => {
              this.currentPassword = '';
              this.newPassword = '';
              this.confirmPassword = '';
              this.toast.success('Password Updated', 'Your password has been changed.');
            },
            error: (err) =>
              this.toast.error('Could not update password', err?.error?.message || 'Please try again.')
          });
      },
      error: (err) => {
        this.savingPassword.set(false);
        this.toast.error('Could not update password', err?.error?.message || 'Please try again.');
      }
    });
  }
}
