package com.hlms.eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Boots the real Eureka server on a random port with self-registration turned off,
 * so the test doesn't need a second Eureka instance or network access to pass.
 * This exercises SpringApplication.run(...) and the @EnableEurekaServer-annotated
 * auto-configuration, which is effectively the entire behavior this module owns.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class EurekaServerApplicationTests {

    @DynamicPropertySource
    static void overrideProps(DynamicPropertyRegistry registry) {
        registry.add("eureka.client.register-with-eureka", () -> "false");
        registry.add("eureka.client.fetch-registry", () -> "false");
    }

    @Test
    void contextLoads() {
        // If the Spring context (including @EnableEurekaServer's auto-config) fails
        // to start, this test fails - that's the main regression this guards against.
        assertThat(true).isTrue();
    }

    @Test
    void mainMethodStartsApplicationWithoutThrowing() {
        // Directly invokes EurekaServerApplication.main(...) (not just SpringApplication.run
        // called from the test) so the source file's own main-method line is what JaCoCo
        // records as covered. Random port + registration disabled so it's safe/fast in CI;
        // the context is left running and is torn down when the test JVM exits.
        System.setProperty("server.port", "0");
        System.setProperty("eureka.client.register-with-eureka", "false");
        System.setProperty("eureka.client.fetch-registry", "false");
        try {
            EurekaServerApplication.main(new String[]{});
        } finally {
            System.clearProperty("server.port");
            System.clearProperty("eureka.client.register-with-eureka");
            System.clearProperty("eureka.client.fetch-registry");
        }
    }

    @Test
    void applicationClassIsAnnotatedAsEurekaServer() {
        assertThat(EurekaServerApplication.class.isAnnotationPresent(EnableEurekaServer.class)).isTrue();
    }
}
