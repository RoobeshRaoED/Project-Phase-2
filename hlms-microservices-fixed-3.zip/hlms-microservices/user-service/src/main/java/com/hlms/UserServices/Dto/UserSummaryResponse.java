package com.hlms.UserServices.Dto;

/**
 * Response shape for the /internal/users/{email} endpoint, called by every other
 * HLMS microservice's Feign UserClient (see e.g. com.hlms.loan.client.UserClient).
 * Field names/order intentionally match the identical record already defined in
 * each caller's client package so Jackson deserializes it without extra mapping.
 */
public record UserSummaryResponse(String email, String name, String mobile, String role, Boolean active) {
}
