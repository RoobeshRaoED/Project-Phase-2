package com.hlms.UserServices.Security;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

/**
 * Signs/verifies with the shared "hlms.jwt.secret" from Config Server - the same
 * property every other HLMS microservice already reads (see e.g.
 * com.hlms.document.security.JwtService) - instead of a hardcoded string that only
 * this service knew about. That mismatch meant a token issued here would fail
 * signature validation everywhere else in the mesh; this fixes it. Nothing else
 * about token issuing/validation (claims, 24h expiry, method signatures) changed.
 */
@Service
public class JwtService {

    // HS256 needs a key of at least 256 bits (32 bytes). Checking this in the
    // constructor means a bad/missing hlms.jwt.secret fails the app at startup with
    // a clear message, instead of surfacing as an opaque WeakKeyException the first
    // time someone logs in.
    private static final int MIN_SECRET_BYTES = 32;

    private final String secretKey;

    public JwtService(@Value("${hlms.jwt.secret}") String secretKey) {

        if (secretKey == null
                || secretKey.isBlank()
                || secretKey.getBytes(StandardCharsets.UTF_8).length < MIN_SECRET_BYTES) {

            throw new IllegalStateException(
                    "hlms.jwt.secret is missing or too short (needs to be at least "
                            + MIN_SECRET_BYTES
                            + " bytes for HS256). Check that config-server is reachable "
                            + "and hlms.jwt.secret is configured in its shared application.properties.");
        }

        this.secretKey = secretKey;
    }

    private Key getSigningKey() {

        return new SecretKeySpec(
                secretKey.getBytes(StandardCharsets.UTF_8),
                SignatureAlgorithm.HS256.getJcaName());
    }

    public String generateToken(
            String email,
            String role) {

        Map<String, Object> claims =
                new HashMap<>();

        claims.put("role", role);

        return Jwts.builder()
                .setClaims(claims)
                .setSubject(email)
                .setIssuedAt(new Date())
                .setExpiration(
                        new Date(
                                System.currentTimeMillis()
                                        + 86400000))
                .signWith(
                        getSigningKey(),
                        SignatureAlgorithm.HS256)
                .compact();
    }

    public String extractEmail(
            String token) {

        return extractAllClaims(token)
                .getSubject();
    }

    public String extractRole(
            String token) {

        return extractAllClaims(token)
                .get("role", String.class);
    }

    public boolean validateToken(
            String token,
            String email) {

        return extractEmail(token)
                .equals(email)
                && !isTokenExpired(token);
    }

    private boolean isTokenExpired(
            String token) {

        return extractAllClaims(token)
                .getExpiration()
                .before(new Date());
    }

    private Claims extractAllClaims(String token) {

        return Jwts.parser()
                .verifyWith((javax.crypto.SecretKey) getSigningKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }
}
