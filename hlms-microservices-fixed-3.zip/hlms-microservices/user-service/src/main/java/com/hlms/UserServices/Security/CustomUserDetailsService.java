package com.hlms.UserServices.Security;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.hlms.UserServices.Repository.appUserRepository;

/**
 * Loads a user by email (the username in this system) for Spring Security's
 * authentication machinery, backing JwtAuthenticationFilter. Mirrors
 * CustomUserDetailsService in every other HLMS microservice's security package.
 */
@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final appUserRepository userRepository;

    public CustomUserDetailsService(appUserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        return userRepository.findByEmailAndDeletedAtIsNull(email)
                .map(UserPrincipal::new)
                .orElseThrow(() -> new UsernameNotFoundException("No user found for email: " + email));
    }
}
