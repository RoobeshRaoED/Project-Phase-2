# User Service Integration - what changed and why

## The core problem
The `UserServices` module was built standalone: its own `spring-boot-starter-parent
4.1.0`, `spring.application.name=UserServices`, no Eureka/Config Client, and no
`/internal/**` endpoint - while the other 6 modules (api-gateway, eureka-server,
config-server, loan/document/legal/repayment/notification-service) were already
built as one Maven-reactor mesh on **Boot 3.2.5 / Spring Cloud 2023.0.1**, all
already expecting to reach it as `user-service` on Eureka via a Feign `UserClient`
calling `GET /internal/users/{email}`.

Boot 4.1.0 needs Spring Cloud 2025.1.x, not 2023.0.1 - the two stacks can't share a
process. Upgrading the other 6 services + gateway/eureka/config-server to Boot 4
would have been a much larger, riskier change than realigning this one module, so
**user-service was moved onto the mesh's existing Boot 3.2.5 stack**, per requirement
8 ("adapt the other microservices to the User Service, not the other way around" -
applied here to the user-related contract/business logic, while the plumbing needed
to physically join the same Eureka/Spring Cloud version was aligned the cheaper
direction).

## Files changed

**`UserServices/UserServices/` → `user-service/`** (folder renamed to match the
parent's `<module>user-service</module>` and the Eureka service name every other
service already expects)

- **`pom.xml`** - now inherits the `hlms-microservices` parent (Boot 3.2.5 / Spring
  Cloud 2023.0.1) instead of its own `spring-boot-starter-parent 4.1.0`. Renamed the
  Boot-4-only starter artifact ids back to their Boot 3.2.5 equivalents
  (`spring-boot-starter-webmvc` → `spring-boot-starter-web`; the four per-module test
  starters + `spring-boot-h2console` → the single `spring-boot-starter-test` +
  `spring-security-test`). Added `spring-cloud-starter-netflix-eureka-client` and
  `spring-cloud-starter-config`. Aligned `jjwt` (0.12.5) and `springdoc` (2.5.0)
  versions with the other five services. **No entity, security, or business-logic
  dependency was touched.**
- **`application.properties`** - `spring.application.name` changed from
  `UserServices` to `user-service` (this is what Eureka/Feign/the gateway actually
  key off of). Added `spring.config.import=optional:configserver:...` and the same
  `eureka.client.service-url.defaultZone` every other service uses. Existing
  datasource/JPA lines are untouched (local properties always win over anything
  config-server supplies with the same key, so behavior is identical to before).
- **`UserServicesApplication.java`** - added `@EnableDiscoveryClient`.
- **New: `Controller/InternalUserController.java`** - `GET /internal/users/{email}`,
  the endpoint every other service's `UserClient` Feign interface already expected.
  It calls the existing `appUserService.getUserByEmail(...)` and reshapes the result
  - no business logic duplicated or changed.
- **New: `Dto/UserSummaryResponse.java`** - `(email, name, mobile, role, active)`,
  matching the identical record every other service already defines in its own
  `client` package.
- **New: `Config/InternalApiKeyFilter.java`** - checks `X-Internal-Api-Key` against
  `hlms.internal.api-key` for any `/internal/**` request, the same pattern used by
  every other service's `InternalApiKeyFilter`. Registered as a plain `@Component`
  (Spring Boot auto-registers any `Filter` bean), **not** wired into
  `JwtSecurityConfig`, so that file - and the rest of user-service's security, JWT,
  entities, repositories, and controllers - is completely untouched.

**`api-gateway/src/main/resources/application.properties`** - the `user-service`
route's path predicate only listed `/api/auth/**, /api/users/**`; user-service also
exposes `/api/otp/**`, `/api/customer-profile/**`, `/api/role-permissions/**`, which
weren't reachable through the gateway before. Added them to the same route.

## What was deliberately left alone
- `JwtSecurityConfig`, `JwtService` (including its hardcoded signing key),
  `roleEnum`, all entities/repositories/services/controllers, and every existing
  `/api/**` endpoint's behavior in user-service - unchanged.
- The other five services' `UserClient`/`FeignClientConfig`/`InternalXxxController`
  classes already correctly targeted `user-service` and needed no changes.
- No schema/SQL changes.

## Follow-up fix: JWT secret mismatch (resolved)
`user-service`'s `JwtService` used to sign/verify tokens with its own hardcoded
secret string, while the other five services validate JWTs against the shared
`hlms.jwt.secret` value from Config Server - meaning a token issued by `user-service`
would fail signature validation everywhere else in the mesh. Fixed by switching
`user-service`'s `JwtService` to the same `@Value("${hlms.jwt.secret}")`
constructor-injected pattern the other five services already use (see e.g.
`document-service`'s `JwtService`), pulled from `config-server`'s shared
`application.properties` - the same value every other service reads, so a token
issued by any HLMS service now validates in every other HLMS service.

This was the "choose hlms.jwt.secret" option rather than hardcoding the
`user-service` secret into the other five services: the shared value already lives
in one place (Config Server) and is what the rest of the mesh was built around, so
standardizing on it is a smaller, safer change than pushing a hardcoded literal out
to five other codebases. Nothing else changed - claims, the 24-hour expiry, and
every method signature/caller in `JwtService` are exactly as before.

**Heads up:** `hlms.jwt.secret` has no local fallback in `user-service` (matching the
other five services), so if Config Server isn't reachable at startup, `user-service`
will fail to start with a missing-property error - same behavior every other HLMS
service already has.

**Also fixed while reviewing this file:** `JwtService`'s constructor now validates
that `hlms.jwt.secret` is present and at least 32 bytes (256 bits, HS256's minimum
key length) *at startup*. Previously a missing/short secret would only surface the
first time someone tried to log in, as an opaque `WeakKeyException` thrown deep
inside the JJWT library. The current shared secret in
`config-server/.../application.properties` is 90 bytes, so this doesn't change
anything today - it just turns a future misconfiguration into a clear startup
error instead of a confusing runtime one.

## Follow-up fix: no JWT enforcement in user-service (resolved)
`user-service` issued JWTs but never actually checked them: `JwtSecurityConfig` ended
in `.anyRequest().permitAll()` with `.authenticated()` commented out, and there was no
`JwtAuthenticationFilter` at all - unlike the other five services, which each have one
wired into their `SecurityConfig`. Every non-public endpoint (`GET/PUT/DELETE
/api/users/{email}`, all of `customerEmploymentProfileController`, all of
`rolePermissionController`) was reachable with no token whatsoever.

Added, mirroring the other five services' pattern exactly:
- **`Security/UserPrincipal.java`** - adapts `appUserEntity` to Spring Security's
  `UserDetails` (`ROLE_<roleEnum name>`, enabled = active + not soft-deleted).
- **`Security/CustomUserDetailsService.java`** - loads a user via the existing
  `appUserRepository.findByEmailAndDeletedAtIsNull(...)`.
- **`Security/JwtAuthenticationFilter.java`** - reads `Authorization: Bearer <token>`,
  validates it via the existing `JwtService.extractEmail`/`validateToken`, and
  populates the `SecurityContext` if valid.
- **`JwtSecurityConfig`** - now injects `JwtAuthenticationFilter` and wires it in via
  `addFilterBefore(..., UsernamePasswordAuthenticationFilter.class)`; `/internal/**`
  was added to the permit-all list (it's guarded separately by
  `InternalApiKeyFilter`, not end-user JWTs); `anyRequest()` now requires
  `.authenticated()` instead of `.permitAll()`.

Net effect: `/api/users/register`, `/login`, `/forgot-password`, `/reset-password`,
and `/api/otp/**` stay public; everything else in `user-service` now requires a
valid `Authorization: Bearer <token>` header, same as every other HLMS
microservice. No entity/repository/service/controller logic changed - only the
security wiring.

## To verify locally
1. `mvn -f hlms-microservices/pom.xml clean install` from the parent (needs internet
   access for the Boot 3.2.5 / Spring Cloud 2023.0.1 dependencies).
2. Start in order: `eureka-server` → `config-server` → `api-gateway` → the six
   business services (any order).
3. Check `http://localhost:8761` - `user-service` should now show up alongside the
   other five.
4. From any other service, an internal call like `GET /internal/users/{email}` with
   header `X-Internal-Api-Key: <hlms.internal.api-key value>` hitting `user-service`
   directly on port 8081 should return a `UserSummaryResponse`.
