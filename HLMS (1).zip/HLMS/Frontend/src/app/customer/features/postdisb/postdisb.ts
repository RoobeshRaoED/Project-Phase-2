import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';

import { AuthService } from '../../core/services/auth.service';
import { LoanService } from '../../core/services/loan.service';
import { DocumentService, fileToBase64 } from '../../core/services/document.service';
import { NotificationService } from '../../core/services/notification.service';
import { ToastService } from '../../core/services/toast.service';

import {
  LoanApplication,
  PostDisbursementDocument,
  ServiceRequest
} from '../../core/models/models';

const PD_DOC_TYPES = [
  'NOC Request',
  'Property Title Copy',
  'Insurance Renewal',
  'Engineer Sign'
];

const REQUEST_TYPES = [
  'Duplicate Statement',
  'Loan Closure Letter',
  'NOC / No-Dues Certificate',
  'Interest Certificate',
];

const ALLOWED_EXTENSIONS = ['pdf', 'jpg', 'jpeg', 'png'];
const MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024;

@Component({
  selector: 'app-postdisb',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './postdisb.html'
})
export class Postdisb {
  private auth = inject(AuthService);
  private loanSvc = inject(LoanService);
  private docSvc = inject(DocumentService);
  private notifSvc = inject(NotificationService);
  private toast = inject(ToastService);
  private route = inject(ActivatedRoute);

  pdDocTypes = PD_DOC_TYPES;
  requestTypes = REQUEST_TYPES;

  docType = PD_DOC_TYPES[0];
  requestType = REQUEST_TYPES[0];
  requestDesc = '';

  appId = signal<string | null>(null);

  listLoading = signal(true);
  eligibleApps = signal<LoanApplication[]>([]);

  docsLoading = signal(true);
  docs = signal<PostDisbursementDocument[]>([]);

  selectedFile = signal<File | null>(null);
  uploading = signal(false);
  uploadError = signal('');

  reqsLoading = signal(true);
  requests = signal<ServiceRequest[]>([]);
  raisingReq = signal(false);
  reqError = signal('');

  constructor() {
    const routeAppId = this.route.snapshot.paramMap.get('appId');

    if (routeAppId) {
      this.appId.set(routeAppId);
      this.listLoading.set(false);
      this.loadDocs(routeAppId);
      this.loadRequests(routeAppId);
      return;
    }

    const email = this.auth.currentUser()?.email;

    if (!email) {
      this.listLoading.set(false);
      return;
    }

    this.loanSvc.listForUser(email).subscribe({
      next: (list) => {
        this.eligibleApps.set(
          (list || []).filter((a) => a.status === 'Disbursed' || a.status === 'Active')
        );

        this.listLoading.set(false);
      },
      error: () => {
        this.listLoading.set(false);
      }
    });
  }

  private loadDocs(appId: string): void {
    this.docsLoading.set(true);

    this.docSvc.listPostDisbByApp(appId).subscribe({
      next: (list) => {
        this.docs.set(list || []);
        this.docsLoading.set(false);
      },
      error: (err) => {
        this.docs.set([]);
        this.docsLoading.set(false);

        this.uploadError.set(
          err?.error?.message ||
            err?.error?.error ||
            err?.error ||
            err?.message ||
            'Could not load uploaded documents.'
        );

        console.error('Post-disbursement document list failed:', err);
      }
    });
  }

  private loadRequests(appId: string): void {
    this.reqsLoading.set(true);

    this.notifSvc.listServiceRequestsForApp(appId).subscribe({
      next: (list) => {
        this.requests.set(list || []);
        this.reqsLoading.set(false);
      },
      error: () => {
        this.requests.set([]);
        this.reqsLoading.set(false);
      }
    });
  }

  raiseRequest(): void {
    const email = this.auth.currentUser()?.email;
    const appId = this.appId();

    if (!email || !appId) {
      this.reqError.set('User session or application ID not found.');
      return;
    }

    this.raisingReq.set(true);
    this.reqError.set('');

    this.notifSvc
      .createServiceRequest({
        userEmail: email,
        appId,
        requestType: this.requestType,
        description: this.requestDesc
      })
      .subscribe({
        next: (savedRequest) => {
          this.raisingReq.set(false);
          this.requestDesc = '';

          if (savedRequest) {
            this.requests.update((list) => [savedRequest, ...list]);
          }

          this.toast.success('Request submitted');
          this.loadRequests(appId);
        },
        error: (err) => {
          this.raisingReq.set(false);

          this.reqError.set(
            err?.error?.message ||
              err?.error?.error ||
              err?.error ||
              err?.message ||
              'Could not submit request. Please try again.'
          );

          console.error('Service request failed:', err);
        }
      });
  }

  onFileSelected(evt: Event): void {
    const input = evt.target as HTMLInputElement;
    const file = input.files?.[0] ?? null;

    this.uploadError.set('');

    if (!file) {
      this.selectedFile.set(null);
      return;
    }

    const extension = file.name.split('.').pop()?.toLowerCase() || '';

    if (!ALLOWED_EXTENSIONS.includes(extension)) {
      this.selectedFile.set(null);
      this.uploadError.set('Invalid file type. Please upload PDF, JPG, JPEG, or PNG.');
      input.value = '';
      return;
    }

    if (file.size > MAX_FILE_SIZE_BYTES) {
      this.selectedFile.set(null);
      this.uploadError.set('File size must not exceed 10 MB.');
      input.value = '';
      return;
    }

    this.selectedFile.set(file);
  }

  selectedFileSizeText(): string {
    const file = this.selectedFile();

    if (!file) {
      return '';
    }

    const sizeMb = file.size / (1024 * 1024);
    return `${sizeMb.toFixed(2)} MB`;
  }

  async upload(): Promise<void> {
    const appId = this.appId();
    const file = this.selectedFile();

    if (!appId) {
      this.uploadError.set('Application ID not found.');
      return;
    }

    if (!file) {
      this.uploadError.set('Please select a file before uploading.');
      return;
    }

    this.uploading.set(true);
    this.uploadError.set('');

    try {
      const fileData = await fileToBase64(file);

      const payload: PostDisbursementDocument = {
        appId,
        docType: this.docType,
        fileName: file.name,
        fileData,
        fileSize: file.size,
        status: 'Pending'
      };

      this.docSvc.uploadPostDisb(payload).subscribe({
        next: (savedDoc) => {
          this.uploading.set(false);
          this.selectedFile.set(null);

          const uploadedDoc: PostDisbursementDocument = {
            ...payload,
            ...(savedDoc || {}),
            appId,
            docType: this.docType,
            fileName: file.name,
            fileData,
            fileSize: file.size,
            status: savedDoc?.status || 'Pending',
            uploadedAt: savedDoc?.uploadedAt || new Date().toISOString()
          };

          this.docs.update((list) => [uploadedDoc, ...list]);

          this.toast.success('Document uploaded');
          this.loadDocs(appId);
        },
        error: (err) => {
          this.uploading.set(false);

          this.uploadError.set(
            err?.error?.message ||
              err?.error?.error ||
              err?.error ||
              err?.message ||
              'Upload failed. Please try again.'
          );

          console.error('Post-disbursement upload failed:', err);
        }
      });
    } catch {
      this.uploading.set(false);
      this.uploadError.set('Could not read the selected file.');
    }
  }

  remove(doc: PostDisbursementDocument): void {
    if (!doc.pdDocId) {
      return;
    }

    if (!confirm(`Delete "${doc.fileName}"?`)) {
      return;
    }

    this.docSvc.removePostDisb(doc.pdDocId).subscribe({
      next: () => {
        this.docs.update((list) => list.filter((d) => d.pdDocId !== doc.pdDocId));
        this.toast.success('Document deleted');
      },
      error: (err) => {
        this.toast.error('Could not delete document');
        console.error('Delete post-disbursement document failed:', err);
      }
    });
  }
}