import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RepaymentService } from '../../../core/services/repayment.service';
import { LoanService } from '../../../core/services/loan.service';
import { NotificationService } from '../../../core/services/notification.service';
import { ToastService } from '../../../core/services/toast.service';
import { Disbursement, EmiInstallment } from '../../../core/models/repayment.model';
import { LoanApplication, WORKFLOW_STAGES } from '../../../core/models/loan-application.model';

@Component({
  selector: 'app-bo-disbursement',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './bo-disbursement.component.html'
})
export class BoDisbursementComponent implements OnInit {
  private repaymentService = inject(RepaymentService);
  private loanService = inject(LoanService);
  private notificationService = inject(NotificationService);
  private toast = inject(ToastService);

  disbursements = signal<Disbursement[]>([]);
  applications = signal<LoanApplication[]>([]);
  loading = signal(true);
  processingAppId = signal<string | null>(null);

  // The application currently being disbursed via the inline form.
  activeApp: LoanApplication | null = null;
  newAmount: number | null = null;
  newMode = 'NEFT';
  newRefNo = '';
  newBankDetails = '';

  recent = computed(() =>
    this.disbursements()
      .slice()
      .sort((a, b) => new Date(b.disbursedDate).getTime() - new Date(a.disbursedDate).getTime())
      .slice(0, 10)
  );

  // appId of the disbursement whose EMI schedule is currently expanded, if any.
  expandedAppId = signal<string | null>(null);
  expandedSchedule = signal<EmiInstallment[]>([]);
  scheduleLoading = signal(false);

  // An application becomes eligible for disbursement as soon as it has
  // cleared "Final Approval" (the second-to-last workflow stage) - it does
  // NOT need to have already been moved onto the "Disbursement" stage first.
  // That final stage move now happens as part of confirmDisburse() itself,
  // together with creating the disbursement record and generating the EMI
  // schedule, so the two can never happen out of sync with each other.
  // The `>=` (instead of `===`) also keeps showing any application that was
  // already sitting on the "Disbursement" stage from before this change.
  readyToDisburse = computed(() =>
    this.applications().filter(
      (a) =>
        (a.stageIndex ?? -1) >= WORKFLOW_STAGES.length - 2 &&
        a.status !== 'Disbursed' &&
        a.status !== 'Rejected'
    )
  );

  ngOnInit(): void {
    this.refresh();
    this.loanService.getAllApplications().subscribe({
      next: (apps) => this.applications.set(apps),
      error: () => this.applications.set([])
    });
  }

  refresh() {
    this.repaymentService.getAllDisbursements().subscribe({
      next: (list) => { this.disbursements.set(list); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  applicantFor(appId: string): string {
    const app = this.applications().find((a) => String(a.appId) === String(appId));
    return app?.applicantName || app?.trackingNo || appId;
  }

  startDisburse(app: LoanApplication) {
    this.activeApp = app;
    this.newAmount = app.loanAmount;
    this.newMode = 'NEFT';
    this.newRefNo = 'DISB-' + Date.now();
    this.newBankDetails = '';
  }

  cancelDisburse() {
    this.activeApp = null;
    this.newAmount = null;
    this.newRefNo = '';
    this.newBankDetails = '';
  }

  confirmDisburse() {
    const app = this.activeApp;
    if (!app?.appId || !this.newAmount || !this.newBankDetails.trim()) {
      this.toast.show('Missing details', 'Please enter the disbursement amount and beneficiary bank details.', 'error');
      return;
    }
    this.processingAppId.set(app.appId);
    this.repaymentService.createDisbursement({
      appId: app.appId,
      amount: this.newAmount,
      disbursedDate: new Date().toISOString(),
      refNo: this.newRefNo,
      mode: this.newMode,
      bankDetails: this.newBankDetails
    }).subscribe({
      next: () => {
        this.processingAppId.set(null);
        this.toast.show('Disbursement recorded', `Funds disbursed for ${app.trackingNo ?? app.appId} and the EMI schedule has been generated.`, 'success');
        // Move the application onto the final "Disbursement" stage and mark
        // it Disbursed in the same step that creates the disbursement record
        // and EMI schedule above, so the stage, status and EMI schedule can
        // never drift apart the way they could when the stage move happened
        // separately (from the application detail page's own
        // "Move to Next Stage" button).
        this.loanService.advanceStage(app.appId!, WORKFLOW_STAGES.length - 1, 'Disbursed').subscribe({ error: () => {} });
        if (app.userEmail) {
          this.notificationService.send(
            app.userEmail,
            'Loan Amount Disbursed',
            `₹${this.newAmount} has been disbursed for your loan application ${app.trackingNo ?? ''}. Ref: ${this.newRefNo}.`
          ).subscribe({ error: () => {} });
        }
        this.cancelDisburse();
        this.refresh();
        this.loanService.getAllApplications().subscribe((apps) => this.applications.set(apps));
      },
error: (err) => {
  this.processingAppId.set(null);

  this.toast.show(
    'Error',
    err?.error?.message ||
      err?.error?.error ||
      err?.error ||
      'Could not record disbursement.',
    'error'
  );

  console.error('Disbursement failed:', err);
}    });
  }

  toggleSchedule(appId: string) {
    if (this.expandedAppId() === appId) {
      this.expandedAppId.set(null);
      this.expandedSchedule.set([]);
      return;
    }
    this.expandedAppId.set(appId);
    this.scheduleLoading.set(true);
    this.repaymentService.getSchedule(appId).subscribe({
      next: (list) => { this.expandedSchedule.set(list); this.scheduleLoading.set(false); },
      error: () => { this.expandedSchedule.set([]); this.scheduleLoading.set(false); }
    });
  }
}