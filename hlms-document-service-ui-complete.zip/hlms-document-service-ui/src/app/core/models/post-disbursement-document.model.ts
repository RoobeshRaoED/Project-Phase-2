/**
 * Mirrors com.tcs.hlms.entity.PostDisbursementDocumentEntity exactly.
 * fileData is a byte[] on the backend -> Jackson serializes/deserializes it as a base64 string.
 */
export interface PostDisbursementDocument {
  pdDocId?: string;              // UUID, generated server-side
  appId: string;
  docType: string;
  fileName: string;
  fileData?: string;             // base64-encoded file bytes
  fileSize?: number;
  note?: string;
  status?: 'Pending' | 'Verified' | 'Rejected' | string;
  uploadedAt?: string;           // OffsetDateTime ISO string
  verifiedBy?: string;
  verifiedAt?: string;
  remarks?: string;
  deletedAt?: string;
}

/** Same set of post-disbursement document types used in the original HLMS UI. */
export const PD_DOC_TYPES: string[] = [
  'Updated KYC / Identity Document',
  'Property Insurance Renewal',
  'NOC / Loan Closure Supporting Document',
  'Address Change Proof',
  'Property Tax Receipt',
  'Other Supporting Document'
];
