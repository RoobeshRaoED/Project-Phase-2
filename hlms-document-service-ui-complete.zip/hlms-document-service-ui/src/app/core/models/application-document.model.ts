/**
 * Mirrors com.tcs.hlms.entity.ApplicationDocumentEntity exactly.
 * fileData is a byte[] on the backend -> Jackson serializes/deserializes it as a base64 string.
 */
export interface ApplicationDocument {
  documentId?: string;           // UUID, generated server-side
  appId: string;
  docType: string;
  fileName: string;
  fileData?: string;             // base64-encoded file bytes
  fileSize?: number;
  uploadedAt?: string;           // OffsetDateTime ISO string
  verificationStatus?: 'Pending' | 'Verified' | 'Rejected' | string;
  verifiedBy?: string;
  verifiedAt?: string;
  remarks?: string;
  deletedAt?: string;
}

/** Document types offered in the upload form (labels only — docType sent as free text, matching the entity). */
export const APPLICATION_DOC_TYPES: string[] = [
  'Identity Proof (Aadhaar / PAN)',
  'Income Proof (Salary Slip / ITR)',
  'Address Proof',
  'Bank Statement (Last 6 months)',
  'Property Documents',
  'Other Supporting Document'
];
