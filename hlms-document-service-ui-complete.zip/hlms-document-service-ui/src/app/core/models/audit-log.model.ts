/**
 * Mirrors com.tcs.hlms.entity.AuditLogEntity exactly.
 */
export interface AuditLog {
  logId?: number;                // Long, IDENTITY-generated
  entityType: string;
  entityId: string;
  action: string;
  actorEmail: string;
  beforeData?: string;           // TEXT / JSON-ish string, free text
  afterData?: string;            // TEXT / JSON-ish string, free text
  createdAt?: string;            // OffsetDateTime ISO string
}

export const AUDIT_ENTITY_TYPES: string[] = [
  'ApplicationDocument',
  'PostDisbursementDocument',
  'Application',
  'Other'
];

export const AUDIT_ACTIONS: string[] = ['CREATE', 'UPDATE', 'DELETE', 'VERIFY', 'REJECT'];
