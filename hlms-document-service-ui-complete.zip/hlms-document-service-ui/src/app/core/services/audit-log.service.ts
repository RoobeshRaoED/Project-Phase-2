import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AuditLog } from '../models/audit-log.model';

/**
 * Maps 1:1 to com.tcs.hlms.controller.AuditLogController
 * Base path: /api/audit-logs
 */
@Injectable({ providedIn: 'root' })
export class AuditLogService {
  private http = inject(HttpClient);
  private base = `${environment.apiUrl}/audit-logs`;

  /** POST /api/audit-logs */
  createAuditLog(auditLog: AuditLog): Observable<AuditLog> {
    return this.http.post<AuditLog>(this.base, auditLog);
  }

  /** GET /api/audit-logs/{logId} */
  getAuditLogById(logId: number): Observable<AuditLog> {
    return this.http.get<AuditLog>(`${this.base}/${logId}`);
  }

  /** GET /api/audit-logs */
  getAllAuditLogs(): Observable<AuditLog[]> {
    return this.http.get<AuditLog[]>(this.base);
  }

  /** DELETE /api/audit-logs/{logId} */
  deleteAuditLog(logId: number): Observable<string> {
    return this.http.delete(`${this.base}/${logId}`, { responseType: 'text' });
  }
}
