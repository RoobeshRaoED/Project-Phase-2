import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { PostDisbursementDocument } from '../models/post-disbursement-document.model';

/**
 * Maps 1:1 to com.tcs.hlms.controller.PostDisbursementDocumentController
 * Base path: /api/post-disbursement-documents
 */
@Injectable({ providedIn: 'root' })
export class PostDisbursementDocumentService {
  private http = inject(HttpClient);
  private base = `${environment.apiUrl}/post-disbursement-documents`;

  /** POST /api/post-disbursement-documents */
  saveDocument(document: PostDisbursementDocument): Observable<PostDisbursementDocument> {
    return this.http.post<PostDisbursementDocument>(this.base, document);
  }

  /** GET /api/post-disbursement-documents/{documentId} */
  getDocumentById(pdDocId: string): Observable<PostDisbursementDocument> {
    return this.http.get<PostDisbursementDocument>(`${this.base}/${pdDocId}`);
  }

  /** GET /api/post-disbursement-documents/app/{appId} */
  getDocumentsByAppId(appId: string): Observable<PostDisbursementDocument[]> {
    return this.http.get<PostDisbursementDocument[]>(`${this.base}/app/${appId}`);
  }

  /** GET /api/post-disbursement-documents */
  getAllDocuments(): Observable<PostDisbursementDocument[]> {
    return this.http.get<PostDisbursementDocument[]>(this.base);
  }

  /** DELETE /api/post-disbursement-documents/{documentId} */
  deleteDocument(pdDocId: string): Observable<string> {
    return this.http.delete(`${this.base}/${pdDocId}`, { responseType: 'text' });
  }
}
