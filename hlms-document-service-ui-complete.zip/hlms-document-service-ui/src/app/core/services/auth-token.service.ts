import { Injectable, signal } from '@angular/core';

const STORAGE_KEY = 'hlms_auth_token';

/**
 * document-service issues no tokens itself — every request must carry the
 * "Authorization: Bearer <jwt>" obtained from user-service's /login (see SecurityConfig.java).
 * In the full HLMS app this token already lives in shared app state after login;
 * this service just gives this module a single place to read/write it.
 */
@Injectable({ providedIn: 'root' })
export class AuthTokenService {
  readonly token = signal<string | null>(localStorage.getItem(STORAGE_KEY));

  setToken(token: string): void {
    const trimmed = token.trim();
    if (trimmed) {
      localStorage.setItem(STORAGE_KEY, trimmed);
    } else {
      localStorage.removeItem(STORAGE_KEY);
    }
    this.token.set(trimmed || null);
  }

  clearToken(): void {
    localStorage.removeItem(STORAGE_KEY);
    this.token.set(null);
  }

  getToken(): string | null {
    return this.token();
  }
}
