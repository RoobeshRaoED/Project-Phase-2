import { Injectable, signal } from '@angular/core';

export interface ToastItem {
  id: number;
  title: string;
  message: string;
  kind: 'success' | 'error' | 'info';
}

let nextId = 1;

@Injectable({ providedIn: 'root' })
export class ToastService {
  readonly toasts = signal<ToastItem[]>([]);

  show(title: string, message: string, kind: ToastItem['kind'] = 'info'): void {
    const item: ToastItem = { id: nextId++, title, message, kind };
    this.toasts.update((list) => [...list, item]);
    setTimeout(() => this.dismiss(item.id), 4500);
  }

  success(title: string, message = ''): void { this.show(title, message, 'success'); }
  error(title: string, message = ''): void { this.show(title, message, 'error'); }

  dismiss(id: number): void {
    this.toasts.update((list) => list.filter((t) => t.id !== id));
  }
}
