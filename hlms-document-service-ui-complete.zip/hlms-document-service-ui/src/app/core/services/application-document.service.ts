import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ApplicationDocument } from '../models/application-document.model';

/**
 * Maps 1:1 to com.tcs.hlms.controller.ApplicationDocumentController
 * Base path: /api/application-documents
 */
@Injectable({ providedIn: 'root' })
export class ApplicationDocumentService {
  private http = inject(HttpClient);
  private base = `${environment.apiUrl}/application-documents`;

  /** POST /api/application-documents */
  saveDocument(document: ApplicationDocument): Observable<ApplicationDocument> {
    return this.http.post<ApplicationDocument>(this.base, document);
  }

  /** GET /api/application-documents/{documentId} */
  getDocumentById(documentId: string): Observable<ApplicationDocument> {
    return this.http.get<ApplicationDocument>(`${this.base}/${documentId}`);
  }

  /** GET /api/application-documents/app/{appId} */
  getDocumentsByAppId(appId: string): Observable<ApplicationDocument[]> {
    return this.http.get<ApplicationDocument[]>(`${this.base}/app/${appId}`);
  }

  /** GET /api/application-documents */
  getAllDocuments(): Observable<ApplicationDocument[]> {
    return this.http.get<ApplicationDocument[]>(this.base);
  }

  /** DELETE /api/application-documents/{documentId} */
  deleteDocument(documentId: string): Observable<string> {
    return this.http.delete(`${this.base}/${documentId}`, { responseType: 'text' });
  }
}
