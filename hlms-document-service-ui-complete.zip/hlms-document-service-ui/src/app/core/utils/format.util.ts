/** Matches the original app's fmtDate(): "07 Aug 2026" style, en-IN locale. */
export function fmtDate(d?: string | Date | null): string {
  if (!d) return '—';
  const dt = new Date(d);
  if (isNaN(dt.getTime())) return '—';
  return dt.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

/** Matches the original app's docBadgeClass()/pdDocBadgeClass(). */
export function statusBadgeClass(status?: string): string {
  if (status === 'Verified') return 'badge-green';
  if (status === 'Rejected') return 'badge-red';
  return 'badge-orange';
}

/** Colour-codes AuditLogEntity.action for the Audit Log table. */
export function auditActionBadgeClass(action?: string): string {
  switch (action) {
    case 'CREATE': return 'badge-green';
    case 'VERIFY': return 'badge-green';
    case 'UPDATE': return 'badge-navy';
    case 'DELETE': return 'badge-red';
    case 'REJECT': return 'badge-red';
    default: return 'badge-gray';
  }
}
