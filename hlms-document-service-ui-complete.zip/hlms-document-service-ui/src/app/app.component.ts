import { Component, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthTokenService } from './core/services/auth-token.service';
import { ToastComponent } from './shared/toast/toast.component';

@Component({
  selector: 'hlms-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, FormsModule, ToastComponent],
  template: `
    <div class="session-bar">
      <span class="status-dot" [class.ok]="!!auth.token()"></span>
      <span>Session Token (JWT from user-service /login):</span>
      <input
        type="password"
        [ngModel]="auth.token()"
        (ngModelChange)="auth.setToken($event)"
        placeholder="Paste Bearer token here to authenticate document-service requests"
      />
    </div>

    <div id="app" class="module-app">
      <div class="topbar">
        <div class="brand">
          <div class="logo">HL</div>
          <div>
            <div class="title">HLMS</div>
            <div class="subtitle">Document Service</div>
          </div>
        </div>
        <div class="topbar-right">
          <div class="user-chip">
            <div class="user-avatar">DS</div>
            <div class="user-name">Document Service Module</div>
          </div>
        </div>
      </div>

      <div class="sidebar">
        <button class="nav-item" routerLink="/documents" routerLinkActive="active"><span class="ic">🗂️</span> Application Documents</button>
        <button class="nav-item" routerLink="/post-disbursement" routerLinkActive="active"><span class="ic">📤</span> Post Disbursement</button>
        <button class="nav-item" routerLink="/bank-office/documents" routerLinkActive="active"><span class="ic">🏦</span> Bank Office Verification</button>
        <button class="nav-item" routerLink="/legal/documents" routerLinkActive="active"><span class="ic">⚖</span> Legal Document Center</button>
        <button class="nav-item" routerLink="/audit-log" routerLinkActive="active"><span class="ic">🧾</span> Audit Log</button>
      </div>

      <div class="main">
        <router-outlet></router-outlet>
      </div>
      <footer class="app-footer">HLMS Document Service — Application Documents · Audit Log · Post Disbursement Documents (live backend on port 8086).</footer>
    </div>

    <hlms-toast></hlms-toast>
  `
})
export class AppComponent {
  auth = inject(AuthTokenService);
}
