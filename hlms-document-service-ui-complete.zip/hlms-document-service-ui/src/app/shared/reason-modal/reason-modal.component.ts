import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'hlms-reason-modal',
  standalone: true,
  imports: [FormsModule],
  template: `
    @if (open) {
      <div class="modal-overlay" (click)="cancel.emit()">
        <div class="modal-box" (click)="$event.stopPropagation()">
          <h3>{{ title }}</h3>
          <p style="font-size:12.5px;color:var(--text-mid);">{{ description }}</p>
          <div class="field">
            <label>Reason for Rejection</label>
            <textarea rows="4" [(ngModel)]="reason" placeholder="e.g. Document unclear, expired, does not match records..."></textarea>
            @if (touched && !reason.trim()) {
              <div class="error">Please provide a reason for rejection.</div>
            }
          </div>
          <button class="btn btn-danger btn-block" (click)="submit()">Confirm Rejection</button>
        </div>
      </div>
    }
  `
})
export class ReasonModalComponent {
  @Input() open = false;
  @Input() title = 'Reject Document';
  @Input() description = 'The uploader will be notified and asked to re-upload a correct document.';
  @Output() confirm = new EventEmitter<string>();
  @Output() cancel = new EventEmitter<void>();

  reason = '';
  touched = false;

  submit(): void {
    this.touched = true;
    if (!this.reason.trim()) return;
    this.confirm.emit(this.reason.trim());
    this.reason = '';
    this.touched = false;
  }
}
