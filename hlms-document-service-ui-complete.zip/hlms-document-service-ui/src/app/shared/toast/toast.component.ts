import { Component, inject } from '@angular/core';
import { ToastService } from '../../core/services/toast.service';

@Component({
  selector: 'hlms-toast',
  standalone: true,
  template: `
    <div class="toast-wrap">
      @for (t of toastService.toasts(); track t.id) {
        <div class="toast" [class.error]="t.kind === 'error'" [class.success]="t.kind === 'success'" (click)="toastService.dismiss(t.id)">
          <strong>{{ t.title }}</strong>
          @if (t.message) { <span>{{ t.message }}</span> }
        </div>
      }
    </div>
  `
})
export class ToastComponent {
  toastService = inject(ToastService);
}
