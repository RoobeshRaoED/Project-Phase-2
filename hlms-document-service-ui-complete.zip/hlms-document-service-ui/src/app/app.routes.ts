import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'documents' },
  {
    path: 'documents',
    loadComponent: () =>
      import('./features/application-documents/application-documents.component').then((m) => m.ApplicationDocumentsComponent)
  },
  {
    path: 'post-disbursement',
    loadComponent: () =>
      import('./features/post-disbursement-documents/post-disbursement-documents.component').then(
        (m) => m.PostDisbursementDocumentsComponent
      )
  },
  // NOTE: 'bank-office/documents' and 'legal/documents' are owned by other modules of
  // document-service that weren't part of this upload (no matching controller/entity was
  // provided), so there is nothing to build them against yet. They're left out of the route
  // table below (routerLink for them still exists in the sidebar, and the '**' wildcard route
  // safely redirects back to Documents if either is clicked) — add them back the same way as
  // the routes below once those controllers/entities are available.
  {
    path: 'audit-log',
    loadComponent: () => import('./features/audit-log/audit-log.component').then((m) => m.AuditLogComponent)
  },
  { path: '**', redirectTo: 'documents' }
];
