import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { PostDisbursementDocumentService } from '../../core/services/post-disbursement-document.service';
import { PostDisbursementDocument, PD_DOC_TYPES } from '../../core/models/post-disbursement-document.model';
import { ToastService } from '../../core/services/toast.service';
import { downloadBase64File, fileToBase64, formatBytes, guessMimeType } from '../../core/utils/file.util';
import { fmtDate, statusBadgeClass } from '../../core/utils/format.util';

@Component({
  selector: 'hlms-post-disbursement-documents',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './post-disbursement-documents.component.html'
})
export class PostDisbursementDocumentsComponent {
  private service = inject(PostDisbursementDocumentService);
  private toast = inject(ToastService);

  appId = '';
  docs = signal<PostDisbursementDocument[]>([]);
  loading = signal(false);
  loaded = signal(false);

  docTypes = PD_DOC_TYPES;
  uploadDocType = PD_DOC_TYPES[0];
  uploadNote = '';
  selectedFile: File | null = null;
  uploading = signal(false);

  fmtDate = fmtDate;
  statusBadgeClass = statusBadgeClass;
  formatBytes = formatBytes;

  load(): void {
    const id = this.appId.trim();
    if (!id) {
      this.toast.error('Application ID Required', 'Enter an Application ID to view its post-disbursement documents.');
      return;
    }
    this.loading.set(true);
    this.service.getDocumentsByAppId(id).subscribe({
      next: (docs) => {
        this.docs.set(docs);
        this.loaded.set(true);
        this.loading.set(false);
      },
      error: (err) => {
        this.loading.set(false);
        this.toast.error('Failed to Load Documents', err?.error?.message || err?.message || 'Request failed.');
      }
    });
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0] ?? null;
    if (file && file.size > 5 * 1024 * 1024) {
      this.toast.error('File Too Large', 'Maximum file size is 5MB.');
      input.value = '';
      this.selectedFile = null;
      return;
    }
    this.selectedFile = file;
  }

  async upload(): Promise<void> {
    const id = this.appId.trim();
    if (!id) {
      this.toast.error('Application ID Required', 'Enter an Application ID before uploading.');
      return;
    }
    if (!this.selectedFile) {
      this.toast.error('No File Selected', 'Choose a file to upload.');
      return;
    }
    this.uploading.set(true);
    try {
      const base64 = await fileToBase64(this.selectedFile);
      const payload: PostDisbursementDocument = {
        appId: id,
        docType: this.uploadDocType,
        fileName: this.selectedFile.name,
        fileData: base64,
        fileSize: this.selectedFile.size,
        note: this.uploadNote.trim() || undefined,
        status: 'Pending',
        uploadedAt: new Date().toISOString()
      };
      this.service.saveDocument(payload).subscribe({
        next: () => {
          this.uploading.set(false);
          this.selectedFile = null;
          this.uploadNote = '';
          this.toast.success('Document Uploaded', this.uploadDocType + ' — pending Legal & Valuation verification.');
          this.load();
        },
        error: (err) => {
          this.uploading.set(false);
          this.toast.error('Upload Failed', err?.error?.message || err?.message || 'Request failed.');
        }
      });
    } catch {
      this.uploading.set(false);
      this.toast.error('Upload Failed', 'Could not read the selected file.');
    }
  }

  download(doc: PostDisbursementDocument): void {
    if (!doc.fileData) {
      this.toast.error('No File Data', 'This document has no stored file content.');
      return;
    }
    downloadBase64File(doc.fileData, doc.fileName, guessMimeType(doc.fileName));
  }

  remove(doc: PostDisbursementDocument): void {
    if (!doc.pdDocId) return;
    if (!confirm(`Delete "${doc.fileName}"? This cannot be undone.`)) return;
    this.service.deleteDocument(doc.pdDocId).subscribe({
      next: () => {
        this.toast.success('Document Deleted', doc.fileName);
        this.load();
      },
      error: (err) => this.toast.error('Delete Failed', err?.error?.message || err?.message || 'Request failed.')
    });
  }
}
