import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApplicationDocumentService } from '../../core/services/application-document.service';
import { ApplicationDocument, APPLICATION_DOC_TYPES } from '../../core/models/application-document.model';
import { ToastService } from '../../core/services/toast.service';
import { downloadBase64File, fileToBase64, formatBytes, guessMimeType } from '../../core/utils/file.util';
import { fmtDate, statusBadgeClass } from '../../core/utils/format.util';

@Component({
  selector: 'hlms-application-documents',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './application-documents.component.html'
})
export class ApplicationDocumentsComponent {
  private service = inject(ApplicationDocumentService);
  private toast = inject(ToastService);

  appId = '';
  docs = signal<ApplicationDocument[]>([]);
  loading = signal(false);
  loaded = signal(false);

  docTypes = APPLICATION_DOC_TYPES;
  uploadDocType = APPLICATION_DOC_TYPES[0];
  selectedFile: File | null = null;
  uploading = signal(false);

  fmtDate = fmtDate;
  statusBadgeClass = statusBadgeClass;
  formatBytes = formatBytes;

  load(): void {
    const id = this.appId.trim();
    if (!id) {
      this.toast.error('Application ID Required', 'Enter an Application ID to view its documents.');
      return;
    }
    this.loading.set(true);
    this.service.getDocumentsByAppId(id).subscribe({
      next: (docs) => {
        this.docs.set(docs);
        this.loaded.set(true);
        this.loading.set(false);
      },
      error: (err) => {
        this.loading.set(false);
        this.toast.error('Failed to Load Documents', err?.error?.message || err?.message || 'Request failed.');
      }
    });
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0] ?? null;
    if (file && file.size > 5 * 1024 * 1024) {
      this.toast.error('File Too Large', 'Maximum file size is 5MB.');
      input.value = '';
      this.selectedFile = null;
      return;
    }
    this.selectedFile = file;
  }

  async upload(): Promise<void> {
    const id = this.appId.trim();
    if (!id) {
      this.toast.error('Application ID Required', 'Enter an Application ID before uploading.');
      return;
    }
    if (!this.selectedFile) {
      this.toast.error('No File Selected', 'Choose a file to upload.');
      return;
    }
    this.uploading.set(true);
    try {
      const base64 = await fileToBase64(this.selectedFile);
      const payload: ApplicationDocument = {
        appId: id,
        docType: this.uploadDocType,
        fileName: this.selectedFile.name,
        fileData: base64,
        fileSize: this.selectedFile.size,
        uploadedAt: new Date().toISOString(),
        verificationStatus: 'Pending'
      };
      this.service.saveDocument(payload).subscribe({
        next: () => {
          this.uploading.set(false);
          this.selectedFile = null;
          this.toast.success('Document Uploaded', this.uploadDocType + ' — pending Bank Office verification.');
          this.load();
        },
        error: (err) => {
          this.uploading.set(false);
          this.toast.error('Upload Failed', err?.error?.message || err?.message || 'Request failed.');
        }
      });
    } catch {
      this.uploading.set(false);
      this.toast.error('Upload Failed', 'Could not read the selected file.');
    }
  }

  download(doc: ApplicationDocument): void {
    if (!doc.fileData) {
      this.toast.error('No File Data', 'This document has no stored file content.');
      return;
    }
    downloadBase64File(doc.fileData, doc.fileName, guessMimeType(doc.fileName));
  }

  remove(doc: ApplicationDocument): void {
    if (!doc.documentId) return;
    if (!confirm(`Delete "${doc.fileName}"? This cannot be undone.`)) return;
    this.service.deleteDocument(doc.documentId).subscribe({
      next: () => {
        this.toast.success('Document Deleted', doc.fileName);
        this.load();
      },
      error: (err) => this.toast.error('Delete Failed', err?.error?.message || err?.message || 'Request failed.')
    });
  }
}
