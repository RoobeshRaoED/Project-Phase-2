import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AuditLogService } from '../../core/services/audit-log.service';
import { AuditLog, AUDIT_ACTIONS, AUDIT_ENTITY_TYPES } from '../../core/models/audit-log.model';
import { ToastService } from '../../core/services/toast.service';
import { fmtDate, auditActionBadgeClass } from '../../core/utils/format.util';

@Component({
  selector: 'hlms-audit-log',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './audit-log.component.html'
})
export class AuditLogComponent {
  private service = inject(AuditLogService);
  private toast = inject(ToastService);

  entityTypes = AUDIT_ENTITY_TYPES;
  actions = AUDIT_ACTIONS;

  // ---- Create form ----
  formEntityType = AUDIT_ENTITY_TYPES[0];
  formEntityId = '';
  formAction = AUDIT_ACTIONS[0];
  formActorEmail = '';
  formBeforeData = '';
  formAfterData = '';
  creating = signal(false);

  // ---- Find by Log ID ----
  searchLogId: number | null = null;
  searching = signal(false);
  searchResult = signal<AuditLog | null>(null);
  searchNotFound = signal(false);

  // ---- All logs ----
  logs = signal<AuditLog[]>([]);
  loading = signal(false);
  loaded = signal(false);
  expandedId = signal<number | null>(null);

  fmtDate = fmtDate;
  auditActionBadgeClass = auditActionBadgeClass;

  create(): void {
    const entityId = this.formEntityId.trim();
    const actorEmail = this.formActorEmail.trim();
    if (!entityId) {
      this.toast.error('Entity ID Required', 'Enter the ID of the record this log entry refers to.');
      return;
    }
    if (!actorEmail) {
      this.toast.error('Actor Email Required', 'Enter the email of the user performing the action.');
      return;
    }
    this.creating.set(true);
    const payload: AuditLog = {
      entityType: this.formEntityType,
      entityId,
      action: this.formAction,
      actorEmail,
      beforeData: this.formBeforeData.trim() || undefined,
      afterData: this.formAfterData.trim() || undefined,
      createdAt: new Date().toISOString()
    };
    this.service.createAuditLog(payload).subscribe({
      next: () => {
        this.creating.set(false);
        this.toast.success('Audit Log Recorded', `${this.formAction} on ${this.formEntityType} ${entityId}`);
        this.formEntityId = '';
        this.formActorEmail = '';
        this.formBeforeData = '';
        this.formAfterData = '';
        if (this.loaded()) this.loadAll();
      },
      error: (err) => {
        this.creating.set(false);
        this.toast.error('Failed to Record Log', err?.error?.message || err?.message || 'Request failed.');
      }
    });
  }

  findById(): void {
    if (this.searchLogId === null || this.searchLogId === undefined || `${this.searchLogId}`.trim() === '') {
      this.toast.error('Log ID Required', 'Enter a Log ID to search for.');
      return;
    }
    this.searching.set(true);
    this.searchResult.set(null);
    this.searchNotFound.set(false);
    this.service.getAuditLogById(this.searchLogId).subscribe({
      next: (log) => {
        this.searching.set(false);
        this.searchResult.set(log);
      },
      error: (err) => {
        this.searching.set(false);
        this.searchNotFound.set(true);
        this.toast.error('Log Not Found', err?.error?.message || err?.message || `No audit log with ID ${this.searchLogId}.`);
      }
    });
  }

  loadAll(): void {
    this.loading.set(true);
    this.service.getAllAuditLogs().subscribe({
      next: (logs) => {
        this.logs.set([...logs].sort((a, b) => (b.logId ?? 0) - (a.logId ?? 0)));
        this.loaded.set(true);
        this.loading.set(false);
      },
      error: (err) => {
        this.loading.set(false);
        this.toast.error('Failed to Load Audit Logs', err?.error?.message || err?.message || 'Request failed.');
      }
    });
  }

  toggleExpand(logId?: number): void {
    if (logId === undefined) return;
    this.expandedId.set(this.expandedId() === logId ? null : logId);
  }

  remove(log: AuditLog): void {
    if (log.logId === undefined) return;
    if (!confirm(`Delete audit log #${log.logId} (${log.action} on ${log.entityType} ${log.entityId})? This cannot be undone.`)) return;
    this.service.deleteAuditLog(log.logId).subscribe({
      next: () => {
        this.toast.success('Audit Log Deleted', `#${log.logId}`);
        if (this.searchResult()?.logId === log.logId) this.searchResult.set(null);
        if (this.loaded()) this.loadAll();
      },
      error: (err) => this.toast.error('Delete Failed', err?.error?.message || err?.message || 'Request failed.')
    });
  }
}
