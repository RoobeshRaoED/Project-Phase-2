export const environment = {
  production: true,
  // Change to wherever document-service is reachable in your deployment
  // (e.g. behind the API gateway, or the Eureka-resolved service URL).
  apiUrl: 'http://localhost:8086/api'
};
