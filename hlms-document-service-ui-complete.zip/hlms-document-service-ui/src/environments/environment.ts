export const environment = {
  production: false,
  // In dev, requests to /api are proxied to http://localhost:8086 by proxy.conf.json
  // (see "npm start"). This avoids CORS issues since document-service has no CORS config.
  apiUrl: '/api'
};
