package com.hlms.loan.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "loan_application")
public class LoanApplication {

    @Id
    @Column(name = "app_id", length = 50)
    private String appId;

    @Column(name = "tracking_no", length = 50, unique = true)
    private String trackingNo;

    @Column(name = "user_email", nullable = false)
    private String userEmail;

    @Column(name = "product_id")
    private String productId;

    @Column(name = "loan_amount", precision = 14, scale = 2)
    private BigDecimal loanAmount;

    @Column(name = "tenure_years")
    private Integer tenureYears;

    @Column(name = "purpose", length = 150)
    private String purpose;

    @Column(name = "interest_rate", precision = 5, scale = 2)
    private BigDecimal interestRate;

    @Column(name = "status", nullable = false)
    private String status = "Draft"; // Draft, Submitted, Under Review, Rejected, Disbursed

    @Column(name = "stage_index", nullable = false)
    private Integer stageIndex = 0;

    @Column(name = "current_step", nullable = false)
    private Integer currentStep = 1;

    // Raw JSON text, mapped to the jsonb column via Hibernate 6's built-in JSON support.
    // Serialize/deserialize with ObjectMapper in the service layer as needed.
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "form_data", columnDefinition = "jsonb", nullable = false)
    private String formData = "{}";

    @Column(name = "saved_at", nullable = false)
    private OffsetDateTime savedAt;

    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;

    @Column(name = "applicant_name", length = 150)
    private String applicantName;
    @Column(name = "applicant_mobile", length = 20)
    private String applicantMobile;
    @Column(name = "applicant_pan", length = 20)
    private String applicantPan;

    @Column(name = "addr_door_no", length = 30)
    private String addrDoorNo;
    @Column(name = "addr_street", length = 150)
    private String addrStreet;
    @Column(name = "addr_city", length = 100)
    private String addrCity;
    @Column(name = "addr_state", length = 100)
    private String addrState;
    @Column(name = "addr_pincode", length = 10)
    private String addrPincode;

    @Column(name = "employment_type", length = 30)
    private String employmentType;
    @Column(name = "employer", length = 150)
    private String employer;
    @Column(name = "monthly_income", precision = 14, scale = 2)
    private BigDecimal monthlyIncome;
    @Column(name = "other_emis", precision = 14, scale = 2)
    private BigDecimal otherEmis;

    @Column(name = "property_address", columnDefinition = "TEXT")
    private String propertyAddress;
    @Column(name = "property_type", length = 50)
    private String propertyType;
    @Column(name = "property_value", precision = 14, scale = 2)
    private BigDecimal propertyValue;

    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    // Read-only join onto product_id above; productId's setter stays the
    // single source of truth for INSERT/UPDATE.
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id", referencedColumnName = "product_id", insertable = false, updatable = false)
    private LoanProduct loanProduct;

    public LoanApplication() {
    }

    public LoanProduct getLoanProduct() {
        return loanProduct;
    }

    public LoanApplication(String appId, String trackingNo, String userEmail, String productId,
                            BigDecimal loanAmount, Integer tenureYears, String purpose, BigDecimal interestRate,
                            String status, Integer stageIndex, Integer currentStep, String formData,
                            OffsetDateTime savedAt, OffsetDateTime createdAt, String applicantName,
                            String applicantMobile, String applicantPan, String addrDoorNo, String addrStreet,
                            String addrCity, String addrState, String addrPincode, String employmentType,
                            String employer, BigDecimal monthlyIncome, BigDecimal otherEmis,
                            String propertyAddress, String propertyType, BigDecimal propertyValue,
                            OffsetDateTime deletedAt) {
        this.appId = appId;
        this.trackingNo = trackingNo;
        this.userEmail = userEmail;
        this.productId = productId;
        this.loanAmount = loanAmount;
        this.tenureYears = tenureYears;
        this.purpose = purpose;
        this.interestRate = interestRate;
        this.status = status;
        this.stageIndex = stageIndex;
        this.currentStep = currentStep;
        this.formData = formData;
        this.savedAt = savedAt;
        this.createdAt = createdAt;
        this.applicantName = applicantName;
        this.applicantMobile = applicantMobile;
        this.applicantPan = applicantPan;
        this.addrDoorNo = addrDoorNo;
        this.addrStreet = addrStreet;
        this.addrCity = addrCity;
        this.addrState = addrState;
        this.addrPincode = addrPincode;
        this.employmentType = employmentType;
        this.employer = employer;
        this.monthlyIncome = monthlyIncome;
        this.otherEmis = otherEmis;
        this.propertyAddress = propertyAddress;
        this.propertyType = propertyType;
        this.propertyValue = propertyValue;
        this.deletedAt = deletedAt;
    }

    @PrePersist
    public void prePersist() {
        OffsetDateTime now = OffsetDateTime.now();
        if (createdAt == null) createdAt = now;
        if (savedAt == null) savedAt = now;
    }

    @PreUpdate
    public void preUpdate() {
        this.savedAt = OffsetDateTime.now();
    }

    public static Builder builder() {
        return new Builder();
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getTrackingNo() {
        return trackingNo;
    }

    public void setTrackingNo(String trackingNo) {
        this.trackingNo = trackingNo;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public BigDecimal getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(BigDecimal loanAmount) {
        this.loanAmount = loanAmount;
    }

    public Integer getTenureYears() {
        return tenureYears;
    }

    public void setTenureYears(Integer tenureYears) {
        this.tenureYears = tenureYears;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getStageIndex() {
        return stageIndex;
    }

    public void setStageIndex(Integer stageIndex) {
        this.stageIndex = stageIndex;
    }

    public Integer getCurrentStep() {
        return currentStep;
    }

    public void setCurrentStep(Integer currentStep) {
        this.currentStep = currentStep;
    }

    public String getFormData() {
        return formData;
    }

    public void setFormData(String formData) {
        this.formData = formData;
    }

    public OffsetDateTime getSavedAt() {
        return savedAt;
    }

    public void setSavedAt(OffsetDateTime savedAt) {
        this.savedAt = savedAt;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public String getApplicantName() {
        return applicantName;
    }

    public void setApplicantName(String applicantName) {
        this.applicantName = applicantName;
    }

    public String getApplicantMobile() {
        return applicantMobile;
    }

    public void setApplicantMobile(String applicantMobile) {
        this.applicantMobile = applicantMobile;
    }

    public String getApplicantPan() {
        return applicantPan;
    }

    public void setApplicantPan(String applicantPan) {
        this.applicantPan = applicantPan;
    }

    public String getAddrDoorNo() {
        return addrDoorNo;
    }

    public void setAddrDoorNo(String addrDoorNo) {
        this.addrDoorNo = addrDoorNo;
    }

    public String getAddrStreet() {
        return addrStreet;
    }

    public void setAddrStreet(String addrStreet) {
        this.addrStreet = addrStreet;
    }

    public String getAddrCity() {
        return addrCity;
    }

    public void setAddrCity(String addrCity) {
        this.addrCity = addrCity;
    }

    public String getAddrState() {
        return addrState;
    }

    public void setAddrState(String addrState) {
        this.addrState = addrState;
    }

    public String getAddrPincode() {
        return addrPincode;
    }

    public void setAddrPincode(String addrPincode) {
        this.addrPincode = addrPincode;
    }

    public String getEmploymentType() {
        return employmentType;
    }

    public void setEmploymentType(String employmentType) {
        this.employmentType = employmentType;
    }

    public String getEmployer() {
        return employer;
    }

    public void setEmployer(String employer) {
        this.employer = employer;
    }

    public BigDecimal getMonthlyIncome() {
        return monthlyIncome;
    }

    public void setMonthlyIncome(BigDecimal monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }

    public BigDecimal getOtherEmis() {
        return otherEmis;
    }

    public void setOtherEmis(BigDecimal otherEmis) {
        this.otherEmis = otherEmis;
    }

    public String getPropertyAddress() {
        return propertyAddress;
    }

    public void setPropertyAddress(String propertyAddress) {
        this.propertyAddress = propertyAddress;
    }

    public String getPropertyType() {
        return propertyType;
    }

    public void setPropertyType(String propertyType) {
        this.propertyType = propertyType;
    }

    public BigDecimal getPropertyValue() {
        return propertyValue;
    }

    public void setPropertyValue(BigDecimal propertyValue) {
        this.propertyValue = propertyValue;
    }

    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static final class Builder {
        private String appId;
        private String trackingNo;
        private String userEmail;
        private String productId;
        private BigDecimal loanAmount;
        private Integer tenureYears;
        private String purpose;
        private BigDecimal interestRate;
        private String status = "Draft";
        private Integer stageIndex = 0;
        private Integer currentStep = 1;
        private String formData = "{}";
        private OffsetDateTime savedAt;
        private OffsetDateTime createdAt;
        private String applicantName;
        private String applicantMobile;
        private String applicantPan;
        private String addrDoorNo;
        private String addrStreet;
        private String addrCity;
        private String addrState;
        private String addrPincode;
        private String employmentType;
        private String employer;
        private BigDecimal monthlyIncome;
        private BigDecimal otherEmis;
        private String propertyAddress;
        private String propertyType;
        private BigDecimal propertyValue;
        private OffsetDateTime deletedAt;

        private Builder() {
        }

        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }

        public Builder trackingNo(String trackingNo) {
            this.trackingNo = trackingNo;
            return this;
        }

        public Builder userEmail(String userEmail) {
            this.userEmail = userEmail;
            return this;
        }

        public Builder productId(String productId) {
            this.productId = productId;
            return this;
        }

        public Builder loanAmount(BigDecimal loanAmount) {
            this.loanAmount = loanAmount;
            return this;
        }

        public Builder tenureYears(Integer tenureYears) {
            this.tenureYears = tenureYears;
            return this;
        }

        public Builder purpose(String purpose) {
            this.purpose = purpose;
            return this;
        }

        public Builder interestRate(BigDecimal interestRate) {
            this.interestRate = interestRate;
            return this;
        }

        public Builder status(String status) {
            this.status = status;
            return this;
        }

        public Builder stageIndex(Integer stageIndex) {
            this.stageIndex = stageIndex;
            return this;
        }

        public Builder currentStep(Integer currentStep) {
            this.currentStep = currentStep;
            return this;
        }

        public Builder formData(String formData) {
            this.formData = formData;
            return this;
        }

        public Builder savedAt(OffsetDateTime savedAt) {
            this.savedAt = savedAt;
            return this;
        }

        public Builder createdAt(OffsetDateTime createdAt) {
            this.createdAt = createdAt;
            return this;
        }

        public Builder applicantName(String applicantName) {
            this.applicantName = applicantName;
            return this;
        }

        public Builder applicantMobile(String applicantMobile) {
            this.applicantMobile = applicantMobile;
            return this;
        }

        public Builder applicantPan(String applicantPan) {
            this.applicantPan = applicantPan;
            return this;
        }

        public Builder addrDoorNo(String addrDoorNo) {
            this.addrDoorNo = addrDoorNo;
            return this;
        }

        public Builder addrStreet(String addrStreet) {
            this.addrStreet = addrStreet;
            return this;
        }

        public Builder addrCity(String addrCity) {
            this.addrCity = addrCity;
            return this;
        }

        public Builder addrState(String addrState) {
            this.addrState = addrState;
            return this;
        }

        public Builder addrPincode(String addrPincode) {
            this.addrPincode = addrPincode;
            return this;
        }

        public Builder employmentType(String employmentType) {
            this.employmentType = employmentType;
            return this;
        }

        public Builder employer(String employer) {
            this.employer = employer;
            return this;
        }

        public Builder monthlyIncome(BigDecimal monthlyIncome) {
            this.monthlyIncome = monthlyIncome;
            return this;
        }

        public Builder otherEmis(BigDecimal otherEmis) {
            this.otherEmis = otherEmis;
            return this;
        }

        public Builder propertyAddress(String propertyAddress) {
            this.propertyAddress = propertyAddress;
            return this;
        }

        public Builder propertyType(String propertyType) {
            this.propertyType = propertyType;
            return this;
        }

        public Builder propertyValue(BigDecimal propertyValue) {
            this.propertyValue = propertyValue;
            return this;
        }

        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public LoanApplication build() {
            return new LoanApplication(appId, trackingNo, userEmail, productId, loanAmount, tenureYears, purpose,
                    interestRate, status, stageIndex, currentStep, formData, savedAt, createdAt, applicantName,
                    applicantMobile, applicantPan, addrDoorNo, addrStreet, addrCity, addrState, addrPincode,
                    employmentType, employer, monthlyIncome, otherEmis, propertyAddress, propertyType,
                    propertyValue, deletedAt);
        }
    }
}
