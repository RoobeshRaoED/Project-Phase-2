package com.hlms2.legal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
public class Hlms2LegalServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(Hlms2LegalServiceApplication.class, args);
    }
}
