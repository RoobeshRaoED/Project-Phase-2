package com.hlms2.repayment.serviceimpl;

import com.hlms2.repayment.dto.EmiInstallmentDTO;
import com.hlms2.repayment.entity.EmiInstallment;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.exception.ValidationException;
import com.hlms2.repayment.exception.Validators;
import com.hlms2.repayment.repository.EmiInstallmentRepository;
import com.hlms2.repayment.service.EmiInstallmentService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Ported from hlms2.serviceimpl.EmiInstallmentServiceImpl (plain JDBC
 * version), then updated for hlms_schema_updated_v2.sql (soft delete +
 * restore; PK unchanged). Persistence goes through Spring Data JPA
 * (EmiInstallmentRepository) instead of a hand-written DAO.
 *
 * Business logic (US-LRM-01..04): validates EMI math, guarantees the
 * outstanding balance can never go negative, and automatically flags
 * OVERDUE installments whose due date has passed unpaid.
 *
 * Business logic (US-LRM-05): {@link #getPaymentHistory} gives a bank
 * officer the complete, chronologically-ordered repayment record for a
 * loan.
 *
 * Business logic (US-DMNG-01, US-DMNG-04, US-DMNG-05): overdue installments
 * are the raw signal for default management - {@link #detectOverdueLoans},
 * {@link #determineEscalationLevel} and {@link #getDefaultStatus} re-derive
 * default detection, escalation tier and status directly from them so there
 * is never a separate flag that can drift out of sync.
 */
@Service
@Transactional
public class EmiInstallmentServiceImpl implements EmiInstallmentService {

    private static final List<String> VALID_STATUSES = List.of("PENDING", "PAID", "OVERDUE");
    private static final BigDecimal ROUNDING_TOLERANCE = BigDecimal.valueOf(1);

    private final EmiInstallmentRepository repository;

    public EmiInstallmentServiceImpl(EmiInstallmentRepository repository) {
        this.repository = repository;
    }

    @Override
    public EmiInstallmentDTO create(EmiInstallmentDTO dto) {
        validate(dto);
        EmiInstallment entity = toEntity(dto);
        if (entity.getInstallmentId() == null || entity.getInstallmentId().isBlank()) {
            entity.setInstallmentId("EMI-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        entity.setStatus(deriveStatus(entity));
        return toDto(repository.save(entity));
    }

    @Override
    public EmiInstallmentDTO update(EmiInstallmentDTO dto) {
        Validators.required(dto.getInstallmentId(), "installmentId");
        repository.findByInstallmentIdAndDeletedAtIsNull(dto.getInstallmentId())
                .orElseThrow(() -> new ResourceNotFoundException("EMI installment " + dto.getInstallmentId() + " does not exist."));
        validate(dto);
        EmiInstallment entity = toEntity(dto);
        // US-LRM-01: an invalid/duplicate payment cannot be recorded against an already-paid installment.
        entity.setStatus(deriveStatus(entity));
        return toDto(repository.save(entity));
    }

    @Override
    public boolean softDelete(String installmentId) {
        return repository.findByInstallmentIdAndDeletedAtIsNull(installmentId)
                .map(entity -> {
                    entity.setDeletedAt(OffsetDateTime.now());
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    public boolean restore(String installmentId) {
        return repository.findById(installmentId)
                .filter(entity -> entity.getDeletedAt() != null)
                .map(entity -> {
                    entity.setDeletedAt(null);
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    @Transactional(readOnly = true)
    public EmiInstallmentDTO findById(String installmentId) {
        Validators.required(installmentId, "installmentId");
        return repository.findByInstallmentIdAndDeletedAtIsNull(installmentId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<EmiInstallmentDTO> findAll() {
        return repository.findByDeletedAtIsNull().stream().map(this::toDto).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<EmiInstallmentDTO> getPaymentHistory(String appId) {
        Validators.required(appId, "appId");
        return repository.findByAppIdAndDeletedAtIsNull(appId).stream()
                .map(this::toDto)
                .sorted(Comparator.comparing(EmiInstallmentDTO::getInstallmentNo))
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public Set<String> detectOverdueLoans() {
        Set<String> overdueAppIds = new LinkedHashSet<>();
        for (EmiInstallmentDTO dto : findAll()) {
            if ("OVERDUE".equalsIgnoreCase(dto.getStatus()) && dto.getAppId() != null) {
                overdueAppIds.add(dto.getAppId());
            }
        }
        return overdueAppIds;
    }

    @Override
    @Transactional(readOnly = true)
    public String determineEscalationLevel(String appId) {
        Validators.required(appId, "appId");
        int overdueCount = countOverdueInstallments(appId);
        if (overdueCount == 0) {
            return "NONE";
        } else if (overdueCount <= 2) {
            return "REMINDER";
        } else if (overdueCount <= 4) {
            return "NOTICE";
        }
        return "LEGAL_ESCALATION";
    }

    @Override
    @Transactional(readOnly = true)
    public String getDefaultStatus(String appId) {
        Validators.required(appId, "appId");
        int overdueCount = 0;
        BigDecimal overdueAmount = BigDecimal.ZERO;
        for (EmiInstallmentDTO dto : getPaymentHistory(appId)) {
            if ("OVERDUE".equalsIgnoreCase(dto.getStatus())) {
                overdueCount++;
                overdueAmount = overdueAmount.add(dto.getEmiAmount());
            }
        }
        if (overdueCount == 0) {
            return "IN_GOOD_STANDING";
        }
        return "DEFAULTED (" + overdueCount + " overdue installment(s), total overdue amount " + overdueAmount
                + ", escalation level " + determineEscalationLevel(appId) + ")";
    }

    private int countOverdueInstallments(String appId) {
        int count = 0;
        for (EmiInstallmentDTO dto : getPaymentHistory(appId)) {
            if ("OVERDUE".equalsIgnoreCase(dto.getStatus())) {
                count++;
            }
        }
        return count;
    }

    private void validate(EmiInstallmentDTO dto) {
        Validators.required(dto.getAppId(), "appId");
        Validators.positive(dto.getInstallmentNo(), "installmentNo");
        Validators.required(dto.getDueDate(), "dueDate");
        Validators.positive(dto.getEmiAmount(), "emiAmount");
        Validators.nonNegative(dto.getPrincipalComponent(), "principalComponent");
        Validators.nonNegative(dto.getInterestComponent(), "interestComponent");
        // US-LRM-03: outstanding balance can never become negative.
        Validators.nonNegative(dto.getClosingBalance(), "closingBalance");

        BigDecimal sumComponents = dto.getPrincipalComponent().add(dto.getInterestComponent());
        if (sumComponents.subtract(dto.getEmiAmount()).abs().compareTo(ROUNDING_TOLERANCE) > 0) {
            throw new ValidationException("principalComponent + interestComponent must equal emiAmount.");
        }
        if (dto.getStatus() != null) {
            Validators.oneOf(dto.getStatus(), "status", VALID_STATUSES.toArray(new String[0]));
        }
        if ("PAID".equalsIgnoreCase(dto.getStatus()) && dto.getPaidDate() == null) {
            throw new ValidationException("paidDate is required when status is PAID.");
        }
    }

    /** US-LRM-04: overdue status is derived automatically rather than trusted from the caller. */
    private String deriveStatus(EmiInstallment entity) {
        if (entity.getPaidDate() != null) {
            return "PAID";
        }
        if (entity.getDueDate() != null && entity.getDueDate().isBefore(LocalDate.now())) {
            return "OVERDUE";
        }
        return "PENDING";
    }

    private EmiInstallment toEntity(EmiInstallmentDTO dto) {
        return EmiInstallment.builder()
                .installmentId(dto.getInstallmentId())
                .appId(dto.getAppId())
                .installmentNo(dto.getInstallmentNo())
                .dueDate(dto.getDueDate())
                .emiAmount(dto.getEmiAmount())
                .principalComponent(dto.getPrincipalComponent())
                .interestComponent(dto.getInterestComponent())
                .closingBalance(dto.getClosingBalance())
                .status(dto.getStatus())
                .paidDate(dto.getPaidDate())
                .build();
    }

    private EmiInstallmentDTO toDto(EmiInstallment entity) {
        return EmiInstallmentDTO.builder()
                .installmentId(entity.getInstallmentId())
                .appId(entity.getAppId())
                .installmentNo(entity.getInstallmentNo())
                .dueDate(entity.getDueDate())
                .emiAmount(entity.getEmiAmount())
                .principalComponent(entity.getPrincipalComponent())
                .interestComponent(entity.getInterestComponent())
                .closingBalance(entity.getClosingBalance())
                .status(entity.getStatus())
                .paidDate(entity.getPaidDate())
                .build();
    }
}
