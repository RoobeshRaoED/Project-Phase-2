package com.hlms2.repayment.controller;

import com.hlms2.repayment.dto.InsurancePolicyDTO;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.service.InsurancePolicyService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/insurance-policies")
public class InsurancePolicyController {

    private final InsurancePolicyService service;

    public InsurancePolicyController(InsurancePolicyService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<InsurancePolicyDTO> create(@RequestBody InsurancePolicyDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(dto));
    }

    @PutMapping("/{policyId}")
    public InsurancePolicyDTO update(@PathVariable String policyId, @RequestBody InsurancePolicyDTO dto) {
        dto.setPolicyId(policyId);
        return service.update(dto);
    }

    @DeleteMapping("/{policyId}")
    public ResponseEntity<Void> softDelete(@PathVariable String policyId) {
        return service.softDelete(policyId) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    @PostMapping("/{policyId}/restore")
    public ResponseEntity<Void> restore(@PathVariable String policyId) {
        return service.restore(policyId) ? ResponseEntity.ok().build() : ResponseEntity.notFound().build();
    }

    @GetMapping("/{policyId}")
    public InsurancePolicyDTO findById(@PathVariable String policyId) {
        InsurancePolicyDTO dto = service.findById(policyId);
        if (dto == null) {
            throw new ResourceNotFoundException("Insurance policy " + policyId + " does not exist.");
        }
        return dto;
    }

    @GetMapping
    public List<InsurancePolicyDTO> findAll() {
        return service.findAll();
    }
}
