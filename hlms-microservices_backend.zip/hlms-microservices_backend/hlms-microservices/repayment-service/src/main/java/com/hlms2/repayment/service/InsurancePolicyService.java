package com.hlms2.repayment.service;

import com.hlms2.repayment.dto.InsurancePolicyDTO;

import java.util.List;

public interface InsurancePolicyService {
    InsurancePolicyDTO create(InsurancePolicyDTO dto);
    InsurancePolicyDTO update(InsurancePolicyDTO dto);
    boolean softDelete(String policyId);
    boolean restore(String policyId);
    InsurancePolicyDTO findById(String policyId);
    List<InsurancePolicyDTO> findAll();
}
