package com.hlms2.repayment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
public class Hlms2RepaymentServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(Hlms2RepaymentServiceApplication.class, args);
    }
}
