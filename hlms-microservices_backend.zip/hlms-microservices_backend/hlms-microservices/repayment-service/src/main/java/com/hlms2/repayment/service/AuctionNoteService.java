package com.hlms2.repayment.service;

import com.hlms2.repayment.dto.AuctionNoteDTO;

import java.util.List;

public interface AuctionNoteService {
    AuctionNoteDTO create(AuctionNoteDTO dto);
    AuctionNoteDTO update(AuctionNoteDTO dto);
    boolean softDelete(String noteId);
    boolean restore(String noteId);
    AuctionNoteDTO findById(String noteId);
    List<AuctionNoteDTO> findAll();

    List<AuctionNoteDTO> getAuctionRecord(String appId);
    AuctionNoteDTO recordAuctionEvent(String appId, String eventDescription);
}
