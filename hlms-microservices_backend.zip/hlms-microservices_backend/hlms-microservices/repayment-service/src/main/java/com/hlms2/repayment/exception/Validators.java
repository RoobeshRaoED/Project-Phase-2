package com.hlms2.repayment.exception;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;

/**
 * Ported from hlms.util.Validators - trimmed down to the checks the
 * repayment-domain ServiceImpl classes use. Throws the unchecked
 * ValidationException instead of the checked one.
 */
public final class Validators {

    private Validators() {
    }

    public static void required(Object value, String fieldName) {
        if (value == null || (value instanceof String && ((String) value).trim().isEmpty())) {
            throw new ValidationException(fieldName + " is required.");
        }
    }

    public static void oneOf(String value, String fieldName, String... allowed) {
        required(value, fieldName);
        if (Arrays.stream(allowed).noneMatch(a -> a.equalsIgnoreCase(value))) {
            throw new ValidationException(fieldName + " must be one of " + Arrays.toString(allowed) + ".");
        }
    }

    public static void positive(BigDecimal value, String fieldName) {
        required(value, fieldName);
        if (value.signum() <= 0) {
            throw new ValidationException(fieldName + " must be positive.");
        }
    }

    public static void positive(Integer value, String fieldName) {
        required(value, fieldName);
        if (value <= 0) {
            throw new ValidationException(fieldName + " must be positive.");
        }
    }

    public static void nonNegative(BigDecimal value, String fieldName) {
        required(value, fieldName);
        if (value.signum() < 0) {
            throw new ValidationException(fieldName + " cannot be negative.");
        }
    }

    public static void maxLength(String value, String fieldName, int max) {
        if (value != null && value.length() > max) {
            throw new ValidationException(fieldName + " cannot exceed " + max + " characters.");
        }
    }

    public static void futureOrToday(LocalDate value, String fieldName) {
        // Kept permissive on purpose (matches hlms.util.Validators.futureOrToday,
        // which only rejects nulls when required elsewhere) - validTill on an
        // already-expired/cancelled policy is a legitimate historical record.
    }

    public static void afterOrEqual(LocalDate later, LocalDate earlier, String laterField, String earlierField) {
        if (later != null && earlier != null && later.isBefore(earlier)) {
            throw new ValidationException(laterField + " must be on or after " + earlierField + ".");
        }
    }
}
