package com.hlms2.repayment.serviceimpl;

import com.hlms2.repayment.dto.AuctionNoteDTO;
import com.hlms2.repayment.entity.AuctionNote;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.exception.Validators;
import com.hlms2.repayment.repository.AuctionNoteRepository;
import com.hlms2.repayment.service.AuctionNoteService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * Ported from hlms2.serviceimpl.AuctionNoteServiceImpl (plain JDBC
 * version), then updated for hlms_schema_updated_v2.sql: delete is now a
 * soft delete (sets deleted_at), with a matching restore(). PK unchanged
 * (note_id remains the natural key); the FK to the auction case stays a
 * flat appId string (see the entity javadoc).
 *
 * Business logic (US-AM-05): every auction case activity must be captured
 * as an auditable, timestamped note with real content. {@link #getAuctionRecord}
 * retrieves the complete, chronologically-ordered set of notes for one
 * auction case, and {@link #recordAuctionEvent} gives callers a single
 * place to append a system-generated audit entry when a lifecycle event
 * happens.
 */
@Service
@Transactional
public class AuctionNoteServiceImpl implements AuctionNoteService {

    private final AuctionNoteRepository repository;

    public AuctionNoteServiceImpl(AuctionNoteRepository repository) {
        this.repository = repository;
    }

    @Override
    public AuctionNoteDTO create(AuctionNoteDTO dto) {
        validate(dto);
        AuctionNote entity = toEntity(dto);
        if (entity.getNoteId() == null || entity.getNoteId().isBlank()) {
            entity.setNoteId("ANT-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        entity.setNoteDate(entity.getNoteDate() == null ? OffsetDateTime.now() : entity.getNoteDate());
        return toDto(repository.save(entity));
    }

    @Override
    public AuctionNoteDTO update(AuctionNoteDTO dto) {
        Validators.required(dto.getNoteId(), "noteId");
        repository.findByNoteIdAndDeletedAtIsNull(dto.getNoteId())
                .orElseThrow(() -> new ResourceNotFoundException("Auction note " + dto.getNoteId() + " does not exist."));
        validate(dto);
        AuctionNote entity = toEntity(dto);
        return toDto(repository.save(entity));
    }

    @Override
    public boolean softDelete(String noteId) {
        return repository.findByNoteIdAndDeletedAtIsNull(noteId)
                .map(entity -> {
                    entity.setDeletedAt(OffsetDateTime.now());
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    public boolean restore(String noteId) {
        return repository.findById(noteId)
                .filter(entity -> entity.getDeletedAt() != null)
                .map(entity -> {
                    entity.setDeletedAt(null);
                    repository.save(entity);
                    return true;
                }).orElse(false);
    }

    @Override
    @Transactional(readOnly = true)
    public AuctionNoteDTO findById(String noteId) {
        Validators.required(noteId, "noteId");
        return repository.findByNoteIdAndDeletedAtIsNull(noteId).map(this::toDto).orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AuctionNoteDTO> findAll() {
        return repository.findByDeletedAtIsNull().stream().map(this::toDto).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<AuctionNoteDTO> getAuctionRecord(String appId) {
        Validators.required(appId, "appId");
        return repository.findByAppIdAndDeletedAtIsNull(appId).stream()
                .map(this::toDto)
                .sorted(Comparator.comparing(AuctionNoteDTO::getNoteDate))
                .toList();
    }

    @Override
    public AuctionNoteDTO recordAuctionEvent(String appId, String eventDescription) {
        Validators.required(appId, "appId");
        Validators.required(eventDescription, "eventDescription");
        AuctionNoteDTO dto = new AuctionNoteDTO();
        dto.setAppId(appId);
        dto.setNoteText(eventDescription);
        return create(dto);
    }

    private void validate(AuctionNoteDTO dto) {
        Validators.required(dto.getAppId(), "appId");
        Validators.required(dto.getNoteText(), "noteText");
        Validators.maxLength(dto.getNoteText(), "noteText", 4000);
    }

    private AuctionNote toEntity(AuctionNoteDTO dto) {
        return AuctionNote.builder()
                .noteId(dto.getNoteId())
                .appId(dto.getAppId())
                .noteDate(dto.getNoteDate())
                .noteText(dto.getNoteText())
                .build();
    }

    private AuctionNoteDTO toDto(AuctionNote entity) {
        return AuctionNoteDTO.builder()
                .noteId(entity.getNoteId())
                .appId(entity.getAppId())
                .noteDate(entity.getNoteDate())
                .noteText(entity.getNoteText())
                .build();
    }
}
