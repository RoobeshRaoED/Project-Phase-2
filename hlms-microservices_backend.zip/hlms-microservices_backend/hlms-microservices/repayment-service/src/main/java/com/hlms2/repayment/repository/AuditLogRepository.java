package com.hlms2.repayment.repository;

import com.hlms2.repayment.entity.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;

// No deletedAt filtering here - audit_log has no soft-delete column
// (see the entity javadoc): every row is "active" until hard-deleted.
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
}
