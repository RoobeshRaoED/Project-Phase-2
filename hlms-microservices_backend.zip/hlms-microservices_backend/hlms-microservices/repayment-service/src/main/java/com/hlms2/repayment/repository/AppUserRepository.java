package com.hlms2.repayment.repository;

import com.hlms2.repayment.entity.AppUser;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AppUserRepository extends JpaRepository<AppUser, String> {
    Optional<AppUser> findByEmailAndActiveTrueAndDeletedAtIsNull(String email);
}
