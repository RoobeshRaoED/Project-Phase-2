package com.hlms2.repayment.serviceimpl;

import com.hlms2.repayment.dto.AuctionCaseDTO;
import com.hlms2.repayment.entity.AuctionCase;
import com.hlms2.repayment.exception.ResourceNotFoundException;
import com.hlms2.repayment.exception.ValidationException;
import com.hlms2.repayment.repository.AuctionCaseRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuctionCaseServiceImplTest {

    @Mock
    private AuctionCaseRepository repository;

    private AuctionCaseServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new AuctionCaseServiceImpl(repository);
    }

    private AuctionCaseDTO validDto() {
        AuctionCaseDTO dto = new AuctionCaseDTO();
        dto.setAppId("APP-1");
        dto.setStage("Notice Issued");
        dto.setNoticeDate(LocalDate.of(2026, 1, 1));
        dto.setNoticeDueDate(LocalDate.of(2026, 1, 10));
        dto.setDemandAmount(BigDecimal.valueOf(50000));
        dto.setPossessionDate(LocalDate.of(2026, 1, 20));
        dto.setAuctionDate(LocalDate.of(2026, 2, 1));
        dto.setReservePrice(BigDecimal.valueOf(40000));
        return dto;
    }

    private AuctionCase entityFrom(AuctionCaseDTO dto, Long id) {
        return AuctionCase.builder()
                .auctionId(id)
                .appId(dto.getAppId())
                .stage(dto.getStage())
                .noticeDate(dto.getNoticeDate())
                .noticeDueDate(dto.getNoticeDueDate())
                .demandAmount(dto.getDemandAmount())
                .possessionDate(dto.getPossessionDate())
                .auctionDate(dto.getAuctionDate())
                .reservePrice(dto.getReservePrice())
                .build();
    }

    // ---------- create() ----------

    @Test
    void create_positive_savesAndReturnsDto() {
        AuctionCaseDTO dto = validDto();
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        when(repository.save(any(AuctionCase.class))).thenAnswer(inv -> {
            AuctionCase e = inv.getArgument(0);
            e.setAuctionId(1L);
            return e;
        });

        AuctionCaseDTO result = service.create(dto);

        assertThat(result.getAuctionId()).isEqualTo(1L);
        assertThat(result.getAppId()).isEqualTo("APP-1");
        assertThat(result.getStage()).isEqualTo("Notice Issued");
        verify(repository).save(any(AuctionCase.class));
    }

    @Test
    void create_edge_defaultsStageWhenNull() {
        AuctionCaseDTO dto = validDto();
        dto.setStage(null);
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        ArgumentCaptor<AuctionCase> captor = ArgumentCaptor.forClass(AuctionCase.class);
        when(repository.save(captor.capture())).thenAnswer(inv -> inv.getArgument(0));

        service.create(dto);

        assertThat(captor.getValue().getStage()).isEqualTo("Notice Issued");
    }

    @Test
    void create_negative_missingAppId_throws() {
        AuctionCaseDTO dto = validDto();
        dto.setAppId(null);

        assertThatThrownBy(() -> service.create(dto))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("appId");
        verifyNoInteractions(repository);
    }

    @Test
    void create_negative_duplicateAppId_throws() {
        AuctionCaseDTO dto = validDto();
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1"))
                .thenReturn(Optional.of(entityFrom(dto, 5L)));

        assertThatThrownBy(() -> service.create(dto))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("already exists");
        verify(repository, never()).save(any());
    }

    @Test
    void create_negative_invalidStage_throws() {
        AuctionCaseDTO dto = validDto();
        dto.setStage("Bogus Stage");
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_missingNoticeDate_throws() {
        AuctionCaseDTO dto = validDto();
        dto.setNoticeDate(null);
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.create(dto))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("noticeDate");
    }

    @Test
    void create_negative_noticeDueDateBeforeNoticeDate_throws() {
        AuctionCaseDTO dto = validDto();
        dto.setNoticeDueDate(LocalDate.of(2025, 12, 31));
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_nonPositiveDemandAmount_throws() {
        AuctionCaseDTO dto = validDto();
        dto.setDemandAmount(BigDecimal.ZERO);
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_nonPositiveReservePrice_throws() {
        AuctionCaseDTO dto = validDto();
        dto.setReservePrice(BigDecimal.valueOf(-1));
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_possessionDateBeforeNoticeDueDate_throws() {
        AuctionCaseDTO dto = validDto();
        dto.setPossessionDate(LocalDate.of(2026, 1, 1));
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_negative_auctionDateBeforePossessionDate_throws() {
        AuctionCaseDTO dto = validDto();
        dto.setAuctionDate(LocalDate.of(2026, 1, 5));
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.create(dto)).isInstanceOf(ValidationException.class);
    }

    @Test
    void create_edge_nullPossessionAndAuctionDatesSkipCheck() {
        AuctionCaseDTO dto = validDto();
        dto.setPossessionDate(null);
        dto.setAuctionDate(null);
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.empty());
        when(repository.save(any(AuctionCase.class))).thenAnswer(inv -> inv.getArgument(0));

        AuctionCaseDTO result = service.create(dto);

        assertThat(result.getPossessionDate()).isNull();
        assertThat(result.getAuctionDate()).isNull();
    }

    // ---------- update() ----------

    @Test
    void update_positive_updatesExisting() {
        AuctionCaseDTO dto = validDto();
        AuctionCase existing = entityFrom(dto, 1L);
        when(repository.findByAuctionIdAndDeletedAtIsNull(1L)).thenReturn(Optional.of(existing));
        when(repository.save(any(AuctionCase.class))).thenAnswer(inv -> inv.getArgument(0));

        AuctionCaseDTO result = service.update(1L, dto);

        assertThat(result.getAuctionId()).isEqualTo(1L);
        assertThat(result.getAppId()).isEqualTo("APP-1");
    }

    @Test
    void update_edge_keepsExistingAppIdWhenDtoAppIdNull() {
        AuctionCaseDTO existingDto = validDto();
        AuctionCase existing = entityFrom(existingDto, 1L);
        when(repository.findByAuctionIdAndDeletedAtIsNull(1L)).thenReturn(Optional.of(existing));
        when(repository.save(any(AuctionCase.class))).thenAnswer(inv -> inv.getArgument(0));

        AuctionCaseDTO updateDto = validDto();
        updateDto.setAppId(null);

        AuctionCaseDTO result = service.update(1L, updateDto);

        assertThat(result.getAppId()).isEqualTo("APP-1");
    }

    @Test
    void update_negative_notFound_throwsResourceNotFound() {
        when(repository.findByAuctionIdAndDeletedAtIsNull(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.update(99L, validDto()))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    // ---------- softDelete() / restore() ----------

    @Test
    void softDelete_positive_returnsTrueAndSetsDeletedAt() {
        AuctionCase existing = entityFrom(validDto(), 1L);
        when(repository.findByAuctionIdAndDeletedAtIsNull(1L)).thenReturn(Optional.of(existing));

        boolean result = service.softDelete(1L);

        assertThat(result).isTrue();
        assertThat(existing.getDeletedAt()).isNotNull();
        verify(repository).save(existing);
    }

    @Test
    void softDelete_negative_notFound_returnsFalse() {
        when(repository.findByAuctionIdAndDeletedAtIsNull(404L)).thenReturn(Optional.empty());

        assertThat(service.softDelete(404L)).isFalse();
        verify(repository, never()).save(any());
    }

    @Test
    void restore_positive_returnsTrueAndClearsDeletedAt() {
        AuctionCase existing = entityFrom(validDto(), 1L);
        existing.setDeletedAt(OffsetDateTime.now());
        when(repository.findById(1L)).thenReturn(Optional.of(existing));

        boolean result = service.restore(1L);

        assertThat(result).isTrue();
        assertThat(existing.getDeletedAt()).isNull();
    }

    @Test
    void restore_negative_notFound_returnsFalse() {
        when(repository.findById(404L)).thenReturn(Optional.empty());

        assertThat(service.restore(404L)).isFalse();
    }

    @Test
    void restore_edge_alreadyActive_returnsFalse() {
        AuctionCase existing = entityFrom(validDto(), 1L);
        existing.setDeletedAt(null);
        when(repository.findById(1L)).thenReturn(Optional.of(existing));

        assertThat(service.restore(1L)).isFalse();
        verify(repository, never()).save(any());
    }

    // ---------- findById() / findByAppId() / findAll() ----------

    @Test
    void findById_positive_returnsDto() {
        AuctionCase existing = entityFrom(validDto(), 1L);
        when(repository.findByAuctionIdAndDeletedAtIsNull(1L)).thenReturn(Optional.of(existing));

        AuctionCaseDTO result = service.findById(1L);

        assertThat(result).isNotNull();
        assertThat(result.getAuctionId()).isEqualTo(1L);
    }

    @Test
    void findById_negative_notFound_returnsNull() {
        when(repository.findByAuctionIdAndDeletedAtIsNull(404L)).thenReturn(Optional.empty());

        assertThat(service.findById(404L)).isNull();
    }

    @Test
    void findByAppId_positive_returnsDto() {
        AuctionCase existing = entityFrom(validDto(), 1L);
        when(repository.findByAppIdAndDeletedAtIsNull("APP-1")).thenReturn(Optional.of(existing));

        assertThat(service.findByAppId("APP-1")).isNotNull();
    }

    @Test
    void findByAppId_negative_missingAppId_throws() {
        assertThatThrownBy(() -> service.findByAppId(null)).isInstanceOf(ValidationException.class);
        verifyNoInteractions(repository);
    }

    @Test
    void findAll_edge_emptyList() {
        when(repository.findByDeletedAtIsNull()).thenReturn(List.of());

        assertThat(service.findAll()).isEmpty();
    }

    @Test
    void findAll_positive_mapsAllEntities() {
        AuctionCase e1 = entityFrom(validDto(), 1L);
        AuctionCaseDTO dto2 = validDto();
        dto2.setAppId("APP-2");
        AuctionCase e2 = entityFrom(dto2, 2L);
        when(repository.findByDeletedAtIsNull()).thenReturn(List.of(e1, e2));

        List<AuctionCaseDTO> result = service.findAll();

        assertThat(result).hasSize(2);
        assertThat(result).extracting(AuctionCaseDTO::getAppId).containsExactlyInAnyOrder("APP-1", "APP-2");
    }
}
