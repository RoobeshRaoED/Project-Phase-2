package com.hlms.UserServices.security;

import com.hlms.UserServices.Entity.appUserEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

/** Adapts appUserEntity to Spring Security's UserDetails, mapping role -> ROLE_<ROLE>. */
public class UserPrincipal implements UserDetails {

    private final appUserEntity user;

    public UserPrincipal(appUserEntity user) {
        this.user = user;
    }

    public appUserEntity getAppUser() {
        return user;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority("ROLE_" + user.getRole().name()));
    }

    @Override
    public String getPassword() {
        return user.getPasswordHash();
    }

    @Override
    public String getUsername() {
        return user.getEmail();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return Boolean.TRUE.equals(user.getActive()) && user.getDeletedAt() == null;
    }
}
