package com.tcs.hlms.serviceImplementation;

import com.tcs.hlms.exceptions.ResourceNotFoundException;
import com.tcs.hlms.entity.AuditLogEntity;
import com.tcs.hlms.repository.AuditLogRepository;
import com.tcs.hlms.service.AuditLogService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuditLogServiceImpl
        implements AuditLogService {

    private final AuditLogRepository auditLogRepository;

    public AuditLogServiceImpl(
            AuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    @Override
    public AuditLogEntity saveAuditLog(
            AuditLogEntity auditLog) {

        return auditLogRepository.save(auditLog);
    }

    @Override
    public AuditLogEntity getAuditLogById(
            Long logId) {

        return auditLogRepository.findById(logId)
        		.orElseThrow(() ->
        	    new ResourceNotFoundException(
        	        "Audit Log not found : "
        	                + logId));
    }

    @Override
    public List<AuditLogEntity> getAllAuditLogs() {
        return auditLogRepository.findAll();
    }

    @Override
    public void deleteAuditLog(Long logId) {
        auditLogRepository.deleteById(logId);
    }
}