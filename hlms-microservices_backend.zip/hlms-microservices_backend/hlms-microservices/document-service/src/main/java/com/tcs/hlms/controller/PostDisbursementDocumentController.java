package com.tcs.hlms.controller;

import com.tcs.hlms.entity.PostDisbursementDocumentEntity;
import com.tcs.hlms.service.PostDisbursementDocumentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/post-disbursement-documents")
public class PostDisbursementDocumentController {

    private final PostDisbursementDocumentService service;

    public PostDisbursementDocumentController(
            PostDisbursementDocumentService service) {
        this.service = service;
    }

    @PostMapping
    public PostDisbursementDocumentEntity saveDocument(
            @RequestBody PostDisbursementDocumentEntity document) {

        return service.saveDocument(document);
    }

    @GetMapping("/{documentId}")
    public PostDisbursementDocumentEntity getDocumentById(
            @PathVariable String documentId) {

        return service.getDocumentById(documentId);
    }

    @GetMapping("/app/{appId}")
    public List<PostDisbursementDocumentEntity> getDocumentsByAppId(
            @PathVariable String appId) {

        return service.getDocumentsByAppId(appId);
    }

    @GetMapping
    public List<PostDisbursementDocumentEntity> getAllDocuments() {

        return service.getAllDocuments();
    }

    @DeleteMapping("/{documentId}")
    public String deleteDocument(
            @PathVariable String documentId) {

        service.deleteDocument(documentId);
        return "Document deleted successfully";
    }
}