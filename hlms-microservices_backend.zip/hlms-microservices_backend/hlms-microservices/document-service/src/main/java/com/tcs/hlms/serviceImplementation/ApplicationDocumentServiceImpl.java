package com.tcs.hlms.serviceImplementation;
import com.tcs.hlms.exceptions.ResourceNotFoundException;
import com.tcs.hlms.entity.ApplicationDocumentEntity;
import com.tcs.hlms.repository.ApplicationDocumentRepository;
import com.tcs.hlms.service.ApplicationDocumentService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ApplicationDocumentServiceImpl
        implements ApplicationDocumentService {

    private final ApplicationDocumentRepository repository;

    public ApplicationDocumentServiceImpl(
            ApplicationDocumentRepository repository) {
        this.repository = repository;
    }

    @Override
    public ApplicationDocumentEntity saveDocument(
            ApplicationDocumentEntity document) {

        return repository.save(document);
    }

    @Override
    public ApplicationDocumentEntity getDocumentById(
            String documentId) {

        return repository.findById(documentId)
        		.orElseThrow(() ->
        	    new ResourceNotFoundException(
        	        "Application Document not found : "
        	                + documentId));
    }

    @Override
    public List<ApplicationDocumentEntity> getDocumentsByAppId(
            String appId) {

        return repository.findByAppId(appId);
    }

    @Override
    public List<ApplicationDocumentEntity> getAllDocuments() {
        return repository.findAll();
    }

    @Override
    public void deleteDocument(String documentId) {
        repository.deleteById(documentId);
    }
}