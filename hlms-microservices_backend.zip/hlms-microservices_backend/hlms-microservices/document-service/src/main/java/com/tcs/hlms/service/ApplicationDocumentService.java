package com.tcs.hlms.service;

import com.tcs.hlms.entity.ApplicationDocumentEntity;

import java.util.List;

public interface ApplicationDocumentService {

    ApplicationDocumentEntity saveDocument(
            ApplicationDocumentEntity document);

    ApplicationDocumentEntity getDocumentById(
            String documentId);

    List<ApplicationDocumentEntity> getDocumentsByAppId(
            String appId);

    List<ApplicationDocumentEntity> getAllDocuments();

    void deleteDocument(String documentId);
}