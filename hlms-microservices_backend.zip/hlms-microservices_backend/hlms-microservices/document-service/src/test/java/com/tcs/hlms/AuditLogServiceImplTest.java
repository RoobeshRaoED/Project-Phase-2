package com.tcs.hlms;

import com.tcs.hlms.entity.AuditLogEntity;
import com.tcs.hlms.exceptions.ResourceNotFoundException;
import com.tcs.hlms.repository.AuditLogRepository;
import com.tcs.hlms.serviceImplementation.AuditLogServiceImpl;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuditLogServiceImplTest {

    @Mock
    private AuditLogRepository repository;

    @InjectMocks
    private AuditLogServiceImpl service;

    @Test
    void saveAuditLog_Success() {

        AuditLogEntity log = new AuditLogEntity();

        when(repository.save(log))
                .thenReturn(log);

        assertNotNull(service.saveAuditLog(log));
    }

    @Test
    void getAuditLogById_Success() {

        AuditLogEntity log = new AuditLogEntity();

        when(repository.findById(1L))
                .thenReturn(Optional.of(log));

        assertNotNull(service.getAuditLogById(1L));
    }

    @Test
    void getAuditLogById_NotFound() {

        when(repository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(
                ResourceNotFoundException.class,
                () -> service.getAuditLogById(1L));
    }

    @Test
    void getAllAuditLogs_Success() {

        when(repository.findAll())
                .thenReturn(List.of(new AuditLogEntity()));

        assertEquals(
                1,
                service.getAllAuditLogs().size());
    }

    @Test
    void getAllAuditLogs_Empty() {

        when(repository.findAll())
                .thenReturn(Collections.emptyList());

        assertTrue(
                service.getAllAuditLogs().isEmpty());
    }

    @Test
    void deleteAuditLog_Success() {

        doNothing()
                .when(repository)
                .deleteById(1L);

        service.deleteAuditLog(1L);

        verify(repository)
                .deleteById(1L);
    }

    @Test
    void saveAuditLog_NullEntity() {

        when(repository.save(null))
                .thenReturn(null);

        assertNull(
                service.saveAuditLog(null));
    }
    @Test
    void saveAuditLog_NullObject() {

        when(repository.save(null))
                .thenReturn(null);

        assertNull(
                service.saveAuditLog(null));
    }
    @Test
    void deleteAuditLog_VerifyInvocation() {

        service.deleteAuditLog(1L);

        verify(repository)
                .deleteById(1L);
    }
    @Test
    void getAllAuditLogs_MultipleRecords() {

        List<AuditLogEntity> list =
                Arrays.asList(
                        new AuditLogEntity(),
                        new AuditLogEntity());

        when(repository.findAll())
                .thenReturn(list);

        assertEquals(
                2,
                service.getAllAuditLogs().size());
    }
    
}
