import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { environment } from '../../../../environments/environment';

/**
 * INTEGRATION NOTE: not registered in app.config.ts — the module-wide
 * hlmsAuthInterceptor (core/interceptors/hlms-auth.interceptor.ts) already
 * attaches whichever role's token is present (via TOKEN_KEYS, which includes
 * 'hlms_bidder_token') and handles 401s for every portal. This file is kept,
 * unregistered, purely as the original source reference — same treatment as
 * legal/core/interceptors/auth.interceptor.ts.
 *
 * Attaches "Authorization: Bearer <jwt>" to every request that targets the
 * HLMS API gateway (every backend endpoint requires this except
 * /user-service/api/users/login|register|forgot-password|reset-password).
 * On a 401 the session is treated as invalid and the user is sent back to /login.
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  const token = auth.getToken();
  const isApiCall = req.url.startsWith(environment.apiBase);
  const authedReq = (isApiCall && token)
    ? req.clone({ setHeaders: { Authorization: `Bearer ${token}` } })
    : req;

  return next(authedReq).pipe(
    catchError((err) => {
      if (isApiCall && err?.status === 401) {
        auth.logout();
        router.navigate(['/login']);
      }
      return throwError(() => err);
    })
  );
};
