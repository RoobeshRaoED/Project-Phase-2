// INTEGRATION LAYER — ported from the standalone hlms-bidder-ui project.
// Mirrors the backend DTOs/entities exactly, matching the shape already
// used by the legal/customer/bankoffice modules so JSON from the gateway
// deserializes straight into these interfaces with no mapping.

export interface AppUser {
  email: string;
  name: string;
  mobile: string;
  role: string; // CUSTOMER | LEGAL | BANK_OFFICER | BIDDER | ADMIN
  active: boolean;
  idType?: string;
  idNumber?: string;
  prefSms?: boolean;
  prefEmail?: boolean;
  prefInapp?: boolean;
  createdAt?: string;
}

export interface RegisterRequest {
  email: string;
  name: string;
  mobile: string;
  password: string;
  role: string;
  idType?: string;
  idNumber?: string;
}

/** Property-relevant subset of loan-service's LoanApplication entity. */
export interface LoanApplication {
  appId: string;
  trackingNo: string;
  userEmail: string;
  status: string;
  applicantName?: string;
  propertyAddress?: string;
  propertyType?: string;
  propertyValue?: number;
}

export interface AuctionCaseDTO {
  auctionId?: number | null;
  appId: string;
  stage: string; // None | Notice Issued | Possession | Auction Scheduled | Resolved
  noticeDate?: string | null;
  noticeDueDate?: string | null;
  demandAmount?: number | null;
  possessionDate?: string | null;
  auctionDate?: string | null;
  reservePrice?: number | null;
}

export interface BidDTO {
  bidId?: string | null;
  appId: string;
  bidderEmail: string;
  bidAmount: number;
  createdAt?: string;
}

/** A listing as shown in the Bidder Portal: an auction joined client-side
 *  with the property fields of its parent LoanApplication. */
export interface AuctionListing {
  auction: AuctionCaseDTO;
  propertyAddress: string;
  propertyType: string;
  propertyValue: number | null;
  trackingNo: string;
}
