// INTEGRATION LAYER — ported from the standalone hlms-bidder-ui project's
// core/services/loan.service.ts. Read-only access to loan-service, used only
// to join property details (address / type / value) onto an auction listing
// -- AuctionCaseDTO itself only carries appId. The bidder portal never
// requests borrower financial or personal fields.

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from '../../../../environments/environment';
import { LoanApplication } from '../models/models';

@Injectable({ providedIn: 'root' })
export class LoanService {
  private readonly base = `${environment.apiBase}/loan-service/api/loan-applications`;

  constructor(private http: HttpClient) {}

  getApplication(appId: string): Observable<LoanApplication> {
    return this.http.get<LoanApplication>(`${this.base}/${appId}`);
  }
}
