// INTEGRATION LAYER — ported from the standalone hlms-bidder-ui project's
// core/services/auth.service.ts. Adjusted to this app's conventions the same
// way legal/core/services/auth.service.ts was: environment.apiBase instead of
// apiGatewayUrl, and clearHlmsSession() added to logout() so signing out here
// also ends the session for every other portal (see core/session/session-keys.ts).

import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, catchError, of, switchMap, tap, throwError } from 'rxjs';

import { environment } from '../../../../environments/environment';
import { AppUser, RegisterRequest } from '../models/models';
import { clearHlmsSession } from '../../../core/session/session-keys';

interface LoginResponse { token: string; }
interface JwtPayload { sub: string; role: string; iat: number; exp: number; }

const TOKEN_KEY = 'hlms_bidder_token';

/**
 * Authenticates against user-service (shared by every HLMS role) and enforces
 * that only accounts with role === 'BIDDER' may use this portal.
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  currentUser = signal<AppUser | null>(null);
  authReady = signal(false);

  private get base(): string {
    return `${environment.apiBase}/user-service/api/users`;
  }

  constructor(private http: HttpClient, private router: Router) {}

  register(req: RegisterRequest): Observable<AppUser> {
    return this.http.post<AppUser>(`${this.base}/register`, { ...req, role: 'BIDDER' });
  }

  login(email: string, password: string): Observable<AppUser> {
    return this.http.post<LoginResponse>(`${this.base}/login`, { email, password }).pipe(
      switchMap((res) => {
        const payload = this.decodeToken(res.token);
        if (!payload) {
          return throwError(() => new Error('Received an invalid token from the server.'));
        }
        if ((payload.role || '').toUpperCase() !== 'BIDDER') {
          return throwError(() => new Error(
            `This portal is only for registered bidders. Your account role is "${payload.role}".`
          ));
        }
        localStorage.setItem(TOKEN_KEY, res.token);
        return this.http.get<AppUser>(`${this.base}/${encodeURIComponent(payload.sub)}`);
      }),
      tap((user) => this.currentUser.set(user)),
      catchError((err) => {
        localStorage.removeItem(TOKEN_KEY);
        return throwError(() => err);
      })
    );
  }

  /** Restores the session from a stored token on app bootstrap. */
  restoreSession(): Observable<AppUser | null> {
    const token = this.getToken();
    if (!token) {
      this.authReady.set(true);
      return of(null);
    }
    const payload = this.decodeToken(token);
    if (!payload || this.isExpired(payload) || (payload.role || '').toUpperCase() !== 'BIDDER') {
      this.clearSession();
      this.authReady.set(true);
      return of(null);
    }
    return this.http.get<AppUser>(`${this.base}/${encodeURIComponent(payload.sub)}`).pipe(
      tap((user) => {
        this.currentUser.set(user);
        this.authReady.set(true);
      }),
      catchError(() => {
        this.clearSession();
        this.authReady.set(true);
        return of(null);
      })
    );
  }

  refreshCurrentUser(): void {
    const u = this.currentUser();
    if (!u) return;
    this.http.get<AppUser>(`${this.base}/${encodeURIComponent(u.email)}`).subscribe({
      next: (fresh) => this.currentUser.set(fresh)
    });
  }

  updateProfile(patch: Partial<AppUser> & { password?: string }): Observable<AppUser> {
    const user = this.currentUser();
    if (!user) return throwError(() => new Error('Not logged in.'));
    return this.http
      .put<AppUser>(`${this.base}/${encodeURIComponent(user.email)}`, { ...user, ...patch })
      .pipe(tap((fresh) => this.currentUser.set(fresh)));
  }

  logout(): void {
    // INTEGRATION CHANGE: also clear the other modules' session keys, otherwise
    // signing out here would leave the other portals still reachable.
    clearHlmsSession();
    this.clearSession();
    this.router.navigate(['/login']);
  }

  clearSession(): void {
    localStorage.removeItem(TOKEN_KEY);
    this.currentUser.set(null);
  }

  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  isLoggedIn(): boolean {
    const token = this.getToken();
    if (!token) return false;
    const payload = this.decodeToken(token);
    return !!payload && !this.isExpired(payload) && (payload.role || '').toUpperCase() === 'BIDDER';
  }

  private isExpired(payload: JwtPayload): boolean {
    return !payload.exp || Date.now() >= payload.exp * 1000;
  }

  private decodeToken(token: string): JwtPayload | null {
    try {
      const parts = token.split('.');
      if (parts.length !== 3) return null;
      const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
      const json = decodeURIComponent(
        atob(base64)
          .split('')
          .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
          .join('')
      );
      return JSON.parse(json);
    } catch {
      return null;
    }
  }
}
