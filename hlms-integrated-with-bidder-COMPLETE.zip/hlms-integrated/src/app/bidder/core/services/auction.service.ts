// INTEGRATION LAYER — ported from the standalone hlms-bidder-ui project's
// core/services/auction.service.ts. Talks to repayment-service's
// AuctionCaseController / BidController — the same service the Legal &
// Valuation and Bank Office portals use to manage auctions (see
// legal/core/services/auction.service.ts), kept here to the exact same
// request/response shapes and environment.apiBase convention.

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';

import { environment } from '../../../../environments/environment';
import { AuctionCaseDTO, BidDTO } from '../models/models';

@Injectable({ providedIn: 'root' })
export class AuctionService {
  private readonly auctions = `${environment.apiBase}/repayment-service/api/auctions`;
  private readonly bidsUrl = `${environment.apiBase}/repayment-service/api/bids`;

  constructor(private http: HttpClient) {}

  listAll(): Observable<AuctionCaseDTO[]> {
    return this.http.get<AuctionCaseDTO[]>(this.auctions);
  }

  getById(auctionId: number): Observable<AuctionCaseDTO> {
    return this.http.get<AuctionCaseDTO>(`${this.auctions}/${auctionId}`);
  }

  getByApplication(appId: string): Observable<AuctionCaseDTO> {
    return this.http.get<AuctionCaseDTO>(`${this.auctions}/by-application/${appId}`);
  }

  getBids(appId: string): Observable<BidDTO[]> {
    return this.http.get<BidDTO[]>(`${this.auctions}/${appId}/bids`).pipe(
      map((bids) => bids.slice().sort((a, b) => b.bidAmount - a.bidAmount))
    );
  }

  placeBid(appId: string, bidderEmail: string, bidAmount: number): Observable<BidDTO> {
    return this.http.post<BidDTO>(`${this.auctions}/${appId}/bids`, { appId, bidderEmail, bidAmount });
  }

  /**
   * GET /repayment-service/api/bids returns every bid across every auction —
   * BidController has no "?bidderEmail=" filter, so "My Bids" is filtered
   * client-side. See MISSING_APIS_AND_NOTES.md.
   */
  getMyBids(bidderEmail: string): Observable<BidDTO[]> {
    return this.http.get<BidDTO[]>(this.bidsUrl).pipe(
      map((all) => all
        .filter((b) => b.bidderEmail === bidderEmail)
        .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || '')))
    );
  }

  /** True while the auction is still accepting bids. */
  isOpen(auction: AuctionCaseDTO): boolean {
    if (!auction.auctionDate) return false;
    return new Date(auction.auctionDate).getTime() > Date.now();
  }

  /**
   * Minimum amount a bidder is allowed to place next, per the rules ported
   * from the original static demo (integration-2.js):
   *   - No bids yet -> the reserve price.
   *   - Otherwise -> highest bid + max(₹5,000, 1% of reserve price rounded
   *     to the nearest ₹1,000).
   *
   * NOTE: this is a client-side-only rule — the backend does not enforce a
   * minimum increment. See MISSING_APIS_AND_NOTES.md.
   */
  minNextBid(auction: AuctionCaseDTO, bids: BidDTO[]): number {
    const reserve = auction.reservePrice || 0;
    if (!bids.length) return reserve;
    const highest = bids[0].bidAmount;
    const onePercent = Math.round((reserve * 0.01) / 1000) * 1000;
    const increment = Math.max(5000, onePercent);
    return highest + increment;
  }
}
