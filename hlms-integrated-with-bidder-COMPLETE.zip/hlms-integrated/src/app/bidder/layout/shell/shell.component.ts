// INTEGRATION LAYER — ported from the standalone hlms-bidder-ui project's
// features/bidder/layout/shell.component.ts, unchanged apart from the
// AuthService import path. Kept as a single file with an inline template,
// same as the original (a straight port, not a rewrite).

import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterOutlet, NavigationEnd } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

interface NavItem { path: string; ic: string; label: string; }

@Component({
  selector: 'app-bidder-shell',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink],
  template: `
    <div id="app">
      <div class="topbar">
        <button class="hamburger" (click)="toggleSidebar()">☰</button>
        <div class="brand">
          <div class="logo"><img src="assets/logo-icon.png" width="34" style="border-radius:8px;"></div>
          <div>
            <div class="title">HLMS</div>
            <div class="subtitle">Bidder Portal</div>
          </div>
        </div>
        <div class="topbar-right">
          <div class="user-chip" [routerLink]="['/bidder/settings']">
            <div class="user-avatar">{{ initials() }}</div>
            <div class="user-name">{{ auth.currentUser()?.name || 'Bidder' }}</div>
          </div>
        </div>
      </div>

      <div class="sidebar" [class.open]="sidebarOpen()">
        @for (item of navItems; track item.path) {
          <button class="nav-item" [class.active]="activePath() === item.path" [routerLink]="['/bidder/' + item.path]">
            <span class="ic">{{ item.ic }}</span>{{ item.label }}
          </button>
        }
        <button class="nav-item" (click)="logout()" style="margin-top:14px;border-top:1px solid var(--border);padding-top:16px;color:var(--red);">
          <span class="ic" style="color:var(--red);">⏻</span>Log Out
        </button>
      </div>

      <div class="main">
        <router-outlet></router-outlet>
      </div>
      <footer class="app-footer">HLMS — Bidder Portal · Connected to HLMS Microservices Backend</footer>
    </div>
  `
})
export class ShellComponent {
  sidebarOpen = signal(false);
  activePath = signal('dashboard');

  navItems: NavItem[] = [
    { path: 'dashboard', ic: '▦', label: 'Dashboard' },
    { path: 'listings', ic: '☆', label: 'Auction Listings' },
    { path: 'my-bids', ic: '☑', label: 'My Bids' },
    { path: 'settings', ic: '◍', label: 'Settings' }
  ];

  constructor(public auth: AuthService, private router: Router) {
    this.router.events.subscribe((e) => {
      if (e instanceof NavigationEnd) {
        const seg = this.router.url.split('/').filter(Boolean)[1] || 'dashboard';
        this.activePath.set(seg);
        this.sidebarOpen.set(false);
      }
    });
  }

  initials(): string {
    const name = this.auth.currentUser()?.name || '';
    return name.split(' ').filter(Boolean).map((p) => p[0]).slice(0, 2).join('').toUpperCase() || 'BD';
  }

  toggleSidebar(): void { this.sidebarOpen.update((v) => !v); }

  logout(): void { this.auth.logout(); }
}
