// INTEGRATION LAYER — ported from the standalone hlms-bidder-ui project's
// features/bidder/dashboard/dashboard.component.ts. Only the model type
// names (AuctionCase -> AuctionCaseDTO, Bid -> BidDTO, matching the shared
// models.ts naming already used by legal/customer) and import paths changed.

import { Component, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { forkJoin, of } from 'rxjs';
import { AuthService } from '../../core/services/auth.service';
import { AuctionService } from '../../core/services/auction.service';
import { ToastService } from '../../core/services/toast.service';
import { AuctionCaseDTO, BidDTO } from '../../core/models/models';

@Component({
  selector: 'app-bidder-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page-head">
      <h1>Welcome, {{ auth.currentUser()?.name || 'Bidder' }}</h1>
      <p>Here's a snapshot of the auction marketplace.</p>
    </div>

    @if (loading()) {
      <div class="page-loading"><span class="spinner dark"></span> Loading dashboard…</div>
    } @else {
      <div class="grid grid-4">
        <div class="card stat">
          <span class="lbl">Open Listings</span>
          <span class="val teal">{{ openCount() }}</span>
        </div>
        <div class="card stat">
          <span class="lbl">Closed Listings</span>
          <span class="val">{{ closedCount() }}</span>
        </div>
        <div class="card stat">
          <span class="lbl">My Total Bids</span>
          <span class="val green">{{ myBids().length }}</span>
        </div>
        <div class="card stat">
          <span class="lbl">Properties I've Bid On</span>
          <span class="val orange">{{ myAppsCount() }}</span>
        </div>
      </div>

      <div class="grid grid-2" style="margin-top:20px;">
        <div class="card">
          <h3>Open Auctions</h3>
          @if (openAuctions().length === 0) {
            <div class="empty-state"><div class="ic">☆</div>No auctions currently open for bidding.</div>
          } @else {
            <div class="quick-links" style="height:auto;max-height:none;">
              @for (a of openAuctions().slice(0, 5); track a.auctionId) {
                <a class="router-link" [routerLink]="['/bidder/listings', a.appId]">
                  <span>{{ a.appId }} — Reserve ₹{{ a.reservePrice | number }}</span>
                  <span class="arrow">→</span>
                </a>
              }
            </div>
          }
          <div style="margin-top:14px;">
            <a routerLink="/bidder/listings" class="btn btn-primary btn-sm">View All Listings</a>
          </div>
        </div>

        <div class="card">
          <h3>My Recent Bids</h3>
          @if (myBids().length === 0) {
            <div class="empty-state"><div class="ic">☑</div>You haven't placed any bids yet.</div>
          } @else {
            <table>
              <thead><tr><th>Application</th><th>Amount</th></tr></thead>
              <tbody>
                @for (b of myBids().slice(0, 5); track b.bidId) {
                  <tr class="clickable-row" [routerLink]="['/bidder/listings', b.appId]">
                    <td>{{ b.appId }}</td>
                    <td>₹{{ b.bidAmount | number }}</td>
                  </tr>
                }
              </tbody>
            </table>
          }
          <div style="margin-top:14px;">
            <a routerLink="/bidder/my-bids" class="btn btn-outline btn-sm">View All My Bids</a>
          </div>
        </div>
      </div>
    }
  `
})
export class DashboardComponent implements OnInit {
  loading = signal(true);
  auctions = signal<AuctionCaseDTO[]>([]);
  myBids = signal<BidDTO[]>([]);

  openAuctions = computed(() => this.auctions().filter((a) => this.auctionSvc.isOpen(a)));
  openCount = computed(() => this.openAuctions().length);
  closedCount = computed(() => this.auctions().length - this.openCount());
  myAppsCount = computed(() => new Set(this.myBids().map((b) => b.appId)).size);

  constructor(public auth: AuthService, private auctionSvc: AuctionService, private toast: ToastService) {}

  ngOnInit(): void {
    const email = this.auth.currentUser()?.email;
    forkJoin({
      auctions: this.auctionSvc.listAll(),
      myBids: email ? this.auctionSvc.getMyBids(email) : of([] as BidDTO[])
    }).subscribe({
      next: (res) => {
        this.auctions.set(res.auctions || []);
        this.myBids.set(res.myBids || []);
        this.loading.set(false);
      },
      error: () => {
        this.loading.set(false);
        this.toast.error('Could not load dashboard', 'Please check your connection and try again.');
      }
    });
  }
}
