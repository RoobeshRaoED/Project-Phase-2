// INTEGRATION LAYER — ported from the standalone hlms-bidder-ui project's
// features/auth/login.component.ts. Retained (as customer/legal's own
// login pages were) even though the shared /login page from the auth
// module is the primary entry point. routerLinks to '/register' and '/'
// are left pointing at the shared auth module pages, unchanged from the
// original — same treatment customer/features/auth/login/login.ts got.

import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div id="authScreen">
      <div class="auth-wrap">
        <div class="auth-side">
          <img class="auth-image" src="assets/logo-hero.png" alt="HLMS">
        </div>
        <div class="auth-form">
          <h2>Welcome back</h2>
          <p class="sub">Log in to your HLMS Bidder account</p>

          @if (error()) { <div class="banner-error">{{ error() }}</div> }

          <div class="field">
            <label>Email</label>
            <input type="email" [(ngModel)]="email" placeholder="you&#64;example.com" (keyup.enter)="submit()">
          </div>
          <div class="field">
            <label>Password</label>
            <div class="password-wrap">
              <input [type]="showPw() ? 'text' : 'password'" [(ngModel)]="password" placeholder="Your password" (keyup.enter)="submit()">
              <span class="password-toggle" (click)="showPw.set(!showPw())">{{ showPw() ? '🙈' : '👁' }}</span>
            </div>
          </div>

          <button class="btn btn-primary btn-block" [disabled]="loading()" (click)="submit()">
            @if (loading()) { <span class="spinner"></span> } Log In
          </button>

          <div class="auth-switch">
            Not registered yet? <a routerLink="/register">Create a bidder account</a>
          </div>
          <div class="auth-switch"><a routerLink="/">← Back to home</a></div>
        </div>
      </div>
    </div>
  `
})
export class LoginComponent {
  email = '';
  password = '';
  loading = signal(false);
  showPw = signal(false);
  error = signal<string | null>(null);

  constructor(private auth: AuthService, private router: Router, private toast: ToastService) {}

  submit(): void {
    this.error.set(null);
    if (!this.email || !this.password) {
      this.error.set('Please enter your email and password.');
      return;
    }
    this.loading.set(true);
    this.auth.login(this.email, this.password).subscribe({
      next: () => {
        this.loading.set(false);
        this.toast.success('Welcome back!');
        this.router.navigate(['/bidder/dashboard']);
      },
      error: (err) => {
        this.loading.set(false);
        this.error.set(err?.error?.message || err?.message || 'Login failed. Please check your credentials.');
      }
    });
  }
}
