// INTEGRATION LAYER — ported from the standalone hlms-bidder-ui project's
// features/bidder/settings/settings.component.ts, unchanged apart from
// import paths.

import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';

@Component({
  selector: 'app-bidder-settings',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-head"><h1>Settings</h1></div>

    <div class="grid grid-2">
      <div class="card">
        <div style="display:flex;align-items:center;gap:14px;margin-bottom:18px;">
          <div class="user-avatar" style="width:56px;height:56px;font-size:20px;">{{ initials() }}</div>
          <div>
            <div style="font-weight:800;font-size:16px;">{{ auth.currentUser()?.name }}</div>
            <div style="color:var(--text-gray);font-size:13px;">{{ auth.currentUser()?.email }}</div>
            <span class="badge badge-navy" style="margin-top:4px;">Bidder</span>
          </div>
        </div>

        <div class="field">
          <label>Mobile Number</label>
          <input [(ngModel)]="mobileDraft" placeholder="10-digit mobile number">
        </div>
        <div class="field">
          <label>ID Type</label>
          <input [value]="auth.currentUser()?.idType || '—'" disabled>
        </div>
        <div class="field">
          <label>ID Number</label>
          <input [value]="auth.currentUser()?.idNumber || '—'" disabled>
        </div>

        <h3 style="margin-top:20px;">Notification Preferences</h3>
        <label style="display:flex;align-items:center;gap:8px;font-size:13.5px;margin-bottom:8px;">
          <input type="checkbox" [(ngModel)]="prefEmail"> Email notifications
        </label>
        <label style="display:flex;align-items:center;gap:8px;font-size:13.5px;margin-bottom:8px;">
          <input type="checkbox" [(ngModel)]="prefSms"> SMS notifications
        </label>
        <label style="display:flex;align-items:center;gap:8px;font-size:13.5px;margin-bottom:18px;">
          <input type="checkbox" [(ngModel)]="prefInapp"> In-app notifications
        </label>

        <button class="btn btn-primary" [disabled]="saving()" (click)="saveProfile()">
          {{ saving() ? 'Saving…' : 'Save Changes' }}
        </button>
        <button class="btn btn-outline" style="margin-left:10px;" (click)="auth.logout()">Log Out</button>
      </div>

      <div class="card">
        <h3>Change Password</h3>
        @if (pwError()) { <div class="banner-error">{{ pwError() }}</div> }
        <div class="field">
          <label>New Password</label>
          <input type="password" [(ngModel)]="newPassword" placeholder="New password">
        </div>
        <div class="field">
          <label>Confirm New Password</label>
          <input type="password" [(ngModel)]="confirmPassword" placeholder="Confirm new password">
        </div>
        <button class="btn btn-primary" [disabled]="savingPw()" (click)="changePassword()">
          {{ savingPw() ? 'Updating…' : 'Update Password' }}
        </button>
      </div>
    </div>
  `
})
export class SettingsComponent {
  mobileDraft = '';
  prefSms = true;
  prefEmail = true;
  prefInapp = true;
  saving = signal(false);

  newPassword = '';
  confirmPassword = '';
  savingPw = signal(false);
  pwError = signal<string | null>(null);

  constructor(public auth: AuthService, private toast: ToastService) {
    const u = this.auth.currentUser();
    this.mobileDraft = u?.mobile || '';
    this.prefSms = u?.prefSms ?? true;
    this.prefEmail = u?.prefEmail ?? true;
    this.prefInapp = u?.prefInapp ?? true;
  }

  initials(): string {
    const name = this.auth.currentUser()?.name || '';
    return name.split(' ').filter(Boolean).map((p) => p[0]).slice(0, 2).join('').toUpperCase() || 'BD';
  }

  saveProfile(): void {
    this.saving.set(true);
    this.auth
      .updateProfile({ mobile: this.mobileDraft, prefSms: this.prefSms, prefEmail: this.prefEmail, prefInapp: this.prefInapp })
      .subscribe({
        next: () => {
          this.saving.set(false);
          this.toast.success('Profile updated');
        },
        error: () => {
          this.saving.set(false);
          this.toast.error('Could not update profile', 'Please try again.');
        }
      });
  }

  changePassword(): void {
    this.pwError.set(null);
    if (!this.newPassword || this.newPassword.length < 6) {
      this.pwError.set('Password must be at least 6 characters.');
      return;
    }
    if (this.newPassword !== this.confirmPassword) {
      this.pwError.set('Passwords do not match.');
      return;
    }
    this.savingPw.set(true);
    this.auth.updateProfile({ password: this.newPassword }).subscribe({
      next: () => {
        this.savingPw.set(false);
        this.newPassword = '';
        this.confirmPassword = '';
        this.toast.success('Password updated');
      },
      error: () => {
        this.savingPw.set(false);
        this.pwError.set('Could not update password. Please try again.');
      }
    });
  }
}
