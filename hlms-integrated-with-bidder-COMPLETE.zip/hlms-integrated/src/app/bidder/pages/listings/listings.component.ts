// INTEGRATION LAYER — ported from the standalone hlms-bidder-ui project's
// features/bidder/listings/listings.component.ts. Only the model type name
// (AuctionListing, unchanged shape) and import paths changed.

import { Component, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { forkJoin, of, catchError } from 'rxjs';
import { AuctionService } from '../../core/services/auction.service';
import { LoanService } from '../../core/services/loan.service';
import { ToastService } from '../../core/services/toast.service';
import { AuctionListing } from '../../core/models/models';

@Component({
  selector: 'app-listings',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page-head">
      <h1>Auction Listings</h1>
      <p>Properties listed for e-auction by the Legal &amp; Valuation team.</p>
    </div>

    <div class="tabs">
      <button class="tab" [class.active]="tab() === 'open'" (click)="tab.set('open')">Open ({{ openListings().length }})</button>
      <button class="tab" [class.active]="tab() === 'closed'" (click)="tab.set('closed')">Closed ({{ closedListings().length }})</button>
    </div>

    @if (loading()) {
      <div class="page-loading"><span class="spinner dark"></span> Loading listings…</div>
    } @else {
      @if (visibleListings().length === 0) {
        <div class="card"><div class="empty-state"><div class="ic">☆</div>No {{ tab() }} listings right now.</div></div>
      } @else {
        <div class="grid grid-3">
          @for (l of visibleListings(); track l.auction.appId) {
            <div class="card product-card clickable-row" [routerLink]="['/bidder/listings', l.auction.appId]">
              <span class="tag">{{ l.propertyType || 'Property' }}</span>
              <h4>{{ l.propertyAddress || l.auction.appId }}</h4>
              <p>Tracking No: {{ l.trackingNo || '—' }}</p>
              <div class="stat">
                <span class="lbl">Reserve Price</span>
                <span class="val teal">₹{{ (l.auction.reservePrice || 0) | number }}</span>
              </div>
              @if (auctionSvc.isOpen(l.auction)) {
                <span class="badge badge-green">Open until {{ l.auction.auctionDate | date:'mediumDate' }}</span>
              } @else {
                <span class="badge badge-gray">Closed</span>
              }
            </div>
          }
        </div>
      }
    }
  `
})
export class ListingsComponent implements OnInit {
  loading = signal(true);
  tab = signal<'open' | 'closed'>('open');
  listings = signal<AuctionListing[]>([]);

  openListings = computed(() => this.listings().filter((l) => this.auctionSvc.isOpen(l.auction)));
  closedListings = computed(() => this.listings().filter((l) => !this.auctionSvc.isOpen(l.auction)));
  visibleListings = computed(() => (this.tab() === 'open' ? this.openListings() : this.closedListings()));

  constructor(public auctionSvc: AuctionService, private loanSvc: LoanService, private toast: ToastService) {}

  ngOnInit(): void {
    this.auctionSvc.listAll().subscribe({
      next: (auctions) => {
        const scheduled = auctions.filter((a) => a.auctionDate);
        if (!scheduled.length) {
          this.listings.set([]);
          this.loading.set(false);
          return;
        }
        forkJoin(
          scheduled.map((auction) =>
            this.loanSvc.getApplication(auction.appId).pipe(
              catchError(() => of(null))
            )
          )
        ).subscribe((apps) => {
          this.listings.set(
            scheduled.map((auction, i) => {
              const app = apps[i];
              return {
                auction,
                propertyAddress: app?.propertyAddress || '',
                propertyType: app?.propertyType || '',
                propertyValue: app?.propertyValue ?? null,
                trackingNo: app?.trackingNo || ''
              };
            })
          );
          this.loading.set(false);
        });
      },
      error: () => {
        this.loading.set(false);
        this.toast.error('Could not load listings', 'Please check your connection and try again.');
      }
    });
  }
}
