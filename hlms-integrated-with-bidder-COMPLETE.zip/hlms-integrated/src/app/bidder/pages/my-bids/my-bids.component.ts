// INTEGRATION LAYER — ported from the standalone hlms-bidder-ui project's
// features/bidder/my-bids/my-bids.component.ts. Only the model type names
// (Bid -> BidDTO, AuctionCase -> AuctionCaseDTO) and import paths changed.

import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { forkJoin, of, catchError } from 'rxjs';
import { AuthService } from '../../core/services/auth.service';
import { AuctionService } from '../../core/services/auction.service';
import { ToastService } from '../../core/services/toast.service';
import { BidDTO, AuctionCaseDTO } from '../../core/models/models';

interface MyBidRow {
  bid: BidDTO;
  auction: AuctionCaseDTO | null;
  isHighest: boolean;
}

@Component({
  selector: 'app-my-bids',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page-head">
      <h1>My Bids</h1>
      <p>Every bid you've placed, across all properties.</p>
    </div>

    @if (loading()) {
      <div class="page-loading"><span class="spinner dark"></span> Loading your bids…</div>
    } @else if (rows().length === 0) {
      <div class="card"><div class="empty-state"><div class="ic">☑</div>You haven't placed any bids yet.
        <div style="margin-top:14px;"><a routerLink="/bidder/listings" class="btn btn-primary btn-sm">Browse Listings</a></div>
      </div></div>
    } @else {
      <div class="card">
        <table>
          <thead><tr><th>Application</th><th>My Bid</th><th>Status</th><th>Placed</th><th></th></tr></thead>
          <tbody>
            @for (r of rows(); track r.bid.bidId) {
              <tr class="clickable-row" [routerLink]="['/bidder/listings', r.bid.appId]">
                <td>{{ r.bid.appId }}</td>
                <td>₹{{ r.bid.bidAmount | number }}</td>
                <td>
                  @if (!r.auction) {
                    <span class="badge badge-gray">Unknown</span>
                  } @else if (auctionSvc.isOpen(r.auction)) {
                    <span class="badge" [class.badge-green]="r.isHighest" [class.badge-orange]="!r.isHighest">
                      {{ r.isHighest ? 'Highest Bidder' : 'Outbid' }}
                    </span>
                  } @else {
                    <span class="badge" [class.badge-green]="r.isHighest" [class.badge-gray]="!r.isHighest">
                      {{ r.isHighest ? 'Won' : 'Closed — Not Won' }}
                    </span>
                  }
                </td>
                <td>{{ r.bid.createdAt ? (r.bid.createdAt | date:'short') : '—' }}</td>
                <td><span class="router-link" style="color:var(--teal);font-weight:700;">View →</span></td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    }
  `
})
export class MyBidsComponent implements OnInit {
  loading = signal(true);
  rows = signal<MyBidRow[]>([]);

  constructor(private auth: AuthService, public auctionSvc: AuctionService, private toast: ToastService) {}

  ngOnInit(): void {
    const email = this.auth.currentUser()?.email;
    if (!email) {
      this.loading.set(false);
      return;
    }
    this.auctionSvc.getMyBids(email).subscribe({
      next: (myBids) => {
        if (!myBids.length) {
          this.rows.set([]);
          this.loading.set(false);
          return;
        }
        const uniqueAppIds = [...new Set(myBids.map((b) => b.appId))];
        forkJoin(
          uniqueAppIds.map((appId) =>
            forkJoin({
              auction: this.auctionSvc.getByApplication(appId).pipe(catchError(() => of(null))),
              bids: this.auctionSvc.getBids(appId).pipe(catchError(() => of([] as BidDTO[])))
            })
          )
        ).subscribe((results) => {
          const byApp = new Map(uniqueAppIds.map((id, i) => [id, results[i]]));
          this.rows.set(
            myBids.map((bid) => {
              const entry = byApp.get(bid.appId);
              const highest = entry?.bids?.[0];
              return {
                bid,
                auction: entry?.auction || null,
                isHighest: !!highest && highest.bidderEmail === email && highest.bidAmount === bid.bidAmount
              };
            })
          );
          this.loading.set(false);
        });
      },
      error: () => {
        this.loading.set(false);
        this.toast.error('Could not load your bids', 'Please check your connection and try again.');
      }
    });
  }
}
