// INTEGRATION LAYER — ported from the standalone hlms-bidder-ui project's
// features/auth/register.component.ts, unchanged. Retained (as customer's
// own register page was) even though the shared /register page from the
// auth module (which already supports the BIDDER account type) is the
// primary entry point.

import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div id="authScreen">
      <div class="auth-wrap">
        <div class="auth-side">
          <img class="auth-image" src="assets/logo-hero.png" alt="HLMS">
        </div>
        <div class="auth-form">
          <h2>Register as a Bidder</h2>
          <p class="sub">Create an account to bid on HLMS auction listings</p>

          @if (error()) { <div class="banner-error">{{ error() }}</div> }

          <div class="field">
            <label>Full Name<span class="req">*</span></label>
            <input [(ngModel)]="name" placeholder="Your full name">
          </div>
          <div class="two-col">
            <div class="field">
              <label>Email<span class="req">*</span></label>
              <input type="email" [(ngModel)]="email" placeholder="you&#64;example.com">
            </div>
            <div class="field">
              <label>Mobile Number<span class="req">*</span></label>
              <input [(ngModel)]="mobile" placeholder="10-digit mobile number">
            </div>
          </div>
          <div class="two-col">
            <div class="field">
              <label>ID Type</label>
              <select [(ngModel)]="idType">
                <option value="AADHAAR">Aadhaar</option>
                <option value="PAN">PAN</option>
                <option value="PASSPORT">Passport</option>
              </select>
            </div>
            <div class="field">
              <label>ID Number</label>
              <input [(ngModel)]="idNumber" placeholder="ID number">
            </div>
          </div>
          <div class="field">
            <label>Password<span class="req">*</span></label>
            <div class="password-wrap">
              <input [type]="showPw() ? 'text' : 'password'" [(ngModel)]="password" placeholder="Create a password">
              <span class="password-toggle" (click)="showPw.set(!showPw())">{{ showPw() ? '🙈' : '👁' }}</span>
            </div>
          </div>

          <button class="btn btn-primary btn-block" [disabled]="loading()" (click)="submit()">
            @if (loading()) { <span class="spinner"></span> } Create Account
          </button>

          <div class="auth-switch">
            Already have an account? <a routerLink="/login">Log in</a>
          </div>
          <div class="auth-switch"><a routerLink="/">← Back to home</a></div>
        </div>
      </div>
    </div>
  `
})
export class RegisterComponent {
  name = '';
  email = '';
  mobile = '';
  password = '';
  idType = 'AADHAAR';
  idNumber = '';
  loading = signal(false);
  showPw = signal(false);
  error = signal<string | null>(null);

  constructor(private auth: AuthService, private router: Router, private toast: ToastService) {}

  submit(): void {
    this.error.set(null);
    if (!this.name || !this.email || !this.mobile || !this.password) {
      this.error.set('Please fill in all required fields.');
      return;
    }
    this.loading.set(true);
    this.auth
      .register({
        name: this.name,
        email: this.email,
        mobile: this.mobile,
        password: this.password,
        role: 'BIDDER',
        idType: this.idType,
        idNumber: this.idNumber
      })
      .subscribe({
        next: () => {
          this.loading.set(false);
          this.toast.success('Account created', 'You can now log in.');
          this.router.navigate(['/login']);
        },
        error: (err) => {
          this.loading.set(false);
          this.error.set(err?.error?.message || err?.message || 'Registration failed. Please try again.');
        }
      });
  }
}
