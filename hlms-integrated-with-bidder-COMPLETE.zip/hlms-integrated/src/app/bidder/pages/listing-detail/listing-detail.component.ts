// INTEGRATION LAYER — ported from the standalone hlms-bidder-ui project's
// features/bidder/listing-detail/listing-detail.component.ts. Only the model
// type names (AuctionCase -> AuctionCaseDTO, Bid -> BidDTO) and import paths
// changed. @Input() appId relies on withComponentInputBinding(), already
// enabled in the integrated app's app.config.ts (same as customer/legal use
// for their own :appId-bound pages).

import { Component, Input, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { forkJoin, of, catchError } from 'rxjs';
import { AuthService } from '../../core/services/auth.service';
import { AuctionService } from '../../core/services/auction.service';
import { LoanService } from '../../core/services/loan.service';
import { ToastService } from '../../core/services/toast.service';
import { AuctionCaseDTO, BidDTO, LoanApplication } from '../../core/models/models';

@Component({
  selector: 'app-listing-detail',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <a class="back-link" routerLink="/bidder/listings">← Back to Listings</a>

    @if (loading()) {
      <div class="page-loading"><span class="spinner dark"></span> Loading listing…</div>
    } @else if (!auction()) {
      <div class="card"><div class="empty-state"><div class="ic">☆</div>This property is not currently listed for auction.</div></div>
    } @else {
      <div class="page-head">
        <h1>{{ property()?.propertyAddress || auction()!.appId }}</h1>
        <p>Application {{ auction()!.appId }} @if (property()?.trackingNo) { · Tracking No: {{ property()!.trackingNo }} }</p>
      </div>

      <div class="grid grid-2">
        <div class="card">
          <h3>Property Details</h3>
          <div class="grid grid-2">
            <div class="stat"><span class="lbl">Property Type</span><span class="val">{{ property()?.propertyType || '—' }}</span></div>
            <div class="stat"><span class="lbl">Estimated Value</span><span class="val">₹{{ (property()?.propertyValue || 0) | number }}</span></div>
            <div class="stat"><span class="lbl">Reserve Price</span><span class="val teal">₹{{ (auction()!.reservePrice || 0) | number }}</span></div>
            <div class="stat">
              <span class="lbl">Status</span>
              @if (isOpen()) {
                <span class="badge badge-green">Open until {{ auction()!.auctionDate | date:'medium' }}</span>
              } @else {
                <span class="badge badge-gray">Closed on {{ auction()!.auctionDate | date:'medium' }}</span>
              }
            </div>
          </div>

          @if (isOpen()) {
            <h3 style="margin-top:22px;">Place a Bid</h3>
            @if (bidError()) { <div class="banner-error">{{ bidError() }}</div> }
            <div class="field">
              <label>Your Bid Amount (minimum ₹{{ minNextBid() | number }})</label>
              <input type="number" [(ngModel)]="bidAmount" [min]="minNextBid()" step="1000">
            </div>
            <button class="btn btn-primary" [disabled]="placingBid()" (click)="placeBid()">
              @if (placingBid()) { <span class="spinner"></span> } Place Bid
            </button>
          } @else {
            <div class="banner-error" style="background:var(--teal-light);color:var(--navy);border-color:var(--teal);margin-top:18px;">
              Bidding has closed for this property.
            </div>
          }
        </div>

        <div class="card">
          <h3>Bid History ({{ bids().length }})</h3>
          @if (bids().length === 0) {
            <div class="empty-state"><div class="ic">☑</div>No bids placed yet. Be the first!</div>
          } @else {
            <table>
              <thead><tr><th>Bidder</th><th>Amount</th><th>Placed</th></tr></thead>
              <tbody>
                @for (b of bids(); track b.bidId) {
                  <tr [class.bid-row-mine]="b.bidderEmail === myEmail()">
                    <td>{{ b.bidderEmail === myEmail() ? 'You' : maskEmail(b.bidderEmail) }}</td>
                    <td>₹{{ b.bidAmount | number }}</td>
                    <td>{{ b.createdAt ? (b.createdAt | date:'short') : '—' }}</td>
                  </tr>
                }
              </tbody>
            </table>
          }
        </div>
      </div>
    }
  `
})
export class ListingDetailComponent implements OnInit {
  @Input() appId!: string;

  loading = signal(true);
  auction = signal<AuctionCaseDTO | null>(null);
  property = signal<LoanApplication | null>(null);
  bids = signal<BidDTO[]>([]);
  bidAmount: number | null = null;
  placingBid = signal(false);
  bidError = signal<string | null>(null);

  isOpen = computed(() => (this.auction() ? this.auctionSvc.isOpen(this.auction()!) : false));
  minNextBid = computed(() => (this.auction() ? this.auctionSvc.minNextBid(this.auction()!, this.bids()) : 0));

  constructor(
    private auth: AuthService,
    public auctionSvc: AuctionService,
    private loanSvc: LoanService,
    private toast: ToastService
  ) {}

  myEmail(): string | undefined {
    return this.auth.currentUser()?.email;
  }

  maskEmail(email: string): string {
    const [name, domain] = email.split('@');
    if (!domain) return email;
    return `${name.slice(0, 2)}***@${domain}`;
  }

  ngOnInit(): void {
    this.load();
  }

  private load(): void {
    this.loading.set(true);
    this.auctionSvc
      .getByApplication(this.appId)
      .pipe(catchError(() => of(null)))
      .subscribe((auction) => {
        this.auction.set(auction);
        if (!auction) {
          this.loading.set(false);
          return;
        }
        forkJoin({
          property: this.loanSvc.getApplication(this.appId).pipe(catchError(() => of(null))),
          bids: this.auctionSvc.getBids(this.appId).pipe(catchError(() => of([] as BidDTO[])))
        }).subscribe((res) => {
          this.property.set(res.property);
          this.bids.set(res.bids);
          this.bidAmount = this.auctionSvc.minNextBid(auction, res.bids);
          this.loading.set(false);
        });
      });
  }

  placeBid(): void {
    this.bidError.set(null);
    const email = this.myEmail();
    if (!email) return;
    const amount = Number(this.bidAmount);
    if (!amount || amount < this.minNextBid()) {
      this.bidError.set(`Your bid must be at least ₹${this.minNextBid().toLocaleString()}.`);
      return;
    }
    this.placingBid.set(true);
    this.auctionSvc.placeBid(this.appId, email, amount).subscribe({
      next: () => {
        this.placingBid.set(false);
        this.toast.success('Bid placed successfully!');
        this.load();
      },
      error: (err) => {
        this.placingBid.set(false);
        this.bidError.set(err?.error?.message || err?.message || 'Could not place bid. Please try again.');
      }
    });
  }
}
