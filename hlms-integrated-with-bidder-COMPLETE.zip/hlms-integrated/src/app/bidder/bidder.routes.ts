import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';

/**
 * Bidder portal, mounted at /bidder.
 * Child paths and the BIDDER-role guard are the originals from
 * hlms-bidder-ui's app.routes.ts. (The standalone app's top-level
 * `''`/`login`/`register` routes and trailing `{ path: '**', redirectTo: '' }`
 * are dropped here -- the shared auth module's Home/Login/Register already
 * cover those, and the top-level app.routes.ts owns the app-wide wildcard.
 * This module's own login/register pages are kept, unregistered above, for
 * parity with how `customer` retains its originals alongside the shared ones.)
 */
export const BIDDER_ROUTES: Routes = [
  {
    path: 'login',
    loadComponent: () => import('./pages/login/login.component').then((m) => m.LoginComponent)
  },
  {
    path: 'register',
    loadComponent: () => import('./pages/register/register.component').then((m) => m.RegisterComponent)
  },
  {
    path: '',
    loadComponent: () => import('./layout/shell/shell.component').then((m) => m.ShellComponent),
    canActivate: [authGuard],
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      {
        path: 'dashboard',
        loadComponent: () => import('./pages/dashboard/dashboard.component').then((m) => m.DashboardComponent)
      },
      {
        path: 'listings',
        loadComponent: () => import('./pages/listings/listings.component').then((m) => m.ListingsComponent)
      },
      {
        path: 'listings/:appId',
        loadComponent: () => import('./pages/listing-detail/listing-detail.component').then((m) => m.ListingDetailComponent)
      },
      {
        path: 'my-bids',
        loadComponent: () => import('./pages/my-bids/my-bids.component').then((m) => m.MyBidsComponent)
      },
      {
        path: 'settings',
        loadComponent: () => import('./pages/settings/settings.component').then((m) => m.SettingsComponent)
      }
    ]
  }
];
