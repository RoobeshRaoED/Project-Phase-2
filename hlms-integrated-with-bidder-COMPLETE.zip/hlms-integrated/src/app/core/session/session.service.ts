import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, catchError, map, of } from 'rxjs';

import { environment } from '../../../environments/environment';
import { TOKEN_KEYS, USER_KEYS, clearHlmsSession } from './session-keys';

/** Roles as user-service's roleEnum serialises them. */
export type BackendRole = 'CUSTOMER' | 'LEGAL' | 'BANK_OFFICER' | 'BIDDER' | 'ADMIN';

/** The user record returned by GET /user-service/api/users/{email}. */
interface BackendUser {
  email: string;
  name: string;
  mobile: string;
  role: BackendRole;
  active?: boolean;
  idType?: string;
  idNumber?: string;
  createdAt?: string;
}

interface JwtPayload {
  sub: string;
  role: string;
  iat: number;
  exp: number;
}

/** Bank office stores a UI-shaped user under 'hlms_session_v1' with lower-case roles. */
const TO_BANKOFFICE_ROLE: Record<BackendRole, string> = {
  CUSTOMER: 'customer',
  LEGAL: 'legal',
  BANK_OFFICER: 'bankoffice',
  BIDDER: 'bidder',
  ADMIN: 'admin'
};

/** Where each role lands after a successful login. */
export const ROLE_HOME: Record<BackendRole, string | null> = {
  ADMIN: '/admin/dashboard',
  BANK_OFFICER: '/officer/bodash',
  LEGAL: '/legal/dashboard',
  CUSTOMER: '/customer/dashboard',
  BIDDER: '/bidder/dashboard'
};

/**
 * INTEGRATION LAYER - single sign-on across the five merged modules.
 *
 * The shared login page (auth module) authenticates once, then this service:
 *   1. copies the JWT into every key the other modules read, and
 *   2. writes the user record in each shape those modules expect, and
 *   3. redirects to the dashboard that matches the role in the JWT.
 *
 * Because of (1) and (2), NO module's AuthService needed its session-restore
 * logic changed -- each one still reads its own key, in its own format.
 */
@Injectable({ providedIn: 'root' })
export class SessionService {
  private http = inject(HttpClient);
  private router = inject(Router);

  private readonly usersApi = `${environment.apiBaseUrl}${environment.services.user}/api/users`;

  /** Decodes a JWT payload without verifying it (the backend verifies). */
  decode(token: string | null): JwtPayload | null {
    if (!token) return null;
    try {
      const parts = token.split('.');
      if (parts.length !== 3) return null;
      const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
      const json = decodeURIComponent(
        atob(base64)
          .split('')
          .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
          .join('')
      );
      return JSON.parse(json) as JwtPayload;
    } catch {
      return null;
    }
  }

  get token(): string | null {
    for (const k of TOKEN_KEYS) {
      const t = localStorage.getItem(k);
      if (t) return t;
    }
    return null;
  }

  get role(): BackendRole | null {
    const payload = this.decode(this.token);
    const role = (payload?.role || '').toUpperCase();
    return role ? (role as BackendRole) : null;
  }

  isLoggedIn(): boolean {
    const payload = this.decode(this.token);
    return !!payload && !!payload.exp && payload.exp * 1000 > Date.now();
  }

  /** Copies the JWT into every module's token key. */
  private fanOutToken(token: string): void {
    for (const k of TOKEN_KEYS) localStorage.setItem(k, token);
  }

  /** Writes the user record in each module's expected shape. */
  private fanOutUser(user: BackendUser): void {
    // customer + auth read 'hlms_user' as the raw backend user record
    localStorage.setItem('hlms_user', JSON.stringify(user));

    // bank office reads 'hlms_session_v1' as its own UI-shaped AppUser
    localStorage.setItem(
      'hlms_session_v1',
      JSON.stringify({
        fullName: user.name,
        email: user.email,
        phone: user.mobile,
        role: TO_BANKOFFICE_ROLE[user.role] ?? 'customer',
        active: user.active,
        createdAt: user.createdAt
      })
    );
  }

  /**
   * Completes login: publishes the session to every module, then resolves to
   * the route the user should land on (or null when the role has no portal).
   *
   * The auth module's AuthService has already stored the token under
   * 'hlms_auth_token' by this point; this reads it back and spreads it.
   */
  establish(): Observable<string | null> {
    const token = localStorage.getItem('hlms_auth_token');
    const payload = this.decode(token);

    if (!token || !payload) {
      return of(null);
    }

    this.fanOutToken(token);
    const role = (payload.role || '').toUpperCase() as BackendRole;

    // Hydrate the full profile so customer/bank-office restore paths find a
    // user record. A failure here must not block login -- those modules
    // re-fetch the profile themselves when the stored record is missing.
    return this.http.get<BackendUser>(`${this.usersApi}/${encodeURIComponent(payload.sub)}`).pipe(
      map((user) => {
        this.fanOutUser({ ...user, role: user.role || role });
        return ROLE_HOME[user.role || role] ?? null;
      }),
      catchError(() => {
        this.fanOutUser({ email: payload.sub, name: payload.sub, mobile: '', role });
        return of(ROLE_HOME[role] ?? null);
      })
    );
  }

  /** Ends the session everywhere and returns to the public home page. */
  logoutAll(navigate = true): void {
    clearHlmsSession();
    if (navigate) this.router.navigateByUrl('/');
  }

  /** Convenience for the shared login page. */
  routeForRole(role: BackendRole | null): string | null {
    return role ? ROLE_HOME[role] ?? null : null;
  }

  /** Exposed so callers can clear a partially-established session. */
  clear(): void {
    clearHlmsSession();
  }

  /** Keys the integration owns, for diagnostics. */
  static readonly keys = { TOKEN_KEYS, USER_KEYS };
}
