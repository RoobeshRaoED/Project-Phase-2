# Bidder Module Integration — Status

The standalone `hlms-bidder-ui` app (see the other zip) is fully complete.
Porting it into this integrated app as `src/app/bidder/` is IN PROGRESS —
do not expect `/bidder/*` routes to work yet: the module is not registered
in the top-level router, and the shared session layer doesn't know about it
yet either. See "Still to do" below — these are the ONLY remaining steps.

## Done so far
All ported from `hlms-bidder-ui`, adjusted only for this project's import
paths / environment / shared-session conventions (see each file's own
"INTEGRATION LAYER" header comment for exactly what changed):

- `core/models/models.ts` — AppUser, RegisterRequest, LoanApplication,
  AuctionCaseDTO, BidDTO, AuctionListing
- `core/services/auth.service.ts` — uses `hlms_bidder_token`; `logout()`
  also calls `clearHlmsSession()`
- `core/services/auction.service.ts`, `core/services/loan.service.ts`
- `core/services/toast.service.ts` — copied from `legal/`
- `core/guards/auth.guard.ts`
- `core/interceptors/auth.interceptor.ts` — ported but NOT registered
  (the global `hlmsAuthInterceptor` in `app.config.ts` already covers every
  role via `TOKEN_KEYS`, once `hlms_bidder_token` is added — see step 4
  below); kept only for parity with `legal/core/interceptors/auth.interceptor.ts`
- `layout/shell/shell.component.ts`
- `layout/toast/toast.component.ts` — copied from `legal/`
- `pages/login/`, `pages/register/`, `pages/dashboard/`, `pages/listings/`,
  `pages/listing-detail/`, `pages/my-bids/`, `pages/settings/` — all ported

Note: the standalone app's marketing **Home** page was deliberately NOT
ported. The integrated app's shared `/` (auth module) already serves that
role for every portal, and the shared `/register` page already has a
"Bidder" account-type option that posts `role: 'BIDDER'` — confirmed by
reading `src/app/auth/pages/auth/register/register.component.html`. This
mirrors how `customer/` keeps its own login/register pages "retired but not
deleted" while the shared pages are the real entry point.

## Still to do (only these steps)
1. Create `src/app/bidder/bidder.routes.ts` (mirror `legal/legal.routes.ts`
   structure, but including `pages/login` and `pages/register` as top-level
   children too, the way `customer/customer.routes.ts` does — since those
   pages were kept here rather than dropped):
   ```ts
   export const BIDDER_ROUTES: Routes = [
     { path: 'login', loadComponent: () => import('./pages/login/login.component').then(m => m.LoginComponent) },
     { path: 'register', loadComponent: () => import('./pages/register/register.component').then(m => m.RegisterComponent) },
     {
       path: '',
       loadComponent: () => import('./layout/shell/shell.component').then(m => m.ShellComponent),
       canActivate: [authGuard],
       children: [
         { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
         { path: 'dashboard', loadComponent: () => import('./pages/dashboard/dashboard.component').then(m => m.DashboardComponent) },
         { path: 'listings', loadComponent: () => import('./pages/listings/listings.component').then(m => m.ListingsComponent) },
         { path: 'listings/:appId', loadComponent: () => import('./pages/listing-detail/listing-detail.component').then(m => m.ListingDetailComponent) },
         { path: 'my-bids', loadComponent: () => import('./pages/my-bids/my-bids.component').then(m => m.MyBidsComponent) },
         { path: 'settings', loadComponent: () => import('./pages/settings/settings.component').then(m => m.SettingsComponent) }
       ]
     }
   ];
   ```
2. Create `src/app/bidder/bidder-root.component.ts` (mirror
   `legal/legal-root.component.ts` exactly, renaming selector to
   `app-bidder-root` and importing this module's own `AuthService`/
   `ToastComponent`).
3. Register the module in `src/app/app.routes.ts` (add alongside the
   existing `customer` / `admin` / `officer` / `legal` entries, same shape):
   ```ts
   {
     path: 'bidder',
     loadComponent: () => import('./bidder/bidder-root.component').then(m => m.AppComponent),
     loadChildren: () => import('./bidder/bidder.routes').then(m => m.BIDDER_ROUTES),
     title: 'HLMS | Bidder Portal'
   }
   ```
4. `src/app/core/session/session-keys.ts` — add `'hlms_bidder_token'` to
   the `TOKEN_KEYS` array.
5. `src/app/core/session/session.service.ts` — change
   `ROLE_HOME.BIDDER` from `null` to `'/bidder/dashboard'`.
6. Copy `assets/logo-icon.png` / `assets/logo-hero.png` from
   `hlms-bidder-ui/src/assets/` into `src/assets/` if not already present
   (check for name collisions with existing assets first).
7. Final syntax/compile sanity pass over every new file under
   `src/app/bidder/`.

Reference the completed `hlms-bidder-ui` zip for all component logic/
templates/CSS class usage — every file above is a straight port, not a
rewrite. The theme (navy/teal) already matches this project's `styles.css`
conventions used by `legal`/`bankoffice`.
