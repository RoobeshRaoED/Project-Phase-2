# HLMS — Home Loan Management System

Monorepo pairing the unified Angular 19 frontend with the Spring Cloud
microservices backend.

```
hlms-project/
├── frontend/   Angular 19 unified UI (customer, admin, bankoffice, legal, bidder, welcome)
└── backend/    Spring Cloud microservices (Eureka, API Gateway, 6 services)
```

## Run order

The backend must be up before the frontend can call it — start Eureka
first so every service can register, then the gateway, then the services
in any order.

```bash
cd hlms-project/backend

cd eureka-server        && mvn spring-boot:run   # 1. service registry (start first, wait for it to be up)
cd ../api-gateway        && mvn spring-boot:run   # 2. single entry point for the frontend
cd ../user-service        && mvn spring-boot:run
cd ../loan-service         && mvn spring-boot:run
cd ../legal-service         && mvn spring-boot:run
cd ../repayment-service      && mvn spring-boot:run
cd ../notification-service    && mvn spring-boot:run
cd ../document-service         && mvn spring-boot:run
```

Then, in a separate terminal:

```bash
cd hlms-project/frontend
npm install
npm start          # ng serve, proxied via proxy.conf.json to the gateway on :8080
```

Visit `http://localhost:4200`.

## Ports

| Service              | Port |
|-----------------------|------|
| eureka-server          | 8761 |
| api-gateway (entry point) | 8080 |
| user-service            | 8081 |
| loan-service             | 8082 |
| notification-service      | 8083 |
| legal-service               | 8084 |
| repayment-service            | 8085 |
| document-service              | 8086 |
| frontend (ng serve)             | 4200 |

## How requests flow

Every portal in the frontend calls the gateway at `http://localhost:8080`
(or a relative path proxied to it via `proxy.conf.json` in dev). The
gateway (`api-gateway/src/main/resources/application.properties`) routes
by path prefix — e.g. `/user-service/**` → `user-service`, stripping the
prefix before forwarding — and its CORS config is locked to
`http://localhost:4200`, matching `ng serve`'s default port. This was
verified to line up exactly across all six service prefixes.

## Portal map (frontend)

`/` customer · `/admin` · `/bankoffice` · `/legal` · `/bidder` · `/welcome`

## Source project verification

Three additional uploads (`Final_customer_and_admin_UI.zip` — containing
`angular-customer-ui` and `hlms-admin-ui` — and `hlms-angular19-hlms-auth.zip`)
were checked file-by-file against the customer, admin, and welcome portals
already in this workspace. All three are already fully merged: every file
matched byte-for-byte except for the namespacing edits (deeper relative
import paths, `assets/<portal>/...` prefixes, route prefixes) that were
applied when each was folded into this unified app. Nothing from those
three zips needed to be re-integrated.

## Build fixes applied (Aug 2026)

`ng serve` surfaced 4 real compile errors, all fixed:
- `bo-docs.component.ts` (bankoffice) — `NotificationService` and
  `AuthService` were injected but never imported; added the imports.
- `welcome/pages/auth/login/login.component.ts` and
  `register/register.component.ts` — `form`/`forgotForm`/`resetForm`
  field initializers referenced `this.fb`, but `fb` was a constructor
  parameter property, which is assigned *after* field initializers run.
  Switched `fb`, `authService`, and `router` to `inject()` fields
  (matching the pattern already used everywhere else in the codebase)
  so they're available before the form groups are built.
- `login.component.ts` also had an entire second copy of the class
  commented out at the bottom of the file (leftover from an earlier
  edit) — removed.

Also cleaned up two build warnings: an unused `RouterLinkActive` import
in `admin-shell.component.ts`, and two redundant `?.` optional-chaining
checks on non-nullable array fields in `eligibility.ts`.

I re-scanned all 171 non-spec `.ts` files afterward for broken relative
imports and for any other `inject()`/constructor-param type missing its
import — zero remaining issues found.

## Known loose ends

- `environment.development.ts` / `environment.prod.ts` files exist inside
  a few portals (customer, bidder, bankoffice, legal) but aren't wired up
  via Angular `fileReplacements` — every portal imports `environment.ts`
  directly regardless of build configuration. They're harmless (unused
  dead code) but worth removing or wiring up properly if you want dev vs.
  prod builds to actually differ.
- Backend `target/` build directories were stripped before packaging;
  run `mvn clean install` per service before first launch.
