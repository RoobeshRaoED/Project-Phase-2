package com.hlms.document.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Calls notification-service's internal (service-to-service) endpoint. Sends a notification via notification-service on behalf of a system flow that has no logged-in user of its own.
 * "notification-service" is resolved via Eureka; see FeignClientConfig for the
 * internal API key header that authenticates this call.
 */
@FeignClient(name = "notification-service", configuration = FeignClientConfig.class)
public interface NotificationClient {

    @PostMapping("/internal/notifications")
    void send(@RequestBody NotificationRequest request);
}
