package com.hlms.document.client;

/** Response/request shape for legal-service's internal endpoint. */
public record LegalStatusResponse(String appId, boolean verificationExists, String decision, String officer) { }
