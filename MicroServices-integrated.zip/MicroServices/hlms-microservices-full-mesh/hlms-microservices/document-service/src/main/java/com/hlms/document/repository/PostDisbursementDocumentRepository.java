package com.hlms.document.repository;

import com.hlms.document.entity.PostDisbursementDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PostDisbursementDocumentRepository extends JpaRepository<PostDisbursementDocument, String> {
    List<PostDisbursementDocument> findByAppIdAndDeletedAtIsNull(String appId);
}
