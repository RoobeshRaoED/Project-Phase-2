package com.hlms.document.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.OffsetDateTime;
@Entity
@Table(name = "post_disbursement_document")
public class PostDisbursementDocument {
    @Id
    @Column(name = "pd_doc_id", length = 50)
    private String pdDocId;
    @Column(name = "app_id", nullable = false)
    private String appId;
    @Column(name = "doc_type", length = 80, nullable = false)
    private String docType;
    @Column(name = "file_name", length = 255, nullable = false)
    private String fileName;
    @JsonIgnore
    @Lob
    @Column(name = "file_data", nullable = false)
    private byte[] fileData;
    @Column(name = "file_size")
    private Integer fileSize;
    @Column(name = "note", columnDefinition = "TEXT")
    private String note;
    @Column(name = "status", length = 30, nullable = false)
    private String status = "Pending";
    @Column(name = "uploaded_at", nullable = false)
    private OffsetDateTime uploadedAt;
    @Column(name = "verified_by")
    private String verifiedBy;
    @Column(name = "verified_at")
    private OffsetDateTime verifiedAt;
    @Column(name = "remarks", columnDefinition = "TEXT")
    private String remarks;
    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;
    @PrePersist
    public void prePersist() {
        if (uploadedAt == null) uploadedAt = OffsetDateTime.now();
    }

    public PostDisbursementDocument() {
    }

    public PostDisbursementDocument(String pdDocId, String appId, String docType, String fileName, byte[] fileData, Integer fileSize, String note, String status, OffsetDateTime uploadedAt, String verifiedBy, OffsetDateTime verifiedAt, String remarks, OffsetDateTime deletedAt) {
        this.pdDocId = pdDocId;
        this.appId = appId;
        this.docType = docType;
        this.fileName = fileName;
        this.fileData = fileData;
        this.fileSize = fileSize;
        this.note = note;
        this.status = status;
        this.uploadedAt = uploadedAt;
        this.verifiedBy = verifiedBy;
        this.verifiedAt = verifiedAt;
        this.remarks = remarks;
        this.deletedAt = deletedAt;
    }

    public String getPdDocId() {
        return pdDocId;
    }
    public void setPdDocId(String pdDocId) {
        this.pdDocId = pdDocId;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public String getDocType() {
        return docType;
    }
    public void setDocType(String docType) {
        this.docType = docType;
    }
    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    public byte[] getFileData() {
        return fileData;
    }
    public void setFileData(byte[] fileData) {
        this.fileData = fileData;
    }
    public Integer getFileSize() {
        return fileSize;
    }
    public void setFileSize(Integer fileSize) {
        this.fileSize = fileSize;
    }
    public String getNote() {
        return note;
    }
    public void setNote(String note) {
        this.note = note;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public OffsetDateTime getUploadedAt() {
        return uploadedAt;
    }
    public void setUploadedAt(OffsetDateTime uploadedAt) {
        this.uploadedAt = uploadedAt;
    }
    public String getVerifiedBy() {
        return verifiedBy;
    }
    public void setVerifiedBy(String verifiedBy) {
        this.verifiedBy = verifiedBy;
    }
    public OffsetDateTime getVerifiedAt() {
        return verifiedAt;
    }
    public void setVerifiedAt(OffsetDateTime verifiedAt) {
        this.verifiedAt = verifiedAt;
    }
    public String getRemarks() {
        return remarks;
    }
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }
    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static Builder builder() {
        return new Builder();
    }
    public static class Builder {
        private String pdDocId;
        private String appId;
        private String docType;
        private String fileName;
        private byte[] fileData;
        private Integer fileSize;
        private String note;
        private String status = "Pending";
        private OffsetDateTime uploadedAt;
        private String verifiedBy;
        private OffsetDateTime verifiedAt;
        private String remarks;
        private OffsetDateTime deletedAt;

        public Builder pdDocId(String pdDocId) {
            this.pdDocId = pdDocId;
            return this;
        }
        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }
        public Builder docType(String docType) {
            this.docType = docType;
            return this;
        }
        public Builder fileName(String fileName) {
            this.fileName = fileName;
            return this;
        }
        public Builder fileData(byte[] fileData) {
            this.fileData = fileData;
            return this;
        }
        public Builder fileSize(Integer fileSize) {
            this.fileSize = fileSize;
            return this;
        }
        public Builder note(String note) {
            this.note = note;
            return this;
        }
        public Builder status(String status) {
            this.status = status;
            return this;
        }
        public Builder uploadedAt(OffsetDateTime uploadedAt) {
            this.uploadedAt = uploadedAt;
            return this;
        }
        public Builder verifiedBy(String verifiedBy) {
            this.verifiedBy = verifiedBy;
            return this;
        }
        public Builder verifiedAt(OffsetDateTime verifiedAt) {
            this.verifiedAt = verifiedAt;
            return this;
        }
        public Builder remarks(String remarks) {
            this.remarks = remarks;
            return this;
        }
        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public PostDisbursementDocument build() {
            return new PostDisbursementDocument(pdDocId, appId, docType, fileName, fileData, fileSize, note, status, uploadedAt, verifiedBy, verifiedAt, remarks, deletedAt);
        }
    }
}