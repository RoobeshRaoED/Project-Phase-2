package com.hlms.loan.service;
import com.hlms.loan.dto.*;
import com.hlms.loan.entity.LoanProduct;
import com.hlms.loan.repository.LoanProductRepository;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
/**
 * Backs feature "3. Loan Guidance & Recommendation Engine".
 *  - US-LG-03/04: personalized product recommendations, matched against purpose + eligibility.
 *  - US-LG-05: EMI/tenure guidance assistant.
 */
@Service
public class LoanGuidanceService {
    private final LoanProductRepository loanProductRepository;
    private final EligibilityService eligibilityService;
    private static final List<Integer> STANDARD_TENURE_OPTIONS = List.of(5, 10, 15, 20, 25, 30);
    /** US-LG-03/04: recommend products that match the customer's purpose and current eligibility. */
    public List<ProductRecommendation> recommend(LoanRecommendationRequest req) {
        EligibilityRequest eligibilityRequest = new EligibilityRequest();
        eligibilityRequest.setMonthlyIncome(req.getMonthlyIncome());
        eligibilityRequest.setOtherEmis(req.getOtherEmis());
        eligibilityRequest.setCibilScore(req.getCibilScore());
        eligibilityRequest.setRequestedAmount(req.getRequestedAmount());
        eligibilityRequest.setTenureYears(req.getTenureYears());
        List<LoanProduct> products = loanProductRepository.findByDeletedAtIsNull();
        String purpose = req.getPurpose() == null ? "" : req.getPurpose().toLowerCase();
        int tenureYears = req.getTenureYears() == null ? 20 : req.getTenureYears();
        List<ProductRecommendation> recommendations = new ArrayList<>();
        for (LoanProduct product : products) {
            // US-LG-04: only recommend products whose max tenure can actually accommodate the request.
            if (tenureYears > product.getMaxTenureYears()) continue;
            boolean purposeMatch = purpose.isBlank()
                    || product.getCategory().toLowerCase().contains(purpose)
                    || product.getName().toLowerCase().contains(purpose);
            EligibilityRequest perProduct = eligibilityRequest;
            perProduct.setInterestRate(product.getInterestRate());
            EligibilityResponse eligibility = eligibilityService.assess(perProduct);
            String matchReason = purposeMatch
                    ? "Matches your stated purpose and current eligibility status: " + eligibility.status()
                    : "Doesn't directly match your stated purpose, but you are " + eligibility.status().toLowerCase()
                      + " for it based on your profile.";
            BigDecimal emi = eligibilityService.emiForLoan(
                    req.getRequestedAmount() == null ? BigDecimal.ZERO : req.getRequestedAmount(),
                    product.getInterestRate(), tenureYears);
            recommendations.add(new ProductRecommendation(
                    product.getProductId(), product.getName(), product.getCategory(),
                    product.getInterestRate(), product.getMaxTenureYears(), product.getMaxLtv(),
                    emi, matchReason));
        }
        // Purpose-matching products first, then lowest interest rate.
        recommendations.sort(Comparator
                .comparing((ProductRecommendation r) -> !purpose.isBlank() && !r.matchReason().startsWith("Matches"))
                .thenComparing(ProductRecommendation::interestRate));
        return recommendations;
    }
    /** US-LG-05: shows EMI/total-interest trade-offs across standard tenure options. */
    public List<EmiOption> emiTenureAssistant(GuidanceAssistantRequest req) {
        List<EmiOption> options = new ArrayList<>();
        BigDecimal amount = req.getLoanAmount();
        BigDecimal rate = req.getInterestRate();
        for (int years : STANDARD_TENURE_OPTIONS) {
            BigDecimal emi = eligibilityService.emiForLoan(amount, rate, years);
            BigDecimal totalPayment = emi.multiply(BigDecimal.valueOf(years * 12L)).setScale(2, RoundingMode.HALF_UP);
            BigDecimal totalInterest = totalPayment.subtract(amount).setScale(2, RoundingMode.HALF_UP);
            options.add(new EmiOption(years, emi, totalPayment, totalInterest, false));
        }
        int recommendedIndex = pickRecommendedIndex(options, req.getMaxAffordableEmi());
        List<EmiOption> result = new ArrayList<>();
        for (int i = 0; i < options.size(); i++) {
            EmiOption o = options.get(i);
            result.add(new EmiOption(o.tenureYears(), o.emi(), o.totalPayment(), o.totalInterest(), i == recommendedIndex));
        }
        return result;
    }
    /**
     * If the customer gave an affordable-EMI ceiling, recommend the shortest tenure that stays
     * within it (minimizes total interest while remaining affordable). Otherwise default to the
     * middle tenure option as a balanced starting point.
     */
    private int pickRecommendedIndex(List<EmiOption> options, BigDecimal maxAffordableEmi) {
        if (maxAffordableEmi != null && maxAffordableEmi.signum() > 0) {
            for (int i = 0; i < options.size(); i++) {
                if (options.get(i).emi().compareTo(maxAffordableEmi) <= 0) {
                    return i;
                }
            }
            return options.size() - 1; // even the longest tenure doesn't fit - flag the closest option
        }
        return options.size() / 2;
    }

    public LoanGuidanceService(LoanProductRepository loanProductRepository, EligibilityService eligibilityService) {
        this.loanProductRepository = loanProductRepository;
        this.eligibilityService = eligibilityService;
    }
}