package com.hlms.loan.dto;
import java.math.BigDecimal;
public class LoanRecommendationRequest {
    private String purpose;           // free text, matched loosely against loan_product.category (US-LG-03)
    private BigDecimal monthlyIncome;
    private BigDecimal otherEmis;
    private Integer cibilScore;
    private BigDecimal requestedAmount;
    private Integer tenureYears;

    public String getPurpose() {
        return purpose;
    }
    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }
    public BigDecimal getMonthlyIncome() {
        return monthlyIncome;
    }
    public void setMonthlyIncome(BigDecimal monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }
    public BigDecimal getOtherEmis() {
        return otherEmis;
    }
    public void setOtherEmis(BigDecimal otherEmis) {
        this.otherEmis = otherEmis;
    }
    public Integer getCibilScore() {
        return cibilScore;
    }
    public void setCibilScore(Integer cibilScore) {
        this.cibilScore = cibilScore;
    }
    public BigDecimal getRequestedAmount() {
        return requestedAmount;
    }
    public void setRequestedAmount(BigDecimal requestedAmount) {
        this.requestedAmount = requestedAmount;
    }
    public Integer getTenureYears() {
        return tenureYears;
    }
    public void setTenureYears(Integer tenureYears) {
        this.tenureYears = tenureYears;
    }
}