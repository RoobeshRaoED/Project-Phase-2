package com.hlms.loan.dto;

import java.time.LocalDate;

/** US-LT-05 Expected Completion Date, computed from stage SLA-days config, not stored. */
public record ExpectedCompletion(
        String appId,
        int currentStageIndex,
        String currentStageName,
        LocalDate expectedCompletionDate,
        int slaDaysRemainingForStage
) {}
