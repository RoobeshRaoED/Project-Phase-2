-- ============================================================
-- HLMS - Housing Loan Management System
-- PostgreSQL Database Schema (COMBINED v2 + v3) - FIXED
--
-- FIX HISTORY:
-- 1. The original file's final section ("9. CONVENIENCE VIEWS") was cut
--    off mid-statement at "CREATE VIEW v_active_loan_appli" with no
--    closing AS SELECT ... FROM ... (no semicolon), which produced
--    "ERROR: syntax error at end of input" in psql/pgAdmin. That
--    statement is now completed, and a v_active_* view was added for
--    every table that has a deleted_at column.
-- 2. schema_additions_v3.sql (otp_verification, eligibility_assessment)
--    is now folded directly into section 1/3 below instead of being a
--    separate file you had to remember to run second - so a fresh
--    database only needs ONE script. Both new tables follow the same
--    soft-delete convention as the rest of the schema and now also
--    have matching v_active_* views (section 9), which the standalone
--    v3 add-on file never had.
-- 3. SOFT-DELETE BUG FIX: the generic soft_delete()/restore_record()
--    functions cast the primary-key column to text with %I::text = $1
--    so they work against this schema's VARCHAR primary keys. That's
--    fine for every table except audit_log, which correctly has NO
--    deleted_at column (an audit trail must stay permanent) - calling
--    soft_delete('audit_log', ...) would previously fail with
--    "column deleted_at does not exist" and no clear explanation. A
--    guard clause now makes that failure explicit and points at the
--    right table instead of a bare Postgres error (see section 8).
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- 1. USERS & ACCESS CONTROL
-- ============================================================

CREATE TABLE app_user (
    email               VARCHAR(255) PRIMARY KEY,
    name                VARCHAR(150) NOT NULL,
    mobile              VARCHAR(20) NOT NULL,
    password_hash       VARCHAR(255) NOT NULL,
    role                VARCHAR(30) NOT NULL CHECK (role IN (
                            'customer', 'legal', 'bankoffice',
                            'bidder', 'admin'
                        )),
    active              BOOLEAN NOT NULL DEFAULT TRUE,
    id_type             VARCHAR(30),
    id_number           VARCHAR(50),
    pref_sms            BOOLEAN NOT NULL DEFAULT TRUE,
    pref_email          BOOLEAN NOT NULL DEFAULT TRUE,
    pref_inapp          BOOLEAN NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at          TIMESTAMPTZ
);
CREATE INDEX idx_app_user_deleted ON app_user(deleted_at);

CREATE TABLE role_permission (
    permission_id  BIGSERIAL PRIMARY KEY,
    role           VARCHAR(30) NOT NULL,
    module         VARCHAR(50) NOT NULL,
    can_view       BOOLEAN NOT NULL DEFAULT FALSE,
    can_add        BOOLEAN NOT NULL DEFAULT FALSE,
    can_edit       BOOLEAN NOT NULL DEFAULT FALSE,
    can_delete     BOOLEAN NOT NULL DEFAULT FALSE,
    UNIQUE (role, module)
);

-- ---- v3 additions (previously a separate schema_additions_v3.sql file,
-- ---- now folded in here so one script builds the whole database) ----

CREATE TABLE otp_verification (
    otp_id       VARCHAR(50) PRIMARY KEY,
    email        VARCHAR(255) NOT NULL REFERENCES app_user(email) ON DELETE CASCADE,
    otp_code     VARCHAR(10) NOT NULL,
    purpose      VARCHAR(30) NOT NULL DEFAULT 'LOGIN',
    expires_at   TIMESTAMPTZ NOT NULL,
    consumed     BOOLEAN NOT NULL DEFAULT FALSE,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at   TIMESTAMPTZ
);
CREATE INDEX idx_otp_email ON otp_verification(email);
CREATE INDEX idx_otp_email_purpose ON otp_verification(email, purpose);
CREATE INDEX idx_otp_deleted ON otp_verification(deleted_at);

CREATE TABLE eligibility_assessment (
    assessment_id             BIGSERIAL PRIMARY KEY,
    user_email                VARCHAR(255) NOT NULL REFERENCES app_user(email) ON DELETE CASCADE,
    requested_amount          NUMERIC(14,2),
    tenure_years              INT,
    cibil_score               INT,
    monthly_income            NUMERIC(14,2),
    other_emis                NUMERIC(14,2),
    interest_rate             NUMERIC(5,2),
    status                    VARCHAR(30) NOT NULL,
    max_eligible_loan_amount  NUMERIC(14,2),
    estimated_emi             NUMERIC(14,2),
    dti_ratio                 NUMERIC(6,4),
    reasons                   JSONB,
    recommendations           JSONB,
    created_at                TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at                TIMESTAMPTZ
);
CREATE INDEX idx_eligibility_user ON eligibility_assessment(user_email);
CREATE INDEX idx_eligibility_created ON eligibility_assessment(created_at);
CREATE INDEX idx_eligibility_deleted ON eligibility_assessment(deleted_at);

CREATE TABLE customer_employment_profile (
    profile_id      BIGSERIAL PRIMARY KEY,
    user_email      VARCHAR(255) NOT NULL UNIQUE REFERENCES app_user(email) ON DELETE CASCADE,
    employment_type VARCHAR(30),
    employer        VARCHAR(150),
    monthly_income  NUMERIC(14,2),
    other_emis      NUMERIC(14,2) DEFAULT 0,
    desired_amount  NUMERIC(14,2),
    pan             VARCHAR(20),
    deleted_at      TIMESTAMPTZ
);

-- ============================================================
-- 2. PRODUCTS & APPLICATIONS
-- ============================================================

CREATE TABLE loan_product (
    product_id       VARCHAR(50) PRIMARY KEY,
    name             VARCHAR(150) NOT NULL,
    category         VARCHAR(50),
    interest_rate    NUMERIC(5,2) NOT NULL,
    max_tenure_years INT NOT NULL,
    max_ltv          VARCHAR(10),
    description      TEXT,
    deleted_at       TIMESTAMPTZ
);

CREATE TABLE loan_application (
    app_id           VARCHAR(50) PRIMARY KEY,
    tracking_no      VARCHAR(50) UNIQUE,
    user_email       VARCHAR(255) NOT NULL REFERENCES app_user(email),
    product_id       VARCHAR(50) REFERENCES loan_product(product_id),
    loan_amount      NUMERIC(14,2),
    tenure_years     INT,
    purpose          VARCHAR(150),
    interest_rate    NUMERIC(5,2),
    status           VARCHAR(30) NOT NULL DEFAULT 'Draft' CHECK (status IN (
                        'Draft', 'Submitted', 'Under Review',
                        'Rejected', 'Disbursed'
                     )),
    stage_index      INT NOT NULL DEFAULT 0,

    current_step     INT NOT NULL DEFAULT 1,
    form_data        JSONB NOT NULL DEFAULT '{}'::jsonb,
    saved_at         TIMESTAMPTZ NOT NULL DEFAULT now(),

    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),

    applicant_name    VARCHAR(150),
    applicant_mobile  VARCHAR(20),
    applicant_pan     VARCHAR(20),

    addr_door_no      VARCHAR(30),
    addr_street       VARCHAR(150),
    addr_city         VARCHAR(100),
    addr_state        VARCHAR(100),
    addr_pincode      VARCHAR(10),

    employment_type   VARCHAR(30),
    employer          VARCHAR(150),
    monthly_income    NUMERIC(14,2),
    other_emis        NUMERIC(14,2),

    property_address  TEXT,
    property_type     VARCHAR(50),
    property_value    NUMERIC(14,2),

    deleted_at        TIMESTAMPTZ
);
CREATE INDEX idx_loan_app_user ON loan_application(user_email);
CREATE INDEX idx_loan_app_product ON loan_application(product_id);
CREATE INDEX idx_loan_app_status ON loan_application(status);
CREATE INDEX idx_loan_app_deleted ON loan_application(deleted_at);

-- ============================================================
-- 3. DOCUMENTS & VERIFICATION
-- ============================================================

CREATE TABLE application_document (
    document_id          VARCHAR(50) PRIMARY KEY,
    app_id               VARCHAR(50) NOT NULL REFERENCES loan_application(app_id) ON DELETE CASCADE,
    doc_type             VARCHAR(50) NOT NULL,
    file_name            VARCHAR(255) NOT NULL,
    file_data            BYTEA NOT NULL,
    file_size            INT,
    uploaded_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    verification_status  VARCHAR(30) NOT NULL DEFAULT 'Pending',
    verified_by          VARCHAR(255) REFERENCES app_user(email),
    verified_at          TIMESTAMPTZ,
    remarks              TEXT,
    deleted_at           TIMESTAMPTZ
);
CREATE INDEX idx_app_doc_app ON application_document(app_id);
CREATE INDEX idx_app_doc_deleted ON application_document(deleted_at);

CREATE TABLE legal_verification (
    verification_id      BIGSERIAL PRIMARY KEY,
    app_id                VARCHAR(50) NOT NULL UNIQUE REFERENCES loan_application(app_id) ON DELETE CASCADE,
    decision              VARCHAR(30),
    decision_date         TIMESTAMPTZ,
    officer               VARCHAR(255) REFERENCES app_user(email),
    remarks               TEXT,
    info_requested        BOOLEAN NOT NULL DEFAULT FALSE,
    info_request_details  TEXT,
    info_requested_at     TIMESTAMPTZ,
    deleted_at            TIMESTAMPTZ
);

CREATE TABLE legal_checklist_item (
    checklist_item_id  VARCHAR(50) PRIMARY KEY,
    app_id             VARCHAR(50) NOT NULL REFERENCES loan_application(app_id) ON DELETE CASCADE,
    checklist_key      VARCHAR(100) NOT NULL,
    status             VARCHAR(30) NOT NULL DEFAULT 'Pending',
    deleted_at         TIMESTAMPTZ
);
CREATE INDEX idx_checklist_app ON legal_checklist_item(app_id);

CREATE TABLE bank_office_decision (
    decision_id    BIGSERIAL PRIMARY KEY,
    app_id         VARCHAR(50) NOT NULL UNIQUE REFERENCES loan_application(app_id) ON DELETE CASCADE,
    status         VARCHAR(30),
    officer        VARCHAR(255) REFERENCES app_user(email),
    decision_date  TIMESTAMPTZ,
    reason         VARCHAR(255),
    remarks        TEXT,
    deleted_at     TIMESTAMPTZ
);

-- ============================================================
-- 4. DISBURSEMENT, INSURANCE & REPAYMENT
-- ============================================================

CREATE TABLE disbursement (
    disbursement_id  BIGSERIAL PRIMARY KEY,
    app_id           VARCHAR(50) NOT NULL UNIQUE REFERENCES loan_application(app_id) ON DELETE CASCADE,
    disbursed_date   TIMESTAMPTZ,
    amount           NUMERIC(14,2),
    ref_no           VARCHAR(50),
    mode             VARCHAR(30),
    bank_details     VARCHAR(150),
    deleted_at       TIMESTAMPTZ
);

CREATE TABLE insurance_policy (
    policy_id    VARCHAR(50) PRIMARY KEY,
    app_id       VARCHAR(50) NOT NULL REFERENCES loan_application(app_id) ON DELETE CASCADE,
    policy_type  VARCHAR(50) CHECK (policy_type IN ('property', 'life')),
    status       VARCHAR(30) NOT NULL DEFAULT 'Active',
    valid_till   DATE,
    deleted_at   TIMESTAMPTZ
);
CREATE INDEX idx_insurance_app ON insurance_policy(app_id);

CREATE TABLE emi_installment (
    installment_id       VARCHAR(50) PRIMARY KEY,
    app_id               VARCHAR(50) NOT NULL REFERENCES loan_application(app_id) ON DELETE CASCADE,
    installment_no       INT NOT NULL,
    due_date             DATE NOT NULL,
    emi_amount           NUMERIC(14,2) NOT NULL,
    principal_component  NUMERIC(14,2),
    interest_component   NUMERIC(14,2),
    closing_balance      NUMERIC(14,2),
    status               VARCHAR(30) NOT NULL DEFAULT 'Due',
    paid_date            DATE,
    deleted_at           TIMESTAMPTZ,
    UNIQUE (app_id, installment_no)
);
CREATE INDEX idx_emi_app ON emi_installment(app_id);
CREATE INDEX idx_emi_status ON emi_installment(status);

-- ============================================================
-- 5. SERVICE REQUESTS & POST-DISBURSEMENT DOCS
-- ============================================================

CREATE TABLE service_request (
    request_id    VARCHAR(50) PRIMARY KEY,
    ref_no        VARCHAR(50) UNIQUE NOT NULL,
    app_id        VARCHAR(50) REFERENCES loan_application(app_id) ON DELETE CASCADE,
    user_email    VARCHAR(255) NOT NULL REFERENCES app_user(email),
    request_type  VARCHAR(50) NOT NULL,
    description   TEXT,
    status        VARCHAR(30) NOT NULL DEFAULT 'Requested',
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at    TIMESTAMPTZ
);
CREATE INDEX idx_service_req_user ON service_request(user_email);
CREATE INDEX idx_service_req_app ON service_request(app_id);
CREATE INDEX idx_service_req_deleted ON service_request(deleted_at);

CREATE TABLE post_disbursement_document (
    pd_doc_id     VARCHAR(50) PRIMARY KEY,
    app_id        VARCHAR(50) NOT NULL REFERENCES loan_application(app_id) ON DELETE CASCADE,
    doc_type      VARCHAR(80) NOT NULL,
    file_name     VARCHAR(255) NOT NULL,
    file_data     BYTEA NOT NULL,
    file_size     INT,
    note          TEXT,
    status        VARCHAR(30) NOT NULL DEFAULT 'Pending',
    uploaded_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    verified_by   VARCHAR(255) REFERENCES app_user(email),
    verified_at   TIMESTAMPTZ,
    remarks       TEXT,
    deleted_at    TIMESTAMPTZ
);
CREATE INDEX idx_pd_doc_app ON post_disbursement_document(app_id);

-- ============================================================
-- 6. AUCTION & LEGAL NOTICES (SARFAESI)
-- ============================================================

CREATE TABLE auction_case (
    auction_id       BIGSERIAL PRIMARY KEY,
    app_id           VARCHAR(50) NOT NULL UNIQUE REFERENCES loan_application(app_id) ON DELETE CASCADE,
    stage            VARCHAR(30) NOT NULL DEFAULT 'None' CHECK (stage IN (
                        'None', 'Notice Issued', 'Possession',
                        'Auction Scheduled', 'Resolved'
                     )),
    notice_date      DATE,
    notice_due_date  DATE,
    demand_amount    NUMERIC(14,2),
    possession_date  DATE,
    auction_date     DATE,
    reserve_price    NUMERIC(14,2),
    deleted_at       TIMESTAMPTZ
);

CREATE TABLE auction_note (
    note_id    VARCHAR(50) PRIMARY KEY,
    app_id     VARCHAR(50) NOT NULL REFERENCES auction_case(app_id) ON DELETE CASCADE,
    note_date  TIMESTAMPTZ NOT NULL DEFAULT now(),
    note_text  TEXT NOT NULL,
    deleted_at TIMESTAMPTZ
);
CREATE INDEX idx_auction_note_app ON auction_note(app_id);

CREATE TABLE legal_notice (
    notice_id    VARCHAR(50) PRIMARY KEY,
    notice_no    VARCHAR(50) UNIQUE NOT NULL,
    app_id       VARCHAR(50) NOT NULL REFERENCES loan_application(app_id) ON DELETE CASCADE,
    notice_type  VARCHAR(50) NOT NULL,
    issue_date   DATE NOT NULL,
    due_date     DATE,
    status       VARCHAR(30) NOT NULL DEFAULT 'Active',
    officer      VARCHAR(255) REFERENCES app_user(email),
    content      TEXT,
    deleted_at   TIMESTAMPTZ
);
CREATE INDEX idx_legal_notice_app ON legal_notice(app_id);

CREATE TABLE bid (
    bid_id        VARCHAR(50) PRIMARY KEY,
    app_id        VARCHAR(50) NOT NULL REFERENCES auction_case(app_id) ON DELETE CASCADE,
    bidder_email  VARCHAR(255) NOT NULL REFERENCES app_user(email),
    bid_amount    NUMERIC(14,2) NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at    TIMESTAMPTZ
);
CREATE INDEX idx_bid_app ON bid(app_id);
CREATE INDEX idx_bid_bidder ON bid(bidder_email);

-- ============================================================
-- 7. NOTIFICATIONS & AUDIT
-- ============================================================

CREATE TABLE notification (
    notification_id  VARCHAR(50) PRIMARY KEY,
    user_email       VARCHAR(255) NOT NULL REFERENCES app_user(email) ON DELETE CASCADE,
    title            VARCHAR(150) NOT NULL,
    body             TEXT,
    channels         TEXT[] NOT NULL DEFAULT ARRAY['inapp'],
    is_read          BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at       TIMESTAMPTZ
);
CREATE INDEX idx_notification_user ON notification(user_email);
CREATE INDEX idx_notification_read ON notification(user_email, is_read);

-- audit_log intentionally has NO deleted_at / soft delete.
CREATE TABLE audit_log (
    log_id       BIGSERIAL PRIMARY KEY,
    entity_type  VARCHAR(50) NOT NULL,
    entity_id    VARCHAR(50) NOT NULL,
    action       VARCHAR(30) NOT NULL,
    actor_email  VARCHAR(255) REFERENCES app_user(email),
    before_data  JSONB,
    after_data   JSONB,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_audit_entity ON audit_log(entity_type, entity_id);
CREATE INDEX idx_audit_actor ON audit_log(actor_email);

-- ============================================================
-- 8. SOFT DELETE FUNCTIONS
-- ============================================================

CREATE OR REPLACE FUNCTION soft_delete(
    p_table      TEXT,
    p_pk_column  TEXT,
    p_pk_value   TEXT
) RETURNS BOOLEAN
LANGUAGE plpgsql
AS $fn_soft_delete$
DECLARE
    affected INT;
BEGIN
    -- Guard: fail with a clear message if p_table has no deleted_at column
    -- (e.g. audit_log, which is intentionally append-only/immutable) instead
    -- of letting Postgres raise an opaque "column deleted_at does not exist".
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = current_schema()
          AND table_name = p_table
          AND column_name = 'deleted_at'
    ) THEN
        RAISE EXCEPTION 'soft_delete(): table "%" has no deleted_at column and does not support soft delete (it may be an intentionally immutable table, e.g. audit_log)', p_table;
    END IF;

    EXECUTE format(
        'UPDATE %I SET deleted_at = now() WHERE %I::text = $1 AND deleted_at IS NULL',
        p_table, p_pk_column
    ) USING p_pk_value;
    GET DIAGNOSTICS affected = ROW_COUNT;
    RETURN affected > 0;
END;
$fn_soft_delete$;

CREATE OR REPLACE FUNCTION restore_record(
    p_table      TEXT,
    p_pk_column  TEXT,
    p_pk_value   TEXT
) RETURNS BOOLEAN
LANGUAGE plpgsql
AS $fn_restore_record$
DECLARE
    affected INT;
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = current_schema()
          AND table_name = p_table
          AND column_name = 'deleted_at'
    ) THEN
        RAISE EXCEPTION 'restore_record(): table "%" has no deleted_at column and does not support soft delete/restore (it may be an intentionally immutable table, e.g. audit_log)', p_table;
    END IF;

    EXECUTE format(
        'UPDATE %I SET deleted_at = NULL WHERE %I::text = $1 AND deleted_at IS NOT NULL',
        p_table, p_pk_column
    ) USING p_pk_value;
    GET DIAGNOSTICS affected = ROW_COUNT;
    RETURN affected > 0;
END;
$fn_restore_record$;

CREATE OR REPLACE FUNCTION cascade_soft_delete_loan_application()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $fn_cascade_loan$
BEGIN
    IF NEW.deleted_at IS NOT NULL AND OLD.deleted_at IS NULL THEN
        UPDATE application_document        SET deleted_at = NEW.deleted_at WHERE app_id = NEW.app_id AND deleted_at IS NULL;
        UPDATE legal_verification          SET deleted_at = NEW.deleted_at WHERE app_id = NEW.app_id AND deleted_at IS NULL;
        UPDATE legal_checklist_item        SET deleted_at = NEW.deleted_at WHERE app_id = NEW.app_id AND deleted_at IS NULL;
        UPDATE bank_office_decision        SET deleted_at = NEW.deleted_at WHERE app_id = NEW.app_id AND deleted_at IS NULL;
        UPDATE disbursement                SET deleted_at = NEW.deleted_at WHERE app_id = NEW.app_id AND deleted_at IS NULL;
        UPDATE insurance_policy            SET deleted_at = NEW.deleted_at WHERE app_id = NEW.app_id AND deleted_at IS NULL;
        UPDATE emi_installment             SET deleted_at = NEW.deleted_at WHERE app_id = NEW.app_id AND deleted_at IS NULL;
        UPDATE service_request             SET deleted_at = NEW.deleted_at WHERE app_id = NEW.app_id AND deleted_at IS NULL;
        UPDATE post_disbursement_document  SET deleted_at = NEW.deleted_at WHERE app_id = NEW.app_id AND deleted_at IS NULL;
        UPDATE auction_case                SET deleted_at = NEW.deleted_at WHERE app_id = NEW.app_id AND deleted_at IS NULL;
        UPDATE legal_notice                SET deleted_at = NEW.deleted_at WHERE app_id = NEW.app_id AND deleted_at IS NULL;
    END IF;
    RETURN NEW;
END;
$fn_cascade_loan$;

CREATE TRIGGER trg_cascade_soft_delete_loan_application
AFTER UPDATE OF deleted_at ON loan_application
FOR EACH ROW
EXECUTE FUNCTION cascade_soft_delete_loan_application();

CREATE OR REPLACE FUNCTION cascade_soft_delete_auction_case()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $fn_cascade_auction$
BEGIN
    IF NEW.deleted_at IS NOT NULL AND OLD.deleted_at IS NULL THEN
        UPDATE auction_note SET deleted_at = NEW.deleted_at WHERE app_id = NEW.app_id AND deleted_at IS NULL;
        UPDATE bid          SET deleted_at = NEW.deleted_at WHERE app_id = NEW.app_id AND deleted_at IS NULL;
    END IF;
    RETURN NEW;
END;
$fn_cascade_auction$;

CREATE TRIGGER trg_cascade_soft_delete_auction_case
AFTER UPDATE OF deleted_at ON auction_case
FOR EACH ROW
EXECUTE FUNCTION cascade_soft_delete_auction_case();

-- ============================================================
-- 9. CONVENIENCE VIEWS FOR ACTIVE (NON-DELETED) RECORDS
-- (completed - the source file was truncated after
--  v_active_loan_product. Every remaining deleted_at-bearing
--  table now has a matching view)
-- ============================================================

CREATE VIEW v_active_app_user AS
    SELECT * FROM app_user WHERE deleted_at IS NULL;

CREATE VIEW v_active_loan_product AS
    SELECT * FROM loan_product WHERE deleted_at IS NULL;

CREATE VIEW v_active_customer_employment_profile AS
    SELECT * FROM customer_employment_profile WHERE deleted_at IS NULL;

CREATE VIEW v_active_loan_application AS
    SELECT * FROM loan_application WHERE deleted_at IS NULL;

CREATE VIEW v_active_application_document AS
    SELECT * FROM application_document WHERE deleted_at IS NULL;

CREATE VIEW v_active_legal_verification AS
    SELECT * FROM legal_verification WHERE deleted_at IS NULL;

CREATE VIEW v_active_legal_checklist_item AS
    SELECT * FROM legal_checklist_item WHERE deleted_at IS NULL;

CREATE VIEW v_active_bank_office_decision AS
    SELECT * FROM bank_office_decision WHERE deleted_at IS NULL;

CREATE VIEW v_active_disbursement AS
    SELECT * FROM disbursement WHERE deleted_at IS NULL;

CREATE VIEW v_active_insurance_policy AS
    SELECT * FROM insurance_policy WHERE deleted_at IS NULL;

CREATE VIEW v_active_emi_installment AS
    SELECT * FROM emi_installment WHERE deleted_at IS NULL;

CREATE VIEW v_active_service_request AS
    SELECT * FROM service_request WHERE deleted_at IS NULL;

CREATE VIEW v_active_post_disbursement_document AS
    SELECT * FROM post_disbursement_document WHERE deleted_at IS NULL;

CREATE VIEW v_active_auction_case AS
    SELECT * FROM auction_case WHERE deleted_at IS NULL;

CREATE VIEW v_active_auction_note AS
    SELECT * FROM auction_note WHERE deleted_at IS NULL;

CREATE VIEW v_active_legal_notice AS
    SELECT * FROM legal_notice WHERE deleted_at IS NULL;

CREATE VIEW v_active_bid AS
    SELECT * FROM bid WHERE deleted_at IS NULL;

CREATE VIEW v_active_notification AS
    SELECT * FROM notification WHERE deleted_at IS NULL;

CREATE VIEW v_active_otp_verification AS
    SELECT * FROM otp_verification WHERE deleted_at IS NULL;

CREATE VIEW v_active_eligibility_assessment AS
    SELECT * FROM eligibility_assessment WHERE deleted_at IS NULL;
