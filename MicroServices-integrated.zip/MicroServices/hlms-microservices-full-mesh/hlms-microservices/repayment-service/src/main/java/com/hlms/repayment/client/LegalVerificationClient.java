package com.hlms.repayment.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Calls legal-service's internal (service-to-service) endpoint. Checks legal-verification status from legal-service for an appId this service already holds.
 * "legal-service" is resolved via Eureka; see FeignClientConfig for the
 * internal API key header that authenticates this call.
 */
@FeignClient(
	    name = "legal-service",
	    contextId = "legalVerificationClient"
	)
public interface LegalVerificationClient {

    @GetMapping("/internal/legal-verifications/application/{appId}/status")
    LegalStatusResponse getStatus(@PathVariable("appId") String appId);
}
