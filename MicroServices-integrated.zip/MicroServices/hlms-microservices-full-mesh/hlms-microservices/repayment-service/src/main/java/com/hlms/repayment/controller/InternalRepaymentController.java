package com.hlms.repayment.controller;

import com.hlms.repayment.entity.EmiInstallment;
import com.hlms.repayment.repository.EmiInstallmentRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Service-to-service endpoint (not for end users): other microservices call this
 * to check repayment health for an application - e.g. legal-service confirming a
 * default before generating a notice, notification-service composing a reminder,
 * loan-service showing repayment progress on a status screen. Protected by
 * InternalApiKeyFilter instead of the normal JWT filter - see SecurityConfig.
 */
@RestController
@RequestMapping("/internal/repayment")
public class InternalRepaymentController {

    private final EmiInstallmentRepository repository;

    public InternalRepaymentController(EmiInstallmentRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/application/{appId}/summary")
    public RepaymentSummaryResponse getSummary(@PathVariable String appId) {
        List<EmiInstallment> installments = repository.findByAppIdAndDeletedAtIsNullOrderByInstallmentNoAsc(appId);
        long paid = installments.stream().filter(i -> "Paid".equalsIgnoreCase(i.getStatus())).count();
        long overdue = installments.stream().filter(i -> "Overdue".equalsIgnoreCase(i.getStatus())).count();
        return new RepaymentSummaryResponse(appId, installments.size(), (int) paid, (int) overdue, overdue > 0);
    }

    public record RepaymentSummaryResponse(String appId, int totalInstallments, int paidInstallments,
                                            int overdueInstallments, boolean inDefault) { }
}
