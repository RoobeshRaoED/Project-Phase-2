package com.hlms.repayment.entity;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
@Entity
@Table(name = "emi_installment", uniqueConstraints = @UniqueConstraint(columnNames = {"app_id", "installment_no"}))
public class EmiInstallment {
    @Id
    @Column(name = "installment_id", length = 50)
    private String installmentId;
    @Column(name = "app_id", nullable = false)
    private String appId;
    @Column(name = "installment_no", nullable = false)
    private Integer installmentNo;
    @Column(name = "due_date", nullable = false)
    private LocalDate dueDate;
    @Column(name = "emi_amount", precision = 14, scale = 2, nullable = false)
    private BigDecimal emiAmount;
    @Column(name = "principal_component", precision = 14, scale = 2)
    private BigDecimal principalComponent;
    @Column(name = "interest_component", precision = 14, scale = 2)
    private BigDecimal interestComponent;
    @Column(name = "closing_balance", precision = 14, scale = 2)
    private BigDecimal closingBalance;
    @Column(name = "status", length = 30, nullable = false)
    private String status = "Due"; // Due, Paid, Overdue
    @Column(name = "paid_date")
    private LocalDate paidDate;
    @Column(name = "deleted_at")
    private OffsetDateTime deletedAt;

    public EmiInstallment() {
    }

    public EmiInstallment(String installmentId, String appId, Integer installmentNo, LocalDate dueDate, BigDecimal emiAmount, BigDecimal principalComponent, BigDecimal interestComponent, BigDecimal closingBalance, String status, LocalDate paidDate, OffsetDateTime deletedAt) {
        this.installmentId = installmentId;
        this.appId = appId;
        this.installmentNo = installmentNo;
        this.dueDate = dueDate;
        this.emiAmount = emiAmount;
        this.principalComponent = principalComponent;
        this.interestComponent = interestComponent;
        this.closingBalance = closingBalance;
        this.status = status;
        this.paidDate = paidDate;
        this.deletedAt = deletedAt;
    }

    public String getInstallmentId() {
        return installmentId;
    }
    public void setInstallmentId(String installmentId) {
        this.installmentId = installmentId;
    }
    public String getAppId() {
        return appId;
    }
    public void setAppId(String appId) {
        this.appId = appId;
    }
    public Integer getInstallmentNo() {
        return installmentNo;
    }
    public void setInstallmentNo(Integer installmentNo) {
        this.installmentNo = installmentNo;
    }
    public LocalDate getDueDate() {
        return dueDate;
    }
    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }
    public BigDecimal getEmiAmount() {
        return emiAmount;
    }
    public void setEmiAmount(BigDecimal emiAmount) {
        this.emiAmount = emiAmount;
    }
    public BigDecimal getPrincipalComponent() {
        return principalComponent;
    }
    public void setPrincipalComponent(BigDecimal principalComponent) {
        this.principalComponent = principalComponent;
    }
    public BigDecimal getInterestComponent() {
        return interestComponent;
    }
    public void setInterestComponent(BigDecimal interestComponent) {
        this.interestComponent = interestComponent;
    }
    public BigDecimal getClosingBalance() {
        return closingBalance;
    }
    public void setClosingBalance(BigDecimal closingBalance) {
        this.closingBalance = closingBalance;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public LocalDate getPaidDate() {
        return paidDate;
    }
    public void setPaidDate(LocalDate paidDate) {
        this.paidDate = paidDate;
    }
    public OffsetDateTime getDeletedAt() {
        return deletedAt;
    }
    public void setDeletedAt(OffsetDateTime deletedAt) {
        this.deletedAt = deletedAt;
    }

    public static Builder builder() {
        return new Builder();
    }
    public static class Builder {
        private String installmentId;
        private String appId;
        private Integer installmentNo;
        private LocalDate dueDate;
        private BigDecimal emiAmount;
        private BigDecimal principalComponent;
        private BigDecimal interestComponent;
        private BigDecimal closingBalance;
        private String status = "Due";
        private LocalDate paidDate;
        private OffsetDateTime deletedAt;

        public Builder installmentId(String installmentId) {
            this.installmentId = installmentId;
            return this;
        }
        public Builder appId(String appId) {
            this.appId = appId;
            return this;
        }
        public Builder installmentNo(Integer installmentNo) {
            this.installmentNo = installmentNo;
            return this;
        }
        public Builder dueDate(LocalDate dueDate) {
            this.dueDate = dueDate;
            return this;
        }
        public Builder emiAmount(BigDecimal emiAmount) {
            this.emiAmount = emiAmount;
            return this;
        }
        public Builder principalComponent(BigDecimal principalComponent) {
            this.principalComponent = principalComponent;
            return this;
        }
        public Builder interestComponent(BigDecimal interestComponent) {
            this.interestComponent = interestComponent;
            return this;
        }
        public Builder closingBalance(BigDecimal closingBalance) {
            this.closingBalance = closingBalance;
            return this;
        }
        public Builder status(String status) {
            this.status = status;
            return this;
        }
        public Builder paidDate(LocalDate paidDate) {
            this.paidDate = paidDate;
            return this;
        }
        public Builder deletedAt(OffsetDateTime deletedAt) {
            this.deletedAt = deletedAt;
            return this;
        }

        public EmiInstallment build() {
            return new EmiInstallment(installmentId, appId, installmentNo, dueDate, emiAmount, principalComponent, interestComponent, closingBalance, status, paidDate, deletedAt);
        }
    }
}