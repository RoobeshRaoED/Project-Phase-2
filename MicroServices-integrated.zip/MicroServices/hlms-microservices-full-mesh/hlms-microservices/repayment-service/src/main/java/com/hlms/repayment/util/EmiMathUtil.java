package com.hlms.repayment.util;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Small self-contained EMI math helper, split out of the monolith's EligibilityService
 * so repayment-service doesn't need a network dependency on loan-service just for a
 * pure calculation (reduced-interest formula, no DB access).
 */
public final class EmiMathUtil {

    private EmiMathUtil() { }

    public static BigDecimal emiForLoan(BigDecimal principal, BigDecimal annualRatePercent, int tenureYears) {
        if (principal == null || principal.signum() <= 0) return BigDecimal.ZERO;
        double p = principal.doubleValue();
        double r = annualRatePercent.doubleValue() / 12.0 / 100.0;
        int n = tenureYears * 12;
        if (r == 0) return principal.divide(BigDecimal.valueOf(n), 2, RoundingMode.HALF_UP);
        double emi = p * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1);
        return BigDecimal.valueOf(emi).setScale(2, RoundingMode.HALF_UP);
    }
}
