package com.hlms.repayment.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

/** Turns on Spring's @Scheduled support, used by ReminderSchedulerService
 *  for US-NM-04 (reminders), US-DMNG-01 (overdue sweep), US-DMNG-04/05 (escalation). */
@Configuration
@EnableScheduling
public class SchedulingConfig {
}
