package com.hlms.repayment.repository;

import com.hlms.repayment.entity.InsurancePolicy;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface InsurancePolicyRepository extends JpaRepository<InsurancePolicy, String> {
    List<InsurancePolicy> findByAppIdAndDeletedAtIsNull(String appId);
}
