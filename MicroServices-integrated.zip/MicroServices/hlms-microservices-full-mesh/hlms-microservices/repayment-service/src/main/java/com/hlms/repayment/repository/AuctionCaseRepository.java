package com.hlms.repayment.repository;

import com.hlms.repayment.entity.AuctionCase;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface AuctionCaseRepository extends JpaRepository<AuctionCase, Long> {
    Optional<AuctionCase> findByAppIdAndDeletedAtIsNull(String appId);
    List<AuctionCase> findByStageAndDeletedAtIsNull(String stage);
}
