package com.hlms.notification.client;

/** Response/request shape for user-service's internal endpoint. */
public record UserSummaryResponse(String email, String name, String mobile, String role, Boolean active) { }
