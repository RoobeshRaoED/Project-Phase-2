package com.hlms.UserServices.Config;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Guards this service's /internal/** endpoints, which are called by other
 * microservices (not end users) and therefore skip normal JWT auth. Requests
 * to /internal/** must carry a matching X-Internal-Api-Key header, shared
 * across every HLMS service (see application.properties -
 * hlms.internal.api-key); anything else on that path is rejected with 403
 * before it reaches the controller.
 *
 * Deliberately NOT wired into JwtSecurityConfig (which stays untouched, as
 * required): registered as a plain servlet Filter bean, so Spring Boot adds
 * it to the filter chain automatically, ahead of the controller layer,
 * regardless of what JwtSecurityConfig's SecurityFilterChain does.
 */
@Component
public class InternalApiKeyFilter extends OncePerRequestFilter {

    @Value("${hlms.internal.api-key}")
    private String expectedKey;

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                     @NonNull HttpServletResponse response,
                                     @NonNull FilterChain filterChain) throws ServletException, IOException {
        if (request.getRequestURI().startsWith("/internal/")) {
            String provided = request.getHeader("X-Internal-Api-Key");
            if (provided == null || !provided.equals(expectedKey)) {
                response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                response.getWriter().write("Forbidden: missing or invalid internal API key");
                return;
            }
        }
        filterChain.doFilter(request, response);
    }
}
