package com.hlms.UserServices.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hlms.UserServices.Dto.UserSummaryResponse;
import com.hlms.UserServices.Entity.appUserEntity;
import com.hlms.UserServices.Service.appUserService;

/**
 * Service-to-service endpoint (not for end users): every other HLMS
 * microservice's Feign UserClient calls this to resolve basic user identity
 * (name, mobile, role, active flag) for an email it already holds. Protected
 * by InternalApiKeyFilter instead of normal JWT auth - see that class and
 * application.properties (hlms.internal.api-key).
 *
 * This is a new, additive controller. It reuses the existing, unmodified
 * appUserService.getUserByEmail(...) - the same read path
 * appUserController's own GET /api/users/{email} already uses - so no
 * business logic, repository, or service code changes were required.
 */
@RestController
@RequestMapping("/internal/users")
public class internalUserController {

    private final appUserService appUserService;

    public internalUserController(appUserService appUserService) {
        this.appUserService = appUserService;
    }

    @GetMapping("/{email}")
    public UserSummaryResponse getUser(@PathVariable("email") String email) {

        appUserEntity user = appUserService.getUserByEmail(email);

        return new UserSummaryResponse(
                user.getEmail(),
                user.getName(),
                user.getMobile(),
                user.getRole() != null ? user.getRole().name() : null,
                user.getActive());
    }
}
