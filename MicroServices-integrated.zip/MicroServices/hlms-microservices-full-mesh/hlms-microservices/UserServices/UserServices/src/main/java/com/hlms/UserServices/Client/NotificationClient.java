package com.hlms.UserServices.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Calls notification-service's internal (service-to-service) endpoint.
 * "notification-service" is resolved via Eureka; see FeignClientConfig for
 * the internal API key header that authenticates this call.
 *
 * Scaffold only: not called from any existing business logic in this
 * service. otpVerificationServiceImplementation currently generates/stores
 * OTPs itself and is left exactly as-is, per the locked-module requirement.
 * Wiring actual OTP delivery through this client is a business-logic change
 * and is intentionally left for a separate, explicit change request.
 */
@FeignClient(name = "notification-service", configuration = FeignClientConfig.class)
public interface NotificationClient {

    @PostMapping("/internal/notifications")
    void send(@RequestBody NotificationRequest request);
}
