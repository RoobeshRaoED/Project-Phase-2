package com.hlms.UserServices.Service;

import com.hlms.UserServices.Dto.LoginRequestDTO;
import com.hlms.UserServices.Dto.LoginResponseDTO;
import com.hlms.UserServices.Dto.RegisterRequestDTO;
import com.hlms.UserServices.Entity.appUserEntity;

public interface appUserService {

    appUserEntity registerUser(
            RegisterRequestDTO request);

    LoginResponseDTO login(
            LoginRequestDTO request);

    appUserEntity getUserByEmail(
            String email);

    appUserEntity updateUser(
            String email,
            appUserEntity user);

    void deleteUser(
            String email);

    String forgotPassword(
            String email);

    String resetPassword(
            String email,
            String otpCode,
            String newPassword);
}