package com.hlms.UserServices.Dto;

/**
 * Response shape for the /internal/users/{email} endpoint. Deliberately
 * mirrors the identical record already defined in every other service's
 * client package (loan-service, document-service, legal-service,
 * repayment-service, notification-service) so their existing Feign
 * UserClient interfaces deserialize this response without any change on
 * their side.
 */
public record UserSummaryResponse(String email, String name, String mobile, String role, Boolean active) { }
