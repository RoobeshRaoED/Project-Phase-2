package com.hlms.UserServices.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.hlms.UserServices.Dto.OtpGenerateRequestDTO;
import com.hlms.UserServices.Dto.OtpVerifyRequestDTO;
import com.hlms.UserServices.Service.otpVerificationService;

@RestController
@RequestMapping("/api/otp")
public class otpVerificationController {

    @Autowired
    private otpVerificationService service;

    @PostMapping("/generate")
    public ResponseEntity<String> generateOtp(
            @RequestBody
            OtpGenerateRequestDTO request) {

        return ResponseEntity.ok(
                service.generateOtp(
                        request.getEmail(),
                        request.getPurpose()));
    }

    @PostMapping("/verify")
    public ResponseEntity<String> verifyOtp(
            @RequestBody
            OtpVerifyRequestDTO request) {

        return ResponseEntity.ok(
                service.verifyOtp(
                        request.getEmail(),
                        request.getOtpCode()));
    }
}