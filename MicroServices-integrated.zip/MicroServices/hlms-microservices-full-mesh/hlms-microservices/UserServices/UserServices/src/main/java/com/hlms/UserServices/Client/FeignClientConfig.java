package com.hlms.UserServices.Client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import feign.RequestInterceptor;

/**
 * Attaches the shared internal API key to every outgoing Feign call so the
 * callee service's /internal/** endpoints (which skip normal JWT auth) can
 * verify the caller is a trusted internal service and not a public client.
 * Same pattern as FeignClientConfig in loan-service/legal-service/etc.
 */
@Configuration
public class FeignClientConfig {

    @Value("${hlms.internal.api-key}")
    private String internalApiKey;

    @Bean
    public RequestInterceptor internalApiKeyInterceptor() {
        return requestTemplate -> requestTemplate.header("X-Internal-Api-Key", internalApiKey);
    }
}
