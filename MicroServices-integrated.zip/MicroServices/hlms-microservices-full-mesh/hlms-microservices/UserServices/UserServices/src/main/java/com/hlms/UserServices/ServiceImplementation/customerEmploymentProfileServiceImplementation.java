package com.hlms.UserServices.ServiceImplementation;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hlms.UserServices.Entity.customerEmploymentProfileEntity;
import com.hlms.UserServices.Exception.DuplicateRecordException;
import com.hlms.UserServices.Exception.ResourceNotFoundException;
import com.hlms.UserServices.Repository.customerEmploymentProfileRepository;
import com.hlms.UserServices.Service.customerEmploymentProfileService;

@Service
public class customerEmploymentProfileServiceImplementation
        implements customerEmploymentProfileService {

    @Autowired
    private customerEmploymentProfileRepository repository;

    @Override
    @Transactional
    public customerEmploymentProfileEntity createProfile(
            customerEmploymentProfileEntity profile) {

        if (repository.existsByUserEmail(
                profile.getUserEmail())) {

            throw new DuplicateRecordException(
                    "Profile already exists");
        }

        return repository.save(profile);
    }

    @Override
    @Transactional(readOnly = true)
    public customerEmploymentProfileEntity getProfile(
            String userEmail) {

        return repository
                .findByUserEmailAndDeletedAtIsNull(userEmail)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Customer Profile Not Found"));
    }

    @Override
    @Transactional(readOnly = true)
    public List<customerEmploymentProfileEntity>
    getAllProfiles() {

        return repository.findAll();
    }

    @Override
    @Transactional
    public customerEmploymentProfileEntity updateProfile(
            String userEmail,
            customerEmploymentProfileEntity profile) {

        customerEmploymentProfileEntity existing =
                getProfile(userEmail);

        existing.setEmploymentType(
                profile.getEmploymentType());

        existing.setEmployer(
                profile.getEmployer());

        existing.setMonthlyIncome(
                profile.getMonthlyIncome());

        existing.setOtherEmis(
                profile.getOtherEmis());

        existing.setDesiredAmount(
                profile.getDesiredAmount());

        existing.setPan(
                profile.getPan());

        return repository.save(existing);
    }

    @Override
    @Transactional
    public void deleteProfile(
            String userEmail) {

        customerEmploymentProfileEntity profile =
                getProfile(userEmail);

        profile.setDeletedAt(
                LocalDateTime.now());

        repository.save(profile);
    }
}
