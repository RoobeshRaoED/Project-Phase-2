package com.hlms.legal.controller;
import com.hlms.legal.entity.LegalChecklistItem;
import com.hlms.legal.entity.LegalVerification;
import com.hlms.legal.service.LegalService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;
/** Legal verification stage (checklist + info requests + decisions). */
@RestController
@RequestMapping("/api/legal")
@PreAuthorize("hasAnyRole('LEGAL','ADMIN')")
public class LegalController {
    private final LegalService service;
    @GetMapping("/{appId}/verification")
    public LegalVerification getVerification(@PathVariable String appId) {
        return service.getVerification(appId);
    }
    @GetMapping("/{appId}/checklist")
    public List<LegalChecklistItem> getChecklist(@PathVariable String appId) {
        return service.getChecklist(appId);
    }
    @PostMapping("/{appId}/decision")
    public LegalVerification recordDecision(@PathVariable String appId, @RequestBody Map<String, String> body) {
        return service.recordDecision(appId, body.get("decision"), body.get("officer"), body.get("remarks"));
    }
    @PostMapping("/{appId}/request-info")
    public LegalVerification requestInfo(@PathVariable String appId, @RequestBody Map<String, String> body) {
        return service.requestInfo(appId, body.get("details"));
    }
    @PutMapping("/{appId}/checklist/{checklistKey}")
    public LegalChecklistItem upsertChecklistItem(@PathVariable String appId, @PathVariable String checklistKey,
                                                   @RequestBody Map<String, String> body) {
        return service.upsertChecklistItem(appId, checklistKey, body.get("status"));
    }

    public LegalController(LegalService service) {
        this.service = service;
    }
}