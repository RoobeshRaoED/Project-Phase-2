package com.hlms.legal.controller;
import com.hlms.legal.entity.LegalNotice;
import com.hlms.legal.service.LegalNoticeService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.time.LocalDate;
import java.util.Map;
/**
 * Service-to-service endpoint (not for end users): repayment-service's automated
 * default-escalation sweep calls this to generate a legal notice for "system",
 * a flow with no logged-in bank officer/JWT. Protected by InternalApiKeyFilter
 * instead of the normal JWT filter - see SecurityConfig.
 */
@RestController
@RequestMapping("/internal/legal-notices")
public class InternalLegalNoticeController {
    private final LegalNoticeService service;
    @PostMapping
    public LegalNotice generate(@RequestBody Map<String, String> body) {
        LocalDate dueDate = body.get("dueDate") != null ? LocalDate.parse(body.get("dueDate")) : null;
        return service.generateNotice(body.get("appId"), body.get("noticeType"), body.get("officer"),
                body.get("content"), dueDate);
    }

    public InternalLegalNoticeController(LegalNoticeService service) {
        this.service = service;
    }
}