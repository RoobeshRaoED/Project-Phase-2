package com.hlms.legal.client;

/** Response/request shape for document-service's internal endpoint. */
public record DocumentStatusResponse(String appId, int totalDocuments, int verifiedDocuments, int rejectedDocuments, boolean allVerified) { }
