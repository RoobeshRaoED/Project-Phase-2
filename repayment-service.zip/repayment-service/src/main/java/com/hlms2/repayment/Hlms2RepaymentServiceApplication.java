package com.hlms2.repayment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hlms2RepaymentServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(Hlms2RepaymentServiceApplication.class, args);
    }
}
