/**
 * Mirrors user-service's `roleEnum`
 * (hlms-microservices/user-service/.../Enum/roleEnum.java):
 *   CUSTOMER, LEGAL, BANK_OFFICER, BIDDER, ADMIN
 *
 * NOTE: the old UI also has an 'employee' staff role (generic back-office
 * employee, distinct from Legal/Bank Office). The backend enum has NO
 * matching value for it — see README "Missing / Broken Endpoints" #4.
 * It is kept here as 'EMPLOYEE' so the Employee Management screen still
 * renders correctly; calls involving it will fail against the current
 * backend until the enum is extended.
 */
export type BackendRole = 'ADMIN' | 'LEGAL' | 'BANK_OFFICER' | 'BIDDER' | 'CUSTOMER';
export type UiRole = BackendRole | 'EMPLOYEE';

export const ROLE_LABELS: Record<UiRole, string> = {
  ADMIN: 'Admin',
  EMPLOYEE: 'Employee',
  LEGAL: 'Legal Team',
  BANK_OFFICER: 'Bank Office',
  CUSTOMER: 'Customer',
  BIDDER: 'Bidder'
};

/**
 * Sub-role used only for BANK_OFFICER staff accounts (mirrors
 * user-service's staffRoleEnum). Not applicable to any other role.
 */
export type StaffRole = 'LOAN_OFFICER' | 'MANAGER';

export const STAFF_ROLE_LABELS: Record<StaffRole, string> = {
  LOAN_OFFICER: 'Loan Officer',
  MANAGER: 'Manager'
};

export interface AppUser {
  email: string;
  name: string;
  mobile: string;
  role: UiRole;
  staffRole?: StaffRole | null;
  active: boolean;
  idType?: string;
  idNumber?: string;
  prefSms?: boolean;
  prefEmail?: boolean;
  prefInapp?: boolean;
  createdAt?: string;
}

export interface RegisterRequest {
  email: string;
  name: string;
  mobile: string;
  password: string;
  role: UiRole;
  staffRole?: StaffRole | null;
  idType?: string;
  idNumber?: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  token: string;
}

export interface JwtPayload {
  sub: string;
  role: BackendRole;
  iat: number;
  exp: number;
}
