import { Component, EventEmitter, Input, OnInit, Output, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  AbstractControl,
  FormBuilder,
  ReactiveFormsModule,
  ValidatorFn,
  Validators
} from '@angular/forms';

import { UserService } from '../../../core/services/user.service';
import { ToastService } from '../../../shared/toast/toast.service';
import { ROLE_LABELS, STAFF_ROLE_LABELS, StaffRole, UiRole } from '../../../core/models/user.model';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MOBILE_RE = /^[6-9]\d{9}$/;
const PASSWORD_RE = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_\-+=]).{8,}$/;

function matchOther(otherControlName: string): ValidatorFn {
  return (control: AbstractControl) => {
    const parent = control.parent;

    if (!parent) {
      return null;
    }

    const other = parent.get(otherControlName);

    if (!other) {
      return null;
    }

    return control.value !== other.value ? { mismatch: true } : null;
  };
}

@Component({
  selector: 'app-add-staff-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './add-staff-modal.component.html'
})
export class AddStaffModalComponent implements OnInit {
  @Input({ required: true }) role!: UiRole;

  @Output() close = new EventEmitter<void>();
  @Output() created = new EventEmitter<void>();

  private fb = inject(FormBuilder);
  private userService = inject(UserService);
  private toast = inject(ToastService);

  roleLabels = ROLE_LABELS;
  staffRoleLabels = STAFF_ROLE_LABELS;
  staffRoleOptions: StaffRole[] = ['LOAN_OFFICER', 'MANAGER'];
  submitting = false;

  form = this.fb.nonNullable.group({
    name: ['', [Validators.required, Validators.minLength(3)]],
    email: ['', [Validators.required, Validators.pattern(EMAIL_RE)]],
    mobile: ['', [Validators.required, Validators.pattern(MOBILE_RE)]],
    staffRole: [''],
    password: ['', [Validators.required, Validators.pattern(PASSWORD_RE)]],
    confirmPassword: ['', [Validators.required, matchOther('password')]]
  });

  get label(): string {
    return this.roleLabels[this.role] ?? this.role;
  }

  get isBankOffice(): boolean {
    return this.role === 'BANK_OFFICER';
  }

  ngOnInit(): void {
    if (this.isBankOffice) {
      this.form.controls.staffRole.setValidators([Validators.required]);
      this.form.controls.staffRole.updateValueAndValidity();
    }
  }

  submit(): void {
    if (this.role === 'BIDDER') {
      this.toast.error(
        'Action not allowed',
        'Admin cannot create bidder accounts from this screen.'
      );
      return;
    }

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const v = this.form.getRawValue();

    this.submitting = true;

    this.userService
      .register({
        name: v.name,
        email: v.email,
        mobile: v.mobile,
        password: v.password,
        role: this.role,
        staffRole: this.isBankOffice ? (v.staffRole as StaffRole) : null,
        idType: 'PAN',
        idNumber: ''
      })
      .subscribe({
        next: () => {
          this.submitting = false;

          this.toast.success(
            `${this.label} Added`,
            `${v.name} can now log in with the credentials provided.`
          );

          this.created.emit();
        },
        error: (err) => {
          this.submitting = false;

          this.toast.error(
            'Could not create account',
            err?.error?.message ||
              `The backend rejected this request. HTTP ${err?.status ?? '?'}`
          );
        }
      });
  }
}