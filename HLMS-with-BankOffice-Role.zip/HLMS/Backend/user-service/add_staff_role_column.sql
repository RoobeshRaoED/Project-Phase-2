-- Adds the staff_role column used to distinguish a Loan Officer from a
-- Manager within Bank Office staff accounts (app_user.role = 'BANK_OFFICER').
-- Hibernate (spring.jpa.hibernate.ddl-auto=update) will add this column
-- automatically the next time user-service starts, but run this manually
-- against Housing_Loan_db if you want it applied immediately or you run
-- with ddl-auto=validate/none in some environment.

ALTER TABLE app_user
  ADD COLUMN IF NOT EXISTS staff_role VARCHAR(20);

-- Allowed values enforced at the application layer (staffRoleEnum):
--   LOAN_OFFICER, MANAGER
-- Optionally enforce at the DB layer too:
-- ALTER TABLE app_user
--   ADD CONSTRAINT chk_staff_role CHECK (staff_role IN ('LOAN_OFFICER', 'MANAGER'));
