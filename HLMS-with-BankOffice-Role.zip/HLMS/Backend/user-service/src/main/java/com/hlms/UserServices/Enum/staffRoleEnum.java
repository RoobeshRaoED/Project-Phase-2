package com.hlms.UserServices.Enum;

/**
 * Sub-role used only for BANK_OFFICER staff accounts, distinguishing
 * a regular loan officer from a manager within the Bank Office team.
 */
public enum staffRoleEnum {

    LOAN_OFFICER,
    MANAGER
}
